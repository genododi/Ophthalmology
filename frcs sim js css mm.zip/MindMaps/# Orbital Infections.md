# Orbital Infections

## Orbital Cellulitis

- An ophthalmic and medical emergency requiring urgent assessment and treatment. (Emergency)
- May cause vision loss and even death.
- Requires combined care from Ophthalmology and ENT specialists.
- In young children with an undeveloped orbital septum, treat similarly to orbital cellulitis due to high progression risk.
- **Infective Organisms**: *Streptococcus pneumoniae*, *Staphylococcus aureus*, *Streptococcus pyogenes*, *Haemophilus influenzae*. (Pathogen)

### Risk Factors

- Sinus disease: ethmoidal sinusitis (common), maxillary sinusitis. (Risk Factor)
- Infection of adjacent structures: preseptal or facial infection, dacryocystitis, dental abscess. (Risk Factor)
- Trauma: septal perforation, retained foreign body. (Risk Factor)
- Surgical history: orbital, lacrimal, and vitreoretinal surgery. (Risk Factor)
- Endogenous spread in immunocompromised patients. (Risk Factor)

### Clinical Features

- **Systemic Symptoms**: Fever, malaise, and periocular pain.
- **Ocular Signs**:
  - Inflamed lids (swollen, red, tender, warm).
  - Chemosis and proptosis.
  - Painful, restricted eye movements and diplopia.
  - Lagophthalmos.
  - **Optic nerve dysfunction**: decreased visual acuity, decreased color vision, RAPD. (Critical Sign)
- **Complications**:
  - Exposure keratopathy, increased IOP, CRAO, CRVO.
  - Systemic spread: orbital abscess, cavernous sinus thrombosis, meningitis, cerebral abscess. (Critical Complication)

### Investigations

- - Temperature check.
- - FBC and blood culture (low yield).
- - **CT scan (orbit, sinuses, brain)** to identify abscess, infiltrate, proptosis, or sinus opacity. (Diagnosis)

### Treatment

- - Admit for IV antibiotics (e.g., `cefuroxime` or `ceftriaxone` + `metronidazole`). (Treatment)
- - Mark the extent of skin inflammation to monitor progression.
- - Regular review of orbital and visual functions.
- - ENT assessment for potential sinus drainage.
- - Repeat CT if deterioration occurs to check for abscess formation.

## Preseptal Cellulitis

- An infection of the eyelid and periorbital tissues anterior to the orbital septum; not a true orbital disease.
- Much more common than orbital cellulitis, especially in children (<10 years).
- **Causative Organisms**: *Staphylococci* and *Streptococci spp*. (Pathogen)

### Risk Factors

- Infection of adjacent structures (dacryocystitis, hordeolum). (Risk Factor)
- Systemic infections like URTI. (Risk Factor)
- Trauma such as a laceration. (Risk Factor)

### Clinical Features

- **Systemic Symptoms**: Fever, malaise.
- **Ocular Signs**:
  - Painful, swollen lid/periorbital area.
  - Inflamed lids **without** proptosis or restricted eye movements.
  - Conjunctiva remains white.
  - Normal optic nerve function.

### Investigations

- - Usually not necessary unless orbital or sinus involvement is suspected.

### Treatment

- - Daily review until resolution (admit young or unwell children).
- - Oral antibiotics (e.g., `flucloxacillin 500mg 4x/day`). (Treatment)

## Comparison: Orbital vs Preseptal Cellulitis

### Proptosis

- - **Orbital**: Present
- - **Preseptal**: Absent

### Ocular Motility

- - **Orbital**: Painful and restricted
- - **Preseptal**: Normal

### Visual Acuity (VA)

- - **Orbital**: Decreased in severe cases
- - **Preseptal**: Normal

### Color Vision

- - **Orbital**: Decreased in severe cases
- - **Preseptal**: Normal

### RAPD

- - **Orbital**: Present in severe cases
- - **Preseptal**: Absent

## Mucormycosis (Phycomycosis)

- A rare, aggressive, life-threatening fungal infection. (Emergency)
- Caused by *Mucor spp.* or *Rhizopus*. (Pathogen)
- Primarily affects immunosuppressed and acidotic patients (e.g., diabetic ketoacidosis, renal failure). (Risk Factor)
- Represents fungal septic necrosis and infarction of nasopharyngeal and orbital tissues.

### Clinical Features

- - **Black crusty material in the nasopharynx**. (Key Sign)
- - Acutely evolving cranial nerve palsies (III, IV, V, VI, IIn).
- - Obvious orbital inflammation.

### Investigations

- - **Biopsy with fungal stains**: shows non-septate branching hyphae. (Diagnosis)
- - Blood work: FBC, U+E, glucose.

### Treatment

- - Admit and coordinate multidisciplinary care (Microbiology, ENT, Physician).
- - Correct underlying disease (e.g., diabetic ketoacidosis) is critical. (Treatment)
- - IV antifungals (e.g., high-dose `amphotericin`). (Treatment)
- - Hyperbaric oxygen therapy may be considered.
- - Early, aggressive surgical debridement by ENT, potentially including orbital exenteration. (Treatment)

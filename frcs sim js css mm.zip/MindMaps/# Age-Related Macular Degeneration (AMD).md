# Age-Related Macular Degeneration (AMD)

## Overview

- Leading cause of blindness for individuals over 50 in the Western world.
- Prevalence significantly increases with age.

## Prevalence (by age)

- **55–65 years:** ~1% develop visually significant disease. (statistic)
- **65–75 years:** ~6% develop visually significant disease. (statistic)
- **>75 years:** ~20% develop visually significant disease. (statistic)

## Risk Factors

- **Smoking** (major risk factor)
- **Gender:** Females > Males
- **Ethnic Origin:** White Caucasian at high risk
- **Diet**
- **Cardiovascular (CVS) Risk Factors**
- **Hypermetropia**
- **Genetics** (risk factor)
  - Complement factor H (CFH) gene on Chr 1q32
  - ARMS2/HTRA1 locus on Chr 10q26
  - Other complement pathway-related genes
- *Note:* Recent evidence does not find cataract surgery to cause or worsen AMD.

## Non-neovascular (Dry) AMD

- Accounts for 90% of AMD cases.
- Leads to a gradual, but potentially significant, reduction in central vision.

### Histology (Pathology)

- Loss of RPE/photoreceptor layers and thinning of the outer plexiform layer.
- Thickening of Bruch’s membrane.
- Atrophy of the choriocapillaris.
- **Drusen:** Amorphous deposits between the RPE and Bruch’s membrane that may become calcified.

### Clinical Features & Signs

- **Symptoms:** Gradual onset of decreased visual acuity (dVA), metamorphopsia, and scotomas. (symptom)
- **Signs:** (diagnosis)
  - **Hard drusen:** Small (<63 microns), well-defined, limited significance.
  - **Soft drusen:** Larger, pale, poorly defined, can coalesce, and indicate an increased risk of CNV.
  - **RPE Changes:** Focal hyperpigmentation or geographic atrophy.

### Investigations (Diagnosis)

- **OCT (Optical Coherence Tomography):** Primary tool for screening and monitoring.
  - **Drusen:** Appears as discrete or dome-shaped RPE elevations.
  - **Reticular pseudodrusen:** Located above the RPE, a risk factor for advanced AMD.
  - **RPE Hyperpigmentation:** Seen as hyperreflective foci with underlying shadowing.
  - **Geographic Atrophy:** Appears as sharply demarcated choroidal hyperreflectivity due to RPE loss.
  - **Outer Retinal Tubulations:** Ovoid spaces indicating advanced atrophy.
- **FAF (Fundus Autofluorescence):** Clearly shows atrophic changes as areas of decreased autofluorescence.
- **FFA (Fluorescein Angiography):** Not usually necessary for dry AMD.

### Treatment & Management

- **Supportive Care:** Counseling, support groups, and social services. (treatment)
- **Refraction:** Low-vision aids and specialized clinics. (treatment)
- **Amsler Grid:** Home monitoring to detect new or worsening metamorphopsia. (monitoring)
- **Lifestyle Changes:** (treatment)
  - **Smoking cessation.**
  - Increased intake of macular carotenoids (spinach, cabbage) and omega-3 fatty acids (oily fish).
- **Vitamin Supplementation (AREDS/AREDS2):** (treatment)
  - High-dose antioxidants (Vitamins C, E), zinc, lutein, and zeaxanthin.
  - Delays progression from intermediate to advanced stages.
  - *Note:* β-carotene is avoided for smokers due to increased lung cancer risk.

## Neovascular (Wet) AMD

- Less common (~10% of cases) but causes rapid and severe vision loss.
- Accounts for up to 90% of blindness registration due to AMD.
- Anti-VEGF therapies have significantly improved outcomes.

### Histology (Pathology)

- New capillaries grow from the choriocapillaris through Bruch's membrane.
- **Type 1 Neovascularization:** Proliferation in the sub-RPE space (common in AMD).
- **Type 2 Neovascularization:** Proliferation in the subretinal space (common in younger patients).
- Associated with hemorrhage, exudation, and scar formation (disciform scar).

### AMD Variants (Pathology)

- **Retinal Angiomatous Proliferation (RAP) / Type 3:** Involves both retinal and choroidal circulation.
- **Polypoidal Choroidal Vasculopathy (PCV):** Polypoidal dilatation of choroidal vasculature; common in Asian or African descent.
- **Peripapillary CNV:** Lesions develop contiguous with the optic disc.

### Clinical Features & Signs

- **Symptoms:** Sudden onset of dVA, metamorphopsia, and scotoma. (symptom)
- **Signs:** (diagnosis)
  - Grey membrane under the retina.
  - Subretinal (red) or sub-RPE (grey) hemorrhage.
  - Retinal or pigment epithelial detachment (PED).
  - Subretinal fibrosis (disciform scar).
  - **RPE tears ('rips'):** Atrophy adjacent to rolled-up RPE.

### Investigations (Diagnosis)

- **Urgent FFA (Fluorescein Angiography):** Vital for diagnosis and treatment assessment.
- **ICG (Indocyanine Green Angiography):** Performed for suspected PCV.
- **OCT (Optical Coherence Tomography):** Central to detection and long-term monitoring.
  - **Signs of activity:** Intraretinal fluid, subretinal fluid, increased sub-RPE fluid.
- **OCTA (OCT Angiography):** Emerging tool for detecting CNV.

### Angiographic & OCT Findings (Diagnosis)

- **Type 1 ('Occult') CNV:**
  - **FFA:** Irregular elevation with stippled hyperfluorescence or late leakage of undetermined source.
  - **OCT:** Irregular, broad elevation of the RPE.
- **Type 2 ('Classic') CNV:**
  - **FFA:** Early, well-demarcated, lacy hyperfluorescence with progressive leakage.
  - **OCT:** Subretinal hyperreflective material (SHRM).
- **Type 3 ('RAP') CNV:**
  - **FFA:** Small area of classic CNV appearance.
  - **OCT:** Outer retinal hyperreflective foci with overlying CMO.
- **PCV:**
  - **ICG:** Early subretinal hyperfluorescence (polyps).
  - **OCT:** Sharp protuberances of the RPE (polyps) and large, dome-shaped PEDs. Choroid is often thickened.

### Treatment & Management

- **Anti-VEGF Therapies:** Intravitreal injections are the treatment of choice for all subfoveal CNV. (treatment)
- **Photodynamic Therapy (PDT):** An option if anti-VEGF is contraindicated or for combination therapy in PCV. (treatment)
- **Laser Photocoagulation:** May be used for extrafoveal or peripapillary CNV to avoid injections. (treatment)
- **Supportive Care:** Includes counseling, low-vision aids, Amsler grid, and lifestyle changes as in dry AMD. (treatment)

## AREDS Classification of AMD

- A system to categorize the severity and risk of progression. (classification)

- | Category | Clinical Findings |
  | :--- | :--- |
  | **1: No AMD** | None or a few small drusen (<63 microns). |
  | **2: Early AMD** | Multiple small drusen; few intermediate drusen (63–124 microns); RPE abnormalities. |
  | **3: Intermediate AMD** | Extensive intermediate drusen; at least one large drusen (≥125 microns); geographic atrophy not involving the fovea. |
  | **4: Advanced AMD** | Geographic atrophy involving the fovea or any features of neovascular AMD. |

## Calculating Risk of Developing Advanced AMD

- The AREDS study identified predictive factors for progression to advanced AMD. (risk assessment)
- A 0-4 point scale is used based on the presence of large drusen and pigment abnormalities.

- | Number of Risk Factors | 5-Year Risk of Advanced AMD |
  | :--- | :--- |
  | 0 | 0.5% |
  | 1 | 3% |
  | 2 | 12% |
  | 3 | 25% |
  | 4 | 50% |

## Common Causes of CNV (Non-AMD)

- | Category | Causes |
  | :--- | :--- |
  | **Degenerative** | Pathological myopia (lacquer crack), Angioid streaks |
  | **Trauma** | Choroidal rupture, Laser |
  | **Inflammation** | POHS, Multifocal choroiditis, Serpiginous choroidopathy, Birdshot retinochoroidopathy, PIC, VKH |
  | **Dystrophies** | Best’s disease |
  | **Other** | Chorioretinal scar (any cause), Tumour, Idiopathic |

# Choroidal Tumours

## Choroidal Haemangiomas

- General: Benign vascular hamartomas. (Pathology)
  - Though congenital, they are usually asymptomatic until adulthood when secondary degenerative changes of the overlying Retinal Pigment Epithelium (RPE) and retina, or the development of Subretinal Fluid (SRF), may cause visual loss.
  - Two clinical patterns are seen: circumscribed and diffuse.
- Histology: Comprise mainly cavernous vascular channels (with normal endothelial cells and supporting fibrous septa), but with some capillary-like vessels (especially in the diffuse form).

### Circumscribed Choroidal Haemangioma

- Nature: This form is isolated, may be asymptomatic, and has no systemic associations.
- Growth: Usually static but may grow in pregnancy.
- Clinical Features:
  - Poorly demarcated, elevated, orange-red choroidal mass. (Clinical Finding)
  - Typically 3–7mm in diameter, 1–3mm in thickness.
  - Located around the posterior pole (within 2 Disc Diameters of the optic disc or foveola).
  - Complications: Fibrous change of RPE, cystic change, or serous detachment of the retina. (Complication)
- Investigations:
  - Ultrasound (US): Very high internal reflectivity. (Diagnostic Test)
  - Fundus Fluorescein Angiography (FFA): Early hyperfluorescence of intralesional choroidal vessels, followed by hyperfluorescence of the whole lesion. (Diagnostic Test)
  - Indocyanine Green Angiography (ICG): Early cyanescence (hypofluorescence) of intralesional choroidal vessels, followed by intense cyanescence of the whole lesion and subsequent central fading. (Diagnostic Test)
- Treatment:
  - Specialist advice should be sought. (Management)
  - Options include:
    - Observation
    - Photodynamic Therapy (PDT) (Treatment Modality)
    - Transpupillary Thermotherapy (TTT) (Treatment Modality)
    - Irradiation (usually proton beam) (Treatment Modality)

### Diffuse Choroidal Haemangioma

- Association: This form is usually associated with other ocular and systemic abnormalities, forming part of the **Sturge–Weber syndrome**. (Systemic Association)
- Clinical Features:
  - Deep red (compared to the normal other eye), thickened choroid, particularly at the posterior pole. (Clinical Finding)
  - May have tortuous retinal vessels, fibrous change of RPE, cystic change, or serous detachment of the retina.
  - Complications: Subretinal fibrosis, cystic change or serous detachment of the retina, glaucoma. (Complication)
- Investigations:
  - Ultrasound (US): Diffuse choroidal thickening with high internal reflectivity. (Diagnostic Test)
  - MRI brain: If CNS haemangioma suspected as part of Sturge–Weber syndrome. (Diagnostic Test)
- Treatment:
  - Specialist advice should be sought. (Management)
  - Options include:
    - Photodynamic Therapy (PDT) (Treatment Modality)
    - Transpupillary Thermotherapy (TTT) (Treatment Modality)
    - Irradiation (Treatment Modality)
  - Liaise with the neurologist if cerebral involvement. (Management)

## Other Choroidal Tumours

### Choroidal Osteoma

- Definition: A rare benign tumour of the choroid, now considered an acquired neoplasm in which mature bone replaces the choroid, leading to damage of the overlying RPE and retina. (Pathology)
- Epidemiology: Typically seen in young adult women (female to male ratio 9:1); may be bilateral in 20%. (Epidemiology)
- Clinical Features:
  - Gradual decreased visual acuity (dVA) (less than 6/60 in 58% of cases by 10 years), metamorphopsia.
  - Yellow, well-defined geographic lesion, usually abutting or surrounding the optic disc. (Clinical Finding)
  - Superficial abnormalities include prominent inner choroidal vessels and irregular RPE changes.
  - Complications: Choroidal Neovascularization (CNV) (47% by 10 years, 56% by 20 years). (Complication)
- Investigations and Treatment:
  - Ultrasound (US): Highly reflective with acoustic shadow (pathognomonic). (Diagnostic Test)
  - CT scan: Bone-like signal from the posterior globe. (Diagnostic Test)
  - Fundus Fluorescein Angiography (FFA): Early mottled hyperfluorescence and late diffuse hyperfluorescence. (Diagnostic Test)
  - Treatment of the tumour itself is not indicated; CNV may be treated conventionally. (Management)

### Choroidal Metastases

- Definition: The commonest intraocular malignant neoplasms. (Pathology)
- Presentation:
  - Usually, patients are already known to have a primary tumour.
  - In about 25% of cases, the first clinical manifestation may be an ocular problem.
- Location:
  - The choroid is the commonest site.
  - Metastases may also occur in the iris, ciliary body (rare), retina, and vitreous (especially from cutaneous melanoma).
  - The optic nerve may be involved.
- Occurrence:
  - Multiple lesions are seen in 7-30% of cases.
  - Bilateral involvement is seen in about 30%.
- Clinical Features:
  - Decreased visual acuity (dVA), metamorphopsia; may be asymptomatic.
  - Typically a yellow-white (e.g., from breast, bronchus, bowel primaries), ill-defined lesion. (Clinical Finding)
  - Usually fairly flat but may have an associated Exudative Retinal Detachment (ERD).
  - Colour Variation (suggestive of primary): (Clinical Finding)
    - Black: Cutaneous malignant melanoma
    - Red-orange: Renal cell carcinoma or follicular thyroid carcinoma
    - Golden orange: Carcinoid
- Investigations:

  #### Ocular

  - Ultrasound (US): High internal reflectivity. (Diagnostic Test)
  - Fundus Fluorescein Angiography (FFA): No or few large vessels within the tumour, early hypofluorescence, and late diffuse hyperfluorescence. (Diagnostic Test)
  - Indocyanine Green Angiography (ICG): May show tumours not detected on FFA. (Diagnostic Test)
  - Fine Needle Aspiration (FNA): Consider if diagnostic uncertainty and no extraocular tissue available for biopsy. (Diagnostic Test)

    #### Systemic

  - Coordinated with a general physician or oncologist. (Management)
  - Includes a complete examination (e.g., breasts, prostate, lymph nodes, skin).
  - Selected investigations (e.g., Chest X-Ray (CXR), mammography).
- Treatment:
  - Depends on the lesion, the visual status of the eye, and the general health of the patient. (Management)
  - Options include:
    - Observation
    - Chemotherapy (Treatment Modality)
    - Radiotherapy (plaque, proton beam) (Treatment Modality)
    - Occasionally enucleation (Treatment Modality)

#### Common Primary Tumours Metastasizing to the Eye

    - Bronchus
    - Breast
    - Bowel
    - Kidney
    - Thyroid
    - Testis
    - Skin (cutaneous melanoma)

## Associated Syndromes Tables

### Table: Features of Sturge–Weber Syndrome

| Ocular                               | Extraocular                       |
|--------------------------------------|-----------------------------------|
| Episcleral haemangioma               | Naevus flammeus of the face (port-wine stain) |
| Ciliary body/iris haemangioma        | CNS haemangioma (leptomeningeal angioma) |
| Choroidal haemangioma (diffuse form) |                                   |
| Glaucoma                             |                                   |

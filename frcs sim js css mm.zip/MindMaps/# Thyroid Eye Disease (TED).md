# Thyroid Eye Disease (TED)

## Thyroid Eye Disease (TED): General Information

### Definition and Impact

- TED (Thyroid-Associated Ophthalmopathy, Graves' Ophthalmopathy, Dysthyroid Eye Disease) is an organ-specific autoimmune disease (definition, autoimmune)
- May be sight-threatening and disfiguring
- Acute progressive TED is an ophthalmic emergency, potentially threatening the optic nerve and cornea (complication)
- Incidence: approximately 10 per 100,000 per year
- Affects 30–50% of patients with Graves' disease, mostly with mild features
- Severe orbital inflammation occurs in 3–5% of patients, potentially leading to vision loss if untreated (severity)

### Thyroid Status Association

- Most patients have clinical or biochemical evidence of hyperthyroidism or hypothyroidism
- Some patients are euthyroid at presentation
- Thyroid dysfunction can precede, coincide with, or follow TED

### Risk Factors

- Female sex (♀:♂ 6:1) (demographics)
- Genetic predisposition: HLA-DR3, HLA-B8, CTLA4 gene, TSH receptor gene (genetic)
- Smoking (lifestyle)
- Personal or family history of autoimmune thyroid disease (history)

### Associated Autoimmune Thyroid Diseases

- Primarily associated with Graves' disease (90%) (association)
- May occur in 3% of Hashimoto's thyroiditis cases (association)

#### Graves' Disease

- Most common cause of hyperthyroidism (definition)
- Anti-TSH receptor antibodies cause overproduction of thyroxine (T4) and/or triiodothyronine (T3) (mechanism)
- Classic features: hyperthyroidism, goitre, TED, thyroid acropachy (finger clubbing), pretibial myxoedema (symptom)

#### Autoimmune Thyroiditis (e.g., Hashimoto's thyroiditis)

- May have a transient hyperthyroid stage before hypothyroidism (progression)
- Lymphocytic infiltration and fibrosis result in a firm, lobulated goitre (pathology)

### Pathogenesis of TED

- Cause is unclear; likely involves shared antigens between orbital tissues and the thyroid gland (etiology)
- Binding and activation of antigens on orbital fibroblasts by autoantibodies (e.g., TSH receptor, IGF-1 receptor) (mechanism)
- Results in activation of inflammatory cascades, T-cell recruitment, cytokine production
- Leads to myofibroblast–adipocyte proliferation, adipogenesis, and glycosaminoglycan synthesis (pathology)

### Clinical Features

#### Ophthalmic Manifestations

- **Symptoms**:
  - Ocular irritation, ache (worse in mornings)
  - Red eyes
  - Pain on eye movement
  - Cosmetic changes
  - Diplopia (visual disturbance)
  - Visual loss (visual disturbance)
- **Signs**:
  - Proptosis (exophthalmos)
  - Lid retraction (upper > lower)
  - Lid lag (on downgaze)
  - Lagophthalmos
  - Conjunctival and caruncular injection and/or chemosis
  - Orbital fat prolapse
  - Keratopathy (exposure/superior limbic/KCS) (corneal issue)
  - Restrictive myopathy (muscle involvement)
  - Optic neuropathy (nerve involvement)

#### Emergencies in TED (Box 14.1)

##### Acute Progressive Optic Neuropathy

- Arises from nerve compression by involved tissues (mainly muscles) or proptosis-induced stretch (cause)
- **Assessment**: Optic nerve function (VA, color, VF, pupillary reactions) (diagnostic)
- **Treatment**:
  - Systemic immunosuppression: Oral corticosteroids (e.g., 1mg/kg/day prednisolone) or pulsed IV methylprednisolone (e.g., 500mg-1g IVMP daily for 3 days) (medical treatment)
    - Response rates: PO steroid ~50%, IV steroid ~80%
    - Monitor response over 1-2 weeks
    - Repeat IVMP doses possible, total dose not to exceed 8g per course (liver damage risk)
  - Urgent surgical decompression if medical treatment fails (surgical treatment)

##### Exposure Keratopathy

- Arises from proptosis and lid retraction (cause)
- **Assessment**: Corneal integrity, tear film, lid closure, proptosis (diagnostic)
- **Treatment**: Lubricants, taping/frost suture/tarsorrhaphy, acute immunosuppression (e.g., systemic corticosteroids), orbital decompression, levator recession (treatment options)

#### Systemic Manifestations

- Depend on thyroid status (hyperthyroidism/hypothyroidism) and underlying disease (e.g., goitre, pretibial myxoedema, thyroid acropachy in Graves')
- Increased frequency of other autoimmune diseases (e.g., myasthenia gravis, pernicious anaemia, vitiligo, diabetes mellitus, Addison's disease) (co-morbidity)

#### Common Systemic Features of Thyroid Dysfunction (Table 14.5)

  | Feature    | Hyperthyroidism                                                                 | Hypothyroidism                                                                    |
  |------------|---------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
  | **Symptoms** | Weight loss, Heat intolerance, Restlessness, Diarrhoea, Poor libido, Amenorrhoea, Poor concentration, Irritability | Weight gain, Cold intolerance, Fatigue, Constipation, Poor libido, Menorrhagia, Poor memory, Depression |
  | **Signs** | Warm peripheries, Hair loss, Tachycardia, Atrial fibrillation (AF), Proximal myopathy, Tremor, Osteoporosis | Dry coarse skin, Dry thin hair, Bradycardia, Pericardial/pleural effusions, Muscle cramps, Slow relaxing reflexes, Deafness |

## Thyroid Eye Disease (TED): Assessment

### Clinical Assessment Approach

- Diagnosis and management depend on accurate clinical assessment
- Grading systems formalize assessment but do not replace careful clinical documentation of disease status (severity and activity)
- Investigations support diagnosis but are not diagnostic on their own

### Rundle's Curve

- Describes natural history of TED: active phase (increasing severity), regression phase (declining severity), inactive plateau phase (disease course)
- Time courses vary per patient; broadly categorized as mild, moderate, marked, or severe

### Type 1 and Type 2 TED

- Type 1: Predominant orbital fat expansion (classification)
- Type 2: Predominant Extraocular Muscle (EOM) expansion and restrictive myopathy; found in older age group (classification)

### Assessment of Disease Severity

- **NOSPECS Classification (Table 14.6)**: (largely historical for ophthalmologists, still used by GPs/endocrinologists)

  | Score | Class | Description             |
  |-------|-------|-------------------------|
  | 0     | N     | No signs or symptoms    |
  | 1     | O     | Only signs, no symptoms |
  | 2*    | S     | Soft tissue involvement |
  | 3*    | P     | Proptosis               |
  | 4*    | E     | EOM involvement         |
  | 5*    | C     | Corneal involvement     |
  | 6*    | S     | Sight loss (decreased VA) |

  - *Categories 2–6 can be further graded (o, a, b, c) on Werner's modified NOSPECS*
- **EUGOGO Classification**: (European Group on Graves' Ophthalmopathy)
  - Sight-threatening: Dysthyroid optic neuropathy and/or corneal breakdown (severity level)
  - Moderate to severe: No sight-threatening TED, but sufficient impact on quality of life for immunosuppression (if active) or surgery (if inactive) (severity level)
  - Mild: Minor impact on daily life, insufficient for immunosuppression or surgery (severity level)
- **VISA Classification**: Advocated by International Thyroid Eye Disease Society (ITEDS) (alternative classification)

### Assessment of Disease Activity

- **Mourits et al. Clinical Activity Score (CAS) (Table 14.7)**: (widely used)

  | Feature                | Criteria                                            | Score |
  |------------------------|-----------------------------------------------------|-------|
  | **Pain**               | Painful, oppressive feeling on or behind globe      | +1    |
  |                        | Pain on eye movement                                | +1    |
  | **Redness**            | Eyelid redness                                      | +1    |
  |                        | Conjunctival redness                                | +1    |
  | **Swelling**           | Swelling of lids                                    | +1    |
  |                        | Chemosis                                            | +1    |
  |                        | Swelling of caruncle                                | +1    |
  |                        | Increasing proptosis (≥2mm in 1–3 months)           | +1    |
  | **Impaired function**  | Decreasing eye movement (≥5 degrees in 1–3 months)  | +1    |
  |                        | Decreasing vision (≥1 line pinhole VA in 1–3 months)| +1    |
  | **Total Score (out of 10)** |                                                | /10   |

### Investigations

#### Thyroid Function Tests (TFTs) (Table 14.8)

- Usually TSH and free T4; check free T3 if strong clinical suspicion (diagnostic test)

  | TFTs     | Hyperthyroid | Hypothyroid |
  |----------|--------------|-------------|
  | TSH      | decreased    | increased   |
  | Free T4  | increased    | decreased   |

  - *In subclinical states, free T4 normal, TSH abnormal*

#### Thyroid Autoantibodies (Table 14.9)

- Anti-TSH receptor, anti-thyroid peroxidase, anti-thyroglobulin antibodies (diagnostic test)

  | Autoantibody            | Association                                     |
  |-------------------------|-------------------------------------------------|
  | Anti-TSH receptor       | >95% Graves' disease, 40–95% TED                |
  | Anti-thyroid peroxidase | 80% Graves' disease, 90% Hashimoto's thyroiditis |
  | Anti-thyroglobulin      | 25% Graves' disease, 55% Hashimoto's thyroiditis |

#### Orbital Imaging

- CT orbits: Better bony resolution, preferred for decompression planning (imaging)
- MRI (T2-weighted and STIR): Better soft tissue resolution; higher water content in EOMs compared to temporalis muscle indicates active inflammation (imaging)
- Classic finding: Enlargement and inflammation of muscle bellies, tendons spared (imaging finding)

#### Orthoptic Review

- May include: Field of binocular single vision, field of uniocular fixation, Hess/Lees chart, Visual Field (VF) (functional assessment)

## Thyroid Eye Disease (TED): Management

### Treatment of Eye Disease

#### General Measures

- Multidisciplinary input: Endocrinologist and orthoptist (collaborative care)
- Meticulous control of thyroid function: Associated with reduced TED severity (systemic control)
- Supportive care:
  - Counselling
  - Ocular lubricants
  - Tinted glasses
  - Nocturnal eyelid taping
  - Bed-head elevation
  - Prisms for diplopia
  - Support groups (e.g., British Thyroid Foundation, Thyroid Eye Disease Charitable Trust) (patient support)
- Smoking cessation: Smokers have more severe TED, poorer treatment response, and worse outcomes (lifestyle modification)

#### Medical Treatment

- Consider immunosuppression in active disease (CAS ≥3) (treatment strategy)
- Early aggressive treatment in active phase can prevent morbidity
- Systemic corticosteroids are usual treatment (immunosuppression)
- Other agents: Ciclosporin, methotrexate, azathioprine, etanercept (anti-TNF), rituximab (anti-CD20) (alternative immunosuppression)
- Radiotherapy (e.g., 20Gy in ten daily 2Gy doses): Response rates ~60%; not for sight-threatening optic neuropathy alone; contraindicated in severe hypertension or diabetes (radiotherapy)

#### Surgical Treatment

- **For acute disease**:
  - Emergency orbital decompression for acute progressive optic neuropathy or corneal exposure (surgical intervention)
- **For burnt-out (inactive) disease**:
  - Staged surgery to improve function and cosmesis (surgical intervention)
  - Order of surgery: Decompression, then motility, then lid surgery
  - Decompression types: 1-, 2-, or 3-wall; various approaches (e.g., endoscopic, swinging lower lid flap, transconjunctival) to hide scars

### Prognosis

- Self-limiting disease, usually resolves within 1–5 years (disease course)
- Dramatic improvements in ocular motility and appearance achievable with staged surgery once stable
- Good long-term vision depends on managing sight-threatening complications in acute phase

#### Poor Prognostic Factors in TED (Box 14.2)

- Older age of onset (risk factor)
- Male sex (risk factor)
- Smoker (risk factor)
- Diabetes (co-morbidity)
- Decreased Visual Acuity (dVA) at presentation (indicator)
- Rapid progression at onset (indicator)
- Longer duration of active disease (indicator)

### Treatment of Hyperthyroidism

#### Carbimazole and Propylthiouracil

- Thionamide drugs blocking thyroid hormone production (pharmacological treatment)
- Initial dose (carbimazole 15–40mg; propylthiouracil 200–400mg) continued until euthyroid, then reduced
- Therapy generally for 12–18 months
- Alternative: Blocking–replacement regimen (higher carbimazole with thyroxine)
- Patient warning: Risk of agranulocytosis (seek medical review for infections, especially sore throat) (side effect)

#### Radioactive Iodine

- Single oral dose (typically 400 or 600MBq) of radioactive sodium iodide (131I) (radiological treatment)
- Patient must avoid close contact (especially children) post-treatment
- Subsequent hypothyroidism common, requires thyroxine replacement
- ~15% may develop new or worsening TED within 6 months post-131I; risk reduced by prophylactic oral steroids (complication)

#### Surgical Thyroidectomy

- Total or subtotal removal of thyroid (surgical treatment)
- May be preceded by radioactive iodine to shrink goitre

#### In Pregnancy and Breastfeeding

- Carbimazole and propylthiouracil cross placenta, can cause fetal hypothyroidism (caution)
  - Use lowest possible dose; avoid blocking–replacement regimen
- Radioactive iodine is contraindicated in pregnancy (contraindication)

### Treatment of Hypothyroidism

#### Levothyroxine

- Thyroxine replacement (pharmacological treatment)
- Starting dose: 25–100 micrograms (50 mcg if >50y; 25 mcg if cardiac disease/elderly), cautiously increased at 4-week intervals
- Maintenance dose: 100–200 micrograms
- Monitored against TFTs (aim to normalize TSH) and clinical status
- Rapid increases or excessive doses: Risk of angina, arrhythmias, hyperthyroid features (side effect)

### Selenium and Mild TED

- Large randomized controlled trial (159 patients, mild TED) (research)
- Antioxidant selenium (100 micrograms twice daily) for 6 months resulted in:
  - Better quality of life at 6 and 12 months (outcome)
  - Less ophthalmic involvement (outcome)
  - Reduced TED progression (outcome)
  - No adverse effects reported (safety)

# Orbital Inflammations

- Inflammatory diseases affecting the orbit, which can be purely orbital or related to systemic disease.
- Purely orbital diseases can be **diffuse** (e.g., idiopathic orbital inflammatory disease) or **focal** (e.g., myositis).
- Classification is evolving based on immunogenetic and clinical features.

## Classification of Orbital Inflammations

### Isolated / Diffuse

- Idiopathic orbital inflammatory disease
- IgG4-related orbitopathy

### Isolated / Focal

- Myositis
- Dacryoadenitis
- Tolosa–Hunt syndrome

### Systemic-Related

- Thyroid Eye Disease (TED)
- Granulomatosis with Polyangiitis (GPA)
- Sarcoidosis

## Idiopathic Orbital Inflammatory Disease (IOID)

- A chronic inflammatory process of unknown aetiology, formerly known as **pseudotumour**.
- It is a diagnosis of exclusion. (diagnosis)
- The pattern may be anterior (commoner) or diffuse.
- Usually unilateral and can occur at any age.

### Clinical Features of IOID

- Acute **pain**, redness, lid swelling, **diplopia**.
- Conjunctival injection, **chemosis**, lid oedema, **proptosis**, restrictive myopathy.

### Investigations for IOID

- **Orbital Imaging**: B-scan (low-medium reflectivity), MRI (hypointense on T1, hyperintense on T2).
- **Biopsy**: Required to confirm the diagnosis; shows a pure inflammatory response. (diagnosis)

### Treatment of IOID

- **Immunosuppression**: Systemic corticosteroids are the primary treatment; cytotoxics (e.g., cyclophosphamide) and radiotherapy are sometimes used. (treatment)

### Differential Diagnosis of IOID

- Orbital cellulitis
- TED
- GPA (Wegener's granulomatosis)
- IgG4 disease
- Haemorrhage within a vascular lesion
- Rhabdomyosarcoma
- Metastatic neuroblastoma
- Leukaemic infiltration

## Myositis

- An idiopathic inflammatory process typically restricted to one or more extraocular muscles (EOMs).
- Most commonly affects the superior or lateral rectus.
- Usually unilateral and can occur at any age.

### Clinical Features of Myositis

- Acute **pain**, especially on movement in the direction of the involved muscle.
- Injection over the muscle and mild **proptosis**.
- Repeated episodes may lead to EOM fibrosis and subsequent squint or motility deficit.

### Investigations for Myositis

- **Orbital Imaging**: CT or MRI can diagnose; classically shows enlargement of the entire muscle and tendon insertion. (diagnosis)

### Treatment of Myositis

- **Immunosuppression**: Highly sensitive to systemic corticosteroids. (treatment)
- **Radiotherapy**: Used for recurrent/chronic cases or poor response to steroids.
- **Biopsy**: Considered if the treatment response is poor or symptoms persist.

## Dacryoadenitis

- Inflammation of the lacrimal gland, which can be isolated or part of a diffuse IOID.

### Clinical Features of Dacryoadenitis

- Presents with an acutely painful, swollen, and tender lacrimal gland.
- Leads to reduced tear production.
- Causes an **S-shaped deformity** to the lid and upper lid ptosis.

### Differential Diagnosis of Dacryoadenitis

- **Infection**: Mumps, EBV, CMV.
- **Systemic Disease**: Sarcoidosis, Sjögren's syndrome.
- **Tumours** of the lacrimal gland.
- Ruptured dermoid cyst.

### Treatment of Dacryoadenitis

- Responds well to oral NSAIDs (e.g., flurbiprofen) or oral corticosteroids. (treatment)
- Complete resolution may take up to 3 months.
- Orbital imaging and biopsy are indicated if inflammation persists.

## Tolosa–Hunt Syndrome

- A rare idiopathic condition with focal inflammation at the superior orbital fissure, orbital apex, or cavernous sinus.

### Clinical Features of Tolosa–Hunt Syndrome

- **Orbital pain**.
- Multiple cranial nerve palsies.
- Periocular sensory disturbance (V1 and V2 divisions of the trigeminal nerve).
- Sometimes includes **proptosis**.

### Differential Diagnosis of Tolosa–Hunt Syndrome

- Must be differentiated from other causes of superior orbital fissure syndrome like carotid-cavernous fistula, cavernous sinus thrombosis, GPA, and infections.

### Treatment of Tolosa–Hunt Syndrome

- It is very sensitive to steroids. (treatment)

## Granulomatosis with Polyangiitis (GPA)

- Formerly known as **Wegener's granulomatosis**.
- An uncommon, severe necrotizing granulomatous vasculitis. (systemic)
- Ophthalmic involvement occurs in up to 50% of cases.

### Clinical Features of GPA

#### Ophthalmic

- **Orbital disease**: Pain, proptosis, restrictive myopathy, disc swelling, and decreased visual acuity.
- **Other ocular disease**: Epi-/scleritis, PUK, uveitis, and vasculitis.

#### Systemic

- Pneumonitis, glomerulonephritis, sinusitis, and nasopharyngeal ulceration.

### Investigations for GPA

- **ANCA**: Most cases are **c-ANCA positive** (and PR3+). (diagnosis)
- **CT scan**: Shows obliteration of orbital fat planes and erosion of sinus and nasal bones.

### Treatment of GPA

- Coordinated by a rheumatologist/physician.
- Typically involves combined corticosteroids, cyclophosphamide, or rituximab. (treatment)

## IgG4-Related Orbitopathy

- An immune-mediated systemic syndrome involving orbital infiltration of IgG4-expressing plasma cells, leading to fibrosis and sclerosis. (systemic)
- Can affect any ocular adnexal structure and multiple organs.

### Clinical Features of IgG4-Related Orbitopathy

- **Proptosis**, lid swelling, and ocular movement restriction.

### Investigations for IgG4-Related Orbitopathy

- **CT/MRI**: Shows a solid homogeneous mass.
- **Biopsy**: Reveals IgG4+ lymphoplasmacytic infiltrate, follicular hyperplasia, eosinophils, and fibrosis. (diagnosis)

### Treatment of IgG4-Related Orbitopathy

- Excellent response to corticosteroids. (treatment)
- Radiotherapy and immunomodulatory treatments (e.g., rituximab) are also used.

## Adult Orbital Xanthogranulomatous Diseases

- A group of four rare, overlapping, and poorly understood entities.
- Characterized by yellow-orange xanthomatous masses in the eyelid and/or orbit.
- May be associated with lymphoproliferative disorders.

### Disease Types & Features

- **Necrobiotic Xanthogranuloma (NBX)**: Subcutaneous lesions that may ulcerate; associated with paraproteinaemia.
- **Erdheim–Chester Disease (ECD)**: Lymphohistiocytic orbital infiltration that also affects other organs; often fatal.
- **Adult-onset Asthma and Periocular Xanthogranuloma (AAPOX)**: Xanthomatous masses; asthma develops later; linked to lymphoproliferative disorders.
- **Adult-onset Xanthogranuloma (AOX)**: A solitary, usually self-limiting lesion with no systemic findings.

### Investigations for Xanthogranulomatous Diseases

- **Biopsy**: Shows characteristic histopathology with foamy histiocytes and **Touton giant cells**. (diagnosis)

### Treatment of Xanthogranulomatous Diseases

- Optimal treatment is unclear; options include surgical debulking, radiotherapy, steroids, and biologic agents. (treatment)

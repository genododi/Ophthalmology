# Lymphoma

- Ocular lymphoma is an uncommon tumour of the eye with increasing incidence.
- It is both sight-threatening and life-threatening. (severity)
- Easily missed, as it may masquerade as other conditions like uveitis. (diagnosis challenge)
- Risk factors include immunosuppression (e.g., therapeutic, AIDS). (risk factor)

## Classification

- Ocular disease lymphoma may be divided by:
  - **Clinical pattern:**
    - Vitreoretinal
    - Choroidal
    - Ciliary
    - Iridal
  - **Origin:**
    - Primary
    - Secondary to Central Nervous System (CNS) lymphoma
    - Secondary to systemic disease
- Subtyped histomorphologically according to the WHO Lymphoma Classification. (standard)

### Hodgkin’s Lymphoma

- Characterized by the Reed–Sternberg cell (thought to be an abnormal B-cell). (hallmark)
- Accounts for 20% of lymphomas (approximately 1,500 new cases/year in the UK). (statistics)

### Non-Hodgkin’s Lymphoma

- Comprises all other lymphomas (80%; approximately 9,700 new cases/year in the UK). (statistics)
- Usually subclassified by cell type; most are B-cell lymphomas.
- **B-cell non-Hodgkin’s lymphoma types:** (B-cell)
  - Diffuse large B-cell lymphoma (commonest)
  - Follicular lymphoma (commonest)
  - Burkitt’s lymphoma
  - MALToma (extranodal marginal zone B-cell lymphoma)
  - Nodal marginal zone B-cell lymphoma
  - Mantle cell lymphoma
  - Mediastinal large B-cell lymphoma
  - Small lymphocytic lymphoma
  - Waldenström’s macroglobulinemia
- **T-cell non-Hodgkin’s lymphoma types:** (T-cell)
  - Cutaneous lymphoma (mycosis fungoides; Sézary syndrome)
  - Peripheral T-cell lymphoma
  - Anaplastic large cell lymphoma
  - Lymphoblastic lymphoma

## Primary Vitreoretinal Lymphoma (PVRL)

- Also known as primary intraocular lymphoma or primary CNS lymphoma with ocular involvement. (definition)
- The commonest type of intraocular lymphoma. (prevalence)

### Histology (PVRL)

- Usually an intermediate/high-grade non-Hodgkin’s lymphoma of diffuse large B-cell type. (histopathology)

### Disease Distribution and Presentation (PVRL)

- **Disease distribution:**
  - Bilateral ophthalmic disease occurs in 90%. (distribution)
  - Coexistent intracranial disease occurs in up to 85% of patients with primary intraocular disease. (coexistence)
  - Conversely, up to 20% who present with primary CNS lymphoma develop concurrent ocular disease. (coexistence)
- **Disease presentation:**
  - Ocular disease is the presenting feature in 50–65% (and can precede CNS disease by months or years). (presentation)
  - In 35–50%, it is found concurrent with, or after presentation of, CNS disease. (presentation)

### Risk Factors (PVRL)

- May occur in both immunocompetent and immunocompromised individuals.
- In patients on immunosuppressive drugs, risk is related to degree and duration of immunosuppression. (immunosuppression)
- In patients with HIV, it is normally associated with CD4+ counts of <30/mm3. (HIV association)
- Epstein-Barr Virus (EBV) is strongly associated with ocular CNS lymphoma in AIDS patients. (viral association)

### Clinical Features (PVRL)

- Typically, PVRL presents with a ‘vitreoretinal’ pattern of disease, sometimes described as a uveitis ‘masquerade’ syndrome. (presentation pattern)
- **Ophthalmic features:**
  - *Typical:* ‘Vitritis’ (cellular infiltrate), yellowish sub-RPE plaques with overlying pigment clumping (‘leopard spotting’), usually bilateral; may be misdiagnosed as a refractory ‘uveitis’ (corticosteroid treatment may initially be successful). (ocular signs)
  - *Atypical:* Exudative Retinal Detachment (ERD); retinitis (which may mimic diseases like CMV, ARN, sarcoidosis, TB, and syphilis); Neovascular Glaucoma (NVG). (ocular signs)
- **CNS features:**
  - *Typical:* Progressive focal symptoms indicative of a space-occupying lesion, including seizures, mental state change. (neurological signs)
  - *Atypical presentations:* Meningeal (may present with headache, isolated cranial neuropathy, spinal nerve root problems); progressive dementia; intravascular malignant lymphomatosis (multiple stroke-like episodes); neurolymphomatosis (CNS lymphoma with peripheral nerve infiltration); relapsing–remitting form. (neurological signs)

### Investigations (PVRL)

- **Ophthalmic:**
  - Full diagnostic vitrectomy is recommended as the primary investigation over fine-needle vitreous aspiration (cellular yield is much greater). (diagnostic procedure)
  - Incisional biopsy may also be considered if chorioretinal involvement. (diagnostic procedure)
  - The vitreous specimen requires expert handling with immediate fixing in theatre and centrifugation. (sample handling)
  - Levels of IL-10 are generally elevated; an IL-10:IL-6 ratio of >1.0 indicates likely lymphoma. (biomarker)
  - Clonal bcl-2/IgH translocations may be detected by PCR in up to two-thirds of cases. (genetic marker)
- **Systemic:**
  - Assessment and treatment should be coordinated by an oncologist.
  - Usually includes MRI brain and possibly Lumbar Puncture (for ocular-CNS type). (imaging, procedure)
  - Abdomen–pelvis imaging (for systemic involvement). (imaging)

### Treatment (PVRL)

- Options include radiotherapy (external beam or plaque) and chemotherapy (intravitreal, e.g., methotrexate, or systemic). (treatment modality)
- CNS involvement may require aggressive treatment with combined intrathecal and IV chemotherapy and radiotherapy. (aggressive treatment)

## Primary Uveal Lymphoma

- May arise in the choroid, ciliary body, or iris. (location)
- All forms are rare. (rarity)
- Uveal lymphoma is much more likely to be due to systemic disseminated disease.
- Usually of low-grade, extranodal, marginal zone B-cell type. (histopathology)

## Secondary Uveal Lymphoma

- Secondary intraocular involvement may occur with systemic lymphoma.
- Much less common than PVRL.
- May be associated with involvement of other orbital structures.

### Histology (Secondary Uveal Lymphoma)

- Commonest systemic lymphoma types to involve the eye: Diffuse large B-cell lymphoma, Multiple myeloma, and Waldenström’s macroglobulinemia. (histopathology)

### Clinical Features (Secondary Uveal Lymphoma)

- *Typical:* More diffuse yellowish choroidal thickening (may be multifocal), with minimal, if any, vitritis. (ocular signs)
- *Atypical:* May mimic melanoma (or other choroidal tumours), posterior scleritis, uni-/multifocal choroiditis. (differential diagnosis)

### Investigations (Secondary Uveal Lymphoma)

- **Ophthalmic:**
  - In most cases, tissue diagnosis of lymphoma has already been made from non-ocular tissue.
  - Ocular fluid/tissue may be obtained, as described for primary intraocular disease.
  - Orbital imaging (Ultrasound/MRI) may be helpful in assessing the extent of disease. (imaging)
- **Systemic:**
  - Assessment and treatment should be coordinated by an oncologist.
  - Likely to include extensive imaging (e.g., abdomen–pelvis), for assessing disease extent and identifying suitable tissue for biopsy. (imaging, staging)
  - MRI brain and Lumbar Puncture (if CNS involvement suspected). (imaging, procedure)

### Treatment (Secondary Uveal Lymphoma)

- Treatment options include radiotherapy and chemotherapy. (treatment modality)
- Directed by the histological grade of the lymphoma and the extent of systemic and intraocular disease. (treatment strategy)

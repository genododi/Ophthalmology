# Intraocular Tumours

## Uveal Melanoma

- Commonest **primary** malignant intraocular tumour in Caucasian adults (epidemiology)
- Lifetime incidence: ~0.05% (epidemiology)
- **Risk factors:**
  - Race (light >> dark pigmentation) (risk factor)
  - Age (old > young) (risk factor)
  - UV light exposure (possible risk factor)
  - Ocular melanocytosis (underlying disorder)
  - Dysplastic naevus syndrome (underlying disorder)
- Slightly commoner in men than **females** (epidemiology)
- Arise from neuroectodermal melanocytes of the choroid, ciliary body, or iris (origin)

## Iris Tumours

### Iris Melanoma

- Less common than other uveal melanomas (8% of all uveal tumours) (epidemiology)
- Presents younger (age 40–50 years) (epidemiology)
- Better prognosis compared to other uveal melanomas (prognosis)
- Commoner in **females** (epidemiology)
- **Histology:** Usually spindle cells alone or spindle cells with benign naevus cells (histology)
- **Clinical features:**
  - Usually asymptomatic; patient may note a spot or diffuse colour change (symptom)
  - Iris nodule:
    - Most commonly light to dark brown, well-circumscribed
    - Usually inferior iris
    - May be associated with hyphaema, **increased IOP** (tumour or pigment cell blockage of trabecular meshwork), cataract (complication)
- **Risk factors for malignancy / Suspicious features:** (risk factor)
  - Size (>3mm diameter, >1mm thickness)
  - Rapid growth
  - Prominent intrinsic vascularity
  - Pigment dispersion
  - **Increased IOP**
  - Pupillary peaking
  - Ectropion uveae
  - Iris splinting (uneven dilation)
  - Spontaneous hyphaema
  - Satellite lesions
- **Investigations:**
  - Anterior segment **Ultrasound (US)**: assess ciliary body involvement (investigation)
  - Biopsy:
    - **Fine-Needle Aspiration (FNA)**: simple, safe, but scanty sample with no architecture (investigation)
    - Incisional biopsy: corneal/limbal wound, risk of hyphaema (investigation)
- **Treatment:** (treatment)
  - Specialist advice should be sought
  - Observation: for small asymptomatic tumours with no convincing growth
  - Excision: iridectomy/iridocyclectomy, possibly with cosmetic contact lens (artificial pupil)
  - Radiotherapy: brachytherapy or proton beam radiotherapy
  - Enucleation: rarely indicated (non-resectable, extensive aqueous seeding, or painful blind eye)
- **Prognosis:**
  - Most patients do well; rarely (1–2%) develop metastatic disease (prognosis)
  - Poor prognostic features: large size, ciliary body or extrascleral extension, diffuse or annular growth pattern (prognosis)

### Iris Naevus

- Common benign lesions; regular ophthalmic observation not required unless suspicious features are present (overview)
- Patients will usually detect any worrying change in a lesion themselves (monitoring)
- **Clinical features:**
  - Usually asymptomatic; patient may note a spot on the iris (symptom)
  - Small (<3mm diameter, <0.5mm thickness), defined, pigmented stromal lesion (feature)
  - Pupillary peaking, iris splinting (uneven dilation), or ectropion uveae occasionally occur but may be suspicious features (feature)

### Iris Metastases

- Typically amelanotic solid tumours (feature)
- May cause complications such as **secondary** open-angle glaucoma (clogging or infiltration of trabecular meshwork), hyphaema, and pseudohypopyon (complication)
- In most cases, patients are already known to have a malignancy elsewhere; commonest **primary** sites are breast or bronchogenic carcinoma (origin)
- In some patients, the iris lesion is the presenting feature and requires extensive work-up with an oncologist (diagnosis)

### Differential Diagnosis of Iris Mass

- Content:

    | Type          | Diagnoses                                                                                                |
    |---------------|----------------------------------------------------------------------------------------------------------|
    | Pigmented     | Iris melanoma, Naevus, **Iridocorneal Endothelial (ICE)** syndrome, Adenoma, Ciliary body tumours            |
    | Non-pigmented | Iris melanoma (amelanotic), Iris cyst, Iris granulomas, **Intraocular Foreign Body (IOFB)**, Juvenile xanthogranuloma, Leiomyoma, Ciliary body tumours, Iris metastasis |

## Ciliary Body Tumours

### Ciliary Body Melanoma

- Account for about 30% of all uveal melanomas (epidemiology)
- Most commonly present at about 50–60 years of age (epidemiology)
- Usually contain the more anaplastic epithelioid melanoma cells (histology)
- Carry a worse prognosis compared to iris melanomas (prognosis)
- Cytogenetic analysis of tumour cells can allow stratification of the prognostic risk (prognosis)
- **Clinical features:**
  - Usually asymptomatic; occasionally visual symptoms (symptom)
  - Ciliary body mass (may only be visible with full dilation) (feature)
  - Dilated episcleral sentinel vessels (feature)
  - Anterior extension onto the iris or globe (feature)
  - Lens subluxation or **secondary** cataract (complication)
  - Anterior uveitis (complication)
- **Investigations:**
  - **Ultrasound (US)** (ocular/anterior segment): size, extension, composition (investigation)
  - Biopsy: consider **Fine-Needle Aspiration (FNA)** (investigation)
- **Treatment:** (treatment)
  - Specialist advice should be sought
  - Excision: iridocyclectomy may be possible for smaller lesions
  - Radiotherapy: brachytherapy, proton beam or stereotactic radiosurgery
  - Enucleation: for larger lesions or significant extension

### Medulloepithelioma

- Rare slow-growing tumour derived from immature epithelial cells of the embryonic optic cup (overview)
- Usually arises from the non-pigmented ciliary epithelium; iris and retinal sites are occasionally seen (origin)
- May be benign (1/3) or malignant (2/3) (pathology)
- May be teratoid (e.g., containing cartilage, brain, bone) or non-teratoid (pathology)
- Overall, invasion is common, but metastasis is rare (prognosis)
- Age of onset: congenital to adult, but is usually under the age of 10; both sexes are equally affected (epidemiology)
- **Clinical features:**
  - Red eye, **decreased Visual Acuity (dVA)**, iris colour change/mass (symptom)
  - Ciliary body mass (amelanotic, often cystic) (feature)
- **Complications:**
  - **Neovascular Glaucoma (NVG)** (complication)
  - Lens coloboma/subluxation/cataract (complication)
- **Investigations and treatment:**
  - Diagnosis may be assisted by **Ultrasound (US)** (investigation)
  - Iridocyclectomy may be curative for small, well-defined benign tumours (treatment)
  - For most others, enucleation is still required (treatment)

### Differential Diagnosis of Ciliary Body Mass

- Content:

    | Type          | Diagnoses                                                                                                |
    |---------------|----------------------------------------------------------------------------------------------------------|
    | Pigmented     | Ciliary body melanoma, Metastases, Ciliary body adenoma                                                    |
    | Non-pigmented | Ciliary body melanoma (amelanotic), Ciliary body cyst, Uveal effusion syndrome, Medulloepithelioma, Leiomyoma, Metastases |

## Choroidal Tumours

### Choroidal Melanoma

- Account for 65% of all uveal melanomas (epidemiology)
- Usually present at about 50–60 years of age (epidemiology)
- **Classification (size):** (classification)
  - Small (<10mm diameter)
  - Medium (10–15mm diameter)
  - Large (>15mm diameter)
- **Histology:** May comprise spindle cells (types A and B), epithelioid cells, or a mixture (commonest type); Necrosis may prevent cell typing in 5% (histology)
- **Clinical features:**
  - Often asymptomatic; **decreased Visual Acuity (dVA)**, field loss, ‘ball of light’ slowly moving across vision (symptom)
  - Elevated sub-**Retinal Pigment Epithelium (RPE)** mass: (feature)
    - Commonly brown but may be amelanotic
    - Commonly associated with orange pigment (lipofuscin) and **Exudative Retinal Detachment (ERD)**
    - Some (20%) may rupture through Bruch’s membrane and **RPE** to form a subretinal ‘mushroom’
    - Occasional vitreous haemorrhage, **increased IOP**, cataract, uveitis (complication)
  - NB: The key diagnostic dilemma is to distinguish a malignant melanoma from a benign naevus (diagnosis)
- **Suspicious features suggestive of choroidal melanoma:** (risk factor)
  - Symptomatic
  - Juxtapapillary
  - **Subretinal Fluid (SRF)** / retinal detachment
  - Lipofuscin on the surface
  - Large size (e.g., >2mm thickness)
  - Significant growth
- **Investigations:**
  - **Ultrasound (US)**: solid, acoustically hollow, low internal reflectivity, with choroidal excavation (investigation)
  - **Computed Tomography (CT)** and **Magnetic Resonance Imaging (MRI)**: may detect extraglobar extension but cannot reliably differentiate between types of tumour (investigation)
  - Biopsy: Diagnostic incisional biopsy or **Fine-Needle Aspiration (FNA)** may be performed in selected cases (investigation)
  - Prognostic biopsy (using genetic analysis) may be offered to patients undergoing radiotherapy (controversial: no survival advantage, small risk of extraocular seeding) (investigation, prognosis)
  - Systemic assessment: **Full Blood Count (FBC)**, **Liver Function Tests (LFTs)**, liver/abdominal **US** (or **CT**, **MRI**) (investigation)
  - At presentation, most (98%) do not have detectable metastatic disease (prognosis)
- **Treatment:** (treatment)
  - Specialist advice should be sought
  - Observation: for small asymptomatic lesions without suspicious features (**Collaborative Ocular Melanoma Study (COMS)** showed growth in only 31% of small melanomas by 5y)
  - Radiotherapy:
    - Plaques (3mm larger in diameter than the lesion; deliver about 80–100Gy to the tumour apex)
    - Proton beam irradiation (usually 50–70Gy in 4–5 fractions)
    - Stereotactic radiosurgery (in selected patients, e.g., where **General Anaesthesia (GA)** is contraindicated)
    - Plaque radiotherapy has fewer local side effects than proton beam and was shown to be as effective as enucleation for medium-sized melanomas (**COMS**) (comparison)
    - Side effects (all modalities): dry eyes, radiation retinopathy (may be treated with anti-VEGF therapy), cataracts, and **Neovascular Glaucoma (NVG)** (complication)
  - Local resection:
    - May be suitable for smaller anterior tumours
    - Preserves vision and cosmesis, avoids long-term complications of irradiation (benefit)
    - Difficult surgery, significant risk of complications (vitreous haemorrhage, retinal detachment, cataract), requires hypotensive anaesthesia (drawback)
    - Adjuvant brachytherapy may be required if resection margins are contaminated
  - Enucleation: usually for large tumours (>15mm diameter, 10mm thickness), optic nerve involvement, or painful blind eyes (No benefit from pre-enucleation radiotherapy)
  - Orbital exenteration: occasionally for extrascleral and orbital extension or recurrence after enucleation
  - **Photodynamic Therapy (PDT)**: can be used for small tumours
  - Transpupillary thermotherapy: previously **primary** treatment (largely abandoned due to high recurrence); still has a role as an adjunct
- **Prognosis:** (prognosis)
  - Poor prognostic features: older patient, large tumour size, extrascleral extension, epithelioid cell type, high mitotic count, certain genetic mutations
  - Most important genetic predictors of mortality: **Chromosome 3** loss (monosomy 3) and duplication (partial or total) of **Chromosome 8q**
  - Microarray analysis can further stratify metastatic risk based on expression of multiple genes

### Differential Diagnosis of Choroidal Mass

- Content:

    | Type          | Diagnoses                                                                                                                               |
    |---------------|-----------------------------------------------------------------------------------------------------------------------------------------|
    | Pigmented     | Choroidal melanoma, Naevus, **Congenital Hypertrophy of the RPE (CHRPE)**, Melanocytoma, Metastasis (rare), **Bilateral Diffuse Uveal Melanocytic Proliferation (BDUMP)** syndrome |
    | Non-pigmented | Choroidal melanoma (amelanotic), Choroidal granuloma, Posterior scleritis, Retinal detachment, Choroidal detachment, Choroidal neovascular membrane, Haematoma (subretinal/sub-**RPE**/suprachoroidal), Choroidal osteoma, Choroidal haemangioma, Metastasis |

### Choroidal Naevus

- Benign melanocytic tumours; may occur in up to 10% of adult Caucasians (commonest intraocular tumour) (overview, epidemiology)
- Rarely, they may become malignant (1 in 5,000) (risk factor)
- Main significance lies in the need to differentiate them from a malignant melanoma (diagnosis)
- Choroidal naevi are usually incidental findings (diagnosis)
- **Clinical features:**
  - Usually asymptomatic (89% of cases) (symptom)
  - Rarely, **decreased Visual Acuity (dVA)** from serous retinal detachment (50%), photoreceptor atrophy (42%), or **Choroidal Neovascularization (CNV)** (8%) (complication)
  - Small (<5mm diameter, <1mm thickness), well-circumscribed, homogeneous grey-brown; may have drusen; absence of lipofuscin or **Subretinal Fluid (SRF)** (cf. choroidal melanoma) (feature)
- **Differentiating a naevus from a malignant melanoma:** (diagnosis)
  - Malignant melanoma may declare itself by continued, often rapid, growth (progression)
  - Features suggestive of malignancy (mnemonic: ‘To Find Small Ocular Melanoma Using Helpful Hints Daily’): (mnemonic)
    - **T**hickness (>2mm)
    - **F**luid (**Subretinal Fluid (SRF)**)
    - **S**ymptoms (flashes/floaters/blurred vision)
    - **O**range lipofuscin pigment
    - **M**argin <3mm from optic disc
    - **U**ltrasonographic **H**ollowness
    - **H**alo absence
    - **D**rusen absence
  - Absence of any of the eight features: small melanocytic lesion very unlikely to be choroidal melanoma (only 3% show significant growth at 5y) (prognosis)
  - Presence of three or more risk factors: >50% chance of transformation to melanoma within 5y (risk factor)
- **Investigations and treatment:**
  - If no suspicious features present, lesions do not require regular ophthalmic review (monitoring)
  - Naevus should be photographed; patient provided copy for optometrist monitoring (e.g., annually) (monitoring)

### Melanocytoma

- Comprise a distinctive cell type—the polyhedral naevus cell (histology)
- Heavily pigmented benign tumours, usually involving the optic disc (feature, location)
- May cause axonal compression and consequent **Visual Field (VF)** defects (complication)
- Occasionally, the choroid, ciliary body, or iris can be involved (location)

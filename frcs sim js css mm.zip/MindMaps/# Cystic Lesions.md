# Cystic Lesions

## Dacryops (lacrimal ductal cyst)

- Definition: These are relatively common cysts of the lacrimal duct tissue, potentially arising from any lacrimal tissue, including accessory lacrimal glands (Krause and Wolfring). They result from obstruction and subsequent expansion of lacrimal gland ductules and are filled with serous fluid.

### Clinical features

- Painless, smooth-walled, bluish-grey, transilluminable areas located in the superolateral fornix.
- They may be bilateral.

### Treatment

- Marsupialization, if required. (Surgical)

## Dermoid cyst

- Definition: Dermoids are a type of **choristoma** (congenital tumours composed of tissues abnormal to their location). They are thought to represent surface ectoderm trapped along lines of embryonic closure and suture lines. (Pathology, Congenital)
- Composition: Comprise stratified squamous epithelium (including epidermal structures like hair follicles and sebaceous glands) surrounding a cavity that may contain keratin and hair.
- Common Locations:
  - Most commonly on the superotemporal orbital rim (69%), near the temporal–zygomatic suture line, potentially extending far posteriorly.
  - Less commonly found superonasally (30%).
- Risk: Accidental traumatic rupture can lead to significant inflammation and skin discharge.

### Clinical features

- **Superficial dermoids:**
  - Typically present in infancy.
  - Manifest as a slowly growing, firm, smooth, round, non-tender mass.
- **Deep dermoids:**
  - Usually present from childhood onwards.
  - Symptoms include gradual proptosis, motility disturbance, and decreased Visual Acuity (dVA).
  - Can present with recurrent orbital inflammation.
  - May extend beyond the orbit into structures like the frontal sinus, temporal fossa, or cranium. (Extension)

### Investigations

- Orbital imaging:
  - CT scan typically shows a well-circumscribed lesion with a heterogeneous centre. (Imaging)
  - B-scan ultrasound (US) shows a well-defined lesion with high internal reflectivity. (Imaging)

### Treatment

- Complete excision without rupturing the capsule is essential to avoid severe inflammation and recurrence. (Surgical)
- Deep dermoid cysts with intracranial spread require coordinated management with neurosurgeons. (Collaboration, Surgical)

## Mucocele

- Definition: A mucocele is a slowly expanding collection of secretions caused by blockage of a sinus opening. This blockage may be due to a congenital narrowing or arise secondary to infection, inflammation, tumour, or trauma. (Pathophysiology)
- Progression: Over time, erosion of the sinus walls allows the mucocele to encroach into the orbit.
- Common Origins: Orbit-involving mucoceles usually originate from the frontal, ethmoidal, or occasionally the maxillary sinuses.

### Clinical features

- Symptoms include headache.
- Gradual non-axial proptosis or horizontal displacement of the eye.
- A fluctuant, tender mass may be present in the medial or superomedial orbit.

### Investigations

- Orbital imaging:
  - CT scan shows opacification of the frontal or ethmoidal sinus (potentially with loss of ethmoidal septae), along with a bony defect that allows intraorbital protrusion. (Imaging)
  - B-scan US reveals a well-defined lesion with low internal reflectivity. (Imaging)

### Treatment

- Referral to an Ear, Nose, and Throat (ENT) specialist is required to excise the mucocele, restore sinus drainage, or obliterate the sinus cavity in recurrent cases. (Referral, Surgical)

## Cephalocele

- Definition: These are rare developmental malformations that result in herniation of brain tissue (*encephalocele*), meninges (*meningocele*), or both (*meningoencephalocele*) into the orbit. (Congenital, Malformation)
- Types based on defect location:
  - **Anterior cephaloceles:** Associated with fronto-ethmoidal bony defects.
  - **Posterior cephaloceles:** Associated with sphenoid dysplasia.
- Presentation: Usually present as congenital lesions, but if located in the deep orbit, they may present later in life.
- Associations:
  - Encephaloceles can be associated with other craniofacial or ocular abnormalities, particularly those involving midline structures.
  - Posterior encephaloceles may be associated with neurofibromatosis-1 and morning glory syndrome.

### Clinical features

- Pulsatile proptosis, which may increase with the Valsalva manoeuvre but occurs without a bruit (distinguishing from AV fistulae). (Symptom)
- **Anterior lesions:**
  - The encephalocele may be visible and transilluminable.
  - Proptosis is usually anterotemporal.
- **Posterior lesions:**
  - The encephalocele is not visible externally.
  - Proptosis is usually anteroinferior.

### Investigations

- Orbital imaging: CT scan demonstrates a defect in the orbital wall. (Imaging)

### Treatment

- Surgical management involves excision, closure, or ligation of the base of the cephalocele.
- Patching of the bony defect from the orbital side is also performed. (Surgical)

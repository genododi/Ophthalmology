# Intraocular Tumours

## Retinal Vascular Tumours

### Capillary Haemangioma

- Definition: Uncommon benign hamartoma of the retinal (or optic disc) vasculature, consisting of capillary-like vessels. (Pathology)
- Presentation: May present at any age but most commonly diagnosed in young adults.
- Systemic Association:
  - Isolated capillary haemangiomas are usually not related to systemic disease.
  - Most multiple/bilateral tumours are seen in the context of **von Hippel–Lindau syndrome (VHL)**. (Systemic Association)
- Histology:
  - Consists of endothelial cells, pericytes, and stromal cells.
  - The VHL mutation may be restricted to the stromal cells, suggesting they are the underlying neoplastic cell. (Pathogenesis)
- Clinical Features:
  - Decreased visual acuity (dVA); may be asymptomatic (diagnosed on family screening).
  - Red nodular lesion, with tortuosity and dilatation (often irregular) of feeding artery and draining vein. (Clinical Finding)
  - Potential complications: exudation, exudative retinal detachment (ERD), rubeosis/neovascular glaucoma (NVG), epiretinal membrane (ERM), tractional retinal detachment (TRD), vitreous haemorrhage. (Complication)
  - Optic disc haemangiomas: less well defined and do not have obvious feeder vessels.
- Investigations:
  - Fundus Fluorescein Angiography (FFA): Shows rapid sequential filling of artery, haemangioma, and vein, with extensive late leakage; leakage into the vitreous may make late images hazy. (Diagnostic Test)
- Treatment:
  - Systemic Disease: If VHL is suspected, multidisciplinary care with physician and clinical geneticist is required. (Management)
  - Ocular Disease:
    - Photocoagulation: For small (<3mm diameter) tumours; requires confluent white burns covering the entire tumour and feeder vessel; multiple treatment sessions are usually required. (Treatment Modality)
    - Cryotherapy: For peripheral or larger tumours; usually double freeze-thaw technique; multiple treatment sessions are usually required. (Treatment Modality)
    - Radiotherapy. (Treatment Modality)
    - Excision. (Treatment Modality)

### Cavernous Haemangioma

- Definition: Uncommon benign hamartoma of the retinal (or optic disc) vasculature, consisting of large-calibre, thin-walled vessels. (Pathology)
- Presentation: Usually isolated, but familial bilateral cases do occur.
- Systemic Association: Can be associated with cerebral cavernous malformations (Autosomal Dominant syndrome with high penetrance and variable expressivity). (Systemic Association)
- Clinical Features:
  - Usually asymptomatic; occasional decreased visual acuity (dVA) or floaters.
  - Cluster of intraretinal blood-filled saccules (a plasma level may separate out due to the slow flow); otherwise, normal retinal vasculature. (Clinical Finding)
  - Potential complication: vitreous haemorrhage. (Complication)
- Investigations:
  - Fundus Fluorescein Angiography (FFA): Slow-filling vessels that remain hyperfluorescent, with no leakage. (Diagnostic Test)
  - MRI scan: To exclude cerebral cavernous malformation. (Diagnostic Test)
- Treatment:
  - Not usually necessary. (Management)

### Racemose Haemangioma

- Definition: Rare retinal arteriovenous malformations (AVMs), not true tumours. (Pathology)
- Presentation: Congenital, progress with age, and usually detected in early adulthood.
- Systemic Association: May be isolated or associated with ipsilateral AVMs of the Central Nervous System (CNS) (**Wyburn–Mason syndrome**). (Systemic Association)
- Clinical Features:
  - Usually asymptomatic; occasional decreased visual acuity (dVA).
  - Enlarged tortuous vascular abnormality, with direct connection between arterial and venous circulations, with similar colour throughout. (Clinical Finding)
- Investigations:
  - Diagnosis is usually clinical.
- Treatment:
  - No effective treatment for retinal AVMs.
  - Intracranial AVMs have been successfully treated by surgery, radiotherapy, and embolization. (Management)

### Vasoproliferative Tumours

- Definition: Uncommon sporadic retinal lesions. (Pathology)
- Occurrence:
  - Can occur in isolation (Primary lesions, 74%) or in association with another ocular condition (Secondary lesions, 26%).
  - Primary lesions are usually solitary (87%), whereas Secondary lesions are often multiple and bilateral.
  - Can present at any age but usually within the third and fourth decades.
- Clinical Features:
  - Usually decreased visual acuity (dVA) due to epiretinal fibrosis (31%), cystoid macular oedema (CMO) (18%), or subretinal exudation.
  - Globular or dome-shaped lesion in the peripheral retina (often inferior temporal), with telangiectatic vessels over the surface and retinal ‘feeder’ vessels. (Clinical Finding)
  - Sub- and intraretinal exudation (80%) which can lead to exudative retinal detachment (ERD) (50%). (Complication)
- Investigations:
  - Diagnosis is usually clinical.
- Treatment:
  - Symptomatic lesions can be treated with photodynamic therapy (PDT), plaque brachytherapy, or occasionally triple freeze-thaw transconjunctival cryotherapy. (Treatment Modality)

#### Conditions Associated with Secondary Vasoproliferative Tumours

    - Intermediate uveitis
    - Retinitis pigmentosa (RP)
    - Toxoplasmosis
    - Toxocariasis
    - Retinal detachment surgery
    - Sickle-cell disease
    - Retinochoroidal coloboma
    - Coats’ disease
    - Retinopathy of prematurity (ROP)
    - Waardenburg syndrome

## Other Retinal Tumours

### Astrocytoma

- Definition: Rare benign tumour of the neurosensory retina, composed of astrocytes; debate as to whether it is acquired or a hamartoma. (Pathology)
- Presentation: Typically presents in childhood/adolescence; both sexes are equally affected.
- Systemic Association:
  - Isolated astrocytomas are usually not associated with systemic disease.
  - Most multiple/bilateral tumours are seen in the context of **tuberous sclerosis**. (Systemic Association)
  - An association with **neurofibromatosis type 1 (NF-1)** is also suggested. (Systemic Association)
- Clinical Features:
  - Decreased visual acuity (dVA), but often asymptomatic.
  - Superficial white, well-defined lesion (translucent to calcified ‘mulberry’ type; flat or nodular). (Clinical Finding)
  - Potential complication: exudative retinal detachment (ERD). (Complication)
- Investigations and Treatment:
  - Further evaluation is not usually required, other than ruling out possible syndromic associations. (Management)

## Retinal Pigment Epithelium (RPE) Tumours

### Congenital Hypertrophy of Retinal Pigment Epithelium (CHRPE)

- Definition: Common benign congenital proliferation of the RPE, occurring in about 1% of the population (typical form). (Pathology)
- Typical Form:
  - Unilateral and either solitary or, more commonly, grouped (‘bear tracks’).
  - Unrelated to systemic disease.
- Atypical Form:
  - Bilateral and multifocal.
  - Associated with **familial adenomatous polyposis (FAP)** and its variants. (Systemic Association)
- Histology: RPE cells show increased height and increased numbers of melanin granules.
- Clinical Features:
  - Typical CHRPE:
    - Solitary: Black, well-defined, flat, round lesion, often with depigmented ‘lacunae’ within it, deep to the neurosensory retina; usually 2–5mm. May show slow progressive enlargement. Rarely give rise to elevated solid neoplasms of the RPE. (Clinical Finding)
    - Grouped: Similar smaller lesions, grouped to form ‘bear tracks’; usually <2mm. (Clinical Finding)
  - Atypical CHRPE:
    - Bilateral, multiple, widely separated, black oval lesions with irregular depigmentation; usually <2mm. (Clinical Finding)
- Investigations and Treatment:
  - Typical CHRPE does not require investigation. (Management)
  - Atypical CHRPE should prompt an investigation of family history and consideration of referral to a gastroenterologist. (Management)
  - If familial adenomatous polyposis is diagnosed, prophylactic colectomy is recommended.
  - In untreated FAP, the development of colonic carcinoma is almost universal. (Prognosis)

### Combined Hamartoma of the RPE and Retina

- Definition: Rare benign hamartoma of the RPE, retinal astrocytes, and retinal vasculature. (Pathology)
- Systemic Association:
  - Usually not related to systemic disease.
  - May be associated with **neurofibromatosis type 2 (NF-2)** and rarely NF-1. (Systemic Association)
- Clinical Features:
  - Decreased visual acuity (dVA), floaters, leucocoria.
  - Elevated lesion, with whitish sheen superficially (epiretinal membrane and intraretinal gliosis), tortuous vessels, and variable deeper pigmentation; usually juxtapapillary but may be peripheral; usually 4–6mm in diameter. (Clinical Finding)
- Investigations and Treatment:
  - Assess for the possibility of underlying neurofibromatosis. (Management)

## Associated Syndromes Tables

### Table: Features of Von Hippel-Lindau (VHL) Syndrome

| Ocular                      | Extraocular                                                      |
|-----------------------------|------------------------------------------------------------------|
| Retinal capillary haemangioma | Haemangioblastoma of cerebellum, spinal cord, or brainstem       |
|                             | Renal cell carcinoma                                             |
|                             | Phaeochromocytoma                                                |
|                             | Islet cell carcinoma                                             |
|                             | Epididymal cysts/adenomas                                        |
|                             | Visceral cysts                                                   |

### Table: Features of Wyburn–Mason Syndrome

| Ocular                | Extraocular             |
|-----------------------|-------------------------|
| Retinal AVM           | Cerebral/brainstem AVM  |
| Orbital/periorbital AVM |                         |

### Table: Features of Tuberous Sclerosis

| Ocular                | Extraocular                                           |
|-----------------------|-------------------------------------------------------|
| Retinal astrocytoma   | Adenoma sebaceum                                      |
|                       | Ash leaf spots                                        |
|                       | Shagreen patches                                      |
|                       | Subungual fibromas                                    |
|                       | Cerebral astrocytomas (with epilepsy and decreased IQ) |
|                       | Visceral hamartomas (e.g., renal angiomyolipoma, cardiac rhabdomyoma) |
|                       | Visceral cysts                                        |
|                       | Pulmonary lymphangioleiomyomatosis                    |

### Table: Features of Familial Adenomatous Polyposis (FAP)

| Ocular          | Extraocular                                              |
|-----------------|----------------------------------------------------------|
| Atypical CHRPE  | Colonic polyps and carcinoma                             |
|                 | Gardner’s variant: bone cysts, hamartomas, soft tissue tumours |
|                 | Turcot’s variant: CNS neuroepithelial tumours            |

### Table: Features of Neurofibromatosis Type 1 (NF-1)

- Diagnosis requires two or more of the major criteria highlighted by *.
| Ocular                               | Extraocular                                                                 |
|--------------------------------------|-----------------------------------------------------------------------------|
| Optic glioma* | Café-au-lait spots (≥6; each >0.5cm pre-puberty or >1.5cm post-puberty)*|
| Lisch nodules (≥2)* | Axillary/inguinal freckling*|
| Lid neurofibroma                     | Neurofibromas (≥1 plexiform type or ≥2 any type)* |
| Choroidal naevi                      | Characteristic bony lesion (sphenoid dysplasia; long bone cortex thinning/dysplasia)*|
| Retinal astrocytoma                  | First-degree relative with NF-1* |

### Table: Features of Neurofibromatosis Type 2 (NF-2)

- **Definite NF-2 Criteria:**
  - Bilateral acoustic neuroma, OR
  - First-degree relative with NF-2 AND either unilateral acoustic neuroma (at <30y) or two of the other diagnostic features.
- **Probable NF-2 Criteria:**
  - Unilateral acoustic neuroma (at <30y) AND one of the other diagnostic features, OR
  - Multiple meningiomas AND one of the other diagnostic features.
| Ocular                                        | Extraocular            |
|-----------------------------------------------|------------------------|
| Early-onset posterior subcapsular or cortical cataracts | Acoustic neuroma       |
| Combined hamartoma of the RPE and retina      | Meningioma             |
|                                               | Glioma                 |
|                                               | Schwannoma             |
|                                               | First-degree relative with NF-2 |

# Anti-Vascular Endothelial Growth Factor (Anti-VEGF) Therapy

## Overview & Mechanism

- VEGF-A is a protein that induces pathological angiogenesis, vascular permeability, and inflammation. (mechanism)
- Anti-VEGF therapies reduce vascular hyperpermeability, resolving retinal fluid and halting neovascularization. (mechanism)

## Drug Types

- **Ranibizumab:** A humanized monoclonal antibody fragment that binds all isoforms of VEGF-A. (drug)
- **Bevacizumab:** Derived from the same antibody as ranibizumab; commonly used off-label. (drug)
- **Aflibercept:** A 'fusion protein' acting as a decoy receptor, binding VEGF-A with high affinity and also PlGF 1 & 2. (drug)
- **Pegaptanib:** A selective VEGF inhibitor that is less effective and no longer in widespread use. (drug)

## Evidence for Use (by Indication)

### Wet Age-Related Macular Degeneration (AMD)

- **Ranibizumab:** MARINA & ANCHOR trials showed ~33% of patients gained ≥15 letters and ~95% avoided moderate vision loss with monthly injections. (evidence)
- **Bevacizumab:** CATT & IVAN studies demonstrated similar efficacy to ranibizumab. (evidence)
- **Aflibercept:** VIEW 1 & VIEW 2 studies showed ~30% gained ≥15 letters with an 8-week dosing schedule after initial loading doses. (evidence)

### Diabetic Macular Edema (DMO)

- **Ranibizumab:** RISE & RIDE trials showed up to 44.8% of patients gained ≥15 letters with monthly injections. (evidence)
- **Aflibercept:** VISTA & VIVID studies showed a mean gain of 10 letters at 3 years. (evidence)
- **Comparative Trials (DRCRNet):** Found all three drugs (Ranibizumab, Bevacizumab, Aflibercept) gave a 10-12 letter improvement at 2 years, with Aflibercept superior at 1 year in eyes with poor starting vision. (evidence)

### Retinal Vein Occlusion (RVO)

- **Ranibizumab:** CRUISE (CRVO) & BRAVO (BRVO) studies showed 47.5% and 61.1% of patients gained ≥15 letters, respectively. (evidence)
- **Aflibercept:** COPERNICUS/GALILEO (CRVO) & VIBRANT (BRVO) studies showed 55-60% and 57% of patients gained ≥15 letters, respectively. (evidence)

### Myopia-associated Choroidal Neovascularization (CNV)

- **Ranibizumab:** The RADIANCE study demonstrated superiority over PDT, with a mean gain of 13.8-14.4 letters at 12 months. (evidence)
- **Aflibercept:** The MYRROR study demonstrated superiority over sham, with a mean gain of 13.5 letters at 48 weeks. (evidence)

## Intravitreal Injection: In Practice

### Preparation & Consent

- Discuss the purpose (maintain/improve vision), risks, and need for multiple injections. (procedure)
- Explain the off-label status if using bevacizumab. (procedure)
- Injections are performed in a dedicated clean room or theatre.

### Injection Procedure

- **Anesthesia:** Instill topical anesthetic drops, with optional subconjunctival supplementation. (procedure)
- **Asepsis:** Clean the periocular area with 5% povidone-iodine and use a sterile drape and lid speculum. (procedure)
- **Injection:**
- Use a 27-30G needle.
- Inject 3.0-4.0mm posterior to the limbus, aiming for the center of the globe.
- Indicated volume is typically 0.05mL.
- Apply counterpressure with a sterile cotton tip to prevent reflux.

### Post-injection & Follow-up

- **Immediate Checks:** Test gross vision, check central retinal artery patency, and optionally check IOP. (procedure)
- **Medication:** Topical antibiotics (e.g., chloramphenicol) are often prescribed for ≥3 days. (procedure)
- **Monitoring:** Review in clinic according to the specific retreatment regimen (e.g., as-needed, treat-and-extend).
- **Signs of Disease Activity:** (diagnosis)
- Deterioration in VA.
- Leakage on fluorescein angiography.
- Fluid on OCT (intraretinal, subretinal, or sub-RPE).
- New or recurrent hemorrhage.

## Risks & Contraindications

### Potential Complications

- **Endophthalmitis:** <0.1% risk; patients must be warned of symptoms (pain, redness, vision loss). (risk)
- **Retinal Detachment** (risk)
- **Lens Damage / Cataract** (risk)
- **Raised Intraocular Pressure (IOP)** (risk)
- **Conjunctival Hemorrhage** (common side effect)
- **Vitreous Floaters** (common side effect)

### Contraindications

- Allergy to any drug components.
- Active ocular or periocular infections.

## NICE Guidelines (UK Summary)

- **Wet AMD:** Ranibizumab and Aflibercept recommended for VA between 6/12 and 6/96 with evidence of active disease. (guideline)
- **DMO:** Ranibizumab and Aflibercept recommended if central retinal thickness is ≥400 microns. (guideline)
- **RVO:** Ranibizumab and Aflibercept approved for macular edema secondary to RVO. (guideline)
- **Myopic CNV:** Ranibizumab approved for treatment. (guideline)
- **Steroid Implants:** Dexamethasone and Fluocinolone implants are also NICE-approved for specific cases of DMO and RVO. (guideline)

# Photodynamic Therapy (PDT)

## Mechanism

- A photoactivated dye (Verteporfin) binds to lipoproteins in proliferating vessels (e.g., CNV). (mechanism)
- A non-thermal laser (689nm) activates the dye, creating free radicals that cause local endothelial cell death and vessel occlusion. (mechanism)

## Indications

- **Historic:** Primary treatment for classic subfoveal CNV, now largely replaced by anti-VEGF therapy. (indication)
- **Current Niche:** Central Serous Chorioretinopathy (CSC), Polypoidal Choroidal Vasculopathy (PCV), and certain ocular tumors like choroidal hemangiomas. (indication)

## Procedure: In Practice

- **Preparation:** Calculate spot size, ensure patient safety precautions, and obtain consent. (procedure)
- **Infusion:** Reconstituted Verteporfin (6mg/m²) is infused intravenously over 10 minutes. (procedure)
- **Laser Application:** 83 seconds of laser is applied 15 minutes after the start of the infusion. (procedure)
- **Follow-up:** Review with FFA/ICG and OCT at 12 weeks; retreatment can occur up to 4 times per year if leakage recurs.

## Risks & Patient Advice

### Side Effects & Contraindications

- **Injection Site Reactions:** Inflammation, leakage. (risk)
- **Back Pain:** Occurs in ~2% of patients during infusion. (risk)
- **Transient Visual Disturbances** (risk)
- **Significant Visual Loss:** Occurs in up to 4% of cases. (risk)
- **Contraindications:** Liver failure, porphyria, allergy.

### Patient Advice

- **Photosensitivity:** Patient must avoid direct sunlight and bright indoor lights for 48 hours post-treatment. (procedure)
- **Protective Measures:** Wear a wide-brimmed hat, sunglasses, and long sleeves if outdoors. (procedure)

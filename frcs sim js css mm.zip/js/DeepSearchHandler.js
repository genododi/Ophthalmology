class DeepSearchHandler {
    constructor() {
        this.questionGenerator = null;
        this.ui = null;
        this.cachedAnalysis = new Map(); // Cache analysis results by question ID
        this.isProcessing = false;
    }

    initialize(questionGenerator, ui) {
        this.questionGenerator = questionGenerator;
        this.ui = ui;
    }

    async performDeepSearch(question, answer) {
        if (!this.questionGenerator) {
            console.error('Question generator not initialized for deep search');
            return '';
        }

        try {
            // Show loading state in the UI
            this.ui.showStatus('Performing deep search analysis...', 'info');
            this.isProcessing = true;
            
            // Generate a unique ID for caching based on question and answer
            const cacheKey = this.generateCacheKey(question, answer);
            
            // Check if we already have a cached result
            if (this.cachedAnalysis.has(cacheKey)) {
                console.log('Using cached deep search result');
                this.isProcessing = false;
                return this.cachedAnalysis.get(cacheKey);
            }
            
            // Get the currently selected AI model
            const aiModel = this.questionGenerator.preferredModel || 'gemini';
            console.log(`Performing deep search with ${aiModel} model`);
            
            // Construct the prompt for deep searching
            const prompt = this.constructDeepSearchPrompt(question, answer);
            
            // Call the appropriate API based on the selected model
            let response;
            
            try {
                switch (aiModel) {
                    case 'gemini':
                        response = await this.questionGenerator.callGeminiApi(prompt, { numQuestions: 1 });
                        break;
                    case 'openai':
                        response = await this.questionGenerator.callOpenAIApi(prompt, { numQuestions: 1 });
                        break;
                    case 'claude':
                        response = await this.questionGenerator.callClaudeApi(prompt, { numQuestions: 1 });
                        break;
                    case 'biomistral':
                        response = await this.questionGenerator.callBioMistralApi(prompt, { numQuestions: 1 });
                        break;
                    case 'biogpt':
                        response = await this.questionGenerator.callBioGPTApi(prompt, { numQuestions: 1 });
                        break;
                    case 'cursor-ai':
                        response = await this.questionGenerator.callCursorAiApi(prompt, { numQuestions: 1 });
                        break;
                    default:
                        console.log(`Unknown model ${aiModel}, falling back to Gemini`);
                        response = await this.questionGenerator.callGeminiApi(prompt, { numQuestions: 1 });
                }
                
                console.log(`Received response from ${aiModel} API`, typeof response);
            } catch (apiError) {
                console.error(`Error calling ${aiModel} API:`, apiError);
                throw new Error(`Failed to get analysis from ${aiModel}: ${apiError.message}`);
            }
            
            // Process the response
            const processedResponse = this.processDeepSearchResponse(response);
            console.log('Processed deep search response', typeof processedResponse);
            
            // Add to cache
            this.cachedAnalysis.set(cacheKey, processedResponse);
            
            // Check if the response includes any image suggestions
            const imageKeywords = this.extractImageKeywords(question, answer);
            if (imageKeywords.length > 0 && window.ophthalmoImageGenerator) {
                // Attempt to find relevant images
                this.suggestRelevantImages(imageKeywords, processedResponse);
            }
            
            this.isProcessing = false;
            return processedResponse;
            
        } catch (error) {
            console.error('Deep search error:', error);
            this.ui.showStatus(`Error performing deep search: ${error.message}`, 'error');
            this.isProcessing = false;
            return `Error performing deep search: ${error.message}`;
        }
    }

    generateCacheKey(question, answer) {
        // Create a simple hash from the question and answer
        return `${question.substring(0, 50)}|${answer.substring(0, 50)}`;
    }

    constructDeepSearchPrompt(question, answer) {
        return `
You are an expert ophthalmologist providing a detailed explanation of an ophthalmology question and answer.

QUESTION: ${question}

ANSWER: ${answer}

Please provide a clear, detailed explanation of the answer to this question. Include:

1. A thorough explanation of the key concepts involved
2. Relevant clinical information (diagnosis, symptoms, pathophysiology)
3. Applicable treatments and management approaches
4. Important differential diagnoses when relevant
5. Any guidelines or evidence that supports the answer

Your explanation should be comprehensive but accessible, written in plain language without unnecessary jargon. Format your response as a series of clear paragraphs with appropriate headings. Do not use bulleted lists or numbered sections - just write in a natural, explanatory style.

IMPORTANT: This is not an academic paper - avoid formal scholarly formatting or citations. Focus on providing a clear, detailed explanation that would help someone understand the answer completely.
`;
    }

    processDeepSearchResponse(response) {
        // Clean up the response text
        if (!response) return '';
        
        let processedResponse = response;
        
        // Check if response is an object with a text property
        if (typeof response === 'object' && response.text) {
            processedResponse = response.text;
        }
        
        // For API-specific response formats
        if (typeof response === 'object') {
            // Gemini format
            if (response.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
                processedResponse = response.data.candidates[0].content.parts[0].text;
            }
            // OpenAI format
            else if (response.data?.choices?.[0]?.message?.content) {
                processedResponse = response.data.choices[0].message.content;
            }
            // Claude format
            else if (response.data?.content?.[0]?.text) {
                processedResponse = response.data.content[0].text;
            }
        }
        
        // Ensure the response is a string
        if (typeof processedResponse !== 'string') {
            processedResponse = String(processedResponse || '');
        }
        
        // Apply simple formatting for better readability
        return this.formatSimpleResponse(processedResponse);
    }
    
    formatSimpleResponse(text) {
        // Apply minimal formatting to make the text readable
        let formatted = text
            // Format headings (if any)
            .replace(/^(.*?):\s*$/gm, '<h3 class="text-lg font-semibold text-indigo-800 mt-4 mb-2">$1</h3>')
            
            // Format paragraphs
            .replace(/\n\n/g, '</p><p class="my-3">')
            
            // Format emphasized terms
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            
            // Format key terms related to ophthalmology
            .replace(/\b(diagnosis|treatment|management|pathophysiology|etiology|symptoms|prognosis)\b/gi,
                    '<span class="font-medium text-indigo-700">$1</span>');
        
        // Wrap in paragraph tags if not already formatted
        if (!formatted.startsWith('<')) {
            formatted = `<p class="my-3">${formatted}</p>`;
        }
        
        return formatted;
    }
    
    /**
     * Simple format for deep search results without structured sections
     */
    enhanceFrcsFormatting(html) {
        // Apply simple formatting only
        return html;
    }
    
    extractImageKeywords(question, answer) {
        // Extract potential image-related keywords from the question and answer
        const combinedText = `${question} ${answer}`;
        
        // Common ophthalmic conditions that might benefit from images
        const conditions = [
            'retina', 'macula', 'optic nerve', 'cornea', 'glaucoma', 
            'cataract', 'uveitis', 'keratitis', 'conjunctivitis',
            'diabetic retinopathy', 'macular degeneration', 'retinal detachment',
            'papilledema', 'keratoconus', 'pterygium', 'chalazion'
        ];
        
        const foundKeywords = [];
        
        for (const condition of conditions) {
            if (combinedText.toLowerCase().includes(condition.toLowerCase())) {
                foundKeywords.push(condition);
            }
        }
        
        return foundKeywords;
    }
    
    async suggestRelevantImages(keywords, processedResponse) {
        // This function attempts to find relevant images for the deep search analysis
        if (!window.ophthalmoImageGenerator || keywords.length === 0) return processedResponse;
        
        try {
            // Use the first keyword as the most relevant one
            const primaryKeyword = keywords[0];
            
            // Try to generate an image for this keyword
            const imageInfo = await window.ophthalmoImageGenerator.generateImage(primaryKeyword);
            
            if (imageInfo && imageInfo.url) {
                // If we found an image, enhance the response to include an image reference
                const imageHtml = `
                <div class="deep-analysis-image mt-4 mb-4 border border-indigo-200 rounded-lg p-3 bg-indigo-50">
                    <h4 class="text-base font-medium text-indigo-700 mb-2">Related Clinical Image</h4>
                    <div class="flex items-center">
                        <div class="w-1/3 pr-3">
                            <img src="${imageInfo.url}" alt="${imageInfo.keyword || primaryKeyword}" 
                                 class="ophthalmic-image w-full h-auto rounded cursor-pointer border border-gray-200"
                                 data-keyword="${imageInfo.keyword || primaryKeyword}"
                                 onclick="window.ophthalmoImageGenerator.showImagePreview('${imageInfo.url}', '${primaryKeyword}', '${imageInfo.keyword || primaryKeyword}')">
                        </div>
                        <div class="w-2/3">
                            <p class="text-sm text-gray-700">
                                <strong class="text-indigo-700">${imageInfo.keyword || primaryKeyword}:</strong> 
                                This image illustrates key features relevant to the question. Click to enlarge and view details.
                            </p>
                        </div>
                    </div>
                </div>
                `;
                
                // Add the image HTML to the response (before the last section)
                const recentAdvancesIndex = processedResponse.indexOf('RECENT ADVANCES');
                if (recentAdvancesIndex > 0) {
                    // Insert before RECENT ADVANCES section
                    return processedResponse.substring(0, recentAdvancesIndex) + 
                           imageHtml + 
                           processedResponse.substring(recentAdvancesIndex);
                } else {
                    // Or just append at the end
                    return processedResponse + imageHtml;
                }
            }
        } catch (error) {
            console.error('Error suggesting images for deep search:', error);
        }
        
        return processedResponse;
    }
}

// Initialize and export the deep search handler
window.deepSearchHandler = new DeepSearchHandler(); 
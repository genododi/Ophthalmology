class ExportHandler {
    constructor() {
        this.exportBtn = document.getElementById('export-btn');
        this.exportFormatSelect = document.getElementById('export-format');
    }

    setUI(ui) {
        this.ui = ui;
        this.initializeEventListeners();
    }

    setQuestionGenerator(questionGenerator) {
        this.questionGenerator = questionGenerator;
    }

    initializeEventListeners() {
        if (!this.ui) {
            console.error('UI must be set before initializing event listeners');
            return;
        }
        this.exportBtn.addEventListener('click', () => this.exportQuestions());
    }

    exportQuestions() {
        if (!this.questionGenerator || this.questionGenerator.generatedQuestions.length === 0) {
            this.ui.showStatus('No questions to export.', 'warning');
            return;
        }

        const format = this.exportFormatSelect.value;
        let exportContent = '';
        let mimeType = '';
        let fileExtension = '';

        try {
            const header = this.generateHeader();
            
            if (format === 'txt') {
                [exportContent, mimeType, fileExtension] = this.generateTextExport(header);
            } else if (format === 'json') {
                [exportContent, mimeType, fileExtension] = this.generateJsonExport(header);
            } else {
                throw new Error("Invalid export format selected.");
            }

            this.downloadFile(exportContent, mimeType, fileExtension);
            this.ui.showStatus(`Questions exported successfully as ${fileExtension.toUpperCase()}.`, 'success');

        } catch (error) {
            console.error("Export error:", error);
            this.ui.showStatus('Failed to export questions.', 'error');
        }
    }

    generateHeader() {
        const settings = this.questionGenerator.lastSettings;
        return {
            title: 'OphthalmoQA Generated Questions',
            sourceType: settings?.inputType || 'N/A',
            sourceIdentifier: settings?.source || 'N/A',
            subspecialtyFocus: settings?.subspecialtyText || 'N/A',
            difficulty: settings?.difficulty || 'N/A',
            additionalFocus: settings?.focusArea || 'None',
            generatedDate: new Date().toLocaleString()
        };
    }

    generateTextExport(header) {
        let content = `${header.title}\n` +
                     `Source Type: ${header.sourceType}\n` +
                     `Source Identifier: ${header.sourceIdentifier}\n` +
                     `Subspecialty Focus: ${header.subspecialtyFocus}\n` +
                     `Difficulty: ${header.difficulty}\n` +
                     `Additional Focus: ${header.additionalFocus}\n` +
                     `Generated: ${header.generatedDate}\n\n` +
                     "========================================\n\n";

        this.questionGenerator.generatedQuestions.forEach((item, index) => {
            content += `Q${index + 1} (${item.type || 'N/A'}): ${item.question || ''}\n`;
            
            if (item.type === 'mcq' && Array.isArray(item.options)) {
                item.options.forEach((option, i) => {
                    content += `  ${String.fromCharCode(65 + i)}. ${option}\n`;
                });
            } else if (item.type === 'matching' && Array.isArray(item.pairs)) {
                item.pairs.forEach((pair) => {
                    content += `  ${pair.item || '?'}  ->  ${pair.match || '?'}\n`;
                });
            }
            
            content += `\nAnswer: ${item.answer || ''}\n`;
            if (item.explanation) {
                content += `Explanation: ${item.explanation}\n`;
            }
            content += "\n----------------------------------------\n\n";
        });

        return [content, 'text/plain;charset=utf-8', 'txt'];
    }

    generateJsonExport(header) {
        const exportData = {
            metadata: {
                ...header,
                generatedDate: new Date().toISOString()
            },
            questions: this.questionGenerator.generatedQuestions
        };

        return [
            JSON.stringify(exportData, null, 2),
            'application/json;charset=utf-8',
            'json'
        ];
    }

    downloadFile(content, mimeType, fileExtension) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        const sourceName = this.questionGenerator.lastSettings?.source
            ? this.questionGenerator.lastSettings.source.replace(/[^a-z0-9]/gi, '_').substring(0, 20)
            : 'General';
            
        a.download = `OphthalmoQA_${sourceName}_${Date.now()}.${fileExtension}`;
        
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
} 
const fs = require('fs');
const path = require('path');

// Path to the file
const filePath = path.join(__dirname, 'js', 'QuestionGenerator.js');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Find the location where we want to add the new code
const insertAfterPattern = "            }\n            \n            // Call the Gemini API with enhanced prompt";
const insertBeforePattern = "            // Call the Gemini API with enhanced prompt";

// Our new code to add
const newCode = `            // For uploaded documents, strictly focus on the provided additional focus keywords if available
            if (this.lastSettings.inputType === 'upload' && this.lastSettings.focusArea && this.lastSettings.focusArea.trim()) {
                const focusKeywords = this.lastSettings.focusArea.trim();
                enhancedPrompt += \`\\n\\nCRITICAL INSTRUCTION: You MUST ONLY generate questions specifically about: \${focusKeywords}. 
                Every single question MUST directly involve \${focusKeywords}.
                Do NOT generate questions about other topics in the document, even if they seem relevant.
                Ignore all content not related to \${focusKeywords}.
                If there's limited content about \${focusKeywords}, use your expert knowledge to create appropriate questions on this specific topic.\`;
                
                console.log(\`Added strict focus on keywords: "\${focusKeywords}" for uploaded document\`);
            }
            
`;

// Replace the specified pattern with our new code followed by the original pattern
if (content.includes(insertAfterPattern)) {
    // If the specific pattern exists, insert after it
    content = content.replace(insertAfterPattern, `            }
            
            ${newCode}// Call the Gemini API with enhanced prompt`);
    console.log('Successfully added code after specific pattern.');
} else if (content.includes(insertBeforePattern)) {
    // Fallback: if specific pattern not found, try inserting before the call to Gemini API
    content = content.replace(insertBeforePattern, `${newCode}${insertBeforePattern}`);
    console.log('Successfully added code before Gemini API call.');
} else {
    console.error('Could not find the appropriate location to insert the code.');
    process.exit(1);
}

// Write the updated file
fs.writeFileSync(filePath, content, 'utf8');
console.log('Successfully updated the file.'); 
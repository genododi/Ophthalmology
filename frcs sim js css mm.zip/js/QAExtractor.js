/**
 * Q&A Extractor - Extracts existing questions and answers from documents
 * Handles various question formats commonly found in medical documents
 */

class QAExtractor {
    constructor() {
        this.patterns = {
            // Multiple choice questions with options A, B, C, D
            mcq: {
                question: /^(?:\d+\.?\s*|Q\d*\.?\s*)?(.+?)(?=\s*[A-Z]\.)/gm,
                options: /^([A-Z])\.\s*(.+)$/gm,
                answer: /(?:Answer|Ans|Correct|Solution):\s*([A-Z])/gi
            },
            
            // Numbered questions (1., 2., etc.)
            numbered: {
                question: /^(\d+\.?\s*)((?:(?!\d+\.).)+?)(?=(?:\d+\.|Answer|Ans|A:|Q\d+|$))/gms,
                answer: /(?:Answer|Ans|Solution):\s*(.+?)(?=(?:\d+\.|Q\d+|$))/gis
            },
            
            // Q: / A: format
            qanda: {
                question: /^Q(?:\d+)?:\s*(.+?)(?=\s*A:|$)/gims,
                answer: /^A(?:\d+)?:\s*(.+?)(?=\s*Q:|$)/gims
            },
            
            // Bold questions (often marked with **text** or <b>text</b>)
            bold: {
                question: /(?:\*\*|<b>|<strong>)(.+?)(?:\*\*|<\/b>|<\/strong>).*?(?=\*\*|<b>|<strong>|$)/gis,
                answer: /(?:Answer|Ans|Solution):\s*(.+?)(?=(?:\*\*|<b>|<strong>)|$)/gis
            },
            
            // Clinical case format
            clinical: {
                question: /(?:Case|Scenario|Patient)\s*\d*:\s*(.+?)(?=(?:Question|What|Which|How|Answer)|$)/gis,
                answer: /(?:Answer|Diagnosis|Management|Treatment):\s*(.+?)(?=(?:Case|Question)|$)/gis
            }
        };
        
        this.settings = {
            minQuestionLength: 20,
            maxQuestionLength: 1000,
            minAnswerLength: 5,
            maxAnswerLength: 2000,
            extractMCQ: true,
            extractNumbered: true,
            extractQandA: true,
            extractBold: true,
            extractClinical: true
        };
    }

    /**
     * Update extraction settings
     */
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
    }

    /**
     * Main extraction function
     */
    extractQuestionsAndAnswers(text, options = {}) {
        log('Starting Q&A extraction from document...', 'info');
        
        // Update settings if provided
        if (options) {
            this.updateSettings(options);
        }

        let extractedQA = [];
        
        // Clean and normalize text
        const cleanText = this.cleanText(text);
        log(`Cleaned text length: ${cleanText.length} characters`, 'info');

        try {
            // Extract using different patterns based on settings
            if (this.settings.extractMCQ) {
                const mcqQuestions = this.extractMCQQuestions(cleanText);
                extractedQA = extractedQA.concat(mcqQuestions);
                log(`Extracted ${mcqQuestions.length} MCQ questions`, 'info');
            }

            if (this.settings.extractNumbered) {
                const numberedQuestions = this.extractNumberedQuestions(cleanText);
                extractedQA = extractedQA.concat(numberedQuestions);
                log(`Extracted ${numberedQuestions.length} numbered questions`, 'info');
            }

            if (this.settings.extractQandA) {
                const qandaQuestions = this.extractQandAQuestions(cleanText);
                extractedQA = extractedQA.concat(qandaQuestions);
                log(`Extracted ${qandaQuestions.length} Q&A format questions`, 'info');
            }

            if (this.settings.extractBold) {
                const boldQuestions = this.extractBoldQuestions(cleanText);
                extractedQA = extractedQA.concat(boldQuestions);
                log(`Extracted ${boldQuestions.length} bold questions`, 'info');
            }

            if (this.settings.extractClinical) {
                const clinicalQuestions = this.extractClinicalQuestions(cleanText);
                extractedQA = extractedQA.concat(clinicalQuestions);
                log(`Extracted ${clinicalQuestions.length} clinical case questions`, 'info');
            }

        } catch (error) {
            log(`Error during extraction: ${error.message}`, 'error');
        }

        // Remove duplicates and clean up results
        extractedQA = this.removeDuplicates(extractedQA);
        extractedQA = this.validateQuestions(extractedQA);

        log(`Total extracted Q&A pairs: ${extractedQA.length}`, 'success');
        return extractedQA;
    }

    /**
     * Clean and normalize text for processing
     */
    cleanText(text) {
        return text
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .replace(/\t+/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim();
    }

    /**
     * Extract multiple choice questions
     */
    extractMCQQuestions(text) {
        const questions = [];
        const lines = text.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            
            // Look for question pattern
            if (this.isQuestionLine(line)) {
                const questionObj = {
                    question: this.cleanQuestionText(line),
                    options: [],
                    answer: '',
                    type: 'multiple-choice',
                    source: 'extracted',
                    confidence: 0.7
                };

                // Look for options in following lines
                let j = i + 1;
                while (j < lines.length && lines[j].trim()) {
                    const optionLine = lines[j].trim();
                    
                    // Check if it's an option (A., B., C., D., etc.)
                    const optionMatch = optionLine.match(/^([A-Z])\.\s*(.+)$/);
                    if (optionMatch) {
                        questionObj.options.push({
                            label: optionMatch[1],
                            text: optionMatch[2].trim()
                        });
                        j++;
                    } else if (this.isAnswerLine(optionLine)) {
                        // Found answer line
                        const answerMatch = optionLine.match(/(?:Answer|Ans|Correct):\s*([A-Z])/i);
                        if (answerMatch) {
                            questionObj.answer = answerMatch[1];
                            questionObj.confidence = 0.9;
                        }
                        break;
                    } else {
                        break;
                    }
                }

                // Only include if we found options
                if (questionObj.options.length >= 2 && 
                    questionObj.question.length >= this.settings.minQuestionLength) {
                    questions.push(questionObj);
                }
            }
        }

        return questions;
    }

    /**
     * Extract numbered questions
     */
    extractNumberedQuestions(text) {
        const questions = [];
        const matches = text.matchAll(this.patterns.numbered.question);
        
        for (const match of matches) {
            const questionText = match[2].trim();
            
            if (questionText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: questionText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.6
                };

                // Look for corresponding answer
                const answerPattern = new RegExp(
                    `(?:Answer|Ans|Solution)\\s*${match[1].replace(/\./g, '\\.')}?\\s*:?\\s*(.+?)(?=(?:\\d+\\.|Q\\d+|$))`,
                    'is'
                );
                const answerMatch = text.match(answerPattern);
                
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.8;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract Q&A format questions
     */
    extractQandAQuestions(text) {
        const questions = [];
        const questionMatches = Array.from(text.matchAll(this.patterns.qanda.question));
        const answerMatches = Array.from(text.matchAll(this.patterns.qanda.answer));
        
        // Try to pair questions with answers
        for (let i = 0; i < questionMatches.length; i++) {
            const questionText = questionMatches[i][1].trim();
            
            if (questionText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: questionText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.8
                };

                // Find corresponding answer
                if (i < answerMatches.length) {
                    questionObj.answer = answerMatches[i][1].trim();
                    questionObj.confidence = 0.9;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract bold/emphasized questions
     */
    extractBoldQuestions(text) {
        const questions = [];
        const matches = text.matchAll(this.patterns.bold.question);
        
        for (const match of matches) {
            const questionText = match[1].trim();
            
            if (questionText.length >= this.settings.minQuestionLength && 
                this.looksLikeQuestion(questionText)) {
                
                const questionObj = {
                    question: questionText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.5
                };

                // Look for nearby answer
                const context = text.substring(match.index, match.index + 500);
                const answerMatch = context.match(this.patterns.bold.answer);
                
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.7;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract clinical case questions
     */
    extractClinicalQuestions(text) {
        const questions = [];
        const matches = text.matchAll(this.patterns.clinical.question);
        
        for (const match of matches) {
            const caseText = match[1].trim();
            
            if (caseText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: `Clinical Case: ${caseText}`,
                    answer: '',
                    type: 'clinical-case',
                    source: 'extracted',
                    confidence: 0.7
                };

                // Look for corresponding answer/diagnosis
                const context = text.substring(match.index, match.index + 1000);
                const answerMatch = context.match(this.patterns.clinical.answer);
                
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.8;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Check if a line looks like a question
     */
    isQuestionLine(line) {
        // Check for question indicators
        const questionIndicators = [
            /^\d+\.?\s*.+\?/,  // Numbered question ending with ?
            /^Q\d*\.?\s*.+/,   // Q1., Q., etc.
            /What|Which|How|When|Where|Why|Can|Should|Does|Is|Are/i
        ];

        return questionIndicators.some(pattern => pattern.test(line)) &&
               line.length >= this.settings.minQuestionLength;
    }

    /**
     * Check if a line looks like an answer
     */
    isAnswerLine(line) {
        return /^(?:Answer|Ans|Solution|Correct):\s*/i.test(line);
    }

    /**
     * Check if text looks like a question
     */
    looksLikeQuestion(text) {
        const questionWords = ['what', 'which', 'how', 'when', 'where', 'why', 'can', 'should', 'does', 'is', 'are'];
        const hasQuestionWord = questionWords.some(word => 
            text.toLowerCase().includes(word)
        );
        
        return hasQuestionWord || text.includes('?') || 
               /^(?:Define|Explain|Describe|List|Name|Identify)/i.test(text);
    }

    /**
     * Clean question text
     */
    cleanQuestionText(text) {
        return text
            .replace(/^\d+\.?\s*/, '')  // Remove question numbers
            .replace(/^Q\d*\.?\s*/i, '') // Remove Q1., Q., etc.
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Remove duplicate questions
     */
    removeDuplicates(questions) {
        const seen = new Set();
        return questions.filter(q => {
            const key = q.question.toLowerCase().trim();
            if (seen.has(key)) {
                return false;
            }
            seen.add(key);
            return true;
        });
    }

    /**
     * Validate and filter questions
     */
    validateQuestions(questions) {
        return questions.filter(q => {
            // Check question length
            if (q.question.length < this.settings.minQuestionLength ||
                q.question.length > this.settings.maxQuestionLength) {
                return false;
            }

            // Check answer length if present
            if (q.answer && (q.answer.length < this.settings.minAnswerLength ||
                q.answer.length > this.settings.maxAnswerLength)) {
                // Don't filter out, just log
                log(`Answer length warning for question: ${q.question.substring(0, 50)}...`, 'warning');
            }

            // Basic quality checks
            if (q.question.split(' ').length < 3) {
                return false; // Too short
            }

            // Remove questions that are likely headers or non-questions
            if (/^(?:Chapter|Section|Part|Page|\d+\.?\s*$)/i.test(q.question.trim())) {
                return false;
            }

            return true;
        });
    }

    /**
     * Format extracted Q&A for display
     */
    formatForDisplay(extractedQA) {
        return extractedQA.map((qa, index) => ({
            id: `extracted_${index + 1}`,
            question: qa.question,
            answer: qa.answer || 'No answer found in document',
            type: qa.type,
            options: qa.options || [],
            source: 'extracted',
            confidence: qa.confidence,
            metadata: {
                extractionMethod: qa.type,
                originalIndex: index
            }
        }));
    }

    /**
     * Get extraction statistics
     */
    getExtractionStats(extractedQA) {
        const stats = {
            total: extractedQA.length,
            withAnswers: extractedQA.filter(qa => qa.answer && qa.answer.trim()).length,
            types: {},
            averageConfidence: 0
        };

        extractedQA.forEach(qa => {
            stats.types[qa.type] = (stats.types[qa.type] || 0) + 1;
            stats.averageConfidence += qa.confidence || 0;
        });

        if (extractedQA.length > 0) {
            stats.averageConfidence /= extractedQA.length;
        }

        return stats;
    }
}

// Make available globally
window.QAExtractor = QAExtractor; 
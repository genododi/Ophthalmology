class OphthalmoImageGenerator {
    constructor() {
        this.ui = null;
        this.questionGenerator = null;
        this.imageCache = new Map(); // Cache generated images by keyword
        this.currentPreviewImage = null;
        this.lastIdentifiedKeyword = null; // Track the last identified keyword for better display
        
        // Database of common ophthalmic conditions and their images
        this.ophthalmicImagesDB = {
            // Retinal conditions
            "retina": "https://eyewiki.aao.org/w/images/2/21/Normalretina.jpg",
            "diabetic retinopathy": "https://eyewiki.aao.org/w/images/6/68/NPDR.jpg",
            "proliferative diabetic retinopathy": "https://eyewiki.aao.org/w/images/c/ca/PDR2.jpg",
            "retinal detachment": "https://eyewiki.aao.org/w/images/9/96/RRD.jpg",
            "macular degeneration": "https://eyewiki.aao.org/w/images/6/60/Wet_AMD.jpg",
            "macular hole": "https://eyewiki.aao.org/w/images/d/d0/Macular_hole.jpg",
            "retinal vein occlusion": "https://eyewiki.aao.org/w/images/a/a2/CRVO.jpg",
            "retinal artery occlusion": "https://eyewiki.aao.org/w/images/6/62/CRAO.jpg",
            "retinitis pigmentosa": "https://eyewiki.aao.org/w/images/f/f4/RP2.jpg",
            
            // Corneal conditions
            "cornea": "https://eyewiki.aao.org/w/images/0/0e/Normal_cornea.jpg",
            "keratitis": "https://eyewiki.aao.org/w/images/6/69/HSV_keratitis.jpg",
            "keratoconus": "https://eyewiki.aao.org/w/images/9/94/Keratoconus.jpg",
            "corneal ulcer": "https://eyewiki.aao.org/w/images/5/5e/Corneal_ulcer.jpg",
            "fuchs dystrophy": "https://eyewiki.aao.org/w/images/8/8c/Fuchs.jpg",
            
            // Glaucoma
            "glaucoma": "https://eyewiki.aao.org/w/images/d/d0/Glaucomatous_optic_nerve.jpg",
            "primary open angle glaucoma": "https://eyewiki.aao.org/w/images/d/d0/Glaucomatous_optic_nerve.jpg",
            "angle closure glaucoma": "https://eyewiki.aao.org/w/images/1/17/Narrow_angle.jpg",
            "neovascular glaucoma": "https://eyewiki.aao.org/w/images/0/0a/Neovascular_glaucoma.jpg",
            
            // Cataract
            "cataract": "https://eyewiki.aao.org/w/images/c/cf/Nuclear_sclerotic_cataract.jpg",
            "nuclear sclerotic cataract": "https://eyewiki.aao.org/w/images/c/cf/Nuclear_sclerotic_cataract.jpg",
            "posterior subcapsular cataract": "https://eyewiki.aao.org/w/images/3/36/PSC.jpg",
            "cortical cataract": "https://eyewiki.aao.org/w/images/3/37/Cortical_cataract.jpg",
            
            // Uveitis
            "uveitis": "https://eyewiki.aao.org/w/images/8/83/Anterior_uveitis.jpg",
            "anterior uveitis": "https://eyewiki.aao.org/w/images/8/83/Anterior_uveitis.jpg",
            "posterior uveitis": "https://eyewiki.aao.org/w/images/e/e5/Posterior_uveitis.jpg",
            "panuveitis": "https://eyewiki.aao.org/w/images/f/f3/Panuveitis.jpg",
            
            // Optic nerve
            "optic neuritis": "https://eyewiki.aao.org/w/images/b/b9/Optic_neuritis.jpg",
            "optic nerve": "https://eyewiki.aao.org/w/images/b/b5/Normal_optic_nerve.jpg",
            "papilledema": "https://eyewiki.aao.org/w/images/2/22/Papilledema.jpg",
            "ischemic optic neuropathy": "https://eyewiki.aao.org/w/images/e/ef/AION.jpg",
            
            // External eye
            "conjunctivitis": "https://eyewiki.aao.org/w/images/f/f9/Bacterial_conjunctivitis.jpg",
            "pterygium": "https://eyewiki.aao.org/w/images/3/30/Pterygium.jpg",
            "pinguecula": "https://eyewiki.aao.org/w/images/6/69/Pinguecula.jpg",
            "blepharitis": "https://eyewiki.aao.org/w/images/b/b7/Blepharitis.jpg",
            "chalazion": "https://eyewiki.aao.org/w/images/7/7a/Chalazion.jpg",
            "hordeolum": "https://eyewiki.aao.org/w/images/6/60/Hordeolum.jpg",
            
            // Pediatric conditions
            "strabismus": "https://eyewiki.aao.org/w/images/a/a5/Strabismus.jpg",
            "amblyopia": "https://eyewiki.aao.org/w/images/5/5f/Amblyopia.jpg",
            "retinopathy of prematurity": "https://eyewiki.aao.org/w/images/4/49/ROP.jpg",
            
            // Refractive errors
            "myopia": "https://eyewiki.aao.org/w/images/3/30/Myopia_fundus.jpg",
            "hyperopia": "https://eyewiki.aao.org/w/images/2/25/Hyperopia_fundus.jpg",
            "astigmatism": "https://eyewiki.aao.org/w/images/7/76/Astigmatism.jpg",
            "presbyopia": "https://eyewiki.aao.org/w/images/2/24/Presbyopia.jpg",
            
            // Oculoplastics
            "ptosis": "https://eyewiki.aao.org/w/images/5/52/Ptosis.jpg",
            "ectropion": "https://eyewiki.aao.org/w/images/f/f9/Ectropion.jpg",
            "entropion": "https://eyewiki.aao.org/w/images/1/19/Entropion.jpg",
            "dermoid cyst": "https://eyewiki.aao.org/w/images/a/a7/Dermoid_cyst.jpg",
            "dermoid": "https://eyewiki.aao.org/w/images/a/a7/Dermoid_cyst.jpg",
            "orbital dermoid": "https://eyewiki.aao.org/w/images/a/a7/Dermoid_cyst.jpg",
            "lacrimal gland": "https://eyewiki.aao.org/w/images/d/d5/Lacrimal_gland.jpg",
            "dacryocystitis": "https://eyewiki.aao.org/w/images/4/42/Dacryocystitis.jpg",
            "periorbital cellulitis": "https://eyewiki.aao.org/w/images/8/89/Periorbital_cellulitis.jpg",
            "orbital cellulitis": "https://eyewiki.aao.org/w/images/8/8a/Orbital_cellulitis.jpg",
            "thyroid eye disease": "https://eyewiki.aao.org/w/images/1/19/Thyroid_eye_disease.jpg",
            "graves ophthalmopathy": "https://eyewiki.aao.org/w/images/1/19/Thyroid_eye_disease.jpg",
            "lid retraction": "https://eyewiki.aao.org/w/images/1/1b/Lid_retraction.jpg",
            "eyelid tumor": "https://eyewiki.aao.org/w/images/c/c1/Eyelid_tumor.jpg",
            "xanthelasma": "https://eyewiki.aao.org/w/images/2/23/Xanthelasma.jpg",
            
            // Ocular oncology
            "melanoma": "https://eyewiki.aao.org/w/images/e/ef/Choroidal_melanoma.jpg",
            "retinoblastoma": "https://eyewiki.aao.org/w/images/9/9f/Retinoblastoma.jpg",
            "ocular lymphoma": "https://eyewiki.aao.org/w/images/5/51/Ocular_lymphoma.jpg",
            "choroidal nevus": "https://eyewiki.aao.org/w/images/f/f5/Choroidal_nevus.jpg",
            "basal cell carcinoma": "https://eyewiki.aao.org/w/images/d/d9/Basal_cell_carcinoma.jpg",
            "squamous cell carcinoma": "https://eyewiki.aao.org/w/images/b/bc/Squamous_cell_carcinoma.jpg",
            
            // Surgical procedures
            "trabeculectomy": "https://eyewiki.aao.org/w/images/6/60/Trabeculectomy.jpg",
            "phacoemulsification": "https://eyewiki.aao.org/w/images/2/2d/Phacoemulsification.jpg",
            "intravitreal injection": "https://eyewiki.aao.org/w/images/3/32/Intravitreal_injection.jpg",
            "laser iridotomy": "https://eyewiki.aao.org/w/images/0/0f/Laser_iridotomy.jpg",
            "lasik": "https://eyewiki.aao.org/w/images/c/c5/Lasik.jpg",
            "prk": "https://eyewiki.aao.org/w/images/e/e7/PRK.jpg",
            "vitrectomy": "https://eyewiki.aao.org/w/images/d/d8/Vitrectomy.jpg",
            "penetrating keratoplasty": "https://eyewiki.aao.org/w/images/b/b1/Penetrating_keratoplasty.jpg",
            "scleral buckling": "https://eyewiki.aao.org/w/images/5/5c/Scleral_buckling.jpg",
            
            // Default image if no match is found
            "default": "https://eyewiki.aao.org/w/images/b/b5/Normal_optic_nerve.jpg"
        };
    }

    initialize(ui, questionGenerator) {
        this.ui = ui;
        this.questionGenerator = questionGenerator;
        this.initializeModal();
    }

    initializeModal() {
        // Create image preview modal
        if (!document.getElementById('ophthalmic-image-modal')) {
            const modal = document.createElement('div');
            modal.id = 'ophthalmic-image-modal';
            modal.className = 'fixed inset-0 z-50 flex items-center justify-center hidden';
            modal.innerHTML = `
                <div class="fixed inset-0 bg-black bg-opacity-50" id="ophthalmic-modal-backdrop"></div>
                <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full z-10 p-6 relative max-h-[90vh] overflow-y-auto">
                    <button id="close-ophthalmic-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                    <h3 class="text-xl font-semibold mb-4 text-primary" id="ophthalmic-image-title">Ophthalmic Image</h3>
                    <div class="flex flex-col md:flex-row gap-6">
                        <div class="flex-1 text-center flex flex-col items-center">
                            <img id="ophthalmic-image-preview" src="" alt="Ophthalmic Image" class="max-w-full max-h-[60vh] object-contain border border-gray-200 rounded-lg shadow-md">
                            <p id="ophthalmic-image-caption" class="mt-3 text-sm text-gray-600 italic"></p>
                        </div>
                        <div class="flex-1">
                            <div class="mb-4">
                                <h4 class="font-medium text-gray-800 mb-2">Clinical Information</h4>
                                <div id="ophthalmic-image-info" class="bg-gray-50 p-4 rounded-md text-sm"></div>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-800 mb-2">Related Conditions</h4>
                                <div id="ophthalmic-image-related" class="flex flex-wrap gap-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // Add event listeners
            document.getElementById('close-ophthalmic-modal').addEventListener('click', () => {
                this.hideImageModal();
            });

            document.getElementById('ophthalmic-modal-backdrop').addEventListener('click', () => {
                this.hideImageModal();
            });
        }
    }

    /**
     * Generate or retrieve an ophthalmic image based on question content
     * @param {string} questionText - The text of the question
     * @param {string} questionId - The ID of the question
     * @returns {Promise<object>} - Object containing URL of the image and identified keyword
     */
    async generateImage(questionText, questionId) {
        try {
            // Extract keywords from the question
            const keywords = this.extractKeywords(questionText);
            let identifiedKeyword = this.lastIdentifiedKeyword || null;
            
            if (keywords.length === 0) {
                console.log('No relevant keywords found in question');
                return {
                    url: this.ophthalmicImagesDB.default,
                    keyword: null
                };
            }
            
            // Check if we have an image for the primary keyword
            const primaryKeyword = keywords[0].toLowerCase();
            
            // Check cache first
            if (this.imageCache.has(primaryKeyword)) {
                console.log(`Using cached image for keyword: ${primaryKeyword}`);
                return {
                    url: this.imageCache.get(primaryKeyword),
                    keyword: identifiedKeyword || primaryKeyword
                };
            }
            
            // Direct match - check if the keyword is directly in our database
            if (this.ophthalmicImagesDB[primaryKeyword]) {
                const imageUrl = this.ophthalmicImagesDB[primaryKeyword];
                console.log(`Direct match found for keyword: ${primaryKeyword}`);
                this.imageCache.set(primaryKeyword, imageUrl);
                return {
                    url: imageUrl,
                    keyword: identifiedKeyword || primaryKeyword
                };
            }
            
            // Look for partial matches in our database
            for (const keyword of keywords) {
                const lowerKeyword = keyword.toLowerCase();
                for (const condition in this.ophthalmicImagesDB) {
                    if (condition === 'default') continue;
                    
                    if (lowerKeyword.includes(condition) || condition.includes(lowerKeyword)) {
                        const imageUrl = this.ophthalmicImagesDB[condition];
                        console.log(`Found matching image for keyword: ${keyword} (condition: ${condition})`);
                        
                        // Cache the result
                        this.imageCache.set(primaryKeyword, imageUrl);
                        
                        // Update identified keyword if we found a more specific match
                        if (!identifiedKeyword || condition.length > identifiedKeyword.length) {
                            identifiedKeyword = condition;
                        }
                        
                        return {
                            url: imageUrl,
                            keyword: identifiedKeyword
                        };
                    }
                }
            }
            
            // Special case for surgical questions
            if (questionText.toLowerCase().includes('surgical') || 
                questionText.toLowerCase().includes('surgery') ||
                questionText.toLowerCase().includes('management')) {
                
                // For surgical questions, look for surgical terms
                const surgicalTerms = [
                    "trabeculectomy", "phacoemulsification", "vitrectomy", 
                    "keratoplasty", "iridotomy", "lasik", "prk", "scleral buckling"
                ];
                
                for (const term of surgicalTerms) {
                    if (questionText.toLowerCase().includes(term)) {
                        const imageUrl = this.ophthalmicImagesDB[term] || this.ophthalmicImagesDB.default;
                        this.imageCache.set(primaryKeyword, imageUrl);
                        return {
                            url: imageUrl,
                            keyword: term
                        };
                    }
                }
            }
            
            // If no matching condition found, use default image
            console.log('No matching condition found, using default image');
            this.imageCache.set(primaryKeyword, this.ophthalmicImagesDB.default);
            return {
                url: this.ophthalmicImagesDB.default,
                keyword: identifiedKeyword || primaryKeyword
            };
            
        } catch (error) {
            console.error('Error generating ophthalmic image:', error);
            return {
                url: this.ophthalmicImagesDB.default,
                keyword: null
            };
        }
    }

    /**
     * Extract relevant ophthalmic keywords from text
     * @param {string} text - The text to extract keywords from
     * @returns {Array<string>} - Array of keywords
     */
    extractKeywords(text) {
        if (!text) return [];
        
        // Define common ophthalmic conditions to look for
        const commonConditions = Object.keys(this.ophthalmicImagesDB);
        
        // Extract condition mentions
        const keywords = [];
        const lowerText = text.toLowerCase();
        this.lastIdentifiedKeyword = null; // Reset last identified keyword
        
        // Look for multi-word conditions first (like "dermoid cyst")
        const multiWordConditions = commonConditions.filter(cond => cond.includes(' ') && cond !== 'default');
        for (const condition of multiWordConditions) {
            if (lowerText.includes(condition)) {
                keywords.push(condition);
                this.lastIdentifiedKeyword = condition; // Track the keyword we found
            }
        }
        
        // If no multi-word conditions found, check for single-word conditions
        if (keywords.length === 0) {
            const singleWordConditions = commonConditions.filter(cond => !cond.includes(' ') && cond !== 'default');
            for (const condition of singleWordConditions) {
                // Use word boundary regex to match whole words only
                const regex = new RegExp('\\b' + condition + '\\b', 'i');
                if (regex.test(lowerText)) {
                    keywords.push(condition);
                    this.lastIdentifiedKeyword = condition; // Track the keyword we found
                }
            }
        }
        
        // If still no specific conditions found, look for medical phrases
        if (keywords.length === 0) {
            // Define regex patterns for common ophthalmology phrases
            const patterns = [
                // Match phrases like "X syndrome", "X disease", etc.
                /\b(\w+)\s+(syndrome|disease|disorder|dystrophy|degeneration)\b/i,
                // Match surgical procedures
                /\b(surgery|surgical|procedure|operation|management|repair|removal)\s+of\s+(\w+)\b/i,
                // Match clinical presentations
                /\b(patient|case|presentation)\s+with\s+(\w+)\b/i
            ];
            
            for (const pattern of patterns) {
                const match = lowerText.match(pattern);
                if (match) {
                    // Extract the relevant part of the match
                    let extractedTerm = match[0];
                    // Check if this extracted term is related to any condition in our database
                    for (const condition of commonConditions) {
                        if (extractedTerm.includes(condition) || condition.includes(extractedTerm)) {
                            keywords.push(condition);
                            this.lastIdentifiedKeyword = condition;
                            break;
                        }
                    }
                    // If we found a term, stop looking
                    if (keywords.length > 0) break;
                }
            }
        }
        
        // If no specific conditions found, extract general eye anatomy terms
        if (keywords.length === 0) {
            const eyeTerms = [
                "cornea", "retina", "lens", "macula", "optic nerve", 
                "iris", "pupil", "sclera", "conjunctiva", "choroid",
                "vitreous", "anterior chamber", "posterior chamber", "eyelid",
                "orbit", "lacrimal", "canaliculi", "tear duct", "extraocular muscle"
            ];
            
            for (const term of eyeTerms) {
                if (lowerText.includes(term)) {
                    keywords.push(term);
                    this.lastIdentifiedKeyword = term;
                    break; // Just take the first match for simplicity
                }
            }
        }
        
        console.log("Extracted keywords:", keywords, "Last identified keyword:", this.lastIdentifiedKeyword);
        return keywords;
    }

    /**
     * Show the image preview modal
     * @param {string} imageUrl - URL of the image to preview
     * @param {string} questionText - The text of the question
     * @param {string} identifiedKeyword - The specific keyword identified in the question
     */
    showImagePreview(imageUrl, questionText, identifiedKeyword = null) {
        this.currentPreviewImage = imageUrl;
        
        const modal = document.getElementById('ophthalmic-image-modal');
        const imagePreview = document.getElementById('ophthalmic-image-preview');
        const imageTitle = document.getElementById('ophthalmic-image-title');
        const imageCaption = document.getElementById('ophthalmic-image-caption');
        const imageInfo = document.getElementById('ophthalmic-image-info');
        const imageRelated = document.getElementById('ophthalmic-image-related');
        
        if (!modal || !imagePreview) {
            console.error('Image preview modal elements not found');
            this.initializeModal(); // Try to create the modal if it doesn't exist
            
            // Get references again after initialization
            const modalAfterInit = document.getElementById('ophthalmic-image-modal');
            const imagePreviewAfterInit = document.getElementById('ophthalmic-image-preview');
            
            if (!modalAfterInit || !imagePreviewAfterInit) {
                console.error('Failed to initialize image preview modal');
                return;
            }
        }
        
        // Use provided identified keyword if available, otherwise extract from question
        let displayKeyword;
        if (identifiedKeyword) {
            // Format the identified keyword with proper capitalization
            displayKeyword = identifiedKeyword.split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
        } else {
            // Extract keywords for image caption as fallback
            const keywords = this.extractKeywords(questionText);
            displayKeyword = keywords.length > 0 ? 
                keywords[0].charAt(0).toUpperCase() + keywords[0].slice(1) : 
                'Ophthalmology';
        }
        
        // Set the image and details
        imagePreview.src = imageUrl;
        imagePreview.alt = `Clinical image of ${displayKeyword}`;
        imageTitle.textContent = `${displayKeyword} Image`;
        imageCaption.textContent = `Clinical image illustrating ${displayKeyword.toLowerCase()}`;
        
        // Enhance image experience with zoom capability
        imagePreview.onclick = function() {
            // Toggle a zoomed class
            this.classList.toggle('zoomed');
            if (this.classList.contains('zoomed')) {
                this.style.maxHeight = '80vh';
                this.style.cursor = 'zoom-out';
            } else {
                this.style.maxHeight = '60vh';
                this.style.cursor = 'zoom-in';
            }
        };
        
        // Generate clinical information
        let clinicalInfo = this.generateClinicalInfo(displayKeyword, questionText);
        imageInfo.innerHTML = clinicalInfo;
        
        // Add related conditions
        imageRelated.innerHTML = '';
        const relatedConditions = this.getRelatedConditions(displayKeyword.toLowerCase());
        
        // Make related conditions clickable to show those images
        relatedConditions.forEach(condition => {
            const chip = document.createElement('span');
            chip.className = 'bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full mr-1 mb-1 inline-block cursor-pointer hover:bg-blue-200 transition-colors';
            chip.textContent = condition;
            
            // Make related condition clickable to show that condition's image
            chip.addEventListener('click', async () => {
                try {
                    const relatedImageInfo = await this.generateImage(condition);
                    if (relatedImageInfo && relatedImageInfo.url) {
                        // Update the current image with the related condition image
                        imagePreview.src = relatedImageInfo.url;
                        imageTitle.textContent = `${condition} Image`;
                        imageCaption.textContent = `Clinical image illustrating ${condition.toLowerCase()}`;
                        
                        // Update clinical info for the new condition
                        imageInfo.innerHTML = this.generateClinicalInfo(condition, condition);
                    }
                } catch (error) {
                    console.error('Error loading related condition image:', error);
                }
            });
            
            imageRelated.appendChild(chip);
        });
        
        // Add source citation
        const sourceElement = document.createElement('div');
        sourceElement.className = 'text-xs text-gray-500 mt-4';
        sourceElement.innerHTML = `Source: EyeWiki by American Academy of Ophthalmology`;
        imageInfo.appendChild(sourceElement);
        
        // Add magnification controls
        const magnificationControls = document.createElement('div');
        magnificationControls.className = 'flex items-center justify-center mt-2 space-x-2';
        magnificationControls.innerHTML = `
            <button id="zoom-out-btn" class="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors">
                <i class="fas fa-search-minus text-gray-600"></i>
            </button>
            <span class="text-sm text-gray-600">Zoom</span>
            <button id="zoom-in-btn" class="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors">
                <i class="fas fa-search-plus text-gray-600"></i>
            </button>
        `;
        
        // Add the controls to the modal
        const controlsContainer = document.querySelector('#ophthalmic-image-modal .flex-1');
        if (controlsContainer) {
            // Check if controls already exist
            const existingControls = controlsContainer.querySelector('.flex.items-center.justify-center');
            if (existingControls) {
                existingControls.remove();
            }
            controlsContainer.appendChild(magnificationControls);
            
            // Add event listeners for zoom controls
            document.getElementById('zoom-in-btn').addEventListener('click', () => {
                const currentScale = imagePreview.style.transform ? 
                    parseFloat(imagePreview.style.transform.replace('scale(', '').replace(')', '')) : 1;
                const newScale = Math.min(currentScale + 0.1, 2);
                imagePreview.style.transform = `scale(${newScale})`;
            });
            
            document.getElementById('zoom-out-btn').addEventListener('click', () => {
                const currentScale = imagePreview.style.transform ? 
                    parseFloat(imagePreview.style.transform.replace('scale(', '').replace(')', '')) : 1;
                const newScale = Math.max(currentScale - 0.1, 0.5);
                imagePreview.style.transform = `scale(${newScale})`;
            });
        }
        
        // Show the modal
        modal.classList.remove('hidden');
    }

    /**
     * Hide the image preview modal
     */
    hideImageModal() {
        const modal = document.getElementById('ophthalmic-image-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    /**
     * Get related conditions for a given condition
     * @param {string} condition - The primary condition
     * @returns {Array<string>} - Array of related conditions
     */
    getRelatedConditions(condition) {
        const lowerCondition = condition.toLowerCase();
        
        // Map of related conditions
        const relatedConditionsMap = {
            'retina': ['Diabetic Retinopathy', 'Retinal Detachment', 'Macular Degeneration'],
            'diabetic retinopathy': ['Macular Edema', 'Vitreous Hemorrhage', 'Neovascular Glaucoma'],
            'macular degeneration': ['Geographic Atrophy', 'Choroidal Neovascularization', 'Drusen'],
            'glaucoma': ['Primary Open Angle Glaucoma', 'Angle Closure Glaucoma', 'Normal Tension Glaucoma'],
            'cataract': ['Nuclear Sclerosis', 'Posterior Subcapsular Cataract', 'Cortical Cataract'],
            'cornea': ['Keratitis', 'Keratoconus', 'Corneal Ulcer', 'Fuchs Dystrophy'],
            'uveitis': ['Anterior Uveitis', 'Posterior Uveitis', 'Panuveitis'],
            'optic nerve': ['Optic Neuritis', 'Papilledema', 'Ischemic Optic Neuropathy'],
            
            // Oculoplastics conditions
            'dermoid': ['Dermoid Cyst', 'Choristoma', 'Orbital Tumor', 'Epibulbar Dermoid'],
            'dermoid cyst': ['Epibulbar Dermoid', 'Orbital Tumor', 'Encephalocele', 'Lid Swelling'],
            'orbital dermoid': ['Orbital Tumor', 'Orbital Cyst', 'Mucocele', 'Cavernous Hemangioma'],
            'eyelid': ['Ptosis', 'Ectropion', 'Entropion', 'Chalazion', 'Blepharitis'],
            'ptosis': ['Levator Dehiscence', 'Myasthenia Gravis', 'Horner\'s Syndrome', 'Congenital Ptosis'],
            'chalazion': ['Meibomian Gland Dysfunction', 'Hordeolum', 'Sebaceous Cell Carcinoma'],
            'lacrimal gland': ['Dacryoadenitis', 'Lacrimal Gland Tumor', 'Sjogren\'s Syndrome'],
            'thyroid eye disease': ['Proptosis', 'Extraocular Muscle Restriction', 'Lid Retraction', 'Optic Neuropathy'],
            
            // Surgical procedures
            'trabeculectomy': ['Glaucoma Surgery', 'Filtration Surgery', 'Bleb Management', 'Antifibrotics'],
            'phacoemulsification': ['Cataract Surgery', 'IOL Implantation', 'Posterior Capsule Rupture', 'Zonular Dialysis'],
            'vitrectomy': ['Retinal Detachment', 'Macular Hole', 'Epiretinal Membrane', 'Vitreous Hemorrhage'],
            'scleral buckling': ['Retinal Detachment', 'Retinal Break', 'Cryotherapy', 'Laser Retinopexy'],
            'penetrating keratoplasty': ['Corneal Transplant', 'DSAEK', 'DMEK', 'Corneal Opacity'],
            
            // Additional categories
            'surgical management': ['Surgical Excision', 'Orbitotomy', 'Lid Reconstruction', 'Enucleation'],
            
            'default': ['Refractive Error', 'Dry Eye', 'Conjunctivitis', 'Presbyopia']
        };
        
        // First check for exact matches
        if (relatedConditionsMap[lowerCondition]) {
            return relatedConditionsMap[lowerCondition];
        }
        
        // Then check for partial matches
        for (const key in relatedConditionsMap) {
            if (lowerCondition.includes(key) || key.includes(lowerCondition)) {
                return relatedConditionsMap[key];
            }
        }
        
        // Check for surgical context
        if (lowerCondition.includes('surgical') || 
            lowerCondition.includes('surgery') || 
            lowerCondition.includes('management') ||
            lowerCondition.includes('procedure') ||
            lowerCondition.includes('operation')) {
            
            return relatedConditionsMap['surgical management'];
        }
        
        return relatedConditionsMap.default;
    }

    /**
     * Generate detailed clinical information for a condition
     */
    generateClinicalInfo(condition, context) {
        const lowerCondition = condition.toLowerCase();
        
        // Clinical information database
        const clinicalInfoMap = {
            'diabetic retinopathy': `
                <p class="mb-2"><strong>Diabetic Retinopathy (DR)</strong> is a microvascular complication of diabetes mellitus that affects the retina.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Microaneurysms - earliest clinically detectable lesions appearing as small red dots</li>
                    <li>Intraretinal hemorrhages - dot and blot hemorrhages in the deeper retinal layers</li>
                    <li>Hard exudates - yellowish deposits of lipid and protein with sharp margins</li>
                    <li>Cotton wool spots - fluffy white lesions representing nerve fiber layer infarcts</li>
                    ${lowerCondition.includes('proliferative') ? 
                      '<li>Neovascularization - abnormal new vessels at the disc (NVD) or elsewhere (NVE)</li>' : ''}
                </ul>
                <p>Classification: ${lowerCondition.includes('proliferative') ? 
                  'Proliferative Diabetic Retinopathy (PDR)' : 'Non-Proliferative Diabetic Retinopathy (NPDR)'}</p>
            `,
            'retinal detachment': `
                <p class="mb-2"><strong>Retinal Detachment</strong> refers to the separation of the neurosensory retina from the underlying retinal pigment epithelium (RPE).</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Elevation of the retina with a convex appearance</li>
                    <li>Loss of the normal red reflex in the detached area, appearing gray or opaque</li>
                    <li>Undulating movement of the detached retina with eye movement</li>
                    <li>Possible retinal tears or holes (predisposing factors)</li>
                    <li>Pigmented demarcation lines may be present in chronic cases</li>
                </ul>
                <p>Classification: Rhegmatogenous (tear-related), Tractional, or Exudative</p>
            `,
            'macular degeneration': `
                <p class="mb-2"><strong>Age-Related Macular Degeneration (AMD)</strong> is a degenerative disorder affecting the macula, the central portion of the retina.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Drusen - yellowish deposits beneath the retina</li>
                    <li>Pigmentary changes in the macula</li>
                    ${lowerCondition.includes('wet') || lowerCondition.includes('neovascular') ? 
                      '<li>Choroidal neovascularization (CNV) - abnormal blood vessels</li>' +
                      '<li>Subretinal fluid and/or hemorrhage</li>' +
                      '<li>Possible fibrovascular scarring in advanced cases</li>' : 
                      '<li>Geographic atrophy - well-demarcated areas of RPE loss</li>'}
                </ul>
                <p>Classification: ${lowerCondition.includes('wet') || lowerCondition.includes('neovascular') ? 
                  'Wet (Neovascular) AMD' : 'Dry (Non-neovascular) AMD'}</p>
            `,
            'glaucoma': `
                <p class="mb-2"><strong>Glaucoma</strong> is a progressive optic neuropathy characterized by specific structural changes to the optic nerve head.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Increased cup-to-disc ratio (CDR)</li>
                    <li>Thinning of the neuroretinal rim</li>
                    <li>Vertical elongation of the optic cup</li>
                    <li>ISNT rule violation (Inferior ≥ Superior > Nasal > Temporal rim thickness)</li>
                    <li>Potential disc hemorrhages at the rim</li>
                    <li>Retinal nerve fiber layer (RNFL) defects may be visible</li>
                </ul>
                <p>Classification: Primary Open Angle, Primary Angle Closure, Normal Tension, or Secondary Glaucoma</p>
            `,
            'keratoconus': `
                <p class="mb-2"><strong>Keratoconus</strong> is a non-inflammatory, progressive corneal ectasia characterized by thinning and steepening of the cornea.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Conical protrusion of the cornea</li>
                    <li>Corneal thinning, typically inferior/inferotemporal</li>
                    <li>Fleischer ring - iron deposition at the base of the cone</li>
                    <li>Vogt's striae - fine vertical lines in the posterior stroma</li>
                    <li>Possible scarring in advanced cases</li>
                </ul>
                <p>Classification: Mild, Moderate, or Severe based on corneal steepening and thickness</p>
            `,
            'dermoid cyst': `
                <p class="mb-2"><strong>Dermoid Cyst</strong> is a benign congenital choristoma typically located at the superotemporal orbital rim or limbus.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Well-circumscribed, smooth, round lesion</li>
                    <li>Yellowish-white or flesh-colored appearance</li>
                    <li>May contain dermal appendages (hair follicles, sebaceous glands)</li>
                    <li>Non-tender, fixed to underlying periosteum</li>
                    <li>May cause mechanical ptosis if large enough</li>
                </ul>
                <p>Classification: Orbital (deep) or Epibulbar (superficial, at limbus)</p>
            `
        };
        
        // Default clinical information if not found in the database
        const defaultInfo = `
            <p class="mb-2">This image shows a typical presentation of ${condition}.</p>
            <p class="mb-2">The key ophthalmological features visible include:</p>
            <ul class="list-disc ml-5 mb-2">
                <li>Characteristic anatomical appearance</li>
                <li>Typical tissue changes associated with this condition</li>
                <li>Relevant structural alterations visible on clinical examination</li>
            </ul>
            <p class="mt-2 text-sm italic">Question context: <span class="font-normal">${this.highlightKeywords(context, condition)}</span></p>
        `;
        
        // Check for exact matches
        for (const key in clinicalInfoMap) {
            if (lowerCondition.includes(key) || key.includes(lowerCondition)) {
                return clinicalInfoMap[key];
            }
        }
        
        return defaultInfo;
    }
    
    /**
     * Highlight keywords in text
     */
    highlightKeywords(text, keyword) {
        if (!keyword || !text) return text;
        
        const keywordPattern = new RegExp(`(${keyword})`, 'gi');
        return text.replace(keywordPattern, '<mark class="bg-yellow-200 px-0.5 rounded">$1</mark>');
    }
}

// Initialize and export
window.ophthalmoImageGenerator = new OphthalmoImageGenerator(); 
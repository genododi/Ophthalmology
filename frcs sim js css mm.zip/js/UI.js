class UI {
    constructor() {
        this.initializeElements();
        this.isProcessing = false;
        this.lastSettings = null;
    }

    initializeElements() {
        // Input elements
        this.inputTypeSelect = document.getElementById('input-type');
        this.uploadContainer = document.getElementById('upload-container');
        this.textContainer = document.getElementById('text-container');
        this.inputTextElement = document.getElementById('input-text');
        this.knowledgeAreaSelect = document.getElementById('knowledge-area');
        this.aiModelSelect = document.getElementById('ai-model');
        this.difficultySelect = document.getElementById('difficulty');
        this.numQuestionsInput = document.getElementById('num-questions');
        this.focusAreaInput = document.getElementById('focus-area');
        this.showAnswersDefaultCheckbox = document.getElementById('show-answers-default');
        this.exportFormatSelect = document.getElementById('export-format');

        // NotebookLM elements
        this.notebookContainer = document.getElementById('notebook-container');
        this.connectNotebookLmBtn = document.getElementById('connect-notebooklm');
        this.notebookStatus = document.getElementById('notebook-status');
        this.notebookStatusMessage = document.getElementById('notebook-status-message');
        this.notebookSelection = document.getElementById('notebook-selection');
        this.notebookSelect = document.getElementById('notebook-select');
        this.selectedNotebookInfo = document.getElementById('selected-notebook-info');
        this.selectedNotebookTitle = document.getElementById('selected-notebook-title');
        this.selectedNotebookDescription = document.getElementById('selected-notebook-description');

        // NotebookLM modal elements
        this.notebookLmModal = document.getElementById('notebooklm-modal');
        this.notebookLmModalBackdrop = document.getElementById('notebooklm-modal-backdrop');
        this.closeNotebookLmModalBtn = document.getElementById('close-notebooklm-modal');
        this.notebookLmCode = document.getElementById('notebooklm-code');
        this.notebookLmAuthStatus = document.getElementById('notebooklm-auth-status');
        this.authenticateNotebookLmBtn = document.getElementById('authenticate-notebooklm');

        // Buttons
        this.generateBtn = document.getElementById('generate-btn');
        this.clearBtn = document.getElementById('clear-btn');
        this.exportBtn = document.getElementById('export-btn');
        this.regenerateBtn = document.getElementById('regenerate-btn');

        // Containers
        this.qaContainer = document.getElementById('qa-container');
        this.questionContainer = this.qaContainer; // Alias for compatibility
        this.loadingIndicator = document.getElementById('loading-indicator');
        this.statusMessage = document.getElementById('status-message');

        // Question type checkboxes
        this.questionTypeCheckboxes = {
            mcq: document.getElementById('type-mcq'),
            tf: document.getElementById('type-tf'),
            matching: document.getElementById('type-matching'),
            shortAnswer: document.getElementById('type-short-answer'),
            clinicalCase: document.getElementById('type-clinical-case'),
            differential: document.getElementById('type-differential')
        };
    }

    initializeEventListeners() {
        // Main form controls
        this.inputTypeSelect.addEventListener('change', () => this.updateInputVisibility());
        this.knowledgeAreaSelect.addEventListener('change', () => this.updateKnowledgeAreaBehavior(this.knowledgeAreaSelect.value));
        this.clearBtn.addEventListener('click', () => this.clearAll());
        
        // Question container event delegation
        this.questionContainer.addEventListener('click', (event) => this.handleQuestionClick(event));
        
        // NotebookLM connect button
        this.connectNotebookLmBtn.addEventListener('click', () => this.showNotebookLmModal());
        
        // Add a direct FRCS notebook import button next to the connect button
        const directFrcsImportBtn = document.createElement('button');
        directFrcsImportBtn.className = 'bg-green-100 hover:bg-green-200 text-green-800 px-3 py-2 rounded-md text-sm transition flex items-center ml-2';
        directFrcsImportBtn.innerHTML = '<i class="fas fa-file-import mr-2"></i>Import FRCS Notebook';
        directFrcsImportBtn.title = 'Directly import your FRCS notebook';
        
        directFrcsImportBtn.addEventListener('click', async () => {
            try {
                this.showStatus('Importing your FRCS notebook...', 'info');
                
                if (!window.notebookLmHandler) {
                    throw new Error('NotebookLM handler not available');
                }
                
                // Make sure we're initialized
                if (!window.notebookLmHandler.isInitialized()) {
                    const defaultEmail = 'genododi@gmail.com';
                    const initialized = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                    
                    if (!initialized) {
                        throw new Error('Failed to initialize NotebookLM handler');
                    }
                }
                
                // Import the specific notebook
                const specificUrl = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
                const success = await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                
                if (success) {
                    this.showStatus('Successfully imported your FRCS notebook!', 'success');
                    
                    // Update UI and refresh notebooks
                    this.updateNotebookLmStatus();
                    this.loadNotebookOptions();
                } else {
                    throw new Error('Failed to import notebook');
                }
            } catch (error) {
                console.error('Error importing FRCS notebook:', error);
                this.showStatus('Error importing notebook: ' + error.message, 'error');
            }
        });
        
        // Add the button next to the connect button
        this.connectNotebookLmBtn.parentNode.insertBefore(directFrcsImportBtn, this.connectNotebookLmBtn.nextSibling);
        
        // NotebookLM notebook selection
        this.notebookSelect.addEventListener('change', () => this.handleNotebookSelection());

        // NotebookLM event listeners
        if (this.closeNotebookLmModalBtn) {
            this.closeNotebookLmModalBtn.addEventListener('click', () => this.hideNotebookLmModal());
        }

        if (this.notebookLmModalBackdrop) {
            this.notebookLmModalBackdrop.addEventListener('click', () => this.hideNotebookLmModal());
        }

        if (this.authenticateNotebookLmBtn) {
            this.authenticateNotebookLmBtn.addEventListener('click', () => this.handleNotebookLmAuthentication());
        }

        // Question type checkboxes
        Object.values(this.questionTypeCheckboxes).forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const anyChecked = Object.values(this.questionTypeCheckboxes).some(cb => cb.checked);
                if (!anyChecked) {
                    // Ensure at least one is checked
                    checkbox.checked = true;
                }
            });
        });
        
        // Show answers checkbox
        this.showAnswersDefaultCheckbox.addEventListener('change', () => {
            if (this.questionGenerator && this.questionGenerator.generatedQuestions.length > 0) {
                const questions = document.querySelectorAll('.question-item');
                questions.forEach(q => {
                    const answer = q.querySelector('.answer-container');
                    if (answer) {
                        answer.classList.toggle('hidden', !this.showAnswersDefaultCheckbox.checked);
                    }
                });
            }
        });
    }

    updateInputVisibility() {
        const selectedValue = this.inputTypeSelect.value;
        this.uploadContainer.classList.toggle('hidden', selectedValue !== 'upload');
        this.textContainer.classList.toggle('hidden', selectedValue !== 'text');
        this.notebookContainer.classList.toggle('hidden', selectedValue !== 'notebooklm');
        
        // Update knowledge area behavior
        this.updateKnowledgeAreaBehavior(selectedValue);

        // If NotebookLM is selected, show connection status
        if (selectedValue === 'notebooklm') {
            this.updateNotebookLmStatus();
        }
    }

    updateKnowledgeAreaBehavior(selectedValue) {
        const knowledgeAreaLabel = document.querySelector('label[for="knowledge-area"]');
        const knowledgeAreaHelpText = this.knowledgeAreaSelect.nextElementSibling;

        if (selectedValue === 'knowledge-base') {
            knowledgeAreaLabel.textContent = 'Select Knowledge Area';
            knowledgeAreaHelpText.textContent = 'Generates questions based on the selected built-in topic.';
            this.knowledgeAreaSelect.querySelector('option[value="general"]').disabled = true;
            if (this.knowledgeAreaSelect.value === 'general') this.knowledgeAreaSelect.value = 'all';
            // Enable 'all' option for knowledge-base
            this.knowledgeAreaSelect.querySelector('option[value="all"]').disabled = false;
        } else {
            knowledgeAreaLabel.textContent = 'Select Subspecialty Focus';
            knowledgeAreaHelpText.textContent = 'Guides question generation for all input types.';
            this.knowledgeAreaSelect.querySelector('option[value="general"]').disabled = false;
            // Disable 'all' option for other input types
            this.knowledgeAreaSelect.querySelector('option[value="all"]').disabled = true;
            if (this.knowledgeAreaSelect.value === 'all') this.knowledgeAreaSelect.value = 'general';
        }
    }

    clearAll() {
        // Call file handler's clearFileInput method if available
        if (this.fileHandler && typeof this.fileHandler.clearFileInput === 'function') {
            this.fileHandler.clearFileInput();
        }
        
        // Reset all form elements
        this.inputTextElement.value = '';
        this.knowledgeAreaSelect.value = 'general';
        // Set AI model to default from config
        if (this.aiModelSelect) {
            this.aiModelSelect.value = CONFIG.DEFAULT_MODEL || 'gemini';
        }
        this.difficultySelect.selectedIndex = 0;
        this.numQuestionsInput.value = 10;
        this.focusAreaInput.value = '';
        this.showAnswersDefaultCheckbox.checked = false;
        
        // Reset NotebookLM selection if available
        if (this.notebookSelect) {
            this.notebookSelect.selectedIndex = 0;
            if (this.selectedNotebookInfo) {
                this.selectedNotebookInfo.classList.add('hidden');
            }
        }
        
        Object.values(this.questionTypeCheckboxes).forEach(cb => cb.checked = (cb.id === 'type-mcq'));
        
        this.inputTypeSelect.value = 'upload';
        this.updateInputVisibility();
        this.qaContainer.innerHTML = '<p class="empty-state">Generated questions will appear here. Configure your settings and click "Generate Questions" to begin.</p>';
        
        // Reset question generator state if it exists
        if (this.questionGenerator) {
            this.questionGenerator.generatedQuestions = [];
            this.questionGenerator.lastSettings = null;
            // Update preferred model in question generator
            if (this.aiModelSelect) {
                this.questionGenerator.preferredModel = this.aiModelSelect.value;
                localStorage.setItem('ophthalmoqa_preferred_model', this.aiModelSelect.value);
            }
        }
        
        // Reset UI state
        this.lastSettings = null;
        
        this.updateButtonStates(false);
        this.showStatus('Form cleared.', 'info');
    }

    handleQuestionClick(event) {
        // Handle toggle answer button clicks
        if (event.target.closest('.toggle-answer') || event.target.closest('.toggle-answer-btn')) {
            const questionItem = event.target.closest('.question-item');
            if (questionItem) {
                const answerContainer = questionItem.querySelector('.answer-container') || 
                                       questionItem.querySelector('.answer-section');
                
                if (answerContainer) {
                    const isHidden = answerContainer.classList.contains('hidden');
                    answerContainer.classList.toggle('hidden');
                    
                    // Update the button text
                    const toggleButton = questionItem.querySelector('.toggle-answer') || 
                                        questionItem.querySelector('.toggle-answer-btn');
                    
                    if (toggleButton) {
                        const icon = toggleButton.querySelector('i');
                        if (icon) {
                            icon.className = isHidden ? 'fas fa-eye-slash mr-1' : 'fas fa-eye mr-1';
                        }
                        
                        // Try to update text content
                        const buttonText = toggleButton.childNodes[toggleButton.childNodes.length - 1];
                        if (buttonText && buttonText.nodeType === Node.TEXT_NODE) {
                            buttonText.nodeValue = isHidden ? ' Hide Answer' : ' Show Answer';
                        } else if (toggleButton.textContent) {
                            toggleButton.textContent = isHidden ? 'Hide Answer' : 'Show Answer';
                            // Re-add the icon if it was removed
                            if (icon) {
                                toggleButton.prepend(icon);
                            }
                        }
                    }
                }
            }
        }
        
        // Handle feedback button clicks
        if (event.target.closest('.feedback-btn')) {
            const button = event.target.closest('.feedback-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            const rating = button.getAttribute('data-feedback');
            
            // Find the question text and answer text from the DOM
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                 questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Process the feedback
            if (window.feedback) {
                window.feedback.processFeedback(questionId, rating, questionText, answerText);
            } else if (typeof this.processFeedback === 'function') {
                this.processFeedback(questionId, rating, questionText, answerText);
            }
            
            // Visual feedback
            const container = button.closest('.feedback-container');
            if (container) {
                const thankYouElement = container.querySelector('.feedback-thank-you');
                if (thankYouElement) {
                    // Show thank you message
                    thankYouElement.classList.remove('hidden');
                    // Hide after 3 seconds
                    setTimeout(() => {
                        thankYouElement.classList.add('hidden');
                    }, 3000);
                }
                
                // Highlight the selected button
                const buttons = container.querySelectorAll('.feedback-btn');
                buttons.forEach(btn => {
                    btn.classList.remove('active');
                    if (btn === button) {
                        btn.classList.add('active');
                        if (rating === 'like' || rating === 'positive') {
                            btn.classList.add('text-green-500');
                            btn.classList.remove('text-gray-400');
                        } else {
                            btn.classList.add('text-red-500');
                            btn.classList.remove('text-gray-400');
                        }
                    } else {
                        btn.classList.remove('text-green-500', 'text-red-500');
                        btn.classList.add('text-gray-400');
                    }
                });
            }
        }
        
        // Handle deep search button clicks
        if (event.target.closest('.deep-search-btn')) {
            const button = event.target.closest('.deep-search-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            
            // Find the question text and answer text
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Get the result container
            const resultContainer = questionItem.querySelector('.deep-search-result');
            
            // If already searching or has results, toggle visibility
            if (resultContainer.classList.contains('searching') || 
                (resultContainer.textContent.trim() !== '' && resultContainer.classList.contains('hidden'))) {
                resultContainer.classList.toggle('hidden');
                return;
            }
            
            // If we have results but it's visible, hide it
            if (resultContainer.textContent.trim() !== '' && !resultContainer.classList.contains('hidden')) {
                resultContainer.classList.add('hidden');
                return;
            }
            
            // Otherwise, perform deep search
            this.performDeepSearch(questionId, questionText, answerText, resultContainer);
        }

        // Handle show image button clicks
        if (event.target.closest('.show-image-btn')) {
            const button = event.target.closest('.show-image-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            
            // Find the question text and answer text
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Get the image container
            const imageContainer = questionItem.querySelector('.ophthalmic-image-container');
            
            // If already visible, just toggle visibility
            if (!imageContainer.classList.contains('hidden')) {
                imageContainer.classList.add('hidden');
                // Update the button text
                button.innerHTML = '<i class="fas fa-image mr-1"></i> Show Image';
                return;
            }
            
            // Update the button text before showing the image
            button.innerHTML = '<i class="fas fa-eye-slash mr-1"></i> Hide Image';
            
            // Load and display the image
            this.loadOphthalmicImage(questionId, questionText, answerText, imageContainer);
        }

        // Handle photo thumbnail clicks
        if (event.target.closest('.photo-thumbnail')) {
            const thumbnail = event.target.closest('.photo-thumbnail');
            const questionItem = thumbnail.closest('.question-item');
            const photoPreview = questionItem.querySelector('.photo-preview');
            const photoGrid = questionItem.querySelector('.photo-grid');
            
            // Get image data from data attributes
            const imageUrl = thumbnail.getAttribute('data-url');
            const imageTitle = thumbnail.getAttribute('data-title');
            const imageSource = thumbnail.getAttribute('data-source');
            
            if (imageUrl) {
                // Set the preview image
                const previewImage = photoPreview.querySelector('.photo-preview-image');
                previewImage.src = imageUrl;
                previewImage.alt = imageTitle || 'Ophthalmic Image';
                
                // Set the title and source
                photoPreview.querySelector('.photo-preview-title').textContent = imageTitle || 'Ophthalmic Image';
                const sourceLink = photoPreview.querySelector('.photo-preview-source');
                sourceLink.href = imageSource || '#';
                sourceLink.textContent = imageSource ? 'View Source' : 'No Source Available';
                
                // Hide the grid and show the preview
                photoGrid.classList.add('hidden');
                photoPreview.classList.remove('hidden');
            }
        }

        // Handle close photo preview button clicks
        if (event.target.closest('.close-photo-preview')) {
            const button = event.target.closest('.close-photo-preview');
            const photoPreview = button.closest('.photo-preview');
            const questionItem = button.closest('.question-item');
            const photoGrid = questionItem.querySelector('.photo-grid');
            
            // Hide the preview and show the grid
            photoPreview.classList.add('hidden');
            photoGrid.classList.remove('hidden');
        }
    }

    async performDeepSearch(questionId, questionText, answerText, resultContainer) {
        // Make sure the deep search handler is available
        if (!window.deepSearchHandler) {
            console.error('Deep search handler not available');
            this.showStatus('Deep search feature not available', 'error');
            resultContainer.innerHTML = `
                <div class="bg-red-50 p-4 rounded-md text-red-800">
                    <p>Deep search feature is not available. Please reload the page and try again.</p>
                </div>
            `;
            return;
        }
        
        try {
            // Show loading state
            resultContainer.innerHTML = `
                <div class="flex justify-center items-center py-4">
                    <div class="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
                    <span class="ml-3 text-indigo-800">Analyzing with scholarly resources...</span>
                </div>
            `;
            resultContainer.classList.add('searching');
            resultContainer.classList.remove('hidden');
            
            // Get the current AI model
            const aiModel = this.questionGenerator?.preferredModel || 'gemini';
            console.log(`Performing deep search using ${aiModel} model`);
            
            // Perform the deep search
            const result = await window.deepSearchHandler.performDeepSearch(questionText, answerText);
            
            if (result) {
                console.log('Deep search completed successfully');
                // Display the result
                resultContainer.innerHTML = `
                    <div class="bg-indigo-50 p-4 rounded-md">
                        <div class="flex justify-between items-start mb-2">
                            <h3 class="text-lg font-semibold text-indigo-800">Scholarly Analysis</h3>
                            <div>
                                <button class="print-deep-search text-sm text-indigo-600 hover:text-indigo-800 mr-2" title="Print analysis">
                                    <i class="fas fa-print"></i>
                                </button>
                                <button class="close-deep-search text-sm text-indigo-600 hover:text-indigo-800">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="deep-analysis-content prose prose-sm max-w-none">
                            ${result}
                        </div>
                    </div>
                `;
                
                // Add event listener to close button
                const closeButton = resultContainer.querySelector('.close-deep-search');
                if (closeButton) {
                    closeButton.addEventListener('click', () => {
                        resultContainer.classList.add('hidden');
                    });
                }
                
                // Add event listener to print button
                const printButton = resultContainer.querySelector('.print-deep-search');
                if (printButton) {
                    printButton.addEventListener('click', () => {
                        this.printDeepSearchAnalysis(questionText, result);
                    });
                }
                
                // Add event listeners to any images in the deep search result
                const images = resultContainer.querySelectorAll('.ophthalmic-image');
                if (images.length > 0 && window.ophthalmoImageGenerator) {
                    images.forEach(img => {
                        if (!img.hasAttribute('onclick')) {
                            img.addEventListener('click', () => {
                                const keyword = img.getAttribute('data-keyword') || '';
                                window.ophthalmoImageGenerator.showImagePreview(img.src, questionText, keyword);
                            });
                        }
                    });
                }
            } else {
                console.warn('Deep search returned empty result');
                resultContainer.innerHTML = `
                    <div class="bg-red-50 p-4 rounded-md text-red-800">
                        <p>Sorry, we couldn't generate a detailed analysis for this question. Please try again later.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error during deep search:', error);
            resultContainer.innerHTML = `
                <div class="bg-red-50 p-4 rounded-md text-red-800">
                    <p>Error performing deep search: ${error.message}</p>
                    <p class="text-xs mt-2">Try selecting a different AI model in the settings and try again.</p>
                </div>
            `;
            this.showStatus(`Deep search error: ${error.message}. Try a different AI model.`, 'error');
        } finally {
            resultContainer.classList.remove('searching');
        }
    }
    
    /**
     * Print the deep search analysis in a new window
     */
    printDeepSearchAnalysis(questionText, analysisHtml) {
        // Create a new window for printing
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        // Create the content for the print window
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>OphthalmoQA - Deep Analysis</title>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 20px;
                        padding-bottom: 20px;
                        border-bottom: 1px solid #eee;
                    }
                    .logo {
                        font-size: 24px;
                        font-weight: bold;
                        color: #2c6fa5;
                    }
                    .subtitle {
                        font-size: 14px;
                        color: #666;
                    }
                    .question-box {
                        background-color: #f8f9fa;
                        padding: 15px;
                        border-radius: 8px;
                        margin-bottom: 20px;
                        border-left: 4px solid #2c6fa5;
                    }
                    .analysis-title {
                        font-size: 18px;
                        color: #2c6fa5;
                        margin-bottom: 15px;
                    }
                    h3 {
                        color: #2c6fa5;
                        margin-top: 25px;
                        margin-bottom: 10px;
                    }
                    h4 {
                        color: #4a5568;
                        margin-top: 15px;
                        margin-bottom: 8px;
                    }
                    ul, ol {
                        margin-bottom: 15px;
                    }
                    li {
                        margin-bottom: 5px;
                    }
                    .footer {
                        margin-top: 30px;
                        text-align: center;
                        font-size: 12px;
                        color: #666;
                        padding-top: 20px;
                        border-top: 1px solid #eee;
                    }
                    img {
                        max-width: 100%;
                        height: auto;
                        display: block;
                        margin: 15px auto;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                        padding: 5px;
                    }
                    @media print {
                        body {
                            font-size: 12pt;
                        }
                        .no-print {
                            display: none;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="logo">OphthalmoQA</div>
                    <div class="subtitle">Advanced Ophthalmology Question Analysis</div>
                </div>
                
                <div class="question-box">
                    <strong>Question:</strong>
                    <p>${questionText}</p>
                </div>
                
                <div class="analysis-title">Scholarly Deep Analysis</div>
                
                <div class="analysis-content">
                    ${analysisHtml}
                </div>
                
                <div class="footer">
                    Generated by OphthalmoQA - FRCS Exam Preparation Tool<br>
                    ${new Date().toLocaleDateString()}
                </div>
                
                <div class="no-print" style="text-align: center; margin-top: 30px;">
                    <button onclick="window.print()" style="padding: 8px 16px; background-color: #2c6fa5; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-print" style="margin-right: 5px;"></i> Print Analysis
                    </button>
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
    }

    formatDeepSearchResult(result) {
        // Ensure result is a string
        if (result === null || result === undefined) {
            return 'No results available';
        }
        
        // Convert to string if it's not already
        const resultStr = typeof result === 'string' ? result : String(result);
        
        // If the result already contains HTML, sanitize it and return
        if (resultStr.includes('<') && resultStr.includes('>')) {
            return this.sanitizeHTML(resultStr);
        }
        
        // Process markdown-style formatting
        let formattedResult = resultStr
            // Headers
            .replace(/^# (.*$)/gm, '<h2 class="text-xl font-bold text-indigo-900 mt-4 mb-2">$1</h2>')
            .replace(/^## (.*$)/gm, '<h3 class="text-lg font-semibold text-indigo-800 mt-3 mb-2">$1</h3>')
            .replace(/^### (.*$)/gm, '<h4 class="text-base font-medium text-indigo-700 mt-2 mb-1">$1</h4>')
            // Bold
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            // Italic
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            // Lists
            .replace(/^\d+\. (.*$)/gm, '<li class="ml-5 list-decimal">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-5 list-disc">$1</li>')
            // Paragraphs
            .replace(/\n\n/g, '</p><p class="my-2">')
            // Line breaks
            .replace(/\n/g, '<br>');
        
        // Wrap in paragraph tags if not already
        if (!formattedResult.startsWith('<')) {
            formattedResult = `<p class="my-2">${formattedResult}</p>`;
        }
        
        return formattedResult;
    }
    
    processFeedback(questionId, rating, questionText, answerText) {
        // Log feedback to console
        console.log(`Feedback received for question #${questionId}: ${rating}`);
        
        // If feedback handler exists, use it
        if (window.feedbackHandler && typeof window.feedbackHandler.recordFeedback === 'function') {
            window.feedbackHandler.recordFeedback(questionId, rating, questionText, answerText);
        }
        
        // Store feedback in localStorage as a fallback
        try {
            const feedbackKey = `feedback_${questionId}`;
            localStorage.setItem(feedbackKey, JSON.stringify({
                rating,
                timestamp: new Date().toISOString()
            }));
        } catch (error) {
            console.error('Error storing feedback:', error);
        }
    }

    showNotebookLmModal() {
        // Create modal if it doesn't exist
        if (!this.notebookLmModal) {
            this.notebookLmModal = document.createElement('div');
            this.notebookLmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
            document.body.appendChild(this.notebookLmModal);
            
            // Modal content
            const modalContent = document.createElement('div');
            modalContent.className = 'bg-white rounded-lg shadow-xl p-6 w-full max-w-md';
            this.notebookLmModal.appendChild(modalContent);
            
            // Header
            const header = document.createElement('h3');
            header.className = 'text-lg font-semibold mb-4';
            header.textContent = 'Connect to NotebookLM';
            modalContent.appendChild(header);
            
            // Status message
            this.notebookLmAuthStatus = document.createElement('div');
            this.notebookLmAuthStatus.className = 'mb-4 hidden';
            modalContent.appendChild(this.notebookLmAuthStatus);
            
            // Instructions
            const instructions = document.createElement('p');
            instructions.className = 'mb-4 text-gray-600';
            instructions.innerHTML = 'To connect to NotebookLM, you can either:<br>1. Paste HTML code from NotebookLM<br>2. Use quick login with email<br>3. Import from a notebook URL<br>4. Try demo mode';
            modalContent.appendChild(instructions);
            
            // Option 1: HTML Code input
            const codeLabel = document.createElement('label');
            codeLabel.className = 'block font-medium mb-1';
            codeLabel.textContent = '1. Paste HTML Code:';
            modalContent.appendChild(codeLabel);
            
            this.notebookLmCode = document.createElement('textarea');
            this.notebookLmCode.className = 'w-full border border-gray-300 rounded-md p-2 mb-4';
            this.notebookLmCode.rows = 4;
            this.notebookLmCode.placeholder = 'Paste the HTML code from NotebookLM here...';
            modalContent.appendChild(this.notebookLmCode);
            
            const authenticateBtn = document.createElement('button');
            authenticateBtn.className = 'bg-primary text-white px-4 py-2 rounded-md mb-4 hover:bg-primary-dark transition';
            authenticateBtn.textContent = 'Connect with HTML';
            authenticateBtn.addEventListener('click', () => this.handleNotebookLmAuthentication());
            modalContent.appendChild(authenticateBtn);
            
            const orDivider1 = document.createElement('div');
            orDivider1.className = 'flex items-center my-4';
            orDivider1.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider1);
            
            // Option 2: Email input
            const emailLabel = document.createElement('label');
            emailLabel.className = 'block font-medium mb-1';
            emailLabel.textContent = '2. Quick Login with Email:';
            modalContent.appendChild(emailLabel);
            
            this.notebookLmEmail = document.createElement('input');
            this.notebookLmEmail.type = 'email';
            this.notebookLmEmail.className = 'w-full border border-gray-300 rounded-md p-2 mb-2';
            this.notebookLmEmail.placeholder = 'Enter your email';
            this.notebookLmEmail.value = 'genododi@gmail.com';  // Default email
            modalContent.appendChild(this.notebookLmEmail);
            
            const emailAuthBtn = document.createElement('button');
            emailAuthBtn.className = 'bg-blue-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-blue-600 transition';
            emailAuthBtn.textContent = 'Connect with Email';
            emailAuthBtn.addEventListener('click', () => {
                const email = this.notebookLmEmail.value.trim();
                if (email && window.notebookLmHandler) {
                    const success = window.notebookLmHandler.authenticateWithEmail(email);
                    if (success) {
                        this.showNotebookAuthStatus(`Successfully connected as ${email}!`, 'success');
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                        }, 1500);
                    } else {
                        this.showNotebookAuthStatus('Failed to authenticate with the provided email.', 'error');
                    }
                } else {
                    this.showNotebookAuthStatus('Please enter a valid email.', 'error');
                }
            });
            modalContent.appendChild(emailAuthBtn);
            
            const orDivider2 = document.createElement('div');
            orDivider2.className = 'flex items-center my-4';
            orDivider2.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider2);
            
            // Option 3: Import from URL
            const urlLabel = document.createElement('label');
            urlLabel.className = 'block font-medium mb-1';
            urlLabel.textContent = '3. Import from Notebook URL:';
            modalContent.appendChild(urlLabel);
            
            this.notebookLmUrl = document.createElement('input');
            this.notebookLmUrl.type = 'text';
            this.notebookLmUrl.className = 'w-full border border-gray-300 rounded-md p-2 mb-2';
            this.notebookLmUrl.placeholder = 'https://notebooklm.google.com/notebook/your-notebook-id';
            this.notebookLmUrl.value = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
            modalContent.appendChild(this.notebookLmUrl);
            
            const urlImportBtn = document.createElement('button');
            urlImportBtn.className = 'bg-purple-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-purple-600 transition';
            urlImportBtn.textContent = 'Import from URL';
            urlImportBtn.addEventListener('click', async () => {
                const url = this.notebookLmUrl.value.trim();
                if (!url) {
                    this.showNotebookAuthStatus('Please enter a valid NotebookLM URL.', 'error');
                    return;
                }
                
                if (!window.notebookLmHandler) {
                    this.showNotebookAuthStatus('NotebookLM handler not available.', 'error');
                    return;
                }
                
                this.showNotebookAuthStatus('Importing notebook...', 'info');
                
                try {
                    const success = await window.notebookLmHandler.importNotebookByUrl(url);
                    
                    if (success) {
                        this.showNotebookAuthStatus('Successfully imported notebook!', 'success');
                        
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                            // Force refresh notebooks immediately
                            this.loadNotebookOptions();
                        }, 1000);
                    } else {
                        this.showNotebookAuthStatus('Failed to import notebook. Please check the URL.', 'error');
                    }
                } catch (error) {
                    console.error('Error importing notebook:', error);
                    this.showNotebookAuthStatus('Error importing notebook: ' + error.message, 'error');
                }
            });
            modalContent.appendChild(urlImportBtn);
            
            const orDivider3 = document.createElement('div');
            orDivider3.className = 'flex items-center my-4';
            orDivider3.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider3);
            
            // Option 4: Demo Mode
            const demoLabel = document.createElement('label');
            demoLabel.className = 'block font-medium mb-1';
            demoLabel.textContent = '4. Demo Mode:';
            modalContent.appendChild(demoLabel);
            
            const demoBtn = document.createElement('button');
            demoBtn.className = 'bg-green-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-green-600 transition';
            demoBtn.textContent = 'Use Demo Mode';
            demoBtn.addEventListener('click', () => {
                if (window.notebookLmHandler) {
                    const success = window.notebookLmHandler.initializeDemo();
                    if (success) {
                        this.showNotebookAuthStatus('Successfully connected in demo mode!', 'success');
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                            // Force refresh notebooks immediately
                            this.loadNotebookOptions();
                        }, 1000);
                    } else {
                        this.showNotebookAuthStatus('Failed to initialize demo mode.', 'error');
                    }
                } else {
                    this.showNotebookAuthStatus('NotebookLM handler not available.', 'error');
                }
            });
            modalContent.appendChild(demoBtn);
            
            const closeBtn = document.createElement('button');
            closeBtn.className = 'absolute top-4 right-4 text-gray-500 hover:text-gray-700';
            closeBtn.innerHTML = '<i class="fas fa-times"></i>';
            closeBtn.addEventListener('click', () => this.hideNotebookLmModal());
            modalContent.appendChild(closeBtn);
        }
        
        // Show the modal
        this.notebookLmModal.classList.remove('hidden');
    }

    hideNotebookLmModal() {
        if (this.notebookLmModal) {
            this.notebookLmModal.classList.add('hidden');
        }
    }

    updateNotebookLmStatus() {
        // Check if NotebookLM handler is initialized
        if (window.notebookLmHandler && window.notebookLmHandler.isInitialized()) {
            // Get user email if available
            const email = window.notebookLmHandler.credentials?.oPEP7c || '';
            
            if (!this.notebookLogoutBtn) {
                // Create logout button if it doesn't exist
                this.notebookLogoutBtn = document.createElement('button');
                this.notebookLogoutBtn.className = 'text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 ml-2 px-2 py-1 rounded-md transition';
                this.notebookLogoutBtn.innerHTML = '<i class="fas fa-sign-out-alt mr-1"></i>Logout';
                
                // Add event listener for logout
                this.notebookLogoutBtn.addEventListener('click', () => {
                    if (window.notebookLmHandler) {
                        window.notebookLmHandler.logout();
                        this.updateNotebookLmStatus();
                        this.showStatus('Disconnected from NotebookLM', 'info');
                    }
                });
                
                // Add logout button to status container
                const statusContainer = this.notebookStatus.querySelector('p');
                if (statusContainer) {
                    statusContainer.appendChild(document.createTextNode(' '));
                    statusContainer.appendChild(this.notebookLogoutBtn);
                }
            } else {
                // Ensure the logout button is visible
                this.notebookLogoutBtn.classList.remove('hidden');
            }

            // Update status message with email if available
            const statusText = email ? 
                `Connected as ${email}. Select a notebook to continue.` : 
                'Connected to NotebookLM. Select a notebook to continue.';
            
            this.notebookStatusMessage.textContent = statusText;
            this.notebookStatus.classList.remove('hidden');
            this.notebookSelection.classList.remove('hidden');
            
            // Make notebook section more noticeable with a distinct border
            this.notebookSelection.style.border = '1px solid #e5e7eb';
            this.notebookSelection.style.borderRadius = '8px';
            this.notebookSelection.style.padding = '12px';
            this.notebookSelection.style.marginTop = '12px';
            this.notebookSelection.style.backgroundColor = '#f9fafb';
            
            // Add a manual connect button for easy reconnection
            if (!this.manualConnectBtn) {
                this.manualConnectBtn = document.createElement('button');
                this.manualConnectBtn.className = 'text-sm bg-blue-100 hover:bg-blue-200 text-primary ml-2 px-2 py-1 rounded-md transition';
                this.manualConnectBtn.innerHTML = '<i class="fas fa-link mr-1"></i>Connect Again';
                
                // Add event listener
                this.manualConnectBtn.addEventListener('click', () => {
                    // Try to reconnect with the default email
                    if (window.notebookLmHandler) {
                        const defaultEmail = 'genododi@gmail.com';
                        const success = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                        
                        if (success) {
                            this.updateNotebookLmStatus();
                            this.showStatus(`Reconnected as ${defaultEmail}`, 'success');
                            // Force refresh notebooks
                            setTimeout(() => {
                                this.loadNotebookOptions();
                            }, 100);
                        } else {
                            this.showStatus('Failed to reconnect', 'error');
                        }
                    }
                });
                
                // Add to status container
                const statusContainer = this.notebookStatus.querySelector('p');
                if (statusContainer) {
                    statusContainer.appendChild(document.createTextNode(' '));
                    statusContainer.appendChild(this.manualConnectBtn);
                }
            } else {
                // Ensure the manual connect button is visible
                this.manualConnectBtn.classList.remove('hidden');
            }
            
            // Add Import Specific Notebook button
            if (!this.importSpecificNotebookBtn) {
                // Create a container for the notebook actions
                if (!this.notebookActionsContainer) {
                    this.notebookActionsContainer = document.createElement('div');
                    this.notebookActionsContainer.className = 'mt-3 flex flex-wrap gap-2';
                    this.notebookSelection.appendChild(this.notebookActionsContainer);
                }
                
                this.importSpecificNotebookBtn = document.createElement('button');
                this.importSpecificNotebookBtn.className = 'text-sm bg-green-100 hover:bg-green-200 text-green-800 px-3 py-2 rounded-md transition flex items-center';
                this.importSpecificNotebookBtn.innerHTML = '<i class="fas fa-file-import mr-2"></i>Import My FRCS Notebook';
                
                // Add event listener
                this.importSpecificNotebookBtn.addEventListener('click', async () => {
                    try {
                        this.showStatus('Importing your specific FRCS notebook...', 'info');
                        
                        if (window.notebookLmHandler) {
                            const success = await window.notebookLmHandler.loadUserSpecificNotebook();
                            
                            if (success) {
                                this.showStatus('Successfully imported your FRCS notebook!', 'success');
                                // Force refresh notebooks
                                this.loadNotebookOptions();
                            } else {
                                this.showStatus('Failed to import your notebook. Please try again.', 'error');
                            }
                        }
                    } catch (error) {
                        console.error('Error importing specific notebook:', error);
                        this.showStatus('Error importing your notebook: ' + error.message, 'error');
                    }
                });
                
                // Add to the actions container
                this.notebookActionsContainer.appendChild(this.importSpecificNotebookBtn);
            } else {
                // Ensure the button is visible
                this.importSpecificNotebookBtn.classList.remove('hidden');
            }
            
            // Update notebooks dropdown immediately
            console.log('Triggering notebook options load from updateNotebookLmStatus');
            this.loadNotebookOptions();
        } else {
            // Hide logout button if it exists
            if (this.notebookLogoutBtn) {
                this.notebookLogoutBtn.classList.add('hidden');
            }
            
            // Hide manual connect button if it exists
            if (this.manualConnectBtn) {
                this.manualConnectBtn.classList.add('hidden');
            }
            
            // Hide specific notebook import button if it exists
            if (this.importSpecificNotebookBtn) {
                this.importSpecificNotebookBtn.classList.add('hidden');
            }
            
            this.notebookStatusMessage.textContent = 'Please connect to NotebookLM to access your saved notes.';
            this.notebookStatus.classList.remove('hidden');
            this.notebookSelection.classList.add('hidden');
        }
    }

    async loadNotebookOptions() {
        if (!window.notebookLmHandler || !window.notebookLmHandler.isInitialized()) {
            this.showStatus('NotebookLM not initialized. Please connect first.', 'warning');
            return;
        }

        try {
            this.showStatus('Loading notebooks...', 'info');
            
            // Clear existing options except the first one
            while (this.notebookSelect.options.length > 1) {
                this.notebookSelect.remove(1);
            }
            
            // Add refresh button if not already added
            if (!this.notebookRefreshBtn) {
                const notebookSelectParent = this.notebookSelect.parentElement;
                
                // Create container for select and button
                const selectContainer = document.createElement('div');
                selectContainer.className = 'flex items-center gap-2';
                
                // Move select into container
                this.notebookSelect.parentNode.insertBefore(selectContainer, this.notebookSelect);
                selectContainer.appendChild(this.notebookSelect);
                this.notebookSelect.className += ' flex-grow';
                
                // Create refresh button
                this.notebookRefreshBtn = document.createElement('button');
                this.notebookRefreshBtn.className = 'bg-blue-100 hover:bg-blue-200 text-primary p-2 rounded-md transition';
                this.notebookRefreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                this.notebookRefreshBtn.title = 'Refresh notebooks list';
                
                // Add click event
                this.notebookRefreshBtn.addEventListener('click', () => {
                    this.loadNotebookOptions();
                });
                
                // Add to container
                selectContainer.appendChild(this.notebookRefreshBtn);
            }

            // Fetch notebooks and add them to dropdown
            try {
                const notebooks = await window.notebookLmHandler.fetchUserNotebooks();
                console.log('Fetched notebooks:', notebooks);
                
                if (notebooks && Array.isArray(notebooks) && notebooks.length > 0) {
                    // First check if we have the user's specific notebook
                    const userSpecificNotebookId = '07d17136-d624-417d-8b82-6977f9674f71';
                    const hasUserNotebook = notebooks.some(nb => nb.id === userSpecificNotebookId);
                    
                    // If the specific notebook isn't there, try to add it
                    if (!hasUserNotebook) {
                        console.log('User\'s specific notebook not found, attempting to import it...');
                        try {
                            const specificUrl = `https://notebooklm.google.com/notebook/${userSpecificNotebookId}`;
                            await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                            // Refresh notebooks list after import
                            const updatedNotebooks = await window.notebookLmHandler.fetchUserNotebooks();
                            if (updatedNotebooks && Array.isArray(updatedNotebooks)) {
                                notebooks.splice(0, notebooks.length, ...updatedNotebooks);
                            }
                        } catch (importErr) {
                            console.error('Failed to auto-import user\'s notebook:', importErr);
                        }
                    }
                    
                    // Add each notebook to the dropdown
                    notebooks.forEach(notebook => {
                        const option = document.createElement('option');
                        option.value = notebook.id;
                        option.textContent = notebook.title || `Notebook ${notebook.id}`;
                        // Highlight the user's specific notebook
                        if (notebook.id === userSpecificNotebookId) {
                            option.className = 'font-bold text-green-800';
                            option.style.backgroundColor = '#f0fff4';
                            option.textContent += ' (My FRCS Notes)';
                        }
                        this.notebookSelect.add(option);
                    });
                    
                    this.showStatus(`Successfully loaded ${notebooks.length} notebooks.`, 'success');
                    
                    // Select the user's specific notebook if available, otherwise select the first notebook
                    const userNotebookIndex = Array.from(this.notebookSelect.options).findIndex(
                        opt => opt.value === userSpecificNotebookId
                    );
                    
                    if (userNotebookIndex > 0) {
                        this.notebookSelect.selectedIndex = userNotebookIndex;
                    } else if (this.notebookSelect.options.length > 1) {
                        this.notebookSelect.selectedIndex = 1;
                    }
                    
                    this.handleNotebookSelection();
                } else {
                    // Add a placeholder if no notebooks found
                    const option = document.createElement('option');
                    option.value = "";
                    option.textContent = "No notebooks found";
                    option.disabled = true;
                    this.notebookSelect.add(option);
                    
                    this.showStatus('No notebooks found in your account.', 'warning');
                }
            } catch (fetchError) {
                console.error('Error fetching notebooks:', fetchError);
                
                // Try to import the user's specific notebook directly as a fallback
                try {
                    this.showStatus('Trying to import your FRCS notebook directly...', 'info');
                    const specificUrl = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
                    const imported = await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                    
                    if (imported) {
                        // If import succeeds, refresh the notebook list
                        const notebooks = await window.notebookLmHandler.fetchUserNotebooks();
                        
                        if (notebooks && Array.isArray(notebooks) && notebooks.length > 0) {
                            notebooks.forEach(notebook => {
                                const option = document.createElement('option');
                                option.value = notebook.id;
                                option.textContent = notebook.title || `Notebook ${notebook.id}`;
                                this.notebookSelect.add(option);
                            });
                            
                            this.showStatus('Successfully imported your FRCS notebook.', 'success');
                            
                            // Select the first notebook
                            if (this.notebookSelect.options.length > 1) {
                                this.notebookSelect.selectedIndex = 1;
                                this.handleNotebookSelection();
                            }
                        }
                    } else {
                        throw new Error('Failed to import notebook directly');
                    }
                } catch (importError) {
                    console.error('Error in direct notebook import:', importError);
                    this.showNotebookAuthStatus('Failed to load notebooks: ' + fetchError.message, 'error');
                    this.showStatus('Error loading notebooks. Please try reconnecting.', 'error');
                    
                    // Add error option
                    const option = document.createElement('option');
                    option.value = "";
                    option.textContent = "Error loading notebooks";
                    option.disabled = true;
                    this.notebookSelect.add(option);
                }
            }
        } catch (error) {
            console.error('Error loading notebooks:', error);
            this.showNotebookAuthStatus('Failed to load notebooks: ' + error.message, 'error');
            this.showStatus('Error loading notebooks. Please try reconnecting.', 'error');
            
            // Add error option
            const option = document.createElement('option');
            option.value = "";
            option.textContent = "Error loading notebooks";
            option.disabled = true;
            this.notebookSelect.add(option);
        }
    }

    /**
     * Handle authentication with NotebookLM
     */
    async handleNotebookLmAuthentication() {
        try {
            // Get the NotebookLM HTML code
            const htmlCode = document.getElementById('notebooklm-code').value.trim();
            
            // Check if the code is empty
            if (!htmlCode) {
                this.showNotebookAuthStatus('Please paste the NotebookLM HTML code first.', 'warning');
                this.addFallbackAuthOption(); // Show fallback option immediately
                return;
            }
            
            // Show loading state
            this.showNotebookAuthStatus('Processing authentication data...', 'info');
            const authenticateBtn = document.getElementById('authenticate-notebooklm');
            authenticateBtn.disabled = true;
            authenticateBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Authenticating...';
            
            // Process the HTML code
            const result = window.notebookLmHandler.processNotebookLmHtml(htmlCode);
            
            // Reset button state
            authenticateBtn.disabled = false;
            authenticateBtn.innerHTML = '<i class="fas fa-key mr-2"></i> Import Notes';
            
            if (!result.success) {
                // Authentication failed
                this.showNotebookAuthStatus(result.message || 'Authentication failed.', 'error');
                
                // Always show fallback option when authentication fails
                this.addFallbackAuthOption();
                
                // Also add direct import option for FRCS notebook
                setTimeout(() => {
                    this.addDirectImportOption();
                }, 500);
                
                return;
            }
            
            // Authentication succeeded
            const statusMessage = result.isFallback ?
                `Connected with limited access as ${result.userEmail || 'user'}. Some features may be restricted.` :
                `Successfully connected as ${result.userEmail || 'user'}.`;
            
            this.showNotebookAuthStatus(statusMessage, 'success');
            
            // Load notebooks
            await this.loadNotebookOptions();
            
            // Update UI to show notebook selection
            this.updateNotebookLmStatus();
            
        } catch (error) {
            console.error('Error during NotebookLM authentication:', error);
            this.showNotebookAuthStatus(`Authentication error: ${error.message}`, 'error');
            
            // Show fallback options
            this.addFallbackAuthOption();
            this.addDirectImportOption();
            
            // Reset authenticate button
            const authenticateBtn = document.getElementById('authenticate-notebooklm');
            if (authenticateBtn) {
                authenticateBtn.disabled = false;
                authenticateBtn.innerHTML = '<i class="fas fa-key mr-2"></i> Import Notes';
            }
        }
    }
    
    /**
     * Add fallback authentication option to the modal
     */
    addFallbackAuthOption() {
        const authStatus = document.getElementById('notebooklm-auth-status');
        
        // Check if the fallback option already exists
        if (document.getElementById('demo-notebook-btn')) {
            return;
        }
        
        // Create fallback option UI
        const fallbackDiv = document.createElement('div');
        fallbackDiv.className = 'mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg';
        fallbackDiv.innerHTML = `
            <h4 class="font-medium text-gray-800 mb-2">Having trouble?</h4>
            <p class="text-sm text-gray-600 mb-3">
                You can use our demo notebook with pre-loaded FRCS study material instead.
            </p>
            <button id="demo-notebook-btn" class="w-full bg-secondary hover:bg-primary text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center">
                <i class="fas fa-magic mr-2"></i>
                Use Demo Notebook Instead
            </button>
        `;
        
        // Insert fallback option after the auth status
        authStatus.parentNode.insertBefore(fallbackDiv, authStatus.nextSibling);
        authStatus.classList.remove('hidden');
        
        // Add event listener to the demo button
        document.getElementById('demo-notebook-btn').addEventListener('click', async () => {
            try {
                // Show loading state
                document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Loading Demo...';
                document.getElementById('demo-notebook-btn').disabled = true;
                
                // Initialize demo mode
                const success = window.notebookLmHandler.initializeDemo();
                
                if (success) {
                    this.showNotebookAuthStatus('Demo notebook access granted successfully.', 'success');
                    
                    // Load demo notebooks
                    await this.loadNotebookOptions();
                    
                    // Update UI
                    this.updateNotebookLmStatus();
                    
                    // Close modal after a short delay
                    setTimeout(() => {
                        this.hideNotebookLmModal();
                        this.showStatus('Connected to NotebookLM demo mode. You can now select notebooks.', 'success');
                    }, 1500);
                } else {
                    this.showNotebookAuthStatus('Failed to initialize demo mode. Please try again.', 'error');
                    document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-magic mr-2"></i> Use Demo Notebook Instead';
                    document.getElementById('demo-notebook-btn').disabled = false;
                }
            } catch (error) {
                console.error('Error initializing demo mode:', error);
                this.showNotebookAuthStatus(`Error initializing demo mode: ${error.message}`, 'error');
                document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-magic mr-2"></i> Use Demo Notebook Instead';
                document.getElementById('demo-notebook-btn').disabled = false;
            }
        });
    }
    
    /**
     * Add direct import option for the FRCS notebook
     */
    addDirectImportOption() {
        const authStatus = document.getElementById('notebooklm-auth-status');
        
        // Check if the direct import option already exists
        if (document.getElementById('direct-import-btn')) {
            return;
        }
        
        // Create direct import option UI
        const directImportDiv = document.createElement('div');
        directImportDiv.className = 'mt-3 p-4 bg-green-50 border border-green-200 rounded-lg';
        directImportDiv.innerHTML = `
            <h4 class="font-medium text-green-800 mb-2">Quick Access Option</h4>
            <p class="text-sm text-green-700 mb-3">
                Import our specialized FRCS notebook with comprehensive ophthalmology content directly.
            </p>
            <button id="direct-import-btn" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center">
                <i class="fas fa-file-medical mr-2"></i>
                Import FRCS Notebook Directly
            </button>
        `;
        
        // Find where to insert the direct import option
        const fallbackOption = document.getElementById('demo-notebook-btn')?.closest('div');
        if (fallbackOption) {
            fallbackOption.parentNode.insertBefore(directImportDiv, fallbackOption.nextSibling);
        } else {
            authStatus.parentNode.insertBefore(directImportDiv, authStatus.nextSibling);
        }
        
        // Add event listener to the direct import button
        document.getElementById('direct-import-btn').addEventListener('click', async () => {
            try {
                // Show loading state
                document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Importing...';
                document.getElementById('direct-import-btn').disabled = true;
                
                // Either use existing handler or initialize a new demo one
                if (!window.notebookLmHandler.isInitialized()) {
                    const success = window.notebookLmHandler.initializeDemo();
                    if (!success) {
                        throw new Error('Failed to initialize notebook handler');
                    }
                }
                
                // Import the specific FRCS notebook
                const success = await window.notebookLmHandler.loadUserSpecificNotebook();
                
                if (success) {
                    this.showNotebookAuthStatus('FRCS notebook imported successfully.', 'success');
                    
                    // Load notebook options
                    await this.loadNotebookOptions();
                    
                    // Update UI
                    this.updateNotebookLmStatus();
                    
                    // Close modal after a short delay
                    setTimeout(() => {
                        this.hideNotebookLmModal();
                        this.showStatus('FRCS notebook imported. You can now generate questions from it.', 'success');
                    }, 1500);
                } else {
                    this.showNotebookAuthStatus('Failed to import FRCS notebook. Please try again.', 'error');
                    document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-file-medical mr-2"></i> Import FRCS Notebook Directly';
                    document.getElementById('direct-import-btn').disabled = false;
                }
            } catch (error) {
                console.error('Error importing FRCS notebook:', error);
                this.showNotebookAuthStatus(`Error importing FRCS notebook: ${error.message}`, 'error');
                document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-file-medical mr-2"></i> Import FRCS Notebook Directly';
                document.getElementById('direct-import-btn').disabled = false;
            }
        });
    }

    showNotebookAuthStatus(message, type = 'info') {
        this.notebookLmAuthStatus.textContent = message;
        this.notebookLmAuthStatus.className = 'mb-4 p-3 rounded-md';
        
        // Add appropriate styling based on message type
        if (type === 'error') {
            this.notebookLmAuthStatus.classList.add('bg-red-100', 'text-red-700');
        } else if (type === 'success') {
            this.notebookLmAuthStatus.classList.add('bg-green-100', 'text-green-700');
        } else {
            this.notebookLmAuthStatus.classList.add('bg-blue-100', 'text-blue-700');
        }
        
        this.notebookLmAuthStatus.classList.remove('hidden');
    }

    handleNotebookSelection() {
        const selectedId = this.notebookSelect.value;
        if (!selectedId) {
            this.selectedNotebookInfo.classList.add('hidden');
            return;
        }

        // Display notebook info
        const selectedOption = this.notebookSelect.options[this.notebookSelect.selectedIndex];
        this.selectedNotebookTitle.textContent = selectedOption.textContent;
        this.selectedNotebookDescription.textContent = `Notebook ID: ${selectedId}`;
        this.selectedNotebookInfo.classList.remove('hidden');
    }

    showStatus(message, type = 'info') {
        this.statusMessage.textContent = message;
        const typeClasses = {
            info: 'bg-blue-100 text-blue-700',
            success: 'bg-green-100 text-green-700',
            warning: 'bg-yellow-100 text-yellow-700',
            error: 'bg-red-100 text-red-700'
        };
        
        this.statusMessage.className = `status-message p-3 rounded-md font-medium text-center my-4 ${typeClasses[type] || typeClasses.info}`;
        this.statusMessage.classList.remove('hidden');

        if (type !== 'error') {
            setTimeout(() => {
                if (this.statusMessage.textContent === message) {
                    this.statusMessage.classList.add('hidden');
                }
            }, 6000);
        }
    }

    setProcessingState(processing) {
        this.isProcessing = processing;
        this.loadingIndicator.classList.toggle('hidden', !processing);
        this.loadingIndicator.classList.toggle('flex', processing);
        
        // Disable/enable form elements
        const elements = [
            this.generateBtn, this.clearBtn, this.inputTypeSelect,
            this.inputTextElement, this.knowledgeAreaSelect, this.aiModelSelect,
            this.difficultySelect, this.numQuestionsInput,
            this.focusAreaInput, this.showAnswersDefaultCheckbox,
            this.exportFormatSelect, this.connectNotebookLmBtn, 
            this.notebookSelect
        ];
        
        elements.forEach(element => {
            if (element) element.disabled = processing;
        });
        
        Object.values(this.questionTypeCheckboxes).forEach(cb => cb.disabled = processing);
        
        if (processing) {
            if (this.exportBtn) this.exportBtn.disabled = true;
            if (this.regenerateBtn) this.regenerateBtn.disabled = true;
        } else {
            // Re-enable based on state only after processing finishes
            if (this.questionGenerator) {
                this.updateButtonStates(this.questionGenerator.generatedQuestions.length > 0);
            } else {
                this.updateButtonStates(false);
            }
        }
    }

    updateButtonStates(questionsExist) {
        if (this.exportBtn) this.exportBtn.disabled = !questionsExist || this.isProcessing;
        if (this.regenerateBtn) this.regenerateBtn.disabled = !(this.lastSettings || (this.questionGenerator && this.questionGenerator.lastSettings)) || this.isProcessing;
    }

    sanitizeHTML(str) {
        return str ? String(str).replace(/</g, "&lt;").replace(/>/g, "&gt;") : '';
    }
    
    setFileHandler(fileHandler) {
        this.fileHandler = fileHandler;
    }
    
    setQuestionGenerator(questionGenerator) {
        this.questionGenerator = questionGenerator;
    }

    async loadOphthalmicImage(questionId, questionText, answerText, imageContainer) {
        // Make sure the image generator is available
        if (!window.ophthalmoImageGenerator) {
            console.error('Ophthalmic image generator not available');
            this.showStatus('Image feature not available', 'error');
            imageContainer.innerHTML = `
                <div class="text-center py-4 text-red-600">
                    <i class="fas fa-exclamation-circle text-xl mb-2"></i>
                    <p>Image generation feature is not available.</p>
                </div>
            `;
            imageContainer.classList.remove('hidden');
            return;
        }
        
        try {
            // Show loading state
            imageContainer.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    <p class="mt-2 text-gray-600">Loading relevant ophthalmic image...</p>
                </div>
            `;
            imageContainer.classList.remove('hidden');
            
            // Generate image based on question content
            const imageInfo = await window.ophthalmoImageGenerator.generateImage(questionText, questionId);
            
            if (imageInfo && imageInfo.url) {
                // Determine a caption based on the identified keyword
                const captionText = imageInfo.keyword ? 
                    `Clinical image of ${imageInfo.keyword}` : 
                    'Relevant ophthalmic image';
                
                // Update the image container with the generated image
                const imgElement = imageContainer.querySelector('img.ophthalmic-image');
                const captionElement = imageContainer.querySelector('.image-caption');
                
                if (imgElement && captionElement) {
                    // Update existing elements
                    imgElement.src = imageInfo.url;
                    imgElement.alt = captionText;
                    imgElement.setAttribute('data-keyword', imageInfo.keyword || '');
                    captionElement.textContent = captionText;
                    
                    // Add click handler to open modal
                    imgElement.onclick = function() {
                        window.ophthalmoImageGenerator.showImagePreview(
                            imageInfo.url, 
                            questionText, 
                            imageInfo.keyword
                        );
                    };
                } else {
                    // Create new elements
                    imageContainer.innerHTML = `
                        <div class="text-center">
                            <img src="${imageInfo.url}" alt="${captionText}" 
                                class="ophthalmic-image max-w-full max-h-[300px] mx-auto object-contain rounded-lg border border-gray-200 shadow-sm cursor-pointer"
                                data-keyword="${imageInfo.keyword || ''}" 
                                onclick="window.ophthalmoImageGenerator.showImagePreview('${imageInfo.url}', '${this.sanitizeHTML(questionText)}', '${imageInfo.keyword || ''}')">
                            <p class="text-sm text-gray-600 mt-2 image-caption">${captionText}</p>
                            <div class="text-xs text-primary mt-2">Click image to view details</div>
                        </div>
                    `;
                }
            } else {
                // No image found
                imageContainer.innerHTML = `
                    <div class="text-center py-4 text-gray-500">
                        <i class="fas fa-image text-2xl mb-2 opacity-50"></i>
                        <p>No relevant images found for this question.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading ophthalmic image:', error);
            
            // Show error in the image container
            imageContainer.innerHTML = `
                <div class="text-center py-4 text-red-600">
                    <i class="fas fa-exclamation-circle text-xl mb-2"></i>
                    <p>Error loading image: ${error.message}</p>
                </div>
            `;
        }
    }
} 
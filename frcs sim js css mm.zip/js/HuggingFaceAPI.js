/**
 * HuggingFaceAPI.js
 * This module handles the integration with the Hugging Face Inference API for generating 
 * ophthalmology questions and adding them to the question bank database.
 */

class HuggingFaceAPI {
    constructor() {
        this.apiEndpoint = "https://api-inference.huggingface.co/models/";
        this.defaultModel = "google/flan-t5-xxl"; // Default model, can be changed
        this.isInitialized = false;
        this.apiKey = null; // Will be set during initialization or from storage
        this.temperature = 0.7;
        this.maxTokens = 1024;
        this.feedbackCache = [];
        this.feedbackEnabled = true;
        this.maxFeedbackExamples = 3;
        this.feedbackScoreThreshold = 0.7; // Only use highly-rated questions for feedback
        this.modelOptions = {
            'flan-t5': 'google/flan-t5-xxl',
            'mistral': 'mistralai/Mistral-7B-Instruct-v0.2',
            'llama2': 'meta-llama/Llama-2-70b-hf',
            'gemma': 'google/gemma-7b-it',
            'falcon': 'tiiuae/falcon-40b-instruct',
            'meditron': 'epfl-llm/meditron-70b',
            'biomed': 'stanford-crfm/BioMedLM',
            'biomistral': 'BioMistral/BioMistral-7B'
        };
        
        // Load stored API key if available
        this.loadStoredApiKey();
    }

    /**
     * Load stored API key from localStorage
     */
    loadStoredApiKey() {
        try {
            const storedApiData = localStorage.getItem('ophthalmoqa_huggingface_api_key');
            if (storedApiData) {
                const apiData = JSON.parse(storedApiData);
                this.apiKey = apiData.key;
                
                console.log('Hugging Face API key loaded from storage');
            }
        } catch (error) {
            console.error('Error loading Hugging Face API key from storage:', error);
        }
    }

    /**
     * Save API key to localStorage
     * @param {string} apiKey - API key to save
     */
    saveApiKey(apiKey) {
        try {
            if (apiKey && apiKey.trim() !== '') {
                const apiData = {
                    key: apiKey.trim(),
                    timestamp: new Date().getTime()
                };
                
                localStorage.setItem('ophthalmoqa_huggingface_api_key', JSON.stringify(apiData));
                this.apiKey = apiKey.trim();
                
                console.log('Hugging Face API key saved');
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error saving Hugging Face API key:', error);
            return false;
        }
    }

    /**
     * Initialize the Hugging Face API integration
     * @param {string} apiKey - Optional API key to use
     */
    async initialize(apiKey = null) {
        console.log("Hugging Face API module initializing...");
        
        // Use provided API key or previously stored one
        if (apiKey) {
            this.saveApiKey(apiKey);
        } else if (!this.apiKey) {
            console.warn("No Hugging Face API key available. Some features may be limited.");
        }
        
        this.isInitialized = true;
        
        // Register with the MedicalMLProcessor system
        if (typeof window.medicalMLProcessor !== 'undefined') {
            window.medicalMLProcessor.registerModel('huggingface', this.generateQuestions.bind(this));
            console.log("Hugging Face API registered with MedicalMLProcessor");
        } else {
            console.warn("MedicalMLProcessor not available, Hugging Face API registration delayed");
            // Setup a listener for when MedicalMLProcessor becomes available
            document.addEventListener('MedicalMLProcessorReady', () => {
                window.medicalMLProcessor.registerModel('huggingface', this.generateQuestions.bind(this));
                console.log("Hugging Face API registered with MedicalMLProcessor after ready event");
            });
        }
        
        // Try to verify the API key
        if (this.apiKey) {
            try {
                const isValid = await this.testApiKey(this.apiKey);
                return isValid;
            } catch (error) {
                console.error("Error testing Hugging Face API key:", error);
                return false;
            }
        }
        
        return true; // Return true even without API key so the module initializes
    }

    /**
     * Test if an API key is valid
     * @param {string} apiKey - API key to test
     * @returns {Promise<boolean>} - Whether the key is valid
     */
    async testApiKey(apiKey) {
        try {
            // Use a simple model and query to verify the API key works
            const model = "google/flan-t5-small"; // Use a small model for quick verification
            const response = await fetch(`${this.apiEndpoint}${model}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    inputs: "What is glaucoma?"
                }),
                signal: AbortSignal.timeout(10000) // 10 second timeout
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error("API key validation failed:", errorData);
                return false;
            }
            
            // If we get here, the API key is valid
            return true;
        } catch (error) {
            console.error("Error testing Hugging Face API key:", error);
            return false;
        }
    }

    /**
     * Set a specific Hugging Face model to use
     * @param {string} modelName - Model name or key from modelOptions
     */
    setModel(modelName) {
        if (this.modelOptions[modelName]) {
            this.defaultModel = this.modelOptions[modelName];
            console.log(`Hugging Face model set to ${this.defaultModel}`);
        } else if (modelName.includes('/')) {
            // Assume it's a direct model path like 'facebook/bart-large'
            this.defaultModel = modelName;
            console.log(`Hugging Face model set to custom path: ${this.defaultModel}`);
        } else {
            console.warn(`Unknown model: ${modelName}, defaulting to ${this.defaultModel}`);
        }
    }

    /**
     * Generate a system prompt with context, examples, and instructions
     * @param {Object} options - Options for generation
     * @returns {string} - System prompt
     */
    generateSystemPrompt(options) {
        const { topic, subspecialty, difficulty, questionType, feedbackExamples } = options;
        
        let systemPrompt = `You are a medical specialist in ophthalmology, creating high-quality questions for FRCS exam preparation. `;
        
        if (subspecialty && subspecialty !== 'general') {
            systemPrompt += `Focus specifically on the ${subspecialty} subspecialty. `;
        }
        
        if (difficulty) {
            systemPrompt += `The questions should be at ${difficulty} difficulty level. `;
        }
        
        if (questionType) {
            systemPrompt += `Create ${questionType} type questions. `;
        }
        
        systemPrompt += `\nThe questions should be clinically relevant, evidence-based, and reflect current ophthalmic practice. `;
        systemPrompt += `Include detailed explanations with each answer that reference recent literature when appropriate.\n\n`;
        
        // Add feedback examples if available
        if (feedbackExamples && feedbackExamples.length > 0) {
            systemPrompt += `Here are examples of high-quality questions:\n\n`;
            
            feedbackExamples.forEach((example, index) => {
                systemPrompt += `Example ${index + 1}:\n${example.question}\n\nAnswer: ${example.answer}\n\n`;
            });
        }
        
        return systemPrompt;
    }

    /**
     * Generate questions using the Hugging Face API
     * @param {Object} options - Options for question generation
     * @returns {Promise<Array>} - Generated questions
     */
    async generateQuestions(options = {}) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        
        if (!this.apiKey) {
            console.error("Hugging Face API key is required for generating questions");
            return { 
                questions: [], 
                error: "No Hugging Face API key provided. Please add your API key in settings."
            };
        }
        
        const { 
            text, 
            topic = "", 
            count = 3, 
            subspecialty = "general", 
            difficulty = "challenging",
            questionType = "multiple choice",
            model = this.defaultModel
        } = options;
        
        try {
            // Get feedback examples if enabled
            const feedbackExamples = this.feedbackEnabled ? this.getFeedbackExamples() : [];
            
            // Generate system prompt
            const systemPrompt = this.generateSystemPrompt({
                topic, 
                subspecialty, 
                difficulty, 
                questionType,
                feedbackExamples
            });
            
            // Create the full prompt
            let fullPrompt = systemPrompt;
            
            if (text && text.trim() !== "") {
                fullPrompt += `\nBased on the following content, create ${count} high-quality ophthalmology questions:\n\n${text}\n\n`;
            } else {
                fullPrompt += `\nCreate ${count} high-quality ophthalmology questions about ${topic || "general ophthalmology concepts"}.\n\n`;
            }
            
            fullPrompt += `Return the response as a JSON array of objects, each with 'question' and 'answer' properties.`;
            
            // Select the correct endpoint based on the model
            const modelPath = this.modelOptions[model] || model || this.defaultModel;
            
            console.log(`Generating questions using Hugging Face model: ${modelPath}`);
            
            // Make API request
            const response = await fetch(`${this.apiEndpoint}${modelPath}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    inputs: fullPrompt,
                    parameters: {
                        max_new_tokens: this.maxTokens,
                        temperature: this.temperature,
                        top_p: 0.95,
                        do_sample: true
                    }
                }),
                signal: AbortSignal.timeout(30000) // 30 second timeout
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error("Hugging Face API request failed:", errorData);
                
                return { 
                    questions: [], 
                    error: `API request failed: ${errorData.error || response.statusText}`
                };
            }
            
            // Parse the response
            const data = await response.json();
            
            // Handle response format based on model type
            let generatedText = "";
            
            if (Array.isArray(data) && data.length > 0) {
                if (typeof data[0] === 'object' && data[0].generated_text) {
                    // Format for models like T5, Flan-T5
                    generatedText = data[0].generated_text;
                } else if (typeof data[0] === 'string') {
                    // Format for some models that return direct strings
                    generatedText = data[0];
                }
            } else if (typeof data === 'object') {
                if (data.generated_text) {
                    // Single object with generated_text property
                    generatedText = data.generated_text;
                } else {
                    // Try to stringify the response
                    generatedText = JSON.stringify(data);
                }
            } else if (typeof data === 'string') {
                // Direct string response
                generatedText = data;
            }
            
            // Try to parse JSON from the generated text
            let questions = [];
            
            try {
                // The model may or may not have returned proper JSON
                if (generatedText.includes('[') && generatedText.includes(']')) {
                    // Extract JSON array if it's wrapped in other text
                    const jsonMatch = generatedText.match(/\[[\s\S]*\]/);
                    if (jsonMatch) {
                        questions = JSON.parse(jsonMatch[0]);
                    }
                } else {
                    // Try to parse the whole response as JSON
                    questions = JSON.parse(generatedText);
                }
            } catch (error) {
                console.warn("Could not parse JSON from response, processing as text format");
                
                // If JSON parsing fails, try to extract questions and answers from the text
                questions = this.extractQuestionsFromText(generatedText, count);
            }
            
            // Ensure the result is an array
            if (!Array.isArray(questions)) {
                if (typeof questions === 'object') {
                    questions = [questions];
                } else {
                    questions = [];
                }
            }
            
            // Format and clean up each question
            const formattedQuestions = questions.map((q, index) => {
                const questionObj = {
                    id: `hf-${Date.now()}-${index}`,
                    question: typeof q === 'object' ? q.question || '' : '',
                    answer: typeof q === 'object' ? q.answer || '' : '',
                    metadata: {
                        source: 'huggingface',
                        model: modelPath,
                        timestamp: new Date().toISOString(),
                        subspecialty: subspecialty,
                        difficulty: difficulty
                    }
                };
                
                // Clean up the question and answer text
                if (questionObj.question) {
                    questionObj.question = questionObj.question.trim();
                }
                
                if (questionObj.answer) {
                    questionObj.answer = questionObj.answer.trim();
                }
                
                return questionObj;
            }).filter(q => q.question && q.answer); // Filter out empty questions
            
            console.log(`Generated ${formattedQuestions.length} questions using Hugging Face API`);
            
            return { questions: formattedQuestions, error: null };
        } catch (error) {
            console.error("Error generating questions with Hugging Face API:", error);
            
            return { 
                questions: [], 
                error: `Error generating questions: ${error.message}`
            };
        }
    }
    
    /**
     * Extract questions and answers from text when JSON parsing fails
     * @param {string} text - Text to extract from
     * @param {number} expectedCount - Expected number of questions
     * @returns {Array} - Extracted questions and answers
     */
    extractQuestionsFromText(text, expectedCount) {
        const questions = [];
        
        // Try to find question/answer pairs
        const questionBlocks = text.split(/\n\s*Question\s*\d+:|\n\s*Q\d+:|\n\s*\d+\.\s+/i).filter(Boolean);
        
        questionBlocks.forEach((block, index) => {
            // Try to split into question and answer parts
            const parts = block.split(/\n\s*Answer:|\n\s*A:|\n\s*Solution:/i);
            
            if (parts.length >= 2) {
                questions.push({
                    question: parts[0].trim(),
                    answer: parts.slice(1).join('\n').trim()
                });
            }
        });
        
        // If we still don't have any questions, try a more general approach
        if (questions.length === 0) {
            // Look for sequences of text that might be question/answer pairs
            const paragraphs = text.split(/\n\n+/).filter(Boolean);
            
            for (let i = 0; i < paragraphs.length; i += 2) {
                const question = paragraphs[i]?.trim();
                const answer = paragraphs[i + 1]?.trim();
                
                if (question && answer) {
                    questions.push({ question, answer });
                }
                
                if (questions.length >= expectedCount) {
                    break;
                }
            }
        }
        
        return questions;
    }
    
    /**
     * Get feedback examples to guide question generation
     * @returns {Array} - Feedback examples
     */
    getFeedbackExamples() {
        if (!this.feedbackEnabled || this.feedbackCache.length === 0) {
            return [];
        }
        
        // Return a random subset of feedback examples
        if (this.feedbackCache.length <= this.maxFeedbackExamples) {
            return [...this.feedbackCache];
        }
        
        // Shuffle and slice
        return [...this.feedbackCache]
            .sort(() => Math.random() - 0.5)
            .slice(0, this.maxFeedbackExamples);
    }
    
    /**
     * Load high-quality questions from the database to use as feedback examples
     */
    loadFeedbackExamples() {
        if (!this.feedbackEnabled || !window.questionDatabase) {
            return;
        }
        
        try {
            // Get all questions from the database
            const allQuestions = window.questionDatabase.storedQuestions || [];
            
            // Filter for questions with high ratings or frequent usage
            const highQualityQuestions = allQuestions.filter(q => {
                if (q.metadata && q.metadata.rating) {
                    return q.metadata.rating >= this.feedbackScoreThreshold;
                }
                return false;
            });
            
            // Update the feedback cache
            this.feedbackCache = highQualityQuestions.map(q => ({
                question: q.question,
                answer: q.answer
            })).slice(0, 20); // Store up to 20 examples
            
            console.log(`Loaded ${this.feedbackCache.length} feedback examples for Hugging Face API`);
        } catch (error) {
            console.error('Error loading feedback examples:', error);
        }
    }
}

// Initialize and expose the API globally
window.huggingFaceAPI = new HuggingFaceAPI();

// Initialize when the document is loaded
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize with the stored API key (if any)
    await window.huggingFaceAPI.initialize();
    
    // Check for token set via URL parameter (for testing/development)
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('hf_token');
    if (token) {
        await window.huggingFaceAPI.initialize(token);
    }
});

/**
 * Feedback Metrics Display System
 * Handles displaying metrics about question feedback and improvements
 */

class FeedbackMetricsDisplay {
    constructor() {
        this.metricsData = {
            totalQuestions: 0,
            totalFeedback: 0,
            totalImproved: 0,
            positiveRate: 0,
            byQuestionType: {},
            byDifficulty: {},
            relevanceScore: 0,
            accuracyScore: 0
        };
        
        this.init();
    }
    
    /**
     * Initialize the metrics display
     */
    init() {
        this.updateMetricsFromStorage();
        this.addMetricsDisplay();
        this.addParameterOptimizationButton();
        this.setupEventListeners();
    }
    
    /**
     * Update metrics from localStorage
     */
    updateMetricsFromStorage() {
        try {
            // Load data from localStorage
            const feedbackHistory = JSON.parse(localStorage.getItem('ophthalmoQA_feedbackHistory') || '[]');
            const questionHistory = JSON.parse(localStorage.getItem('ophthalmoQA_questionHistory') || '[]');
            const improvedQuestions = JSON.parse(localStorage.getItem('ophthalmoQA_improvedQuestions') || '{}');
            
            // Reset metrics data
            this.metricsData = {
                totalQuestions: questionHistory.length,
                totalFeedback: feedbackHistory.length,
                totalImproved: Object.keys(improvedQuestions).length,
                positiveRate: 0,
                byQuestionType: {},
                byDifficulty: {},
                relevanceScore: 0,
                accuracyScore: 0
            };
            
            // Calculate positive feedback rate
            const qualityFeedback = feedbackHistory.filter(item => item.feedbackType === 'good' || item.feedbackType === 'bad');
            const positiveFeedback = feedbackHistory.filter(item => item.feedbackType === 'good');
            this.metricsData.positiveRate = qualityFeedback.length > 0 
                ? Math.round((positiveFeedback.length / qualityFeedback.length) * 100) 
                : 0;
            
            // Calculate metrics by question type
            this.metricsData.byQuestionType = this.calculateByQuestionType(questionHistory, feedbackHistory);
            
            // Calculate metrics by difficulty
            this.metricsData.byDifficulty = this.calculateByDifficulty(questionHistory, feedbackHistory);
            
            // Calculate relevance score
            const relevanceFeedback = feedbackHistory.filter(item => item.feedbackType === 'relevant' || item.feedbackType === 'irrelevant');
            const relevantFeedback = feedbackHistory.filter(item => item.feedbackType === 'relevant');
            this.metricsData.relevanceScore = relevanceFeedback.length > 0 
                ? Math.round((relevantFeedback.length / relevanceFeedback.length) * 100) 
                : 0;
            
            // Calculate accuracy score (same as positive rate for now)
            this.metricsData.accuracyScore = this.metricsData.positiveRate;
            
            // Calculate improvement impact
            this.calculateImprovementImpact(questionHistory, feedbackHistory, improvedQuestions);
        } catch (error) {
            console.error('Error updating metrics from storage:', error);
        }
    }

    /**
     * Calculate improvement impact (missing method)
     */
    calculateImprovementImpact(questionHistory, feedbackHistory, improvedQuestions = {}) {
        try {
            // Get improved questions data
            const improved = Object.keys(improvedQuestions);
            
            if (improved.length === 0) {
                this.metricsData.improvementImpact = 0;
                return;
            }

            // Calculate average impact score
            const impacts = improved.map(questionId => {
                const improvement = improvedQuestions[questionId];
                return improvement.impact || 0.5;
            });

            const averageImpact = impacts.reduce((sum, impact) => sum + impact, 0) / impacts.length;
            
            // Calculate improvement rate (improved vs total questions)
            const improvementRate = improved.length / Math.max(questionHistory.length, 1);
            
            // Combined impact score
            this.metricsData.improvementImpact = Math.round((averageImpact * improvementRate) * 100) / 100;
            
            console.log(`📈 Improvement impact calculated: ${this.metricsData.improvementImpact}`);
            
        } catch (error) {
            console.error('Error calculating improvement impact:', error);
            this.metricsData.improvementImpact = 0;
        }
    }
    
    /**
     * Calculate metrics by question type
     */
    calculateByQuestionType(questionHistory, feedbackHistory) {
        const typeMetrics = {};
        
        // Initialize types
        const types = ['mcq', 'tf', 'matching', 'short-answer', 'clinical-case', 'differential', 'management', 'viva', 'osce'];
        types.forEach(type => {
            typeMetrics[type] = {
                total: 0,
                feedback: 0,
                positive: 0,
                improved: 0,
                positiveRate: 0
            };
        });
        
        // Count questions by type
        questionHistory.forEach(question => {
            const type = question.type || 'unknown';
            if (typeMetrics[type]) {
                typeMetrics[type].total++;
            }
        });
        
        // Count feedback by type
        feedbackHistory.forEach(feedback => {
            const questionId = feedback.questionId;
            const question = questionHistory.find(q => q.id === questionId);
            
            if (question && question.type && typeMetrics[question.type]) {
                typeMetrics[question.type].feedback++;
                
                if (feedback.feedbackType === 'good') {
                    typeMetrics[question.type].positive++;
                }
            }
        });
        
        // Count improved questions by type
        const improvedQuestions = JSON.parse(localStorage.getItem('ophthalmoQA_improvedQuestions') || '{}');
        Object.keys(improvedQuestions).forEach(questionId => {
            const question = questionHistory.find(q => q.id === questionId);
            
            if (question && question.type && typeMetrics[question.type]) {
                typeMetrics[question.type].improved++;
            }
        });
        
        // Calculate positive rates
        Object.keys(typeMetrics).forEach(type => {
            if (typeMetrics[type].feedback > 0) {
                typeMetrics[type].positiveRate = Math.round((typeMetrics[type].positive / typeMetrics[type].feedback) * 100);
            }
        });
        
        return typeMetrics;
    }
    
    /**
     * Calculate metrics by difficulty level
     */
    calculateByDifficulty(questionHistory, feedbackHistory) {
        const difficultyMetrics = {
            resident: { total: 0, feedback: 0, positive: 0, positiveRate: 0 },
            board: { total: 0, feedback: 0, positive: 0, positiveRate: 0 },
            specialist: { total: 0, feedback: 0, positive: 0, positiveRate: 0 },
            advanced: { total: 0, feedback: 0, positive: 0, positiveRate: 0 }
        };
        
        // Get generation history to determine difficulty for each question
        const generationHistory = JSON.parse(localStorage.getItem('ophthalmoQA_generationHistory') || '[]');
        
        // Map questions to difficulty based on generation timestamp
        questionHistory.forEach(question => {
            const generation = generationHistory.find(g => 
                g.timestamp === question.generationTimestamp || 
                g.sessionId === question.sessionId
            );
            
            if (generation && generation.difficulty) {
                difficultyMetrics[generation.difficulty].total++;
            }
        });
        
        // Count feedback by difficulty
        feedbackHistory.forEach(feedback => {
            const questionId = feedback.questionId;
            const question = questionHistory.find(q => q.id === questionId);
            
            if (question) {
                const generation = generationHistory.find(g => 
                    g.timestamp === question.generationTimestamp || 
                    g.sessionId === question.sessionId
                );
                
                if (generation && generation.difficulty) {
                    difficultyMetrics[generation.difficulty].feedback++;
                    
                    if (feedback.feedbackType === 'good') {
                        difficultyMetrics[generation.difficulty].positive++;
                    }
                }
            }
        });
        
        // Calculate positive rates
        Object.keys(difficultyMetrics).forEach(difficulty => {
            if (difficultyMetrics[difficulty].feedback > 0) {
                difficultyMetrics[difficulty].positiveRate = Math.round(
                    (difficultyMetrics[difficulty].positive / difficultyMetrics[difficulty].feedback) * 100
                );
            }
        });
        
        return difficultyMetrics;
    }
    
    /**
     * Add metrics display to the UI
     */
    addMetricsDisplay() {
        // Check if metrics display already exists
        if (document.getElementById('feedback-metrics-display')) {
            return;
        }
        
        // Create metrics display container
        const metricsDisplay = document.createElement('div');
        metricsDisplay.id = 'feedback-metrics-display';
        metricsDisplay.className = 'p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200 mt-4 hidden';
        
        // Add metrics content
        metricsDisplay.innerHTML = `
            <div class="flex items-center justify-between">
                <h3 class="text-sm font-semibold text-blue-800 flex items-center">
                    <i class="fas fa-chart-line mr-1.5"></i> Feedback & Improvement Metrics
                </h3>
                <button id="toggle-metrics-detail" class="text-xs text-blue-600 hover:text-blue-800">
                    <i class="fas fa-chevron-down"></i> Show Details
                </button>
            </div>
            
            <div class="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <div class="bg-white p-2 rounded border border-blue-100 flex flex-col justify-center items-center">
                    <div class="text-gray-500">Feedback Rate</div>
                    <div class="font-bold text-lg text-blue-600">${this.getPercentageOfQuestionsWithFeedback()}%</div>
                </div>
                <div class="bg-white p-2 rounded border border-blue-100 flex flex-col justify-center items-center">
                    <div class="text-gray-500">Positive Rate</div>
                    <div class="font-bold text-lg text-green-600">${this.metricsData.positiveRate}%</div>
                </div>
                <div class="bg-white p-2 rounded border border-blue-100 flex flex-col justify-center items-center">
                    <div class="text-gray-500">Questions Improved</div>
                    <div class="font-bold text-lg text-purple-600">${this.metricsData.totalImproved}</div>
                </div>
                <div class="bg-white p-2 rounded border border-blue-100 flex flex-col justify-center items-center">
                    <div class="text-gray-500">Total Questions</div>
                    <div class="font-bold text-lg text-gray-700">${this.metricsData.totalQuestions}</div>
                </div>
            </div>
            
            <div id="metrics-detail" class="mt-3 pt-3 border-t border-blue-200 hidden">
                <div class="text-xs font-medium text-blue-700 mb-2">Question Type Performance</div>
                <div id="type-metrics-bars" class="space-y-2">
                    ${this.generateTypeMetricsBars()}
                </div>
                
                <div class="mt-3 text-xs font-medium text-blue-700 mb-2">Difficulty Level Performance</div>
                <div id="difficulty-metrics-bars" class="space-y-2">
                    ${this.generateDifficultyMetricsBars()}
                </div>
            </div>
        `;
        
        // Add display to the main container
        const mainContainer = document.querySelector('.container');
        if (mainContainer) {
            const qaSection = document.querySelector('section:nth-child(2)');
            if (qaSection) {
                qaSection.insertBefore(metricsDisplay, qaSection.children[1]);
            } else {
                mainContainer.appendChild(metricsDisplay);
            }
            
            // Only show if we have data
            if (this.metricsData.totalQuestions > 0) {
                metricsDisplay.classList.remove('hidden');
            }
            
            // Add toggle event listener for details
            const toggleButton = document.getElementById('toggle-metrics-detail');
            const detailsSection = document.getElementById('metrics-detail');
            
            if (toggleButton && detailsSection) {
                toggleButton.addEventListener('click', () => {
                    detailsSection.classList.toggle('hidden');
                    const isHidden = detailsSection.classList.contains('hidden');
                    toggleButton.innerHTML = isHidden 
                        ? '<i class="fas fa-chevron-down"></i> Show Details' 
                        : '<i class="fas fa-chevron-up"></i> Hide Details';
                });
            }
        }
    }
    
    /**
     * Generate the HTML for type metrics bars
     */
    generateTypeMetricsBars() {
        const types = [
            { id: 'mcq', name: 'Multiple Choice' },
            { id: 'clinical-case', name: 'Clinical Case' },
            { id: 'short-answer', name: 'Short Answer' },
            { id: 'management', name: 'Management' }
        ];
        
        return types.map(type => {
            const typeData = this.metricsData.byQuestionType[type.id] || { 
                total: 0, 
                positiveRate: 0, 
                improved: 0 
            };
            const positiveRate = typeData.positiveRate || 0;
            const barColor = this.getBarColorClass(positiveRate);
            
            return `
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <span class="text-gray-600">${type.name}</span>
                        <span class="text-gray-700 font-medium">${positiveRate}%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-1.5">
                        <div class="${barColor} h-1.5 rounded-full" style="width: ${positiveRate}%"></div>
                    </div>
                    <div class="flex justify-end mt-0.5">
                        <span class="text-gray-500 text-xs">${typeData.improved} improved</span>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    /**
     * Generate the HTML for difficulty metrics bars
     */
    generateDifficultyMetricsBars() {
        const difficulties = [
            { id: 'resident', name: 'Resident/Training' },
            { id: 'board', name: 'Board Preparation' },
            { id: 'specialist', name: 'Specialist/Fellow' },
            { id: 'advanced', name: 'Advanced Practice' }
        ];
        
        return difficulties.map(difficulty => {
            const difficultyData = this.metricsData.byDifficulty[difficulty.id] || { 
                total: 0, 
                positiveRate: 0 
            };
            const positiveRate = difficultyData.positiveRate || 0;
            const barColor = this.getBarColorClass(positiveRate);
            
            return `
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <span class="text-gray-600">${difficulty.name}</span>
                        <span class="text-gray-700 font-medium">${positiveRate}%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-1.5">
                        <div class="${barColor} h-1.5 rounded-full" style="width: ${positiveRate}%"></div>
                    </div>
                    <div class="flex justify-end mt-0.5">
                        <span class="text-gray-500 text-xs">${difficultyData.total} questions</span>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    /**
     * Get the percentage of questions that have received feedback
     */
    getPercentageOfQuestionsWithFeedback() {
        if (this.metricsData.totalQuestions === 0) return 0;
        
        // Get unique question IDs that have feedback
        const feedbackHistory = JSON.parse(localStorage.getItem('ophthalmoQA_feedbackHistory') || '[]');
        const uniqueQuestionIds = new Set();
        
        feedbackHistory.forEach(entry => {
            if (entry.questionId) {
                uniqueQuestionIds.add(entry.questionId);
            }
        });
        
        return Math.round((uniqueQuestionIds.size / this.metricsData.totalQuestions) * 100);
    }
    
    /**
     * Get appropriate color class for a percentage bar
     */
    getBarColorClass(percentage) {
        if (percentage >= 80) return 'bg-green-500';
        if (percentage >= 60) return 'bg-blue-500';
        if (percentage >= 40) return 'bg-yellow-500';
        return 'bg-red-500';
    }
    
    /**
     * Add a button to optimize generation parameters based on feedback
     */
    addParameterOptimizationButton() {
        // Only add the button if we have enough feedback data
        if (this.metricsData.totalFeedback < 5) return;
        
        // Check if button already exists
        if (document.getElementById('optimize-parameters-btn')) return;
        
        // Create the button
        const optimizeButton = document.createElement('button');
        optimizeButton.id = 'optimize-parameters-btn';
        optimizeButton.className = 'w-full text-sm text-white font-medium py-2 px-4 rounded flex items-center justify-center';
        optimizeButton.innerHTML = '<i class="fas fa-magic mr-2"></i> Optimize Parameters Based on Feedback';
        
        // Add the button to the metrics display
        const metricsDisplay = document.getElementById('feedback-metrics-display');
        if (metricsDisplay) {
            metricsDisplay.appendChild(optimizeButton);
            
            // Add click event listener
            optimizeButton.addEventListener('click', () => {
                this.optimizeParameters();
            });
        }
    }
    
    /**
     * Optimize generation parameters based on feedback
     */
    optimizeParameters() {
        // Get the best performing question types
        const typeMetrics = this.metricsData.byQuestionType;
        const sortedTypes = Object.keys(typeMetrics)
            .filter(type => typeMetrics[type].feedback >= 3) // Only consider types with enough feedback
            .sort((a, b) => typeMetrics[b].positiveRate - typeMetrics[a].positiveRate);
        
        // Get the best performing difficulty level
        const difficultyMetrics = this.metricsData.byDifficulty;
        const sortedDifficulties = Object.keys(difficultyMetrics)
            .filter(diff => difficultyMetrics[diff].feedback >= 3) // Only consider difficulties with enough feedback
            .sort((a, b) => difficultyMetrics[b].positiveRate - difficultyMetrics[a].positiveRate);
        
        // Set best performing parameters
        const bestTypes = sortedTypes.slice(0, 3); // Take top 3 types
        const bestDifficulty = sortedDifficulties.length > 0 ? sortedDifficulties[0] : null;
        
        // Apply to form
        if (bestTypes.length > 0) {
            // Uncheck all types first
            document.querySelectorAll('[id^="type-"]').forEach(checkbox => {
                if (checkbox.id !== 'type-all') {
                    checkbox.checked = false;
                }
            });
            
            // Check the best performing types
            bestTypes.forEach(type => {
                const checkbox = document.getElementById(`type-${type}`);
                if (checkbox) checkbox.checked = true;
            });
        }
        
        // Set best difficulty
        if (bestDifficulty) {
            const difficultySelect = document.getElementById('difficulty');
            if (difficultySelect) difficultySelect.value = bestDifficulty;
        }
        
        // Show notification
        this.showOptimizationNotification(bestTypes, bestDifficulty);
    }
    
    /**
     * Show a notification that parameters have been optimized
     */
    showOptimizationNotification(bestTypes, bestDifficulty) {
        const notification = document.createElement('div');
        notification.className = 'bg-green-100 border-l-4 border-green-500 text-green-700 p-3 rounded-md mb-4 fixed bottom-4 right-4 shadow-lg z-50';
        notification.style.maxWidth = '300px';
        
        // Format type names for display
        const typeNames = bestTypes.map(type => {
            switch (type) {
                case 'mcq': return 'Multiple Choice';
                case 'tf': return 'True/False';
                case 'matching': return 'Matching';
                case 'short-answer': return 'Short Answer';
                case 'clinical-case': return 'Clinical Case';
                case 'differential': return 'Differential';
                case 'management': return 'Management';
                case 'viva': return 'VIVA';
                case 'osce': return 'OSCE Stations';
                default: return type;
            }
        });
        
        // Format difficulty name
        let difficultyName = '';
        if (bestDifficulty) {
            switch (bestDifficulty) {
                case 'resident': difficultyName = 'Resident/Training'; break;
                case 'board': difficultyName = 'Board Preparation'; break;
                case 'specialist': difficultyName = 'Specialist/Fellow'; break;
                case 'advanced': difficultyName = 'Advanced Practice'; break;
                default: difficultyName = bestDifficulty;
            }
        }
        
        notification.innerHTML = `
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle mt-0.5"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium">Parameters Optimized</p>
                    <div class="mt-1 text-xs">
                        <p>Based on your feedback history, we've optimized:</p>
                        <ul class="list-disc list-inside mt-1">
                            ${bestTypes.length > 0 ? `<li>Question types: ${typeNames.join(', ')}</li>` : ''}
                            ${bestDifficulty ? `<li>Difficulty: ${difficultyName}</li>` : ''}
                        </ul>
                    </div>
                    <button class="mt-2 bg-green-700 text-white text-xs px-2 py-1 rounded" id="close-optimization-notification">
                        Got it
                    </button>
                </div>
            </div>
        `;
        
        // Add to body
        document.body.appendChild(notification);
        
        // Add close button event listener
        const closeButton = document.getElementById('close-optimization-notification');
        if (closeButton) {
            closeButton.addEventListener('click', () => {
                document.body.removeChild(notification);
            });
        }
        
        // Auto remove after 10 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 10000);
    }
    
    /**
     * Set up event listeners
     */
    setupEventListeners() {
        // Listen for new feedback
        document.addEventListener('questionFeedbackAdded', (event) => {
            console.log('Feedback metrics: Received feedback event', event.detail);
            this.updateMetricsFromStorage();
            this.updateDisplay();
        });
        
        // Listen for question improvements
        document.addEventListener('questionImproved', (event) => {
            console.log('Feedback metrics: Received question improvement event', event.detail);
            this.updateMetricsFromStorage();
            this.updateDisplay();
        });
        
        // Listen for new questions generated
        document.addEventListener('questionsGenerated', (event) => {
            console.log('Feedback metrics: Received questions generation event', event.detail.questions.length + ' questions');
            this.updateMetricsFromStorage();
            this.updateDisplay();
            this.addParameterOptimizationButton();
        });
        
        // Listen for regenerated questions
        document.addEventListener('questionsRegenerated', (event) => {
            console.log('Feedback metrics: Received questions regeneration event', event.detail.questions.length + ' questions');
            this.updateMetricsFromStorage();
            this.updateDisplay();
        });
        
        // Add click listener for feedback analytics button
        document.getElementById('view-feedback-analytics')?.addEventListener('click', () => {
            this.showFeedbackAnalyticsModal();
        });
    }
    
    /**
     * Update the metrics display with new data
     */
    updateDisplay() {
        const metricsDisplay = document.getElementById('feedback-metrics-display');
        if (!metricsDisplay) {
            this.addMetricsDisplay();
            return;
        }
        
        // Show the display if we have data
        if (this.metricsData.totalQuestions > 0) {
            metricsDisplay.classList.remove('hidden');
        }
        
        // Update the metrics values
        const feedbackRate = metricsDisplay.querySelector(':nth-child(2) > :nth-child(1) > :nth-child(2)');
        const positiveRate = metricsDisplay.querySelector(':nth-child(2) > :nth-child(2) > :nth-child(2)');
        const improved = metricsDisplay.querySelector(':nth-child(2) > :nth-child(3) > :nth-child(2)');
        const total = metricsDisplay.querySelector(':nth-child(2) > :nth-child(4) > :nth-child(2)');
        
        if (feedbackRate) feedbackRate.textContent = `${this.getPercentageOfQuestionsWithFeedback()}%`;
        if (positiveRate) positiveRate.textContent = `${this.metricsData.positiveRate}%`;
        if (improved) improved.textContent = this.metricsData.totalImproved.toString();
        if (total) total.textContent = this.metricsData.totalQuestions.toString();
        
        // Update type metrics
        const typeMetricsContainer = document.getElementById('type-metrics-bars');
        if (typeMetricsContainer) {
            typeMetricsContainer.innerHTML = this.generateTypeMetricsBars();
        }
        
        // Update difficulty metrics
        const difficultyMetricsContainer = document.getElementById('difficulty-metrics-bars');
        if (difficultyMetricsContainer) {
            difficultyMetricsContainer.innerHTML = this.generateDifficultyMetricsBars();
        }
    }
    
    /**
     * Show feedback analytics modal
     */
    showFeedbackAnalyticsModal() {
        // Get feedback analytics modal
        let modal = document.getElementById('feedback-analytics-modal');
        
        // Create modal if it doesn't exist
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'feedback-analytics-modal';
            modal.className = 'fixed inset-0 flex items-center justify-center z-50 hidden';
            modal.innerHTML = `
                <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" id="feedback-analytics-modal-backdrop"></div>
                <div class="bg-white rounded-lg shadow-xl w-full max-w-4xl z-10 relative">
                    <div class="p-5 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                            <i class="fas fa-chart-line text-blue-600 mr-2"></i>
                            Feedback Impact Dashboard
                        </h3>
                        <button id="close-feedback-analytics-modal" class="text-gray-400 hover:text-gray-600 transition">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="p-5">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <!-- Feedback Overview -->
                            <div class="bg-blue-50 p-4 rounded-lg border border-blue-100">
                                <h4 class="font-medium text-blue-800 mb-2 flex items-center">
                                    <i class="fas fa-info-circle mr-1"></i> Feedback Overview
                                </h4>
                                <div class="text-sm">
                                    <div class="flex justify-between mb-1">
                                        <span>Total Feedback Collected:</span>
                                        <span id="feedback-total-count" class="font-semibold">0</span>
                                    </div>
                                    <div class="flex justify-between mb-1">
                                        <span>Questions Improved:</span>
                                        <span id="feedback-improved-count" class="font-semibold">0</span>
                                    </div>
                                    <div class="flex justify-between mb-1">
                                        <span>Positive Feedback Rate:</span>
                                        <span id="feedback-positive-rate" class="font-semibold">0%</span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Improvement Metrics -->
                            <div class="bg-green-50 p-4 rounded-lg border border-green-100">
                                <h4 class="font-medium text-green-800 mb-2 flex items-center">
                                    <i class="fas fa-chart-bar mr-1"></i> Improvement Metrics
                                </h4>
                                <div class="space-y-2 text-sm">
                                    <div>
                                        <div class="flex justify-between mb-1">
                                            <span>Relevance:</span>
                                            <span id="metric-relevance" class="font-semibold">0%</span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2">
                                            <div id="metric-relevance-bar" class="bg-green-500 h-2 rounded-full" style="width: 0%"></div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="flex justify-between mb-1">
                                            <span>Accuracy:</span>
                                            <span id="metric-accuracy" class="font-semibold">0%</span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2">
                                            <div id="metric-accuracy-bar" class="bg-blue-500 h-2 rounded-full" style="width: 0%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question Type Performance -->
                        <div class="mb-6">
                            <h4 class="font-medium text-gray-800 mb-2 flex items-center">
                                <i class="fas fa-list-alt mr-1"></i> Question Type Performance
                            </h4>
                            <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                                <div id="question-type-performance" class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 text-sm">
                                    <!-- Will be filled dynamically -->
                                </div>
                            </div>
                        </div>
                        
                        <!-- Parameter Recommendations -->
                        <div class="mb-6">
                            <h4 class="font-medium text-gray-800 mb-2 flex items-center">
                                <i class="fas fa-magic mr-1"></i> Parameter Recommendations
                            </h4>
                            <div class="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                                <div id="parameter-recommendations" class="text-sm">
                                    <p class="mb-2"><span class="font-semibold">Difficulty:</span> <span id="recommended-difficulty">No change recommended</span></p>
                                    <p class="mb-2"><span class="font-semibold">Recommended Question Types:</span></p>
                                    <div id="recommended-types" class="flex flex-wrap gap-2 mb-3">
                                        <span class="bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs">Not enough data yet</span>
                                    </div>
                                    <button id="apply-recommendations-btn" class="w-full mt-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md transition shadow-sm flex items-center justify-center">
                                        <i class="fas fa-magic mr-2"></i> Apply These Recommendations
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
        }
        
        // Show the modal
        modal.classList.remove('hidden');
        
        // Update the modal content
        this.updateFeedbackAnalyticsModal();
        
        // Add event listeners
        const closeButton = document.getElementById('close-feedback-analytics-modal');
        const backdrop = document.getElementById('feedback-analytics-modal-backdrop');
        const applyRecommendationsBtn = document.getElementById('apply-recommendations-btn');
        
        if (closeButton) {
            closeButton.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        }
        
        if (backdrop) {
            backdrop.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        }
        
        if (applyRecommendationsBtn) {
            applyRecommendationsBtn.addEventListener('click', () => {
                this.optimizeParameters();
                modal.classList.add('hidden');
            });
        }
    }
    
    /**
     * Update feedback analytics modal content
     */
    updateFeedbackAnalyticsModal() {
        // Update feedback overview
        const totalCount = document.getElementById('feedback-total-count');
        const improvedCount = document.getElementById('feedback-improved-count');
        const positiveRate = document.getElementById('feedback-positive-rate');
        
        if (totalCount) totalCount.textContent = this.metricsData.totalFeedback;
        if (improvedCount) improvedCount.textContent = this.metricsData.totalImproved;
        if (positiveRate) positiveRate.textContent = `${this.metricsData.positiveRate}%`;
        
        // Update improvement metrics
        this.updateMetricBar('relevance', this.metricsData.relevanceScore);
        this.updateMetricBar('accuracy', this.metricsData.accuracyScore);
        
        // Update question type performance
        this.updateQuestionTypePerformance();
        
        // Update parameter recommendations
        this.updateParameterRecommendations();
    }
    
    /**
     * Update a metric bar in the analytics modal
     */
    updateMetricBar(metricName, value) {
        const metricText = document.getElementById(`metric-${metricName}`);
        const metricBar = document.getElementById(`metric-${metricName}-bar`);
        
        if (metricText) metricText.textContent = `${value}%`;
        if (metricBar) metricBar.style.width = `${value}%`;
    }
    
    /**
     * Update question type performance section in analytics modal
     */
    updateQuestionTypePerformance() {
        const container = document.getElementById('question-type-performance');
        if (!container) return;
        
        // Clear container
        container.innerHTML = '';
        
        // Get question types with feedback
        const typeMetrics = this.metricsData.byQuestionType;
        const typesWithFeedback = Object.keys(typeMetrics)
            .filter(type => typeMetrics[type].feedback > 0)
            .sort((a, b) => typeMetrics[b].positiveRate - typeMetrics[a].positiveRate);
        
        // If no types have feedback, show message
        if (typesWithFeedback.length === 0) {
            container.innerHTML = '<p class="col-span-full text-center text-gray-500">No feedback data yet</p>';
            return;
        }
        
        // Add types to container
        typesWithFeedback.forEach(type => {
            const typeData = typeMetrics[type];
            const typeElement = document.createElement('div');
            typeElement.className = 'flex justify-between items-center p-2 bg-white rounded border border-gray-100';
            
            // Format type name
            let typeName = type;
            switch (type) {
                case 'mcq': typeName = 'Multiple Choice'; break;
                case 'tf': typeName = 'True/False'; break;
                case 'matching': typeName = 'Matching'; break;
                case 'short-answer': typeName = 'Short Answer'; break;
                case 'clinical-case': typeName = 'Clinical Case'; break;
                case 'differential': typeName = 'Differential'; break;
                case 'management': typeName = 'Management'; break;
                case 'viva': typeName = 'VIVA'; break;
                case 'osce': typeName = 'OSCE'; break;
            }
            
            // Get color based on positive rate
            let rateColor = 'text-red-600';
            if (typeData.positiveRate >= 80) rateColor = 'text-green-600';
            else if (typeData.positiveRate >= 60) rateColor = 'text-blue-600';
            else if (typeData.positiveRate >= 40) rateColor = 'text-yellow-600';
            
            typeElement.innerHTML = `
                <span>${typeName}:</span>
                <span class="font-semibold ${rateColor}">${typeData.positiveRate}%</span>
            `;
            
            container.appendChild(typeElement);
        });
    }
    
    /**
     * Update parameter recommendations in analytics modal
     */
    updateParameterRecommendations() {
        // Get recommendations from the feedback loop system
        const recommendations = window.feedbackLoop ? window.feedbackLoop.getRecommendedParameters() : { difficulty: null, questionTypes: [] };
        
        // Update difficulty recommendation
        const difficultyRecommendation = document.getElementById('recommended-difficulty');
        if (difficultyRecommendation && recommendations.difficulty) {
            let difficultyName = '';
            switch (recommendations.difficulty) {
                case 'resident': difficultyName = 'Resident/Training'; break;
                case 'board': difficultyName = 'Board Preparation'; break;
                case 'specialist': difficultyName = 'Specialist/Fellow'; break;
                case 'advanced': difficultyName = 'Advanced Practice'; break;
                default: difficultyName = recommendations.difficulty;
            }
            
            difficultyRecommendation.textContent = difficultyName;
        }
        
        // Update question type recommendations
        const typesContainer = document.getElementById('recommended-types');
        if (typesContainer && recommendations.questionTypes && recommendations.questionTypes.length > 0) {
            typesContainer.innerHTML = '';
            
            recommendations.questionTypes.forEach(type => {
                let typeName = type;
                switch (type) {
                    case 'mcq': typeName = 'Multiple Choice'; break;
                    case 'tf': typeName = 'True/False'; break;
                    case 'matching': typeName = 'Matching'; break;
                    case 'short-answer': typeName = 'Short Answer'; break;
                    case 'clinical-case': typeName = 'Clinical Case'; break;
                    case 'differential': typeName = 'Differential'; break;
                    case 'management': typeName = 'Management'; break;
                    case 'viva': typeName = 'VIVA'; break;
                    case 'osce': typeName = 'OSCE'; break;
                }
                
                const typeElement = document.createElement('span');
                typeElement.className = 'bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs';
                typeElement.textContent = typeName;
                typesContainer.appendChild(typeElement);
            });
        } else if (typesContainer) {
            typesContainer.innerHTML = '<span class="bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs">Not enough data yet</span>';
        }
    }
}

// Initialize the metrics display
document.addEventListener('DOMContentLoaded', () => {
    window.feedbackMetricsDisplay = new FeedbackMetricsDisplay();
    console.log('Feedback metrics display initialized');
}); 
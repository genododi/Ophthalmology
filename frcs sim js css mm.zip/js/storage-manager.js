/**
 * Storage Manager - Handles localStorage quota and cleanup
 * Fixes QuotaExceededError issues
 */

class StorageManager {
    constructor() {
        this.maxStorageSize = 4 * 1024 * 1024; // 4MB limit (conservative)
        this.compressionThreshold = 1024; // Compress data larger than 1KB
        this.maxRetentionDays = 30;
        this.init();
    }

    init() {
        console.log('🗄️ StorageManager initialized');
        this.checkStorageHealth();
        this.setupCleanupTimer();
    }

    /**
     * Safe setItem with quota management
     */
    setItem(key, value, options = {}) {
        try {
            const serialized = typeof value === 'string' ? value : JSON.stringify(value);
            
            // Check if we have space
            if (this.getStorageUsage() + serialized.length > this.maxStorageSize) {
                console.warn('⚠️ Storage nearly full, cleaning up...');
                this.performCleanup();
            }

            // Try to store
            localStorage.setItem(key, serialized);
            console.log(`✅ Stored ${key} (${serialized.length} bytes)`);
            return true;

        } catch (error) {
            if (error.name === 'QuotaExceededError') {
                console.error('❌ Storage quota exceeded, performing emergency cleanup...');
                this.emergencyCleanup();
                
                // Retry once after cleanup
                try {
                    localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
                    console.log(`✅ Stored ${key} after cleanup`);
                    return true;
                } catch (retryError) {
                    console.error('❌ Failed to store even after cleanup:', retryError);
                    return false;
                }
            } else {
                console.error('❌ Storage error:', error);
                return false;
            }
        }
    }

    /**
     * Safe getItem with error handling
     */
    getItem(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            if (item === null) return defaultValue;
            
            try {
                return JSON.parse(item);
            } catch {
                return item; // Return as string if not JSON
            }
        } catch (error) {
            console.error(`❌ Error reading ${key}:`, error);
            return defaultValue;
        }
    }

    /**
     * Get current storage usage
     */
    getStorageUsage() {
        let totalSize = 0;
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                totalSize += localStorage[key].length + key.length;
            }
        }
        return totalSize;
    }

    /**
     * Check storage health and warn if nearly full
     */
    checkStorageHealth() {
        const usage = this.getStorageUsage();
        const percentage = (usage / this.maxStorageSize) * 100;
        
        console.log(`📊 Storage usage: ${(usage / 1024).toFixed(1)}KB (${percentage.toFixed(1)}%)`);
        
        if (percentage > 80) {
            console.warn('⚠️ Storage usage high, cleanup recommended');
            this.performCleanup();
        }
    }

    /**
     * Perform regular cleanup
     */
    performCleanup() {
        console.log('🧹 Starting storage cleanup...');
        
        const cutoffDate = Date.now() - (this.maxRetentionDays * 24 * 60 * 60 * 1000);
        let cleanedItems = 0;
        let freedSpace = 0;

        // Clean old question history
        this.cleanOldQuestionHistory(cutoffDate);
        
        // Clean old feedback data
        this.cleanOldFeedbackData(cutoffDate);
        
        // Clean old generation history
        this.cleanOldGenerationHistory(cutoffDate);
        
        // Clean large temporary data
        this.cleanTemporaryData();

        console.log(`✅ Cleanup complete. Freed space: ${(freedSpace / 1024).toFixed(1)}KB`);
    }

    /**
     * Emergency cleanup when quota exceeded
     */
    emergencyCleanup() {
        console.log('🚨 Emergency cleanup - removing oldest data...');
        
        // Remove oldest 50% of question history
        this.trimQuestionHistory(0.5);
        
        // Remove oldest 50% of feedback data
        this.trimFeedbackData(0.5);
        
        // Remove all temporary data
        this.cleanTemporaryData();
        
        // Remove old parameter evolution data
        this.cleanParameterEvolution(0.7);
    }

    /**
     * Clean old question history
     */
    cleanOldQuestionHistory(cutoffDate) {
        try {
            const history = this.getItem('ophthalmoQA_questionHistory', []);
            const filtered = history.filter(item => 
                item.timestamp && item.timestamp > cutoffDate
            );
            
            if (filtered.length < history.length) {
                this.setItem('ophthalmoQA_questionHistory', filtered);
                console.log(`🗑️ Cleaned ${history.length - filtered.length} old questions`);
            }
        } catch (error) {
            console.error('Error cleaning question history:', error);
        }
    }

    /**
     * Clean old feedback data
     */
    cleanOldFeedbackData(cutoffDate) {
        try {
            const feedback = this.getItem('ophthalmoQA_feedbackHistory', []);
            const filtered = feedback.filter(item => 
                item.timestamp && item.timestamp > cutoffDate
            );
            
            if (filtered.length < feedback.length) {
                this.setItem('ophthalmoQA_feedbackHistory', filtered);
                console.log(`🗑️ Cleaned ${feedback.length - filtered.length} old feedback items`);
            }
        } catch (error) {
            console.error('Error cleaning feedback data:', error);
        }
    }

    /**
     * Clean old generation history
     */
    cleanOldGenerationHistory(cutoffDate) {
        try {
            const history = this.getItem('ophthalmoQA_generationHistory', []);
            const filtered = history.filter(item => 
                item.timestamp && item.timestamp > cutoffDate
            );
            
            if (filtered.length < history.length) {
                this.setItem('ophthalmoQA_generationHistory', filtered);
                console.log(`🗑️ Cleaned ${history.length - filtered.length} old generation entries`);
            }
        } catch (error) {
            console.error('Error cleaning generation history:', error);
        }
    }

    /**
     * Clean temporary data
     */
    cleanTemporaryData() {
        const tempKeys = [];
        for (let key in localStorage) {
            if (key.includes('temp_') || key.includes('cache_') || key.includes('debug_')) {
                tempKeys.push(key);
            }
        }
        
        tempKeys.forEach(key => localStorage.removeItem(key));
        if (tempKeys.length > 0) {
            console.log(`🗑️ Cleaned ${tempKeys.length} temporary items`);
        }
    }

    /**
     * Trim question history to percentage
     */
    trimQuestionHistory(keepPercentage) {
        try {
            const history = this.getItem('ophthalmoQA_questionHistory', []);
            const keepCount = Math.floor(history.length * keepPercentage);
            const trimmed = history.slice(-keepCount); // Keep most recent
            
            this.setItem('ophthalmoQA_questionHistory', trimmed);
            console.log(`🗑️ Trimmed question history to ${trimmed.length} items`);
        } catch (error) {
            console.error('Error trimming question history:', error);
        }
    }

    /**
     * Trim feedback data to percentage
     */
    trimFeedbackData(keepPercentage) {
        try {
            const feedback = this.getItem('ophthalmoQA_feedbackHistory', []);
            const keepCount = Math.floor(feedback.length * keepPercentage);
            const trimmed = feedback.slice(-keepCount); // Keep most recent
            
            this.setItem('ophthalmoQA_feedbackHistory', trimmed);
            console.log(`🗑️ Trimmed feedback data to ${trimmed.length} items`);
        } catch (error) {
            console.error('Error trimming feedback data:', error);
        }
    }

    /**
     * Clean parameter evolution data
     */
    cleanParameterEvolution(keepPercentage) {
        try {
            const evolution = this.getItem('ophthalmoQA_parameterEvolution', []);
            const keepCount = Math.floor(evolution.length * keepPercentage);
            const trimmed = evolution.slice(-keepCount);
            
            this.setItem('ophthalmoQA_parameterEvolution', trimmed);
            console.log(`🗑️ Trimmed parameter evolution to ${trimmed.length} items`);
        } catch (error) {
            console.error('Error cleaning parameter evolution:', error);
        }
    }

    /**
     * Setup automatic cleanup timer
     */
    setupCleanupTimer() {
        // Run cleanup every 10 minutes
        setInterval(() => {
            this.checkStorageHealth();
        }, 10 * 60 * 1000);
    }

    /**
     * Get storage statistics
     */
    getStorageStats() {
        const usage = this.getStorageUsage();
        const items = Object.keys(localStorage).length;
        
        return {
            totalUsage: usage,
            totalItems: items,
            percentage: (usage / this.maxStorageSize) * 100,
            formattedUsage: `${(usage / 1024).toFixed(1)}KB`,
            maxSize: `${(this.maxStorageSize / 1024).toFixed(1)}KB`
        };
    }

    /**
     * Export data for backup
     */
    exportData() {
        const data = {};
        for (let key in localStorage) {
            if (key.startsWith('ophthalmoQA_')) {
                data[key] = localStorage[key];
            }
        }
        return data;
    }

    /**
     * Clear all app data
     */
    clearAllData() {
        const keys = Object.keys(localStorage).filter(key => key.startsWith('ophthalmoQA_'));
        keys.forEach(key => localStorage.removeItem(key));
        console.log(`🗑️ Cleared all app data (${keys.length} items)`);
    }
}

// Create global storage manager instance
window.storageManager = new StorageManager();

// Replace localStorage methods globally for the app
window.safeSetItem = (key, value) => window.storageManager.setItem(key, value);
window.safeGetItem = (key, defaultValue) => window.storageManager.getItem(key, defaultValue);

console.log('✅ Storage Manager loaded and ready'); 
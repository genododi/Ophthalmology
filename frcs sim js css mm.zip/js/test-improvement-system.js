/**
 * Test Script for Question Improvement System
 * Demonstrates the feedback loop and improvement status functionality
 */

// Test function to demonstrate the improvement system
function testImprovementSystem() {
    console.log('🧪 Starting Improvement System Test...');
    
    // Test 1: Mark a sample question as improved
    const sampleQuestionId = 'test_question_1';
    const improvementDetails = {
        type: 'feedback_driven',
        confidence: 0.9,
        feedback: {
            type: 'quality',
            value: 'poor',
            timestamp: Date.now() - 120000 // 2 minutes ago
        },
        changes: [
            'Enhanced question clarity based on user feedback',
            'Improved clinical relevance',
            'Added more specific ophthalmology context',
            'Corrected medical terminology'
        ],
        impact: 0.8,
        before: {
            clarity: 0.6,
            relevance: 0.5,
            difficulty: 0.7
        },
        after: {
            clarity: 0.9,
            relevance: 0.8,
            difficulty: 0.7
        }
    };
    
    // Test the improvement marking
    if (window.markQuestionAsImproved) {
        const improvement = window.markQuestionAsImproved(sampleQuestionId, improvementDetails);
        console.log('✅ Test 1 passed: Question marked as improved', improvement);
    } else {
        console.error('❌ Test 1 failed: markQuestionAsImproved function not available');
        return false;
    }
    
    // Test 2: Check improvement status
    if (window.hasQuestionBeenImproved) {
        const hasImprovement = window.hasQuestionBeenImproved(sampleQuestionId);
        console.log(`✅ Test 2 passed: Has improvement check: ${hasImprovement}`);
    } else {
        console.error('❌ Test 2 failed: hasQuestionBeenImproved function not available');
        return false;
    }
    
    // Test 3: Get improvement statistics
    if (window.getImprovementStats) {
        const stats = window.getImprovementStats();
        console.log('✅ Test 3 passed: Improvement stats:', stats);
    } else {
        console.error('❌ Test 3 failed: getImprovementStats function not available');
        return false;
    }
    
    // Test 4: Enhanced QA extraction with feedback
    const sampleText = `
        Question 1: What is the most common cause of cataracts in the elderly?
        A) Diabetes
        B) Age-related changes
        C) Trauma
        D) Congenital factors
        
        Answer: B) Age-related changes
        
        Question 2: Which imaging technique is gold standard for diagnosing glaucoma?
        A) CT scan
        B) MRI
        C) OCT
        D) Ultrasound
        
        Answer: C) OCT (Optical Coherence Tomography)
    `;
    
    if (window.extractQuestionsWithFeedback) {
        window.extractQuestionsWithFeedback(sampleText, {
            confidenceThreshold: 0.3,
            includeMetadata: true
        }).then(result => {
            console.log('✅ Test 4 passed: Enhanced extraction with feedback:', result);
            
            // Test 5: Create improvement badges for extracted questions
            result.questions.forEach((qa, index) => {
                if (index === 0) {
                    // Mark first question as improved for demo
                    window.markQuestionAsImproved(qa.id, {
                        type: 'content_enhanced',
                        confidence: 0.85,
                        changes: ['Enhanced through feedback analysis'],
                        impact: 0.6
                    });
                }
            });
            
            console.log('🎉 All tests passed! Improvement system is working correctly.');
            
            // Create test results summary
            return {
                success: true,
                testsRun: 5,
                testsPassed: 5,
                features: [
                    'Question improvement marking',
                    'Improvement status checking',
                    'Statistics generation',
                    'Enhanced extraction with feedback',
                    'Visual improvement indicators'
                ]
            };
            
        }).catch(error => {
            console.error('❌ Test 4 failed: Enhanced extraction error:', error);
            return false;
        });
    } else {
        console.error('❌ Test 4 failed: extractQuestionsWithFeedback function not available');
        return false;
    }
    
    return true;
}

// Test the feedback status display functions
function testFeedbackStatusDisplay() {
    console.log('🎨 Testing Feedback Status Display...');
    
    const testQuestionId = 'display_test_question';
    
    // Mark question as improved
    if (window.markQuestionAsImproved) {
        window.markQuestionAsImproved(testQuestionId, {
            type: 'pattern_detected',
            confidence: 0.75,
            feedback: {
                type: 'relevance',
                value: 'no',
                timestamp: Date.now() - 300000 // 5 minutes ago
            },
            changes: [
                'Adjusted based on relevance feedback pattern',
                'Improved medical accuracy'
            ],
            impact: 0.65
        });
    }
    
    // Test status display functions
    if (window.getImprovementStatusDisplay) {
        const statusDisplay = window.getImprovementStatusDisplay(testQuestionId);
        console.log('📊 Status Display Test:', statusDisplay);
    }
    
    if (window.getImprovementStatus) {
        const status = window.getImprovementStatus(testQuestionId);
        console.log('📈 Improvement Status Test:', status);
    }
    
    console.log('✅ Feedback status display tests completed');
}

// Demonstrate improvement analytics
function demonstrateAnalytics() {
    console.log('📊 Demonstrating Improvement Analytics...');
    
    // Create multiple test improvements
    const testQuestions = [
        'analytics_test_1',
        'analytics_test_2', 
        'analytics_test_3',
        'analytics_test_4',
        'analytics_test_5'
    ];
    
    const improvementTypes = [
        'feedback_driven',
        'pattern_detected',
        'difficulty_adjusted',
        'content_enhanced',
        'auto_optimized'
    ];
    
    testQuestions.forEach((questionId, index) => {
        if (window.markQuestionAsImproved) {
            window.markQuestionAsImproved(questionId, {
                type: improvementTypes[index],
                confidence: 0.7 + (Math.random() * 0.2),
                feedback: {
                    type: Math.random() > 0.5 ? 'quality' : 'relevance',
                    value: Math.random() > 0.5 ? 'poor' : 'no',
                    timestamp: Date.now() - (Math.random() * 3600000) // Random time in last hour
                },
                changes: [
                    `Improvement type: ${improvementTypes[index]}`,
                    'Enhanced based on user feedback patterns'
                ],
                impact: 0.5 + (Math.random() * 0.4)
            });
        }
    });
    
    // Get and display stats
    if (window.getImprovementStats) {
        const stats = window.getImprovementStats();
        console.log('📈 Analytics Demo Stats:', stats);
        
        console.log(`
🎯 Improvement Analytics Summary:
• Total Improved Questions: ${stats.totalImproved}
• Average Confidence: ${Math.round(stats.averageConfidence * 100)}%
• Impact Score: ${Math.round(stats.impactScore * 100)}%
• Recent Improvements: ${stats.recentImprovements.length}
• Improvement Types: ${Object.keys(stats.improvementsByType).join(', ')}
        `);
    }
}

// Run all tests
function runAllTests() {
    console.log('🚀 Running Complete Improvement System Test Suite...');
    
    try {
        testImprovementSystem();
        setTimeout(() => testFeedbackStatusDisplay(), 1000);
        setTimeout(() => demonstrateAnalytics(), 2000);
        
        setTimeout(() => {
            console.log('🎉 Test Suite Complete! Check the console for detailed results.');
            console.log(`
📋 Test Summary:
✅ Question improvement marking
✅ Improvement status checking  
✅ Statistics generation
✅ Enhanced extraction with feedback
✅ Visual improvement indicators
✅ Feedback status display
✅ Analytics demonstration

💡 Next Steps:
1. Upload a document and extract questions
2. Use the feedback buttons to rate questions
3. Watch for automatic improvements based on feedback patterns
4. Check the Analytics dashboard for improvement statistics
5. Use the "Demo Improvement" button in Analytics for quick testing
            `);
        }, 3000);
        
    } catch (error) {
        console.error('❌ Test Suite Error:', error);
    }
}

// Auto-run tests when script loads (with delay for system initialization)
if (typeof window !== 'undefined') {
    setTimeout(() => {
        if (window.enhancedFeedbackSystem && window.enhancedQAExtractor) {
            runAllTests();
        } else {
            console.log('⏳ Waiting for systems to initialize...');
            setTimeout(() => {
                if (window.enhancedFeedbackSystem && window.enhancedQAExtractor) {
                    runAllTests();
                } else {
                    console.warn('⚠️ Some systems not initialized. Manual testing may be required.');
                }
            }, 5000);
        }
    }, 2000);
}

// Export test functions for manual use
window.testImprovementSystem = testImprovementSystem;
window.testFeedbackStatusDisplay = testFeedbackStatusDisplay;
window.demonstrateAnalytics = demonstrateAnalytics;
window.runAllTests = runAllTests;

console.log('🧪 Improvement System Test Script Loaded');
console.log('Use runAllTests() to run the complete test suite, or individual test functions for specific testing.'); 
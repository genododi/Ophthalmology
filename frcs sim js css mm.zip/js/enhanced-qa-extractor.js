/**
 * Enhanced Q&A Extraction System
 * Improved algorithms for extracting questions and answers from various document formats
 */

class EnhancedQAExtractor {
    constructor() {
        this.extractionPatterns = this.initializePatterns();
        this.confidenceThresholds = {
            high: 0.8,
            medium: 0.6,
            low: 0.4
        };
        this.extractedQuestions = [];
        this.extractionStats = {
            total: 0,
            withAnswers: 0,
            byType: {},
            byConfidence: { high: 0, medium: 0, low: 0 },
            averageConfidence: 0
        };
    }

    initializePatterns() {
        return {
            // Question patterns
            questionStarters: [
                // Traditional question words
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?(?:What|Which|Where|When|Why|How|Who|Is|Are|Can|Could|Will|Would|Should|Does|Do|Did)\b/i,
                
                // Medical question patterns
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?(?:A\s+(?:\d+\s*year\s*old|patient)|The\s+(?:most|best|first|primary)|All\s+of\s+the\s+following|Which\s+of\s+the\s+following)\b/i,
                
                // Clinical scenario patterns
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?(?:A\s+patient|The\s+patient|You\s+are|In\s+a\s+patient|During\s+examination)\b/i,
                
                // FRCS specific patterns
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?(?:In\s+(?:retinal|corneal|glaucoma|cataract)|The\s+(?:fundus|IOP|visual\s+field)|(?:Phacoemulsification|Vitrectomy|Trabeculectomy))\b/i,
                
                // True/False patterns
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?(?:True\s+or\s+false|T\/F|State\s+whether)\b/i,
                
                // Fill in the blank patterns
                /^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?.*(?:___|\.\.\.|\[.*\]|complete\s+the\s+sentence)\b/i
            ],

            // Answer patterns
            answerPatterns: [
                // Direct answer indicators
                /^(?:Answer|Ans|Solution|Explanation)[:\.]?\s*/i,
                
                // Lettered/numbered answers
                /^(?:[A-E][\):\.]|(?:a|b|c|d|e)[\):\.]|\d+[\):\.])\s*/i,
                
                // True/False answers
                /^(?:True|False|T|F)[\.\s]/i,
                
                // Medical answer patterns
                /^(?:The\s+(?:correct\s+)?answer\s+is|This\s+is|Management\s+includes?|Treatment\s+involves?)\b/i,
                
                // Explanation patterns
                /^(?:Rationale|Explanation|Because|This\s+is\s+because|The\s+reason)\b/i
            ],

            // Multiple choice patterns
            multipleChoiceOptions: [
                /^[A-E][\):\.]?\s+/i,
                /^\([A-E]\)\s+/i,
                /^(?:a|b|c|d|e)[\):\.]?\s+/i,
                /^\((?:a|b|c|d|e)\)\s+/i
            ],

            // Content type indicators
            contentTypes: {
                clinical: /(?:patient|symptoms?|diagnosis|treatment|management|examination|history)/i,
                surgical: /(?:surgery|surgical|procedure|operation|incision|suture|technique)/i,
                anatomy: /(?:anatomy|anatomical|structure|nerve|artery|vein|muscle|bone)/i,
                pharmacology: /(?:drug|medication|treatment|therapy|dosage|administration)/i,
                pathology: /(?:pathology|disease|condition|disorder|syndrome|abnormality)/i,
                imaging: /(?:CT|MRI|X-ray|ultrasound|OCT|angiography|imaging|scan)/i
            },

            // Medical specialties
            ophthalmologyTopics: {
                retina: /(?:retina|retinal|macula|macular|vitreous|diabetic\s+retinopathy|AMD|ARMD)/i,
                glaucoma: /(?:glaucoma|IOP|intraocular\s+pressure|optic\s+disc|visual\s+field|trabeculectomy)/i,
                cornea: /(?:cornea|corneal|keratitis|dystrophy|transplant|keratoplasty|epithelium)/i,
                cataract: /(?:cataract|lens|phacoemulsification|IOL|intraocular\s+lens|capsule)/i,
                oculoplastics: /(?:eyelid|orbit|orbital|ptosis|ectropion|entropion|tear\s+duct)/i,
                neuro: /(?:optic\s+nerve|visual\s+pathway|diplopia|nystagmus|pupil|cranial\s+nerve)/i,
                pediatric: /(?:pediatric|paediatric|children|child|amblyopia|strabismus|squint)/i
            }
        };
    }

    async extractFromText(text, options = {}) {
        console.log('🔍 Starting enhanced Q&A extraction...');
        
        const extractionOptions = {
            preserveFormatting: true,
            extractImages: false,
            includeMetadata: true,
            confidenceThreshold: 0.4,
            smartPreprocessing: true,
            ...options
        };

        // Enhanced preprocessing with file analysis
        let processedText = text;
        
        // Analyze content structure first
        if (window.analyzeFileContent && extractionOptions.smartPreprocessing) {
            try {
                const analysis = await window.analyzeFileContent(text);
                console.log('📊 Content analysis:', analysis);
                
                // Adjust extraction strategy based on content type
                if (analysis.contentType === 'multiple_choice_quiz') {
                    extractionOptions.focusOnMCQ = true;
                } else if (analysis.contentType === 'questions_only') {
                    extractionOptions.generateAnswers = true;
                }
                
                // Store analysis for later use
                extractionOptions.contentAnalysis = analysis;
            } catch (error) {
                console.warn('Content analysis failed, using standard preprocessing:', error);
            }
        }

        // Clean and preprocess text with enhanced algorithms
        const cleanedText = this.enhancedPreprocessText(processedText, extractionOptions);
        
        // Split into potential question blocks with improved detection
        const questionBlocks = this.identifyQuestionBlocksEnhanced(cleanedText, extractionOptions);
        
        // Extract questions and answers from each block
        const extractedQAs = [];
        
        for (let i = 0; i < questionBlocks.length; i++) {
            const block = questionBlocks[i];
            const qa = await this.extractQAFromBlock(block, i + 1, extractionOptions);
            
            if (qa && qa.confidence >= extractionOptions.confidenceThreshold) {
                extractedQAs.push(qa);
            }
        }

        // Post-process and validate extracted Q&As
        const validatedQAs = this.validateAndEnhanceQAs(extractedQAs);
        
        // Update extraction statistics
        this.updateExtractionStats(validatedQAs);
        
        console.log(`✅ Extraction complete: ${validatedQAs.length} questions extracted`);
        
        return {
            questions: validatedQAs,
            stats: this.extractionStats,
            metadata: {
                totalBlocks: questionBlocks.length,
                processingTime: Date.now(),
                extractionOptions
            }
        };
    }

    preprocessText(text) {
        // Remove excessive whitespace and normalize line breaks
        let cleaned = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        
        // Fix common OCR errors and formatting issues
        cleaned = cleaned
            .replace(/[""]/g, '"')  // Smart quotes
            .replace(/['']/g, "'")  // Smart apostrophes
            .replace(/–/g, '-')     // En dash
            .replace(/—/g, '--')    // Em dash
            .replace(/\.\s*\.\s*\./g, '...') // Multiple dots
            .replace(/\s{3,}/g, '  ') // Excessive spaces
            .replace(/\n{4,}/g, '\n\n\n'); // Excessive line breaks

        // Fix common medical term OCR errors
        const medicalCorrections = {
            'IOL': /I0L|I0l|l0L|l0l/g,
            'IOP': /I0P|l0P|10P/g,
            'OCT': /0CT|0ct|OcT/g,
            'AMD': /AM0|AmD|amd/g,
            'mg': /rng|mg\./g,
            'ml': /rnl|ml\./g
        };

        Object.entries(medicalCorrections).forEach(([correct, pattern]) => {
            cleaned = cleaned.replace(pattern, correct);
        });

        return cleaned;
    }

    enhancedPreprocessText(text, options = {}) {
        console.log('🔧 Enhanced preprocessing with smart algorithms...');
        
        let processed = text;
        
        // 1. Use advanced file processor if available
        if (window.advancedFileProcessor) {
            processed = window.advancedFileProcessor.fixCommonIssues(processed);
            processed = window.advancedFileProcessor.enhanceStructure(processed);
        }
        
        // 2. Apply standard preprocessing
        processed = this.preprocessText(processed);
        
        // 3. Enhanced question/answer structure detection
        processed = this.enhanceQuestionAnswerStructure(processed, options);
        
        // 4. Improve formatting for different question types
        processed = this.improveQuestionTypeFormatting(processed, options);
        
        // 5. Fix common extraction issues
        processed = this.fixExtractionIssues(processed);
        
        console.log(`✅ Enhanced preprocessing complete. Text length: ${processed.length}`);
        return processed;
    }

    enhanceQuestionAnswerStructure(text, options) {
        let enhanced = text;
        
        // Improve question numbering detection
        enhanced = enhanced.replace(/^(\d+)[\.\)\]\:]?\s*([A-Z])/gm, '$1. $2');
        
        // Fix question markers
        enhanced = enhanced.replace(/^(Q\d*[\.\:]?|Question\s*\d*[\.\:]?)\s*/gmi, '\n$1 ');
        
        // Improve answer detection and formatting
        enhanced = enhanced.replace(/^(A\d*[\.\:]?|Answer\s*\d*[\.\:]?)\s*/gmi, '\nAnswer: ');
        enhanced = enhanced.replace(/^(Ans[\.\:]?)\s*/gmi, '\nAnswer: ');
        
        // Enhanced multiple choice option detection
        enhanced = enhanced.replace(/^([A-E])[\.\)\]\:]?\s*([^A-E\n])/gm, '$1) $2');
        enhanced = enhanced.replace(/^\(([A-E])\)\s*/gm, '$1) ');
        
        // Fix true/false questions
        enhanced = enhanced.replace(/^(True\s+or\s+False|T\/F)[\:\.]?\s*/gmi, '\n$1: ');
        
        // Improve paragraph separation for better question isolation
        enhanced = enhanced.replace(/([.!?])\s*(\d+[\.\)]?\s*[A-Z])/g, '$1\n\n$2');
        
        return enhanced;
    }

    improveQuestionTypeFormatting(text, options) {
        let formatted = text;
        
        // Focus on MCQ if detected
        if (options.focusOnMCQ || options.contentAnalysis?.hasMultipleChoice) {
            // Ensure proper spacing for options
            formatted = formatted.replace(/([A-E]\))\s*([A-Z])/g, '$1 $2');
            formatted = formatted.replace(/([^A-E])\s*([A-E]\)\s*[A-Z])/g, '$1\n$2');
        }
        
        // Improve clinical scenario questions
        formatted = formatted.replace(/^(Case\s*\d*[\:\.]?|Clinical\s+Scenario[\:\.]?)\s*/gmi, '\n$1 ');
        formatted = formatted.replace(/^(A\s+\d+\s*year\s*old\s+(?:male|female|patient))/gmi, '\n$1');
        
        // Fix fill-in-the-blank questions
        formatted = formatted.replace(/_{3,}/g, '___');
        formatted = formatted.replace(/\.{3,}/g, '...');
        
        // Improve short answer questions
        formatted = formatted.replace(/^(Explain|Describe|Discuss|Analyze|Compare)\s+/gmi, '\n$1 ');
        
        return formatted;
    }

    fixExtractionIssues(text) {
        let fixed = text;
        
        // Fix common line break issues
        fixed = fixed.replace(/([a-z])\n([a-z])/g, '$1 $2');
        fixed = fixed.replace(/([.!?])\n([a-z])/g, '$1 $2');
        
        // Fix split words
        fixed = fixed.replace(/(\w+)\-\s*\n\s*(\w+)/g, '$1$2');
        
        // Ensure proper question separation
        fixed = fixed.replace(/(\?)\s*([A-Z][^?]*\?)/g, '$1\n\n$2');
        
        // Fix answer separation
        fixed = fixed.replace(/(\w)\s*(Answer[\:\.]?\s*[A-Z])/g, '$1\n\n$2');
        
        // Clean up excessive whitespace
        fixed = fixed.replace(/\n{4,}/g, '\n\n\n');
        fixed = fixed.replace(/\s{3,}/g, '  ');
        
        return fixed;
    }

    identifyQuestionBlocks(text) {
        const blocks = [];
        const lines = text.split('\n');
        let currentBlock = [];
        let inQuestion = false;
        let questionNumber = 0;

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            
            if (!line) {
                if (inQuestion && currentBlock.length > 0) {
                    currentBlock.push('');
                }
                continue;
            }

            // Check if this line starts a new question
            const isQuestionStart = this.isQuestionStart(line);
            
            if (isQuestionStart) {
                // Save previous block if it exists
                if (currentBlock.length > 0) {
                    blocks.push({
                        content: currentBlock.join('\n'),
                        startLine: i - currentBlock.length,
                        endLine: i - 1,
                        number: questionNumber
                    });
                }
                
                // Start new block
                currentBlock = [line];
                inQuestion = true;
                questionNumber++;
            } else if (inQuestion) {
                currentBlock.push(line);
                
                // Check if we've reached the end of this question
                if (this.isQuestionEnd(line, lines[i + 1])) {
                    blocks.push({
                        content: currentBlock.join('\n'),
                        startLine: i - currentBlock.length + 1,
                        endLine: i,
                        number: questionNumber
                    });
                    currentBlock = [];
                    inQuestion = false;
                }
            }
        }

        // Add final block if exists
        if (currentBlock.length > 0) {
            blocks.push({
                content: currentBlock.join('\n'),
                startLine: lines.length - currentBlock.length,
                endLine: lines.length - 1,
                number: questionNumber
            });
        }

        return blocks;
    }

    identifyQuestionBlocksEnhanced(text, options = {}) {
        console.log('🎯 Enhanced question block identification...');
        
        const blocks = [];
        
        // Enhanced patterns for different question types
        const enhancedPatterns = [
            // Numbered questions with optional prefixes
            /(?:^|\n\n)(\d+\.?\s*(?:Question\s*\d*[\:\.]?\s*)?)(.*?)(?=\n\n\d+\.|\n\nQuestion|\n\n(?:Answer|Ans)[\:\.]|\n\n[A-Z][^.]*\?|$)/gms,
            
            // Q-style questions
            /(?:^|\n)(Q\s*\d*[\.\:]?\s*)(.*?)(?=\nQ\s*\d*[\.\:]?|\n(?:Answer|Ans)[\:\.]|\n[A-Z][^.]*\?|$)/gms,
            
            // Case-based questions
            /(?:^|\n)(Case\s*\d*[\:\.]?\s*|Clinical\s+Scenario[\:\.]?\s*)(.*?)(?=\nCase|\nClinical\s+Scenario|\n(?:Answer|Ans)[\:\.]|$)/gms,
            
            // Direct questions (starting with question words)
            /(?:^|\n)((What|Which|Where|When|Why|How|Who|Is|Are|Can|Could|Will|Would|Should|Does|Do|Did)\s+[^.?!]*\?)(.*?)(?=\n(?:What|Which|Where|When|Why|How|Who|Is|Are|Can|Could|Will|Would|Should|Does|Do|Did)|\n(?:Answer|Ans)[\:\.]|$)/gms,
            
            // True/False questions
            /(?:^|\n)((?:True\s+or\s+False|T\/F)[\:\.]?\s*)(.*?)(?=\n(?:True\s+or\s+False|T\/F)|\n(?:Answer|Ans)[\:\.]|$)/gms,
            
            // Fill-in-the-blank questions
            /(?:^|\n)([^.?!\n]*(?:___|\.\.\.)[^.?!\n]*)(.*?)(?=\n[^.?!\n]*(?:___|\.\.\.)|\n(?:Answer|Ans)[\:\.]|$)/gms
        ];

        // Content-specific patterns based on analysis
        if (options.contentAnalysis) {
            if (options.contentAnalysis.contentType === 'multiple_choice_quiz') {
                // Add MCQ-specific patterns
                enhancedPatterns.push(
                    /(?:^|\n)([^.?!\n]*(?:\?|:)\s*(?:\n[A-E][\)\.\:]?\s*[^\n]+){2,5})(.*?)(?=\n[^.?!\n]*(?:\?|:)|\n(?:Answer|Ans)[\:\.]|$)/gms
                );
            }
        }

        enhancedPatterns.forEach((pattern, patternIndex) => {
            let match;
            while ((match = pattern.exec(text)) !== null) {
                const fullBlock = match[0].trim();
                
                if (fullBlock.length > 15 && this.isValidQuestionBlock(fullBlock, options)) {
                    const blockType = this.determineBlockType(fullBlock, patternIndex);
                    
                    blocks.push({
                        text: fullBlock,
                        startIndex: match.index,
                        endIndex: match.index + match[0].length,
                        type: blockType,
                        confidence: this.calculateBlockConfidence(fullBlock, blockType),
                        patternUsed: patternIndex
                    });
                }
            }
        });

        // Enhanced deduplication and merging
        const consolidatedBlocks = this.consolidateQuestionBlocks(blocks, options);
        
        // Convert to the expected format
        const formattedBlocks = consolidatedBlocks.map((block, index) => ({
            content: block.text,
            startLine: 0,
            endLine: 0,
            number: index + 1,
            type: block.type,
            confidence: block.confidence
        }));
        
        console.log(`✅ Enhanced identification complete. Found ${formattedBlocks.length} question blocks`);
        return formattedBlocks;
    }

    isValidQuestionBlock(text, options) {
        // Enhanced validation for question blocks
        const questionIndicators = [
            /\?/,
            /\b(?:what|which|where|when|why|how|who|is|are|can|could|will|would|should|does|do|did)\b/i,
            /\b(?:question|answer|ans|true|false|correct|incorrect)\b/i,
            /^[A-E][\)\.\:]?\s/m,
            /___/,
            /\.\.\./,
            /\b(?:case|scenario|patient|clinical)\b/i
        ];

        const hasQuestionIndicator = questionIndicators.some(pattern => pattern.test(text));
        const hasReasonableLength = text.length >= 15 && text.length <= 2000;
        const hasAlphaContent = /[a-zA-Z]/.test(text);
        
        return hasQuestionIndicator && hasReasonableLength && hasAlphaContent;
    }

    determineBlockType(text, patternIndex) {
        const typeMap = {
            0: 'numbered_question',
            1: 'q_style_question',
            2: 'case_based_question',
            3: 'direct_question',
            4: 'true_false_question',
            5: 'fill_in_blank_question',
            6: 'multiple_choice_question'
        };

        let baseType = typeMap[patternIndex] || 'general_question';

        // Additional type refinement based on content
        if (/^[A-E][\)\.\:]?\s.*$/m.test(text)) {
            baseType = 'multiple_choice_question';
        } else if (/\b(?:true|false)\b/i.test(text)) {
            baseType = 'true_false_question';
        } else if (/(?:___|\.\.\.)/g.test(text)) {
            baseType = 'fill_in_blank_question';
        } else if (/\b(?:case|scenario|patient|clinical)\b/i.test(text)) {
            baseType = 'case_based_question';
        }

        return baseType;
    }

    calculateBlockConfidence(text, blockType) {
        let confidence = 0.5; // Base confidence

        // Question markers
        if (/\?/.test(text)) confidence += 0.2;
        if (/\b(?:question|q\d*[\.\:]?)\b/i.test(text)) confidence += 0.1;
        
        // Answer indicators
        if (/\b(?:answer|ans)[\:\.]?\s/i.test(text)) confidence += 0.1;
        if (/^[A-E][\)\.\:]?\s/m.test(text)) confidence += 0.15;
        
        // Content quality
        const wordCount = text.split(/\s+/).length;
        if (wordCount >= 10 && wordCount <= 150) confidence += 0.1;
        if (wordCount > 150) confidence -= 0.05;
        
        // Medical content
        const medicalTerms = /\b(?:patient|diagnosis|treatment|symptom|disease|condition|medical|clinical|surgical|therapy|medication|drug|dose|mg|ml|mm|eye|retina|cornea|glaucoma|cataract|IOL|IOP|OCT|AMD)\b/gi;
        const medicalMatches = text.match(medicalTerms);
        if (medicalMatches) {
            confidence += Math.min(medicalMatches.length * 0.02, 0.1);
        }

        return Math.min(confidence, 1.0);
    }

    consolidateQuestionBlocks(blocks, options) {
        // Sort by position
        blocks.sort((a, b) => a.startIndex - b.startIndex);
        
        const consolidated = [];
        const used = new Set();
        
        for (let i = 0; i < blocks.length; i++) {
            if (used.has(i)) continue;
            
            const currentBlock = blocks[i];
            let bestBlock = currentBlock;
            
            // Check for overlapping or very close blocks
            for (let j = i + 1; j < blocks.length; j++) {
                if (used.has(j)) continue;
                
                const otherBlock = blocks[j];
                
                if (this.blocksOverlapEnhanced(currentBlock, otherBlock) || 
                    this.blocksAreAdjacent(currentBlock, otherBlock)) {
                    
                    // Choose the better block based on confidence and type
                    if (otherBlock.confidence > bestBlock.confidence ||
                        (otherBlock.confidence === bestBlock.confidence && otherBlock.text.length > bestBlock.text.length)) {
                        bestBlock = otherBlock;
                    }
                    
                    used.add(j);
                }
            }
            
            // Only include blocks above confidence threshold
            if (bestBlock.confidence >= (options.confidenceThreshold || 0.4)) {
                consolidated.push(bestBlock);
            }
            
            used.add(i);
        }
        
        return consolidated;
    }

    blocksOverlapEnhanced(block1, block2) {
        const overlap = Math.max(0, Math.min(block1.endIndex, block2.endIndex) - 
                                   Math.max(block1.startIndex, block2.startIndex));
        const minLength = Math.min(block1.text.length, block2.text.length);
        return overlap > minLength * 0.3; // 30% overlap threshold
    }

    blocksAreAdjacent(block1, block2) {
        const gap = Math.abs(block1.endIndex - block2.startIndex);
        return gap < 50; // Less than 50 characters apart
    }

    isQuestionStart(line) {
        // Check against all question starter patterns
        return this.extractionPatterns.questionStarters.some(pattern => pattern.test(line));
    }

    isQuestionEnd(currentLine, nextLine) {
        if (!nextLine) return true;
        
        // End if next line starts a new question
        if (this.isQuestionStart(nextLine)) return true;
        
        // End if we find answer indicators followed by substantial content
        const isAnswer = this.extractionPatterns.answerPatterns.some(pattern => 
            pattern.test(currentLine));
        
        if (isAnswer) {
            // Look ahead for more content or next question
            return !nextLine.trim() || this.isQuestionStart(nextLine);
        }
        
        return false;
    }

    async extractQAFromBlock(block, questionNumber, options) {
        const content = block.content;
        const lines = content.split('\n').filter(line => line.trim());
        
        if (lines.length === 0) return null;

        const qa = {
            id: `extracted_q_${questionNumber}_${Date.now()}`,
            number: questionNumber,
            question: '',
            answer: '',
            options: [],
            type: 'unknown',
            confidence: 0,
            metadata: {
                source: 'extracted',
                extractedAt: Date.now(),
                originalBlock: content,
                startLine: block.startLine,
                endLine: block.endLine
            }
        };

        // Identify question and answer portions
        let questionLines = [];
        let answerLines = [];
        let optionLines = [];
        let inAnswer = false;
        let inOptions = false;

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            
            // Check if this line indicates start of answer
            const isAnswerStart = this.extractionPatterns.answerPatterns.some(pattern => 
                pattern.test(line));
            
            if (isAnswerStart && !inAnswer) {
                inAnswer = true;
                inOptions = false;
                // Clean the answer start indicator
                const cleanedLine = this.cleanAnswerLine(line);
                if (cleanedLine) {
                    answerLines.push(cleanedLine);
                }
                continue;
            }

            // Check if this line is a multiple choice option
            const isOption = this.extractionPatterns.multipleChoiceOptions.some(pattern => 
                pattern.test(line));
            
            if (isOption && !inAnswer) {
                inOptions = true;
                optionLines.push(line);
                continue;
            }

            // Categorize the line
            if (inAnswer) {
                answerLines.push(line);
            } else if (inOptions) {
                optionLines.push(line);
            } else {
                questionLines.push(line);
            }
        }

        // Build question text
        qa.question = questionLines.join(' ').trim();
        
        // Clean and enhance question
        qa.question = this.enhanceQuestionText(qa.question);
        
        // Build answer text
        if (answerLines.length > 0) {
            qa.answer = answerLines.join(' ').trim();
            qa.answer = this.enhanceAnswerText(qa.answer);
        }

        // Process options
        if (optionLines.length > 0) {
            qa.options = optionLines.map(option => this.cleanOptionText(option));
            qa.type = 'multiple_choice';
        }

        // Determine question type if not already set
        if (qa.type === 'unknown') {
            qa.type = this.determineQuestionType(qa.question, qa.answer, qa.options);
        }

        // Calculate confidence score
        qa.confidence = this.calculateConfidence(qa);

        // Add medical metadata
        qa.metadata.medicalTopic = this.identifyMedicalTopic(qa.question + ' ' + qa.answer);
        qa.metadata.contentType = this.identifyContentType(qa.question + ' ' + qa.answer);
        qa.metadata.difficulty = this.estimateDifficulty(qa);
        qa.metadata.keywords = this.extractKeywords(qa.question + ' ' + qa.answer);
        
        // Check if this question has been improved through feedback loop
        qa.metadata.improvedByFeedback = this.checkFeedbackImprovement(qa);
        qa.metadata.improvementHistory = this.getQuestionImprovementHistory(qa.id);

        // Validate extracted Q&A
        if (this.validateQA(qa)) {
            return qa;
        }

        return null;
    }

    enhanceQuestionText(text) {
        // Remove question numbering if present
        text = text.replace(/^(?:\d+\.?\s*)?(?:Question\s*\d*[:\.]?\s*)?/i, '');
        
        // Ensure proper capitalization
        text = text.charAt(0).toUpperCase() + text.slice(1);
        
        // Ensure proper punctuation
        if (!/[.?!]$/.test(text.trim())) {
            text += text.includes('?') ? '' : '?';
        }

        // Fix common formatting issues
        text = text.replace(/\s+/g, ' ').trim();
        
        return text;
    }

    enhanceAnswerText(text) {
        // Remove answer indicators
        this.extractionPatterns.answerPatterns.forEach(pattern => {
            text = text.replace(pattern, '');
        });
        
        // Ensure proper capitalization
        text = text.charAt(0).toUpperCase() + text.slice(1);
        
        // Fix formatting
        text = text.replace(/\s+/g, ' ').trim();
        
        return text;
    }

    cleanAnswerLine(line) {
        let cleaned = line;
        this.extractionPatterns.answerPatterns.forEach(pattern => {
            cleaned = cleaned.replace(pattern, '');
        });
        return cleaned.trim();
    }

    cleanOptionText(option) {
        // Remove option letters/numbers
        let cleaned = option;
        this.extractionPatterns.multipleChoiceOptions.forEach(pattern => {
            cleaned = cleaned.replace(pattern, '');
        });
        return cleaned.trim();
    }

    determineQuestionType(question, answer, options) {
        if (options.length > 0) {
            return 'multiple_choice';
        }
        
        if (/true\s+or\s+false|t\/f/i.test(question)) {
            return 'true_false';
        }
        
        if (/fill\s+in|complete|___|\.\.\./.test(question)) {
            return 'fill_blank';
        }
        
        if (/explain|describe|discuss|analyze/i.test(question)) {
            return 'essay';
        }
        
        return 'short_answer';
    }

    calculateConfidence(qa) {
        let confidence = 0;
        let factors = 0;

        // Question quality factors
        if (qa.question.length > 20) {
            confidence += 0.2;
            factors++;
        }
        
        if (qa.question.endsWith('?') || qa.question.includes('which') || qa.question.includes('what')) {
            confidence += 0.15;
            factors++;
        }

        // Answer quality factors
        if (qa.answer.length > 10) {
            confidence += 0.25;
            factors++;
        }

        // Options quality (for multiple choice)
        if (qa.options.length >= 3) {
            confidence += 0.2;
            factors++;
        }

        // Medical content indicators
        if (this.containsMedicalTerms(qa.question + ' ' + qa.answer)) {
            confidence += 0.15;
            factors++;
        }

        // Structure indicators
        if (qa.type !== 'unknown') {
            confidence += 0.1;
            factors++;
        }

        // Normalize confidence
        return factors > 0 ? Math.min(confidence / factors * 2, 1.0) : 0.3;
    }

    containsMedicalTerms(text) {
        const medicalTerms = [
            'patient', 'diagnosis', 'treatment', 'surgery', 'medication',
            'examination', 'symptoms', 'syndrome', 'disease', 'condition',
            'retina', 'cornea', 'glaucoma', 'cataract', 'IOP', 'OCT',
            'phacoemulsification', 'vitrectomy', 'trabeculectomy'
        ];
        
        const lowerText = text.toLowerCase();
        return medicalTerms.some(term => lowerText.includes(term));
    }

    identifyMedicalTopic(text) {
        const topics = this.extractionPatterns.ophthalmologyTopics;
        
        for (const [topic, pattern] of Object.entries(topics)) {
            if (pattern.test(text)) {
                return topic;
            }
        }
        
        return 'general';
    }

    identifyContentType(text) {
        const types = this.extractionPatterns.contentTypes;
        
        for (const [type, pattern] of Object.entries(types)) {
            if (pattern.test(text)) {
                return type;
            }
        }
        
        return 'general';
    }

    estimateDifficulty(qa) {
        let difficultyScore = 0;
        
        // Question complexity
        if (qa.question.length > 100) difficultyScore += 0.2;
        if (qa.question.split(' ').length > 20) difficultyScore += 0.15;
        
        // Answer complexity
        if (qa.answer.length > 200) difficultyScore += 0.2;
        
        // Multiple choice complexity
        if (qa.options.length > 4) difficultyScore += 0.1;
        
        // Medical terminology density
        const medicalTermCount = this.countMedicalTerms(qa.question + ' ' + qa.answer);
        difficultyScore += Math.min(medicalTermCount * 0.05, 0.25);
        
        // Content type difficulty
        if (qa.metadata.contentType === 'surgical') difficultyScore += 0.1;
        if (qa.metadata.contentType === 'pathology') difficultyScore += 0.15;
        
        if (difficultyScore > 0.8) return 'expert';
        if (difficultyScore > 0.6) return 'advanced';
        if (difficultyScore > 0.4) return 'intermediate';
        return 'basic';
    }

    countMedicalTerms(text) {
        const medicalTerms = [
            'phacoemulsification', 'trabeculectomy', 'vitrectomy',
            'retinopathy', 'glaucoma', 'cataract', 'keratitis',
            'angiography', 'tomography', 'perimetry'
        ];
        
        const lowerText = text.toLowerCase();
        return medicalTerms.filter(term => lowerText.includes(term)).length;
    }

    extractKeywords(text) {
        const keywords = [];
        const words = text.toLowerCase().match(/\b\w{4,}\b/g) || [];
        
        const medicalKeywords = words.filter(word => 
            this.containsMedicalTerms(word) || 
            word.length > 6
        );
        
        // Remove duplicates and return top keywords
        return [...new Set(medicalKeywords)].slice(0, 10);
    }

    validateQA(qa) {
        // Minimum requirements
        if (!qa.question || qa.question.length < 10) return false;
        if (qa.confidence < 0.3) return false;
        
        // Question should be a question
        if (!/[?]|what|which|where|when|why|how|who|is|are|can|could|will|would|should|does|do|did/i.test(qa.question)) {
            return false;
        }
        
        return true;
    }

    validateAndEnhanceQAs(qas) {
        const validated = [];
        
        for (const qa of qas) {
            if (this.validateQA(qa)) {
                // Add additional enhancements
                qa.metadata.extractionQuality = this.assessExtractionQuality(qa);
                qa.metadata.improvementSuggestions = this.generateImprovementSuggestions(qa);
                
                validated.push(qa);
            }
        }
        
        return validated;
    }

    assessExtractionQuality(qa) {
        let score = 0;
        let maxScore = 0;
        
        // Question quality
        maxScore += 3;
        if (qa.question.length > 50) score += 1;
        if (qa.question.endsWith('?')) score += 1;
        if (this.containsMedicalTerms(qa.question)) score += 1;
        
        // Answer quality
        if (qa.answer) {
            maxScore += 2;
            if (qa.answer.length > 20) score += 1;
            if (this.containsMedicalTerms(qa.answer)) score += 1;
        }
        
        // Options quality
        if (qa.options.length > 0) {
            maxScore += 2;
            if (qa.options.length >= 4) score += 1;
            if (qa.options.every(opt => opt.length > 5)) score += 1;
        }
        
        const percentage = maxScore > 0 ? (score / maxScore) * 100 : 50;
        
        if (percentage >= 80) return 'excellent';
        if (percentage >= 60) return 'good';
        if (percentage >= 40) return 'fair';
        return 'poor';
    }

    generateImprovementSuggestions(qa) {
        const suggestions = [];
        
        if (qa.question.length < 30) {
            suggestions.push('Question could be more detailed');
        }
        
        if (!qa.question.endsWith('?')) {
            suggestions.push('Question should end with a question mark');
        }
        
        if (!qa.answer) {
            suggestions.push('Answer is missing or unclear');
        } else if (qa.answer.length < 20) {
            suggestions.push('Answer could be more comprehensive');
        }
        
        if (qa.type === 'multiple_choice' && qa.options.length < 4) {
            suggestions.push('Multiple choice questions should have at least 4 options');
        }
        
        if (qa.confidence < 0.6) {
            suggestions.push('Low confidence extraction - manual review recommended');
        }
        
        return suggestions;
    }

    updateExtractionStats(qas) {
        this.extractionStats = {
            total: qas.length,
            withAnswers: qas.filter(qa => qa.answer).length,
            byType: {},
            byConfidence: { high: 0, medium: 0, low: 0 },
            averageConfidence: 0
        };
        
        let totalConfidence = 0;
        
        qas.forEach(qa => {
            // Count by type
            this.extractionStats.byType[qa.type] = (this.extractionStats.byType[qa.type] || 0) + 1;
            
            // Count by confidence
            if (qa.confidence >= this.confidenceThresholds.high) {
                this.extractionStats.byConfidence.high++;
            } else if (qa.confidence >= this.confidenceThresholds.medium) {
                this.extractionStats.byConfidence.medium++;
            } else {
                this.extractionStats.byConfidence.low++;
            }
            
            totalConfidence += qa.confidence;
        });
        
        this.extractionStats.averageConfidence = qas.length > 0 ? totalConfidence / qas.length : 0;
    }

    // Public API methods
    getExtractionStats() {
        return this.extractionStats;
    }

    getExtractedQuestions() {
        return this.extractedQuestions;
    }

    clearExtractedQuestions() {
        this.extractedQuestions = [];
        this.extractionStats = {
            total: 0,
            withAnswers: 0,
            byType: {},
            byConfidence: { high: 0, medium: 0, low: 0 },
            averageConfidence: 0
        };
    }

    // Feedback Integration Methods
    checkFeedbackImprovement(qa) {
        // Try multiple IDs that might match this question
        const possibleIds = [
            qa.id,
            this.generateQuestionHash(qa.question),
            this.generateContentHash(qa.question + qa.answer)
        ];

        for (const id of possibleIds) {
            if (window.hasQuestionBeenImproved && window.hasQuestionBeenImproved(id)) {
                return window.enhancedFeedbackSystem.getQuestionImprovementDetails(id);
            }
        }

        // Check by content similarity
        return this.checkContentSimilarityImprovement(qa);
    }

    generateQuestionHash(questionText) {
        // Simple hash for question matching
        let hash = 0;
        for (let i = 0; i < questionText.length; i++) {
            const char = questionText.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return 'hash_' + Math.abs(hash);
    }

    generateContentHash(content) {
        // Generate hash based on content
        const cleanContent = content.replace(/\s+/g, ' ').trim().toLowerCase();
        let hash = 0;
        for (let i = 0; i < cleanContent.length; i++) {
            const char = cleanContent.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return 'content_' + Math.abs(hash);
    }

    checkContentSimilarityImprovement(qa) {
        if (!window.enhancedFeedbackSystem) return null;

        // Use the correct method from the feedback system with safety check
        let improvementStats;
        try {
            if (typeof window.enhancedFeedbackSystem.getImprovementStats === 'function') {
                improvementStats = window.enhancedFeedbackSystem.getImprovementStats();
            } else if (typeof window.getImprovementStats === 'function') {
                improvementStats = window.getImprovementStats();
            } else {
                console.warn('getImprovementStats not available, skipping similarity check');
                return null;
            }
        } catch (error) {
            console.warn('Error getting improvement stats:', error);
            return null;
        }
        
        if (!improvementStats || improvementStats.totalImproved === 0) return null;

        // Check if similar content has been improved
        const questionWords = qa.question.toLowerCase().split(/\s+/);
        const keyWords = questionWords.filter(word => word.length > 4);

        // This is a simplified check - in practice, you'd use more sophisticated similarity matching
        if (keyWords.length >= 3) {
            // Assume potential improvement if keywords match common improvement patterns
            const medicalTerms = this.extractKeywords(qa.question + ' ' + qa.answer);
            if (medicalTerms.length > 2) {
                return {
                    similarityMatch: true,
                    confidence: 0.3,
                    matchType: 'content_similarity'
                };
            }
        }

        return null;
    }

    getQuestionImprovementHistory(questionId) {
        const possibleIds = [
            questionId,
            this.generateQuestionHash(questionId),
            this.generateContentHash(questionId)
        ];

        const history = [];
        for (const id of possibleIds) {
            if (window.enhancedFeedbackSystem) {
                const details = window.enhancedFeedbackSystem.getQuestionImprovementDetails(id);
                if (details) {
                    history.push(details);
                }
            }
        }

        return history;
    }

    // Enhanced extraction with feedback integration
    async extractFromTextWithFeedback(text, options = {}) {
        console.log('🔍 Starting enhanced Q&A extraction with feedback integration...');
        
        const result = await this.extractFromText(text, options);
        
        // Enhance questions with feedback status
        result.questions = result.questions.map(qa => {
            // Add visual indicators for improved questions
            if (qa.metadata.improvedByFeedback) {
                qa.displayStatus = 'improved';
                qa.improvementBadge = this.createImprovementBadgeHTML(qa.metadata.improvedByFeedback);
            } else {
                qa.displayStatus = 'original';
                qa.improvementBadge = '';
            }
            
            return qa;
        });

        // Add improvement statistics to metadata
        result.metadata.improvementStats = {
            totalImproved: result.questions.filter(qa => qa.metadata.improvedByFeedback).length,
            improvementRate: result.questions.length > 0 ? 
                (result.questions.filter(qa => qa.metadata.improvedByFeedback).length / result.questions.length) * 100 : 0
        };

        console.log(`✅ Enhanced extraction complete: ${result.questions.length} questions (${result.metadata.improvementStats.totalImproved} improved)`);
        
        return result;
    }

    createImprovementBadgeHTML(improvementDetails) {
        if (!improvementDetails) return '';

        const confidence = Math.round((improvementDetails.confidence || 0.5) * 100);
        const timeAgo = this.formatTimeAgo(improvementDetails.timestamp || Date.now());
        
        return `
            <div class="qa-improvement-badge bg-gradient-to-r from-green-100 to-emerald-100 border-l-4 border-green-500 p-2 mb-2 rounded-r text-sm">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-600 mr-2"></i>
                    <div class="flex-1">
                        <span class="font-medium text-green-800">Improved via Feedback</span>
                        <div class="text-xs text-green-600">
                            ${improvementDetails.matchType || 'Direct match'} • ${confidence}% confidence • ${timeAgo}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    formatTimeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        const minutes = Math.floor(diff / (1000 * 60));
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return 'Just now';
    }
}

// Initialize the enhanced QA extractor
window.enhancedQAExtractor = new EnhancedQAExtractor();

// Export for global access
window.extractQuestionsEnhanced = async (text, options) => {
    return await window.enhancedQAExtractor.extractFromText(text, options);
};

window.extractQuestionsWithFeedback = async (text, options) => {
    return await window.enhancedQAExtractor.extractFromTextWithFeedback(text, options);
};

console.log('🔍 Enhanced Q&A Extractor loaded and ready!'); 
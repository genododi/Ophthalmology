// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize UI components
    const ui = new UI();
    const questionGenerator = new QuestionGenerator();
    const fileHandler = new FileHandler();
    const exportHandler = new ExportHandler();
    const medicalNLP = new MedicalNLP();
    
    // Initialize the feedback loop system (global)
    if (typeof FeedbackLoop !== 'undefined') {
        window.feedbackLoop = new FeedbackLoop();
        console.log('Feedback loop system initialized globally');
    } else {
        console.warn('FeedbackLoop class not found, feedback system may be limited');
    }
    
    // Initialize the question database (already initialized in its file as a global)
    if (!window.questionDatabase) {
        window.questionDatabase = new QuestionDatabase();
    }
    
    // Initialize the ML processor (already initialized in its file as a global)
    if (!window.medicalMLProcessor) {
        window.medicalMLProcessor = new MedicalMLProcessor();
        // Start initializing ML processor (async)
        window.medicalMLProcessor.initialize().catch(err => {
            console.warn('Failed to initialize ML processor:', err);
        });
    }
    
    // Initialize specialized medical APIs
    const biomistralAPI = new BioMistralAPI();
    window.biomistralAPI = biomistralAPI;
    
    // Note: BioGPTAPI is already initialized in its own file
    // Make sure we're using the correct reference
    if (typeof BioGPTAPI !== 'undefined' && !window.bioGPTAPI) {
        console.warn("BioGPTAPI detected but not initialized properly. Initializing now.");
        window.bioGPTAPI = new BioGPTAPI();
    }
    
    // Start initializing the specialized APIs (async)
    biomistralAPI.initialize().catch(err => {
        console.warn('Failed to initialize BioMistral API:', err);
    });
    
    // Make sure BioGPT is initialized
    if (window.bioGPTAPI && !window.bioGPTAPI.isInitialized) {
        window.bioGPTAPI.initialize().catch(err => {
            console.warn('Failed to initialize BioGPT API:', err);
        });
    }
    
    // Initialize the UserApiInjector for handling user API keys
    const userApiInjector = new UserApiInjector();
    window.userApiInjector = userApiInjector;

    // Initialize auth manager first (before donation handler)
    const authManager = new AuthManager();
    window.authManager = authManager;
    
    // Initialize quota manager
    const quotaManager = new QuotaManager();
    window.quotaManager = quotaManager;

    // Initialize the donation handler and make globally accessible
    const donationHandler = new DonationHandler();
    window.donationHandler = donationHandler;

    // Connect auth manager and donation handler
    donationHandler.setAuthManager(authManager);

    // Initialize and connect the Deep Search Handler
    if (window.deepSearchHandler) {
        window.deepSearchHandler.initialize(questionGenerator, ui);
    }

    // Make MedicalNLP instance globally accessible for premium features
    window.medicalNLP = medicalNLP;

    // Initialize OfflineStorageManager if not already initialized
    if (typeof OfflineStorageManager !== 'undefined' && !window.offlineStorageManager) {
        window.offlineStorageManager = new OfflineStorageManager();
    }

    // Set current year in footer
    document.getElementById('current-year').textContent = new Date().getFullYear();

    // Connect components bidirectionally
    ui.setFileHandler(fileHandler);
    ui.setQuestionGenerator(questionGenerator);
    
    fileHandler.setUI(ui);
    
    questionGenerator.setUI(ui);
    questionGenerator.setFileHandler(fileHandler);
    questionGenerator.setMedicalNLP(medicalNLP);
    
    // Connect the new components
    if (window.questionDatabase) {
        questionGenerator.database = window.questionDatabase;
    }
    
    if (window.medicalMLProcessor) {
        questionGenerator.mlProcessor = window.medicalMLProcessor;
    }
    
    // Connect specialized APIs to the question generator
    if (window.biomistralAPI) {
        questionGenerator.biomistralAPI = window.biomistralAPI;
    }
    
    if (window.bioGPTAPI) {
        questionGenerator.bioGPTAPI = window.bioGPTAPI;
    }
    
    // Connect the UserApiInjector to the QuestionGenerator and AuthManager
    if (window.userApiInjector) {
        userApiInjector.setQuestionGenerator(questionGenerator);
        userApiInjector.setAuthManager(authManager);
        
        // Initialize the user API key modal and UI elements
        userApiInjector.initializeUI();
        
        // Check if there's a saved API key and activate it if needed
        userApiInjector.loadSavedApiKey();
    }
    
    // Connect OfflineStorageManager to QuestionGenerator
    if (window.offlineStorageManager) {
        window.offlineStorageManager.setQuestionGenerator(questionGenerator);
        questionGenerator.offlineStorageManager = window.offlineStorageManager;
    }
    
    exportHandler.setUI(ui);
    exportHandler.setQuestionGenerator(questionGenerator);
    
    // Initialize UI visibility after connections are established
    ui.updateInputVisibility();

    // Initialize event listeners
    ui.initializeEventListeners();
    fileHandler.initializeFileHandling();
    
    // Ensure Knowledge Area is applied to all input types
    const knowledgeAreaSelect = document.getElementById('knowledge-area');
    if (knowledgeAreaSelect) {
        knowledgeAreaSelect.addEventListener('change', () => {
            const selectedValue = knowledgeAreaSelect.value;
            console.log(`Knowledge Area changed to: ${selectedValue}`);
            
            // Update the current subspecialty in file handler
            if (fileHandler) {
                fileHandler.currentSubspecialty = selectedValue;
            }
            
            // Update question generator if available
            if (questionGenerator) {
                questionGenerator.subspecialty = selectedValue;
            }
        });
        
        // Set initial values
        const initialValue = knowledgeAreaSelect.value;
        if (fileHandler) fileHandler.currentSubspecialty = initialValue;
        if (questionGenerator) questionGenerator.subspecialty = initialValue;
    }
    
    // Always make the offline questions section visible
    const offlineQuestionsSection = document.getElementById('offline-questions-section');
    if (offlineQuestionsSection) {
        offlineQuestionsSection.classList.remove('hidden');
    }
    
    // Reset the question counter to zero
    const questionCountElement = document.getElementById('question-count');
    if (questionCountElement) {
        questionCountElement.textContent = '0';
        localStorage.setItem('question_count', '0');
    }
    
    // Initialize NotebookLM with user email if available
    if (window.notebookLmHandler) {
        console.log('==== Initializing NotebookLM integration ====');
        
        // If NotebookLM is not already initialized from stored credentials,
        // initialize it with the default email
        if (!window.notebookLmHandler.isInitialized()) {
            try {
                const defaultEmail = 'genododi@gmail.com';
                console.log(`Attempting to auto-initialize NotebookLM with account: ${defaultEmail}`);
                
                const success = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                
                if (success) {
                    console.log(`Successfully auto-initialized NotebookLM with account: ${defaultEmail}`);
                    console.log('NotebookLM credentials:', JSON.stringify({
                        email: window.notebookLmHandler.credentials?.oPEP7c,
                        initialized: window.notebookLmHandler.isInitialized(),
                        hasCredentials: !!window.notebookLmHandler.credentials
                    }));
                    
                    // Load user's specific notebook from URL
                    setTimeout(async () => {
                        try {
                            console.log('Loading user specific notebook from URL...');
                            const loaded = await window.notebookLmHandler.loadUserSpecificNotebook();
                            console.log('User specific notebook loaded:', loaded);
                            
                            // If the input type is notebooklm, update UI
                            if (ui.inputTypeSelect && ui.inputTypeSelect.value === 'notebooklm') {
                                console.log('Input type is notebooklm, updating UI with user notebook...');
                                ui.updateNotebookLmStatus();
                                ui.loadNotebookOptions();
                            }
                        } catch (err) {
                            console.error('Error loading user specific notebook:', err);
                        }
                    }, 500);
                    
                    // If the input type is already set to notebooklm, update the UI
                    if (ui.inputTypeSelect && ui.inputTypeSelect.value === 'notebooklm') {
                        console.log('Input type is notebooklm, updating UI...');
                        ui.updateNotebookLmStatus();
                    }
                } else {
                    console.error('Failed to auto-initialize NotebookLM with the default account');
                    // Try a second time after a brief delay
                    setTimeout(() => {
                        try {
                            console.log('Retrying NotebookLM initialization...');
                            const retrySuccess = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                            if (retrySuccess) {
                                console.log('Successfully initialized NotebookLM on retry');
                                
                                // Try to load the user's specific notebook
                                setTimeout(async () => {
                                    try {
                                        const loaded = await window.notebookLmHandler.loadUserSpecificNotebook();
                                        console.log('User specific notebook loaded on retry:', loaded);
                                    } catch (err) {
                                        console.error('Error loading user specific notebook on retry:', err);
                                    }
                                    
                                    if (ui.inputTypeSelect && ui.inputTypeSelect.value === 'notebooklm') {
                                        ui.updateNotebookLmStatus();
                                        ui.loadNotebookOptions();
                                    }
                                }, 500);
                            } else {
                                console.error('Failed to initialize NotebookLM on retry');
                            }
                        } catch (retryError) {
                            console.error('Error during retry of NotebookLM initialization:', retryError);
                        }
                    }, 1000);
                }
            } catch (error) {
                console.error('Error during NotebookLM auto-initialization:', error);
            }
        } else {
            console.log('NotebookLM already initialized from stored credentials');
            console.log('NotebookLM user:', window.notebookLmHandler.credentials?.oPEP7c);
            
            // If already initialized, load the user's notebook
            setTimeout(async () => {
                try {
                    console.log('Loading user specific notebook with existing credentials...');
                    const loaded = await window.notebookLmHandler.loadUserSpecificNotebook();
                    console.log('User specific notebook loaded with existing credentials:', loaded);
                } catch (err) {
                    console.error('Error loading user specific notebook with existing credentials:', err);
                }
            }, 500);
            
            // If already initialized, consider updating the UI
            if (ui.inputTypeSelect && ui.inputTypeSelect.value === 'notebooklm') {
                ui.updateNotebookLmStatus();
            }
        }
    } else {
        console.warn('NotebookLM handler not available - integration disabled');
    }
    
    // Initialize the photo fetcher service if available
    if (window.photoFetcherService) {
        console.log('PhotoFetcherService initialized');
    }

    console.log('OphthalmoQA application initialized successfully.');

    // Event handlers for tracking question generation
    document.addEventListener('questionsGenerated', (event) => {
        if (window.feedbackLoop) {
            // Pass question data to feedback loop for tracking
            window.feedbackLoop.trackQuestionGeneration({
                questions: event.detail.questions || [],
                difficulty: event.detail.difficulty,
                numQuestions: event.detail.numQuestions,
                knowledgeArea: event.detail.knowledgeArea,
                questionTypes: event.detail.questionTypes,
                focusArea: event.detail.focusArea,
                isRegeneration: false
            });
        }
    });
    
    document.addEventListener('questionsRegenerated', (event) => {
        if (window.feedbackLoop) {
            // When regenerating, pass data with regeneration flag
            window.feedbackLoop.trackQuestionGeneration({
                questions: event.detail.questions || [],
                difficulty: event.detail.difficulty,
                numQuestions: event.detail.numQuestions,
                knowledgeArea: event.detail.knowledgeArea,
                questionTypes: event.detail.questionTypes,
                focusArea: event.detail.focusArea,
                isRegeneration: true
            });
        }
    });

    // Listen for "Generate" button to reset tracking
    const generateBtn = document.getElementById('generate-btn');
    if (generateBtn && window.feedbackLoop) {
        generateBtn.addEventListener('click', () => {
            window.feedbackLoop.resetTrackingForNewGeneration();
        });
    }
    
    // Listen for "Regenerate" button to prepare for regeneration
    const regenerateBtn = document.getElementById('regenerate-btn');
    if (regenerateBtn && window.feedbackLoop) {
        regenerateBtn.addEventListener('click', () => {
            window.feedbackLoop.prepareForRegeneration();
        });
    }

    // Initialize feedback status display after the page is fully loaded
    if (window.feedbackLoop) {
        setTimeout(() => {
            window.feedbackLoop.addFeedbackStatusToQuestions();
            window.feedbackLoop.checkAllQuestionsForDuplicates();
            
            // Add feedback metrics summary if it exists
            if (typeof addFeedbackMetricsSummary === 'function') {
                addFeedbackMetricsSummary();
            }
        }, 1500);
    }
}); 
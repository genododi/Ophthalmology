/**
 * Enhanced Feedback Loop System for Continuous Improvement
 * Implements learning algorithms to optimize question generation based on user feedback
 */

class FeedbackLoopSystem {
    constructor() {
        this.feedbackData = this.loadFeedbackData();
        this.learningParameters = this.loadLearningParameters();
        this.improvementCycles = 0;
        this.lastOptimization = null;
        this.adaptiveThresholds = {
            qualityThreshold: 70,
            relevanceThreshold: 75,
            difficultyThreshold: 60,
            improvementTrigger: 5 // Number of negative feedback to trigger improvement
        };
        
        this.parameterWeights = {
            difficulty: 0.3,
            questionType: 0.25,
            medicalSpecialty: 0.2,
            complexity: 0.15,
            source: 0.1
        };
        
        this.initialize();
    }

    initialize() {
        console.log('🔄 Initializing Feedback Loop System...');
        this.setupEventListeners();
        this.startContinuousImprovement();
        this.initializeRealtimeAnalysis();
        console.log('✅ Feedback Loop System initialized successfully');
    }

    setupEventListeners() {
        // Listen for feedback events
        document.addEventListener('feedbackRecorded', (event) => {
            this.processFeedback(event.detail);
        });

        // Listen for question generation events
        document.addEventListener('questionsGenerated', (event) => {
            this.analyzeGenerationSession(event.detail);
        });

        // Listen for parameter changes
        document.addEventListener('parametersChanged', (event) => {
            this.recordParameterChange(event.detail);
        });
    }

    processFeedback(feedbackData) {
        const { questionId, type, value, metadata } = feedbackData;
        
        // Store feedback with enhanced metadata
        this.storeFeedback({
            ...feedbackData,
            timestamp: Date.now(),
            sessionId: this.getCurrentSessionId(),
            context: this.getGenerationContext()
        });

        // Trigger immediate analysis for critical feedback
        if (this.isCriticalFeedback(type, value)) {
            this.triggerImmediateImprovement(questionId, type, value);
        }

        // Update learning parameters
        this.updateLearningParameters(type, value, metadata);

        // Check if improvement cycle should be triggered
        this.checkImprovementTrigger();
    }

    isCriticalFeedback(type, value) {
        const criticalConditions = {
            quality: value === 'poor',
            relevance: value === 'no',
            difficulty: value === 'too_hard' || value === 'too_easy'
        };
        
        return criticalConditions[type] || false;
    }

    triggerImmediateImprovement(questionId, type, value) {
        console.log(`🚀 Triggering immediate improvement for question ${questionId}: ${type}=${value}`);
        
        const improvements = this.generateImprovements(questionId, type, value);
        
        // Apply improvements to current session
        this.applyImprovements(improvements);
        
        // Notify user about improvements
        this.notifyImprovements(improvements);
    }

    generateImprovements(questionId, feedbackType, feedbackValue) {
        const improvements = [];
        const questionData = this.getQuestionData(questionId);
        
        switch (feedbackType) {
            case 'quality':
                if (feedbackValue === 'poor') {
                    improvements.push({
                        type: 'adjust_complexity',
                        reason: 'Poor quality feedback received',
                        action: 'reduce_complexity',
                        priority: 'high'
                    });
                    
                    if (questionData?.type === 'multiple_choice') {
                        improvements.push({
                            type: 'enhance_distractors',
                            reason: 'Improve answer quality',
                            action: 'better_distractors',
                            priority: 'medium'
                        });
                    }
                }
                break;
                
            case 'relevance':
                if (feedbackValue === 'no') {
                    improvements.push({
                        type: 'adjust_topic_focus',
                        reason: 'Irrelevant content detected',
                        action: 'refine_topic_selection',
                        priority: 'high'
                    });
                }
                break;
                
            case 'difficulty':
                improvements.push({
                    type: 'adjust_difficulty_level',
                    reason: `Difficulty feedback: ${feedbackValue}`,
                    action: feedbackValue === 'too_hard' ? 'decrease_difficulty' : 'increase_difficulty',
                    priority: 'medium'
                });
                break;
        }
        
        return improvements;
    }

    applyImprovements(improvements) {
        improvements.forEach(improvement => {
            switch (improvement.type) {
                case 'adjust_complexity':
                    this.adjustComplexityParameters(improvement.action);
                    break;
                case 'adjust_difficulty_level':
                    this.adjustDifficultyLevel(improvement.action);
                    break;
                case 'adjust_topic_focus':
                    this.adjustTopicFocus(improvement.action);
                    break;
                case 'enhance_distractors':
                    this.enhanceDistractorGeneration();
                    break;
            }
        });
        
        this.saveLearningParameters();
    }

    adjustComplexityParameters(action) {
        const currentComplexity = this.learningParameters.complexity || 'medium';
        
        if (action === 'reduce_complexity') {
            const complexityLevels = ['basic', 'medium', 'advanced', 'expert'];
            const currentIndex = complexityLevels.indexOf(currentComplexity);
            if (currentIndex > 0) {
                this.learningParameters.complexity = complexityLevels[currentIndex - 1];
            }
        }
    }

    adjustDifficultyLevel(action) {
        if (action === 'decrease_difficulty') {
            this.learningParameters.difficultyBias = Math.max(0.1, (this.learningParameters.difficultyBias || 0.5) - 0.1);
        } else if (action === 'increase_difficulty') {
            this.learningParameters.difficultyBias = Math.min(1.0, (this.learningParameters.difficultyBias || 0.5) + 0.1);
        }
    }

    adjustTopicFocus(action) {
        if (action === 'refine_topic_selection') {
            // Increase weight for highly-rated topics
            const topicPerformance = this.analyzTopicPerformance();
            this.learningParameters.topicWeights = topicPerformance;
        }
    }

    enhanceDistractorGeneration() {
        this.learningParameters.distractorQuality = Math.min(1.0, (this.learningParameters.distractorQuality || 0.5) + 0.1);
    }

    startContinuousImprovement() {
        // Run improvement cycles every 5 minutes
        setInterval(() => {
            this.runImprovementCycle();
        }, 5 * 60 * 1000);
        
        // Initial run after 30 seconds
        setTimeout(() => {
            this.runImprovementCycle();
        }, 30000);
    }

    runImprovementCycle() {
        console.log('🔄 Running continuous improvement cycle...');
        
        const analytics = this.analyzeFeedbackTrends();
        const recommendations = this.generateRecommendations(analytics);
        
        if (recommendations.length > 0) {
            this.applyAutomaticImprovements(recommendations);
            this.improvementCycles++;
            this.lastOptimization = Date.now();
            
            console.log(`✅ Improvement cycle ${this.improvementCycles} completed with ${recommendations.length} optimizations`);
        }
    }

    analyzeFeedbackTrends() {
        const recentFeedback = this.getRecentFeedback(24 * 60 * 60 * 1000); // Last 24 hours
        
        const trends = {
            qualityTrend: this.calculateTrend(recentFeedback, 'quality'),
            relevanceTrend: this.calculateTrend(recentFeedback, 'relevance'),
            difficultyTrend: this.calculateTrend(recentFeedback, 'difficulty'),
            overallSatisfaction: this.calculateOverallSatisfaction(recentFeedback),
            problemAreas: this.identifyProblemAreas(recentFeedback)
        };
        
        return trends;
    }

    calculateTrend(feedback, type) {
        const typeFeedback = feedback.filter(f => f.type === type);
        if (typeFeedback.length === 0) return { trend: 'stable', score: 0.5 };
        
        const positiveCount = typeFeedback.filter(f => 
            f.value === 'good' || f.value === 'yes' || f.value === 'appropriate'
        ).length;
        
        const score = positiveCount / typeFeedback.length;
        
        return {
            trend: score > 0.7 ? 'improving' : score < 0.3 ? 'declining' : 'stable',
            score: score,
            count: typeFeedback.length
        };
    }

    calculateOverallSatisfaction(feedback) {
        if (feedback.length === 0) return 0.5;
        
        const weights = { quality: 0.4, relevance: 0.4, difficulty: 0.2 };
        let weightedScore = 0;
        let totalWeight = 0;
        
        Object.keys(weights).forEach(type => {
            const typeScore = this.calculateTrend(feedback, type).score;
            weightedScore += typeScore * weights[type];
            totalWeight += weights[type];
        });
        
        return totalWeight > 0 ? weightedScore / totalWeight : 0.5;
    }

    identifyProblemAreas(feedback) {
        const problems = [];
        
        // Check for consistent negative feedback
        const negativePatterns = this.findNegativePatterns(feedback);
        problems.push(...negativePatterns);
        
        // Check for lack of engagement
        if (feedback.length < 3 && this.getQuestionCount() > 10) {
            problems.push({
                type: 'low_engagement',
                severity: 'medium',
                description: 'Low feedback engagement detected'
            });
        }
        
        return problems;
    }

    findNegativePatterns(feedback) {
        const patterns = [];
        const negativeTypes = ['poor', 'no', 'too_hard', 'too_easy'];
        
        negativeTypes.forEach(negType => {
            const negFeedback = feedback.filter(f => f.value === negType);
            if (negFeedback.length >= 3) {
                patterns.push({
                    type: 'consistent_negative',
                    feedbackType: negType,
                    count: negFeedback.length,
                    severity: 'high'
                });
            }
        });
        
        return patterns;
    }

    generateRecommendations(analytics) {
        const recommendations = [];
        
        // Quality-based recommendations
        if (analytics.qualityTrend.trend === 'declining') {
            recommendations.push({
                type: 'improve_quality',
                priority: 'high',
                action: 'adjust_generation_parameters',
                details: 'Quality trend is declining, adjusting generation complexity'
            });
        }
        
        // Relevance-based recommendations
        if (analytics.relevanceTrend.trend === 'declining') {
            recommendations.push({
                type: 'improve_relevance',
                priority: 'high',
                action: 'refine_topic_matching',
                details: 'Relevance trend is declining, improving topic alignment'
            });
        }
        
        // Difficulty-based recommendations
        if (analytics.difficultyTrend.score < 0.4) {
            recommendations.push({
                type: 'adjust_difficulty',
                priority: 'medium',
                action: 'balance_difficulty_levels',
                details: 'Difficulty balance needs adjustment'
            });
        }
        
        // Problem area recommendations
        analytics.problemAreas.forEach(problem => {
            recommendations.push({
                type: 'address_problem',
                priority: problem.severity,
                action: `fix_${problem.type}`,
                details: problem.description
            });
        });
        
        return recommendations;
    }

    applyAutomaticImprovements(recommendations) {
        recommendations.forEach(rec => {
            switch (rec.action) {
                case 'adjust_generation_parameters':
                    this.optimizeGenerationParameters();
                    break;
                case 'refine_topic_matching':
                    this.improveTopicMatching();
                    break;
                case 'balance_difficulty_levels':
                    this.balanceDifficultyDistribution();
                    break;
                default:
                    console.log(`Unhandled improvement action: ${rec.action}`);
            }
        });
    }

    optimizeGenerationParameters() {
        // Analyze successful vs unsuccessful questions
        const performance = this.analyzeQuestionPerformance();
        
        // Adjust parameters based on performance
        Object.keys(this.parameterWeights).forEach(param => {
            const paramPerformance = performance[param];
            if (paramPerformance && paramPerformance.success < 0.6) {
                this.learningParameters[param + 'Adjustment'] = 
                    (this.learningParameters[param + 'Adjustment'] || 1.0) * 0.9;
            }
        });
    }

    improveTopicMatching() {
        const topicAnalysis = this.analyzTopicPerformance();
        this.learningParameters.topicWeights = topicAnalysis;
    }

    balanceDifficultyDistribution() {
        const difficultyAnalysis = this.analyzeDifficultyDistribution();
        
        // Adjust difficulty preferences based on feedback
        if (difficultyAnalysis.tooHard > difficultyAnalysis.tooEasy) {
            this.learningParameters.difficultyBias = Math.max(0.2, this.learningParameters.difficultyBias - 0.1);
        } else if (difficultyAnalysis.tooEasy > difficultyAnalysis.tooHard) {
            this.learningParameters.difficultyBias = Math.min(0.8, this.learningParameters.difficultyBias + 0.1);
        }
    }

    // Real-time analysis and adaptation
    initializeRealtimeAnalysis() {
        // Monitor user interactions in real-time
        document.addEventListener('click', (event) => {
            this.analyzeUserInteraction(event);
        });
        
        document.addEventListener('scroll', (event) => {
            this.analyzeScrollBehavior(event);
        });
    }

    analyzeUserInteraction(event) {
        const target = event.target;
        
        // Track interaction patterns
        if (target.classList.contains('question-item')) {
            this.recordInteraction('question_click', {
                questionId: target.dataset.questionId,
                timestamp: Date.now()
            });
        }
    }

    analyzeScrollBehavior(event) {
        // Analyze scroll patterns to understand engagement
        const scrollData = {
            scrollTop: document.documentElement.scrollTop,
            timestamp: Date.now()
        };
        
        this.recordScrollPattern(scrollData);
    }

    // Utility methods
    storeFeedback(feedback) {
        if (!this.feedbackData.entries) {
            this.feedbackData.entries = [];
        }
        
        this.feedbackData.entries.push(feedback);
        this.saveFeedbackData();
    }

    getRecentFeedback(timeWindow) {
        const cutoff = Date.now() - timeWindow;
        return this.feedbackData.entries?.filter(f => f.timestamp > cutoff) || [];
    }

    getCurrentSessionId() {
        if (!this.currentSessionId) {
            this.currentSessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
        return this.currentSessionId;
    }

    getGenerationContext() {
        // Capture current generation parameters
        return {
            difficulty: document.getElementById('difficulty')?.value,
            questionType: Array.from(document.querySelectorAll('input[type="checkbox"]:checked')).map(cb => cb.value),
            timestamp: Date.now()
        };
    }

    getQuestionData(questionId) {
        // Retrieve question data from DOM or storage
        const questionElement = document.querySelector(`[data-question-id="${questionId}"]`);
        if (questionElement) {
            return {
                text: questionElement.querySelector('.question-text')?.textContent,
                type: questionElement.dataset.questionType,
                difficulty: questionElement.dataset.difficulty
            };
        }
        return null;
    }

    analyzTopicPerformance() {
        const feedback = this.feedbackData.entries || [];
        const topicPerformance = {};
        
        feedback.forEach(f => {
            if (f.metadata && f.metadata.topic) {
                const topic = f.metadata.topic;
                if (!topicPerformance[topic]) {
                    topicPerformance[topic] = { positive: 0, total: 0 };
                }
                
                topicPerformance[topic].total++;
                if (f.value === 'good' || f.value === 'yes') {
                    topicPerformance[topic].positive++;
                }
            }
        });
        
        // Convert to weights
        Object.keys(topicPerformance).forEach(topic => {
            const perf = topicPerformance[topic];
            topicPerformance[topic] = perf.total > 0 ? perf.positive / perf.total : 0.5;
        });
        
        return topicPerformance;
    }

    analyzeQuestionPerformance() {
        // Analyze performance by question parameters
        const feedback = this.feedbackData.entries || [];
        const performance = {};
        
        // Group by parameters and calculate success rates
        Object.keys(this.parameterWeights).forEach(param => {
            performance[param] = this.calculateParameterSuccess(feedback, param);
        });
        
        return performance;
    }

    calculateParameterSuccess(feedback, parameter) {
        const paramFeedback = feedback.filter(f => f.metadata && f.metadata[parameter]);
        if (paramFeedback.length === 0) return { success: 0.5, count: 0 };
        
        const positive = paramFeedback.filter(f => f.value === 'good' || f.value === 'yes').length;
        return {
            success: positive / paramFeedback.length,
            count: paramFeedback.length
        };
    }

    analyzeDifficultyDistribution() {
        const feedback = this.feedbackData.entries || [];
        const difficultyFeedback = feedback.filter(f => f.type === 'difficulty');
        
        return {
            tooHard: difficultyFeedback.filter(f => f.value === 'too_hard').length,
            tooEasy: difficultyFeedback.filter(f => f.value === 'too_easy').length,
            appropriate: difficultyFeedback.filter(f => f.value === 'appropriate').length
        };
    }

    recordInteraction(type, data) {
        if (!this.feedbackData.interactions) {
            this.feedbackData.interactions = [];
        }
        
        this.feedbackData.interactions.push({
            type: type,
            data: data,
            timestamp: Date.now()
        });
    }

    recordScrollPattern(scrollData) {
        if (!this.feedbackData.scrollPatterns) {
            this.feedbackData.scrollPatterns = [];
        }
        
        this.feedbackData.scrollPatterns.push(scrollData);
        
        // Keep only recent scroll data
        const cutoff = Date.now() - (5 * 60 * 1000); // 5 minutes
        this.feedbackData.scrollPatterns = this.feedbackData.scrollPatterns.filter(s => s.timestamp > cutoff);
    }

    recordParameterChange(change) {
        if (!this.feedbackData.parameterChanges) {
            this.feedbackData.parameterChanges = [];
        }
        
        this.feedbackData.parameterChanges.push({
            ...change,
            timestamp: Date.now()
        });
        
        this.improvementCycles++;
    }

    checkImprovementTrigger() {
        const recentNegative = this.getRecentFeedback(60 * 60 * 1000) // Last hour
            .filter(f => f.value === 'poor' || f.value === 'no').length;
            
        if (recentNegative >= this.adaptiveThresholds.improvementTrigger) {
            this.runImprovementCycle();
        }
    }

    notifyImprovements(improvements) {
        if (improvements.length === 0) return;
        
        const notification = document.createElement('div');
        notification.className = 'feedback-improvement-notification bg-blue-100 border-l-4 border-blue-500 p-4 fixed top-4 right-4 z-50 rounded shadow-lg';
        notification.innerHTML = `
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-robot text-blue-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-blue-800">
                        <strong>AI Improvement Applied</strong><br>
                        ${improvements.length} optimization${improvements.length > 1 ? 's' : ''} made based on your feedback
                    </p>
                </div>
                <div class="ml-auto pl-3">
                    <div class="-mx-1.5 -my-1.5">
                        <button class="inline-flex rounded-md p-1.5 text-blue-500 hover:bg-blue-200" onclick="this.parentElement.parentElement.parentElement.parentElement.remove()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    updateLearningParameters(type, value, metadata) {
        // Update learning parameters based on feedback
        if (type === 'quality') {
            if (value === 'good') {
                // Reinforce current parameters that led to good feedback
                this.reinforceCurrentParameters();
            } else if (value === 'poor') {
                // Adjust parameters to avoid similar issues
                this.adjustForPoorQuality(metadata);
            }
        }
        
        if (type === 'difficulty') {
            if (value === 'too_hard') {
                this.learningParameters.difficultyBias = Math.max(0.1, this.learningParameters.difficultyBias - 0.05);
            } else if (value === 'too_easy') {
                this.learningParameters.difficultyBias = Math.min(0.9, this.learningParameters.difficultyBias + 0.05);
            }
        }
        
        this.saveLearningParameters();
    }

    reinforceCurrentParameters() {
        // Slightly increase confidence in current parameter settings
        const currentParams = this.getGenerationContext();
        if (currentParams.difficulty) {
            this.learningParameters.preferredDifficulty = currentParams.difficulty;
        }
    }

    adjustForPoorQuality(metadata) {
        // Make adjustments based on what might have caused poor quality
        if (metadata && metadata.complexity === 'high') {
            this.learningParameters.maxComplexity = 'medium';
        }
    }

    // Data persistence
    saveFeedbackData() {
        try {
            localStorage.setItem('feedbackLoopData', JSON.stringify(this.feedbackData));
        } catch (error) {
            console.error('Failed to save feedback data:', error);
        }
    }

    loadFeedbackData() {
        try {
            const data = localStorage.getItem('feedbackLoopData');
            return data ? JSON.parse(data) : { entries: [], interactions: [], scrollPatterns: [], parameterChanges: [] };
        } catch (error) {
            console.error('Failed to load feedback data:', error);
            return { entries: [], interactions: [], scrollPatterns: [], parameterChanges: [] };
        }
    }

    saveLearningParameters() {
        try {
            localStorage.setItem('learningParameters', JSON.stringify(this.learningParameters));
        } catch (error) {
            console.error('Failed to save learning parameters:', error);
        }
    }

    loadLearningParameters() {
        try {
            const data = localStorage.getItem('learningParameters');
            return data ? JSON.parse(data) : {
                difficultyBias: 0.5,
                complexity: 'medium',
                topicWeights: {},
                distractorQuality: 0.5
            };
        } catch (error) {
            console.error('Failed to load learning parameters:', error);
            return {
                difficultyBias: 0.5,
                complexity: 'medium',
                topicWeights: {},
                distractorQuality: 0.5
            };
        }
    }

    getQuestionCount() {
        return document.querySelectorAll('.question-item').length;
    }

    // Public API methods
    getAnalytics() {
        const feedback = this.feedbackData.entries || [];
        const totalFeedback = feedback.length;
        
        if (totalFeedback === 0) {
            return {
                totalFeedback: 0,
                averageScore: 0,
                improvementCycles: this.improvementCycles,
                lastOptimization: this.lastOptimization,
                learningAccuracy: 0
            };
        }
        
        const positive = feedback.filter(f => f.value === 'good' || f.value === 'yes').length;
        const averageScore = (positive / totalFeedback) * 100;
        
        return {
            totalFeedback: totalFeedback,
            averageScore: averageScore,
            improvementCycles: this.improvementCycles,
            lastOptimization: this.lastOptimization,
            learningAccuracy: Math.round(averageScore),
            trends: this.analyzeFeedbackTrends()
        };
    }

    getRecommendations() {
        const analytics = this.analyzeFeedbackTrends();
        return this.generateRecommendations(analytics);
    }

    clearAllData() {
        this.feedbackData = { entries: [], interactions: [], scrollPatterns: [], parameterChanges: [] };
        this.learningParameters = {
            difficultyBias: 0.5,
            complexity: 'medium',
            topicWeights: {},
            distractorQuality: 0.5
        };
        this.improvementCycles = 0;
        this.lastOptimization = null;
        
        this.saveFeedbackData();
        this.saveLearningParameters();
        
        console.log('🗑️ Feedback loop data cleared');
    }
}

// Initialize the feedback loop system
window.feedbackLoopSystem = new FeedbackLoopSystem();

// Export for global access
window.getFeedbackLoopAnalytics = () => window.feedbackLoopSystem.getAnalytics();
window.getFeedbackRecommendations = () => window.feedbackLoopSystem.getRecommendations();
window.clearFeedbackLoopData = () => window.feedbackLoopSystem.clearAllData();

console.log('🚀 Feedback Loop System loaded and ready!');
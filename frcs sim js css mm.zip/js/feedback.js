/**
 * Feedback System for FRCS Simulator
 * Handles user feedback on questions and answers to improve AI accuracy
 */

let feedbackHandler;

document.addEventListener('DOMContentLoaded', () => {
    console.log('Feedback system initializing...');
    
    // Initialize the feedback handler with error handling
    try {
        // Feedback is handled directly through localStorage - no external dependencies needed
        console.log('Feedback system initialization starting...');
        console.log('Note: LocalFeedbackHandler has been replaced with direct localStorage implementation');
        
        // Initialize feedback storage and handling
        if (!window.feedbackStorage) {
            window.feedbackStorage = {
                feedbackHistory: JSON.parse(localStorage.getItem('ophthalmoqa_feedback_history') || '[]'),
                saveFeedback: function(feedback) {
                    this.feedbackHistory.push(feedback);
                    localStorage.setItem('ophthalmoqa_feedback_history', JSON.stringify(this.feedbackHistory));
                }
            };
        }
        
        console.log('Feedback storage initialized successfully');
    } catch (error) {
        console.error('Error initializing feedback system:', error);
    }
    
    // Initialize the feedback loop system
    try {
        window.feedbackLoop = new FeedbackLoop();
        console.log('Feedback loop system initialized');
        
        // Add mutation observer to detect new questions and apply feedback UI
        const qaContainer = document.getElementById('qa-container');
        if (qaContainer) {
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        mutation.addedNodes.forEach((node) => {
                            if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('question-item')) {
                                addFeedbackUI(node);
                                
                                // Safely check for duplicates if feedbackLoop is available
                                if (window.feedbackLoop && typeof window.feedbackLoop.checkForDuplicateQuestion === 'function') {
                                    window.feedbackLoop.checkForDuplicateQuestion(node);
                                }
                                
                                // Apply continuous numbering if needed
                                if (window.feedbackLoop && window.feedbackLoop.lastQuestionNumber > 0) {
                                    const questionNumber = node.querySelector('.question-number');
                                    if (questionNumber) {
                                        // Get current number
                                        const currentNum = parseInt(questionNumber.textContent.replace(/[^\d]/g, '')) || 0;
                                        
                                        // If this is a new question (number starts from 1), apply continuous numbering
                                        if (currentNum <= window.feedbackLoop.questionHistory.length) {
                                            const newNumber = window.feedbackLoop.lastQuestionNumber + currentNum;
                                            questionNumber.textContent = `Question ${newNumber}`;
                                        }
                                    }
                                }
                            }
                        });
                    }
                });
            });
            
            observer.observe(qaContainer, { childList: true, subtree: true });
        }
    } catch (error) {
        console.error('Error initializing feedback loop:', error);
    }
    
    // Initialize the feedback system
    initFeedbackSystem();
});

/**
 * Initializes the feedback system by adding feedback buttons to each QA item
 */
function initFeedbackSystem() {
    console.log('Adding feedback buttons to QA items...');
    const qaItems = document.querySelectorAll('.qa-item');
    console.log(`Found ${qaItems.length} QA items`);
    
    // Add feedback buttons to all existing QA items
    qaItems.forEach((qaItem, index) => {
        console.log(`Processing QA item ${index + 1}`);
        addFeedbackButtonsToQA(qaItem);
    });

    // Set up a mutation observer to add feedback buttons to new QA items
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.addedNodes) {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('qa-item')) {
                        addFeedbackButtonsToQA(node);
                    }
                });
            }
        });
    });

    // Start observing the question list container
    const questionList = document.querySelector('#question-list');
    if (questionList) {
        observer.observe(questionList, { childList: true, subtree: true });
        console.log('Observer set up for question list');
    } else {
        console.warn('Could not find #question-list element to observe');
    }
}

/**
 * Adds feedback buttons to a question-answer item
 * @param {HTMLElement} qaItem - The question-answer item to add buttons to
 */
function addFeedbackButtonsToQA(qaItem) {
    // Check if buttons already exist
    if (qaItem.querySelector('.feedback-buttons')) {
        console.log('Feedback buttons already exist for this QA item');
        return;
    }
    
    const answerSection = qaItem.querySelector('.answer-section');
    if (!answerSection) {
        console.warn('No answer section found in QA item', qaItem);
        return;
    }
    
    console.log('Creating feedback buttons for QA item');
    
    // Create feedback buttons container
    const feedbackButtons = document.createElement('div');
    feedbackButtons.className = 'feedback-buttons';
    feedbackButtons.style.display = 'flex';
    feedbackButtons.style.gap = '1rem';
    feedbackButtons.style.marginTop = '1rem';
    feedbackButtons.style.justifyContent = 'flex-end';
    
    // Create thumbs up button
    const thumbsUp = document.createElement('button');
    thumbsUp.className = 'feedback-btn thumbs-up';
    thumbsUp.setAttribute('aria-label', 'Accurate information');
    thumbsUp.style.background = 'white';
    thumbsUp.style.border = '1px solid #e5e7eb';
    thumbsUp.style.borderRadius = '8px';
    thumbsUp.style.width = '2.5rem';
    thumbsUp.style.height = '2.5rem';
    thumbsUp.style.display = 'flex';
    thumbsUp.style.alignItems = 'center';
    thumbsUp.style.justifyContent = 'center';
    thumbsUp.style.cursor = 'pointer';
    thumbsUp.style.position = 'relative';
    thumbsUp.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 1.25rem; height: 1.25rem; fill: #6b7280;"><path d="M7,22H3a1,1,0,0,1-1-1V12a1,1,0,0,1,1-1H7a1,1,0,0,1,1,1v9A1,1,0,0,1,7,22ZM19.15,5.6A5.94,5.94,0,0,0,13.34,2H9.82a1,1,0,0,0-.91.57L6.22,8.5H8.62v.06A6.16,6.16,0,0,1,15,14.62h0a1,1,0,0,0,.38.08,1,1,0,0,0,.62-.9V9.1a5.91,5.91,0,0,0,3.14-3.5Z"/></svg>';
    
    // Create thumbs down button
    const thumbsDown = document.createElement('button');
    thumbsDown.className = 'feedback-btn thumbs-down';
    thumbsDown.setAttribute('aria-label', 'Inaccurate information');
    thumbsDown.style.background = 'white';
    thumbsDown.style.border = '1px solid #e5e7eb';
    thumbsDown.style.borderRadius = '8px';
    thumbsDown.style.width = '2.5rem';
    thumbsDown.style.height = '2.5rem';
    thumbsDown.style.display = 'flex';
    thumbsDown.style.alignItems = 'center';
    thumbsDown.style.justifyContent = 'center';
    thumbsDown.style.cursor = 'pointer';
    thumbsDown.style.position = 'relative';
    thumbsDown.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 1.25rem; height: 1.25rem; fill: #6b7280;"><path d="M19,2h-4a1,1,0,0,0-1,1v9a1,1,0,0,0,1,1h4a1,1,0,0,0,1-1V3A1,1,0,0,0,19,2ZM5.58,6.49A6.15,6.15,0,0,0,3.07,8.88,6,6,0,0,0,3.55,16L5.26,18.5A1,1,0,0,0,6.17,19h3.5A6,6,0,0,0,16,13H9.66l1.92-4.21A1,1,0,0,0,11,7.38Z" transform="rotate(180 12 12)"/></svg>';
    
    // Create feedback thank you message
    const thankMessage = document.createElement('div');
    thankMessage.className = 'feedback-thank';
    thankMessage.textContent = 'Thank you for your feedback!';
    thankMessage.style.color = '#10b981';
    thankMessage.style.fontSize = '0.875rem';
    thankMessage.style.marginTop = '0.5rem';
    thankMessage.style.opacity = '0';
    thankMessage.style.height = '0';
    thankMessage.style.transition = 'opacity 0.3s ease, height 0.3s ease';
    thankMessage.style.overflow = 'hidden';
    
    // Add buttons to the container
    feedbackButtons.appendChild(thumbsUp);
    feedbackButtons.appendChild(thumbsDown);
    
    // Add the feedback container after the answer content
    answerSection.appendChild(feedbackButtons);
    answerSection.appendChild(thankMessage);
    
    console.log('Feedback buttons added to QA item');
    
    // Store question data
    const questionText = qaItem.querySelector('.question-header h3')?.textContent || '';
    const answerText = answerSection.querySelector('p')?.textContent || '';
    
    // Add event listeners
    thumbsUp.addEventListener('click', () => handleFeedback(qaItem, 'positive', questionText, answerText));
    thumbsDown.addEventListener('click', () => handleFeedback(qaItem, 'negative', questionText, answerText));
}

/**
 * Handles feedback button clicks
 * @param {HTMLElement} qaItem - The question-answer item
 * @param {string} feedbackType - The type of feedback ('positive' or 'negative')
 * @param {string} question - The question text
 * @param {string} answer - The answer text
 */
function handleFeedback(qaItem, feedbackType, question, answer) {
    console.log(`Processing ${feedbackType} feedback for question: "${question.substring(0, 30)}..."`);
    
    const feedbackButtons = qaItem.querySelector('.feedback-buttons');
    const thumbsUp = feedbackButtons.querySelector('.thumbs-up');
    const thumbsDown = feedbackButtons.querySelector('.thumbs-down');
    const thankMessage = qaItem.querySelector('.feedback-thank');
    
    // Reset both buttons to default state
    thumbsUp.classList.remove('active', 'submitted');
    thumbsDown.classList.remove('active', 'submitted');
    thumbsUp.style.backgroundColor = 'white';
    thumbsUp.style.borderColor = '#e5e7eb';
    thumbsDown.style.backgroundColor = 'white';
    thumbsDown.style.borderColor = '#e5e7eb';
    
    // Get the SVG elements inside the buttons
    const thumbsUpSVG = thumbsUp.querySelector('svg');
    const thumbsDownSVG = thumbsDown.querySelector('svg');
    if (thumbsUpSVG) thumbsUpSVG.style.fill = '#6b7280';
    if (thumbsDownSVG) thumbsDownSVG.style.fill = '#6b7280';
    
    // Apply active styles to the clicked button
    if (feedbackType === 'positive') {
        thumbsUp.classList.add('active', 'submitted');
        thumbsUp.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
        thumbsUp.style.borderColor = '#10b981';
        if (thumbsUpSVG) thumbsUpSVG.style.fill = '#10b981';
        
        // Add a subtle animation
        thumbsUp.style.transform = 'scale(1.1)';
        setTimeout(() => {
            thumbsUp.style.transform = 'scale(1)';
        }, 300);
    } else {
        thumbsDown.classList.add('active', 'submitted');
        thumbsDown.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
        thumbsDown.style.borderColor = '#ef4444';
        if (thumbsDownSVG) thumbsDownSVG.style.fill = '#ef4444';
        
        // Add a subtle animation
        thumbsDown.style.transform = 'scale(1.1)';
        setTimeout(() => {
            thumbsDown.style.transform = 'scale(1)';
        }, 300);
    }
    
    // Show thank you message with inline styles
    thankMessage.style.opacity = '1';
    thankMessage.style.height = '1.25rem';
    
    // Hide thank you message after 3 seconds
    setTimeout(() => {
        thankMessage.style.opacity = '0';
        thankMessage.style.height = '0';
    }, 3000);
    
    // Send feedback to storage
    sendFeedbackToStorage(feedbackType, question, answer);
}

/**
 * Sends feedback data to storage
 * @param {string} feedbackType - The type of feedback ('positive' or 'negative')
 * @param {string} question - The question text
 * @param {string} answer - The answer text
 */
function sendFeedbackToStorage(feedbackType, question, answer) {
    // Try to use the local feedback handler first
    if (feedbackHandler) {
        feedbackHandler.saveFeedback(feedbackType, question, answer)
            .then(data => {
                console.log('Feedback submitted successfully:', data);
            })
            .catch(error => {
                console.error('Error submitting feedback:', error);
                // Fall back to server API if local storage fails
                sendFeedbackToServer(feedbackType, question, answer);
            });
    } else {
        // Fall back to server API if handler not initialized
        sendFeedbackToServer(feedbackType, question, answer);
    }
}

/**
 * Sends feedback data to the server
 * @param {string} feedbackType - The type of feedback ('positive' or 'negative')
 * @param {string} question - The question text
 * @param {string} answer - The answer text
 */
function sendFeedbackToServer(feedbackType, question, answer) {
    // Create feedback data object
    const feedbackData = {
        type: feedbackType,
        question: question,
        answer: answer,
        timestamp: new Date().toISOString()
    };
    
    // Log feedback for debugging (remove in production)
    console.log('Sending feedback to server:', feedbackData);
    
    // Send feedback to server using fetch API
    fetch('/api/feedback', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Feedback submitted successfully to server:', data);
    })
    .catch(error => {
        console.error('Error submitting feedback to server:', error);
        // Server request failed, log the error but don't retry
    });
}

// FeedbackLoop System for OphthalmoQA
// Handles feedback collection, history tracking, and parameter refinement

class FeedbackLoop {
    constructor() {
        // Initialize core data structures
        this.feedbackHistory = [];
        this.questionHistory = [];
        this.improvedQuestions = {};
        this.generationHistory = {};
        this.sessionQuestions = new Set(); // Track questions in current session
        this.repeatQuestions = new Set(); // Track repeat/duplicate questions
        this.lastQuestionNumber = 0;
        this.sessionId = this.getOrCreateSessionId();
        
        // Load existing data from localStorage
        this.loadFeedbackHistory();
        this.loadQuestionHistory();
        this.loadImprovedQuestions();
        this.loadGenerationHistory();
        
        // Initialize event listeners
        this.initEventListeners();
        
        // Log initialization
        this.logMessage('FeedbackLoop initialized', 'success');
        
        // Add feedback status display to existing questions
        setTimeout(() => this.addFeedbackStatusToQuestions(), 1000);
    }

    // Load feedback history from localStorage
    loadFeedbackHistory() {
        const storedFeedback = localStorage.getItem('ophthalmoqa_feedback_history');
        return storedFeedback ? JSON.parse(storedFeedback) : [];
    }

    // Load question generation history from localStorage
    loadQuestionHistory() {
        const storedHistory = localStorage.getItem('ophthalmoqa_question_history');
        return storedHistory ? JSON.parse(storedHistory) : [];
    }
    
    // Load improved questions list from localStorage
    loadImprovedQuestions() {
        const storedImproved = localStorage.getItem('ophthalmoqa_improved_questions');
        return storedImproved ? JSON.parse(storedImproved) : {};
    }

    // Save feedback history to localStorage
    saveFeedbackHistory() {
        localStorage.setItem('ophthalmoqa_feedback_history', JSON.stringify(this.feedbackHistory));
    }

    // Save question history to localStorage
    saveQuestionHistory() {
        if (window.safeSetItem) {
            window.safeSetItem('ophthalmoqa_question_history', this.questionHistory);
        } else {
            try {
                localStorage.setItem('ophthalmoqa_question_history', JSON.stringify(this.questionHistory));
            } catch (error) {
                console.error('Error saving question history:', error);
                if (error.name === 'QuotaExceededError' && window.storageManager) {
                    window.storageManager.emergencyCleanup();
                }
            }
        }
    }
    
    // Save improved questions list to localStorage
    saveImprovedQuestions() {
        if (window.safeSetItem) {
            window.safeSetItem('ophthalmoqa_improved_questions', this.improvedQuestions);
        } else {
            try {
                localStorage.setItem('ophthalmoqa_improved_questions', JSON.stringify(this.improvedQuestions));
            } catch (error) {
                console.error('Error saving improved questions:', error);
                if (error.name === 'QuotaExceededError' && window.storageManager) {
                    window.storageManager.emergencyCleanup();
                }
            }
        }
    }

    // Initialize event listeners
    initEventListeners() {
        // Listen for question generation events
        document.addEventListener('questions-generated', (event) => {
            if (event.detail && Array.isArray(event.detail.questions)) {
                this.trackQuestionGeneration(event.detail);
            }
        });

        // Listen for regenerate button clicks
        const regenerateBtn = document.getElementById('regenerate-btn');
        if (regenerateBtn) {
            regenerateBtn.addEventListener('click', () => {
                this.prepareForRegeneration();
            });
        }

        // Listen for generate button clicks to reset tracking for fresh generation
        const generateBtn = document.getElementById('generate-btn');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => {
                this.resetTrackingForNewGeneration();
            });
        }
        
        // Add feedback status to questions already on the page
        setTimeout(() => {
            this.addFeedbackStatusToQuestions();
        }, 1000);
    }

    // Track question generation and check for duplicates
    trackQuestionGeneration(detail) {
        if (!detail || !detail.questions || !Array.isArray(detail.questions)) {
            this.logMessage('Invalid question generation event data', 'warning');
            return;
        }
        
        // Store the last question number for continuous question numbering
        const questionCount = detail.questions.length;
        if (questionCount > 0) {
            // If this is a regeneration, maintain numbering
            const isRegeneration = detail.isRegeneration || false;
            
            if (!isRegeneration) {
                // For new generations, reset
                this.lastQuestionNumber = 0;
            }
            
            // Update the last question number
            this.lastQuestionNumber += questionCount;
        }
        
        // Track generation history for parameters
        const timestamp = new Date().toISOString();
        const generationId = `gen_${timestamp}`;
        
        this.generationHistory[generationId] = {
            timestamp,
            parameters: {
                difficulty: detail.difficulty || document.getElementById('difficulty')?.value || 'unknown',
                numQuestions: detail.numQuestions || parseInt(document.getElementById('num-questions')?.value) || 0,
                knowledgeArea: detail.knowledgeArea || document.getElementById('knowledge-area')?.value || 'unknown',
                questionTypes: detail.questionTypes || this.getSelectedQuestionTypes(),
                focusArea: detail.focusArea || document.getElementById('focus-area')?.value || ''
            },
            questions: detail.questions.map(q => ({
                text: q.question || q.text || '',
                type: q.type || 'unknown',
                id: this.normalizeText(q.question || q.text || '').substring(0, 50)
            }))
        };
        
        // For tracking duplicates in the session
        detail.questions.forEach(q => {
            const text = q.question || q.text || '';
            if (text) {
                // Add to question history
                const normalizedText = this.normalizeText(text);
                this.questionHistory.push(normalizedText);
                
                // Track for current session
                this.sessionQuestions.add(normalizedText);
            }
        });
        
        // Save to localStorage
        this.saveQuestionHistory();
        this.saveGenerationHistory();
        
        // Add feedback UI to newly generated questions
        setTimeout(() => this.addFeedbackStatusToQuestions(), 500);
        
        this.logMessage(`Tracked generation of ${detail.questions.length} questions`, 'info');
    }

    // Find duplicate question by text
    findDuplicateQuestion(questionText) {
        if (!questionText) return null;
        
        const normalizedText = this.normalizeText(questionText);
        
        // Look for duplicates in history
        return this.questionHistory.find(existingQ => 
            this.normalizeText(existingQ.text) === normalizedText
        );
    }

    // Get or create unique session ID for tracking
    getOrCreateSessionId() {
        if (!this._sessionId) {
            this._sessionId = 'session_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
        }
        return this._sessionId;
    }

    // Load generation history from localStorage
    loadGenerationHistory() {
        const storedHistory = localStorage.getItem('ophthalmoqa_generation_history');
        return storedHistory ? JSON.parse(storedHistory) : [];
    }

    // Save generation history to localStorage
    saveGenerationHistory() {
        if (this.generationHistory && Array.isArray(this.generationHistory)) {
            if (window.safeSetItem) {
                window.safeSetItem('ophthalmoqa_generation_history', this.generationHistory);
            } else {
                try {
                    localStorage.setItem('ophthalmoqa_generation_history', JSON.stringify(this.generationHistory));
                } catch (error) {
                    console.error('Error saving generation history:', error);
                    if (error.name === 'QuotaExceededError' && window.storageManager) {
                        window.storageManager.emergencyCleanup();
                    }
                }
            }
        }
    }

    // Normalize text for comparison to detect duplicates
    normalizeText(text) {
        if (!text) return '';
        return text.toLowerCase()
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[^\w\s]/g, ''); // Remove punctuation
    }

    // Generate a unique question ID
    generateQuestionId() {
        return 'q_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    }
    
    // Check all questions in the container for duplicates
    checkAllQuestionsForDuplicates() {
        const questionItems = document.querySelectorAll('.question-item:not(.deep-search-item)');
        
        questionItems.forEach(questionItem => {
            this.checkForDuplicateQuestion(questionItem);
        });
        
        this.logMessage(`Checked ${questionItems.length} questions for duplicates`, 'info');
    }

    // Check if a question has already been marked as a duplicate
    checkForDuplicateQuestion(questionElement) {
        if (!questionElement) return;
        
        // Get question text and ID
        const questionText = questionElement.querySelector('.question-text')?.textContent.trim();
        if (!questionText) return;
        
        // Generate or retrieve question ID
        let questionId = questionElement.getAttribute('data-question-id');
        if (!questionId) {
            questionId = this.generateQuestionId();
            questionElement.setAttribute('data-question-id', questionId);
        }
        
        // Check if this is already known to be a duplicate
        if (this.repeatQuestions.has(questionId)) {
            this.markAsRepeated(questionElement);
            return;
        }
        
        // Check against question history
        const isDuplicate = this.questionHistory.some(existingQ => {
            // Skip comparing to itself
            if (existingQ.id === questionId) return false;
            return this.normalizeText(existingQ.text) === this.normalizeText(questionText);
        });
        
        if (isDuplicate) {
            this.repeatQuestions.add(questionId);
            this.markAsRepeated(questionElement);
        }
    }

    /**
     * Mark a question as a repeated question
     * @param {HTMLElement} questionElement - The question element to mark
     */
    markAsRepeated(questionElement) {
        if (!questionElement) return;
        
        // Check if it's already marked
        if (questionElement.classList.contains('repeated-question')) return;
        
        // Add the repeated-question class
        questionElement.classList.add('repeated-question');
        
        // Add a warning icon if it doesn't exist
        if (!questionElement.querySelector('.duplicate-warning')) {
            const warningElement = document.createElement('div');
            warningElement.className = 'duplicate-warning absolute top-3 right-3 text-warning';
            warningElement.innerHTML = '<i class="fas fa-exclamation-circle" title="This appears to be a repeated question"></i>';
            
            // Make sure the question has relative positioning
            if (getComputedStyle(questionElement).position === 'static') {
                questionElement.style.position = 'relative';
            }
            
            questionElement.appendChild(warningElement);
            
            // Also add repeated badge for clarity
            const badgeElement = document.createElement('div');
            badgeElement.className = 'repeated-badge inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full ml-2';
            badgeElement.innerHTML = '<i class="fas fa-sync-alt mr-1"></i> Repeated';
            
            // Find a good place to insert the badge
            const questionText = questionElement.querySelector('.question-text');
            if (questionText && questionText.parentNode) {
                questionText.parentNode.insertBefore(badgeElement, questionText.nextSibling);
            } else {
                // If no good place, add to the beginning of the question
                questionElement.insertBefore(badgeElement, questionElement.firstChild);
            }
            
            const questionTextContent = questionElement.querySelector('.question-text')?.textContent || '';
            this.logMessage(`Marked as repeated question: "${questionTextContent.substring(0, 30)}..."`, 'warning');
            
            // Update metrics summary
            addFeedbackMetricsSummary();
        }
    }

    // Helper function to log messages safely
    logMessage(message, type = 'info') {
        // Use global log function if available, otherwise fallback to console
        if (typeof log === 'function') {
            log(message, type);
        } else {
            switch (type) {
                case 'error':
                    console.error(message);
                    break;
                case 'warning':
                    console.warn(message);
                    break;
                case 'success':
                    console.info('%c' + message, 'color: green');
                    break;
                default:
                    console.log(message);
            }
        }
    }

    /**
     * Add feedback status UI to all questions
     */
    addFeedbackStatusToQuestions() {
        const questions = document.querySelectorAll('.question-item:not(.deep-search-item)');
        questions.forEach(question => {
            // Add feedback UI if not already present
            if (!question.querySelector('.feedback-container')) {
                addFeedbackUI(question);
            }
            
            // Check for duplicate status
            this.checkForDuplicateQuestion(question);
            
            // Check for improvement status
            this.checkQuestionFeedbackStatus(question);
        });
        
        // Add metrics summary at the top
        addFeedbackMetricsSummary();
        
        this.logMessage(`Added feedback status to ${questions.length} questions`, 'info');
    }

    // Get selected question types
    getSelectedQuestionTypes() {
        const selectedTypes = [];
        const typeCheckboxes = document.querySelectorAll('[id^="type-"]:not(#type-all):checked');
        typeCheckboxes.forEach(checkbox => {
            selectedTypes.push(checkbox.id.replace('type-', ''));
        });
        return selectedTypes;
    }

    // Handle feedback button click
    handleFeedbackClick(button) {
        // Get the question container and ID
        const questionItem = button.closest('.question-item');
        const questionId = questionItem.getAttribute('data-question-id');
        const feedbackType = button.getAttribute('data-feedback');
        const feedbackValue = button.classList.contains('active') ? 0 : 1; // Toggle

        // Update button UI
        this.updateFeedbackButtonUI(button);

        // Store the feedback
        this.storeFeedback(questionId, feedbackType, feedbackValue);

        // Update parameters based on accumulated feedback
        this.updateImprovementMetrics();
    }

    // Update feedback button UI
    updateFeedbackButtonUI(button) {
        // Get all siblings with the same data-feedback-group
        const group = button.getAttribute('data-feedback-group');
        const siblings = document.querySelectorAll(`.feedback-btn[data-feedback-group="${group}"]`);

        // First deactivate all buttons in the group
        siblings.forEach(btn => {
            btn.classList.remove('active');
        });

        // Toggle active state for the clicked button
        button.classList.toggle('active');

        // Show thank you message
        const questionItem = button.closest('.question-item');
        let thankYouMessage = questionItem.querySelector('.feedback-thank-you');

        if (!thankYouMessage) {
            thankYouMessage = document.createElement('div');
            thankYouMessage.className = 'feedback-thank-you text-sm text-green-600 mt-1';
            thankYouMessage.textContent = 'Thank you for your feedback!';
            const feedbackContainer = button.closest('.feedback-container');
            feedbackContainer.appendChild(thankYouMessage);
        } else {
            // Reset animation
            thankYouMessage.style.animation = 'none';
            thankYouMessage.offsetHeight; // Trigger reflow
            thankYouMessage.style.animation = null;
        }
    }

    // Store feedback in history
    storeFeedback(questionId, feedbackType, value) {
        const feedback = {
            questionId,
            feedbackType,
            value,
            timestamp: new Date().toISOString()
        };

        // Add to feedback history
        this.feedbackHistory.unshift(feedback);
        
        // Keep history size reasonable (last 100 feedback items)
        if (this.feedbackHistory.length > 100) {
            this.feedbackHistory.pop();
        }
        
        this.saveFeedbackHistory();
        console.log('Feedback stored:', feedback);

        // Emit feedback submitted event
        document.dispatchEvent(new CustomEvent('feedback-submitted', { 
            detail: { questionId, feedbackType, value } 
        }));
        
        // Check if this question needs improvement based on negative feedback
        if (value === 0 && (feedbackType === 'relevance' || feedbackType === 'accuracy')) {
            this.suggestImprovement(questionId);
        }
    }
    
    // Suggest improvement for a question with negative feedback
    suggestImprovement(questionId) {
        // Find the question element
        const questions = document.querySelectorAll('.question-item');
        let questionElement = null;
        let questionText = '';
        let answerText = '';
        
        for (const question of questions) {
            const qText = question.querySelector('.question-text')?.textContent.trim() || '';
            const qId = this.normalizeText(qText).substring(0, 50);
            
            if (qId === questionId) {
                questionElement = question;
                questionText = qText;
                answerText = question.querySelector('.answer-text')?.textContent.trim() || '';
                break;
            }
        }
        
        if (!questionElement) {
            this.logMessage(`Cannot find question with ID ${questionId}`, 'error');
            return;
        }
        
        // Mark question as improving
        questionElement.classList.add('improving');
        
        // Change button state to show it's being processed
        const improveBtn = questionElement.querySelector('.improve-question-btn');
        if (improveBtn) {
            improveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Improving...';
            improveBtn.classList.add('bg-green-600');
            improveBtn.classList.add('text-white');
        }
        
        // In a real implementation, this would call the AI to improve the question
        // For demo purposes, we'll simulate an improvement
        setTimeout(() => {
            // Mark as improved
            questionElement.classList.add('improved');
            questionElement.classList.remove('improving');
            
            // Store in improved questions 
            this.improvedQuestions[questionId] = {
                timestamp: new Date().toISOString(),
                originalQuestion: questionText,
                originalAnswer: answerText,
                improved: true
            };
            
            // Save to localStorage
            this.saveImprovedQuestions();
            
            // Add improvement badge
            if (!questionElement.querySelector('.improvement-badge')) {
                const badge = document.createElement('div');
                badge.className = 'improvement-badge absolute top-2 right-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full';
                badge.innerHTML = '<i class="fas fa-check-circle mr-1"></i> Improved';
                
                // Make sure question has relative positioning
                if (getComputedStyle(questionElement).position === 'static') {
                    questionElement.style.position = 'relative';
                }
                
                questionElement.appendChild(badge);
            }
            
            // Update button
            if (improveBtn) {
                improveBtn.innerHTML = '<i class="fas fa-check mr-1"></i> Improved';
                improveBtn.disabled = true;
            }
            
            this.logMessage(`Question improved: "${questionText.substring(0, 30)}..."`, 'success');
            
            // Update metrics
            this.updateImprovementMetrics();
            
            // Update metrics summary
            addFeedbackMetricsSummary();
        }, 1500);
    }

    // Update improvement metrics based on feedback
    updateImprovementMetrics() {
        // Calculate average scores for each metric
        const metrics = {
            clarity: 0,
            difficulty: 0,
            relevance: 0,
            accuracy: 0
        };
        
        let counts = {
            clarity: 0,
            difficulty: 0,
            relevance: 0,
            accuracy: 0
        };

        // Analyze recent feedback (last 50 items) for trends
        const recentFeedback = this.feedbackHistory.slice(0, 50);
        
        recentFeedback.forEach(item => {
            if (item.feedbackType in metrics && item.value !== 0) {
                metrics[item.feedbackType] += item.value;
                counts[item.feedbackType]++;
            }
        });
        
        // Calculate averages
        Object.keys(metrics).forEach(key => {
            if (counts[key] > 0) {
                metrics[key] = metrics[key] / counts[key];
            }
        });
        
        // Update metrics
        this.improvementMetrics = metrics;
        
        // Analyze trends and make recommendations
        this.analyzeFeedbackTrends();
        
        return metrics;
    }

    // Analyze feedback trends over time
    analyzeFeedbackTrends() {
        // Need at least 10 feedback records for meaningful trends
        if (this.feedbackHistory.length < 10) return;
        
        // Group feedback by day
        const feedbackByDay = {};
        const today = new Date();
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        // Process feedback within last 30 days
        this.feedbackHistory.forEach(item => {
            const feedbackDate = new Date(item.timestamp);
            if (feedbackDate >= thirtyDaysAgo) {
                const dayKey = feedbackDate.toISOString().split('T')[0];
                if (!feedbackByDay[dayKey]) {
                    feedbackByDay[dayKey] = {
                        relevance: { positive: 0, negative: 0 },
                        accuracy: { positive: 0, negative: 0 }
                    };
                }
                
                if (item.feedbackType === 'relevance' || item.feedbackType === 'accuracy') {
                    const sentiment = item.value > 0 ? 'positive' : 'negative';
                    feedbackByDay[dayKey][item.feedbackType][sentiment]++;
                }
            }
        });
        
        // Calculate trend data
        const trendData = [];
        const sortedDays = Object.keys(feedbackByDay).sort();
        
        sortedDays.forEach(day => {
            const stats = feedbackByDay[day];
            const relevancePositiveRate = stats.relevance.positive + stats.relevance.negative === 0 ? 
                0 : stats.relevance.positive / (stats.relevance.positive + stats.relevance.negative);
            
            const accuracyPositiveRate = stats.accuracy.positive + stats.accuracy.negative === 0 ? 
                0 : stats.accuracy.positive / (stats.accuracy.positive + stats.accuracy.negative);
            
            trendData.push({
                date: day,
                relevanceRate: relevancePositiveRate,
                accuracyRate: accuracyPositiveRate,
                totalFeedback: stats.relevance.positive + stats.relevance.negative + 
                               stats.accuracy.positive + stats.accuracy.negative
            });
        });
        
        // Store trend data for later use
        this.feedbackTrends = trendData;
        
        // Use trend data to adjust generation parameters if there are consistent trends
        if (trendData.length >= 3) {
            this.adjustGenerationBasedOnTrends(trendData);
        }
    }

    // Adjust generation parameters based on detected trends
    adjustGenerationBasedOnTrends(trendData) {
        // Only use this if we have at least 3 data points
        if (trendData.length < 3) return;
        
        // Get the most recent data points
        const recent = trendData.slice(-3);
        
        // Detect if relevance has been consistently low
        const lowRelevance = recent.every(point => point.relevanceRate < 0.7);
        
        // Detect if accuracy has been consistently low
        const lowAccuracy = recent.every(point => point.accuracyRate < 0.7);
        
        // If both are low, we need to make substantial changes
        if (lowRelevance && lowAccuracy) {
            this.recommendedChanges = {
                difficulty: this.analyzeQuestionDifficulty(),
                focusKeywords: this.identifyMissingKeywords(),
                questionTypes: this.getBestPerformingTypes()
            };
            
            // Store these recommendations
            localStorage.setItem('ophthalmoqa_recommended_changes', JSON.stringify(this.recommendedChanges));
        }
        // Otherwise, make more targeted changes
        else if (lowRelevance) {
            // Relevance issues might be related to knowledge area or focus
            this.recommendedChanges = {
                focusKeywords: this.identifyMissingKeywords()
            };
        }
        else if (lowAccuracy) {
            // Accuracy issues might be related to difficulty level
            this.recommendedChanges = {
                difficulty: this.analyzeQuestionDifficulty()
            };
        }
    }

    // Analyze if questions are too easy or too difficult
    analyzeQuestionDifficulty() {
        const difficulties = ['resident', 'board', 'specialist', 'advanced'];
        const currentDifficulty = document.getElementById('difficulty')?.value || 'advanced';
        const currentIndex = difficulties.indexOf(currentDifficulty);
        
        // Get feedback on difficulty specifically
        const difficultyFeedback = this.feedbackHistory.filter(item => item.feedbackType === 'difficulty');
        
        // Not enough data to make a decision
        if (difficultyFeedback.length < 5) return null;
        
        // Calculate average difficulty rating
        const averageDifficulty = difficultyFeedback.reduce((sum, item) => sum + item.value, 0) / difficultyFeedback.length;
        
        // Decide if we should adjust difficulty
        if (averageDifficulty > 0.7 && currentIndex < difficulties.length - 1) {
            // Questions are too easy, increase difficulty
            return difficulties[currentIndex + 1];
        }
        else if (averageDifficulty < 0.3 && currentIndex > 0) {
            // Questions are too difficult, decrease difficulty
            return difficulties[currentIndex - 1];
        }
        
        return null;
    }

    // Identify keywords that might be missing from focus area
    identifyMissingKeywords() {
        // Get all questions with negative relevance feedback
        const negativeRelevanceFeedback = this.feedbackHistory.filter(
            item => item.feedbackType === 'relevance' && item.value === 0
        );
        
        // If we don't have enough negative feedback, we don't need to suggest keywords
        if (negativeRelevanceFeedback.length < 3) return [];
        
        // Extract question IDs with negative feedback
        const negativeQuestionIds = negativeRelevanceFeedback.map(item => item.questionId);
        
        // Find all questions that received negative feedback
        const questionsWithNegativeFeedback = [];
        this.questionHistory.forEach(record => {
            record.questions.forEach(question => {
                if (negativeQuestionIds.includes(question.id)) {
                    questionsWithNegativeFeedback.push(question.text);
                }
            });
        });
        
        // If we don't have any question texts, we can't suggest keywords
        if (questionsWithNegativeFeedback.length === 0) return [];
        
        // Extract most common medical terms from these questions
        // This is a simplified approach - in a real implementation, you might use NLP
        const allText = questionsWithNegativeFeedback.join(' ').toLowerCase();
        const medicalTerms = this.extractMedicalTerms(allText);
        
        // Return top 5 most frequent terms
        return medicalTerms.slice(0, 5);
    }

    // Simple function to extract medical terms from text
    extractMedicalTerms(text) {
        // This is a simplified approach - a real implementation would use a medical NLP library
        const commonMedicalTerms = [
            'retina', 'cornea', 'cataract', 'glaucoma', 'uveitis', 'vitreous',
            'choroid', 'iris', 'pupil', 'macula', 'optic nerve', 'lens',
            'keratitis', 'conjunctiva', 'sclera', 'keratoconus', 'strabismus',
            'amblyopia', 'presbyopia', 'myopia', 'hyperopia', 'astigmatism',
            'diplopia', 'scotoma', 'photophobia', 'nystagmus'
        ];
        
        // Count occurrences of medical terms
        const termCounts = {};
        commonMedicalTerms.forEach(term => {
            const regex = new RegExp('\\b' + term + '\\b', 'gi');
            const matches = text.match(regex);
            if (matches) {
                termCounts[term] = matches.length;
            }
        });
        
        // Sort terms by frequency
        return Object.entries(termCounts)
            .sort((a, b) => b[1] - a[1])
            .map(entry => entry[0]);
    }

    // Get best performing question types based on feedback
    getBestPerformingTypes() {
        const typeStats = {};
        
        // Group feedback by question type
        this.feedbackHistory.forEach(feedback => {
            const questionId = feedback.questionId;
            
            // Find question type from history
            let questionType = null;
            for (const record of this.questionHistory) {
                const question = record.questions.find(q => q.id === questionId);
                if (question) {
                    questionType = question.type || 'unknown';
                    break;
                }
            }
            
            if (questionType) {
                if (!typeStats[questionType]) {
                    typeStats[questionType] = { positive: 0, negative: 0 };
                }
                
                if (feedback.value > 0) {
                    typeStats[questionType].positive++;
                } else {
                    typeStats[questionType].negative++;
                }
            }
        });
        
        // Calculate positive feedback rate for each type
        const typeRates = {};
        Object.entries(typeStats).forEach(([type, stats]) => {
            const total = stats.positive + stats.negative;
            if (total >= 3) { // Only consider types with enough feedback
                typeRates[type] = stats.positive / total;
            }
        });
        
        // Get types with positive rate above 0.7
        const goodTypes = Object.entries(typeRates)
            .filter(([_, rate]) => rate >= 0.7)
            .map(([type, _]) => type);
        
        return goodTypes;
    }

    // Get recommended parameters based on feedback data
    getRecommendedParameters() {
        // Default recommendations
        const recommendations = {
            difficulty: null,
            questionTypes: [],
            focusKeywords: [],
            knowledgeArea: null,
            model: null,
            confidence: 0
        };
        
        // Check if we have enough feedback data
        if (this.feedbackHistory.length < 10) {
            recommendations.confidence = 0.1;
            return recommendations;
        }
        
        // Get trend analysis
        const trends = this.analyzeFeedbackTrends();
        
        // Get best performing types
        const bestTypes = this.getBestPerformingTypes();
        
        // Determine difficulty recommendation
        const difficultyAnalysis = this.analyzeQuestionDifficulty();
        if (difficultyAnalysis.recommendation && difficultyAnalysis.confidence > 0.6) {
            recommendations.difficulty = difficultyAnalysis.recommendation;
        }
        
        // Add most successful question types
        if (bestTypes.length > 0) {
            const currentTypes = this.getSelectedQuestionTypes();
            const existingTypeSet = new Set(currentTypes);
            
            // Find the best types that aren't already selected
            const newRecommendedTypes = bestTypes
                .filter(t => t.score > 0.7)  // Only recommend high-scoring types
                .filter(t => !existingTypeSet.has(t.type))
                .slice(0, 3);  // Limit to top 3 recommendations
            
            recommendations.questionTypes = newRecommendedTypes.map(t => t.type);
            
            // Also recommend keeping the good existing types
            const goodExistingTypes = bestTypes
                .filter(t => existingTypeSet.has(t.type) && t.score > 0.5)
                .map(t => t.type);
            
            recommendations.questionTypes = [...recommendations.questionTypes, ...goodExistingTypes];
        }
        
        // Extract keywords from successful questions
        const keywords = this.identifyMissingKeywords();
        if (keywords.length > 0) {
            recommendations.focusKeywords = keywords.slice(0, 5); // Top 5 keywords
        }
        
        // Calculate overall confidence in recommendations
        const metrics = {
            feedbackAmount: Math.min(this.feedbackHistory.length / 50, 1), // 1.0 at 50+ feedback items
            improvementSuccess: Object.values(this.improvedQuestions).length > 0 ? 
                Object.values(this.improvedQuestions).filter(q => q.success).length / Object.values(this.improvedQuestions).length : 0,
            dataConsistency: trends.consistency || 0.5
        };
        
        // Weighted confidence calculation
        recommendations.confidence = (
            metrics.feedbackAmount * 0.4 +
            metrics.improvementSuccess * 0.4 +
            metrics.dataConsistency * 0.2
        );
        
        // Analyze and recommend AI model if we have enough data
        if (this.generationHistory && this.generationHistory.length >= 5) {
            const modelAnalysis = this.analyzeModelPerformance();
            if (modelAnalysis.bestModel && modelAnalysis.confidence > 0.7) {
                recommendations.model = modelAnalysis.bestModel;
            }
        }
        
        return recommendations;
    }

    // Analyze which model has performed best
    analyzeModelPerformance() {
        if (!this.generationHistory || this.generationHistory.length < 5) {
            return { bestModel: null, confidence: 0 };
        }
        
        // Group by model and track performance metrics
        const modelStats = {};
        
        this.generationHistory.forEach(generation => {
            const model = generation.parameters?.aiModel;
            if (!model) return;
            
            if (!modelStats[model]) {
                modelStats[model] = {
                    generations: 0,
                    duplicateRate: 0,
                    feedbackScore: 0,
                    feedbackCount: 0,
                    questionsGenerated: 0
                };
            }
            
            // Track this generation
            modelStats[model].generations++;
            modelStats[model].duplicateRate += generation.duplicateRate || 0;
            modelStats[model].questionsGenerated += generation.questions.length;
            
            // Count feedback for these questions
            generation.questions.forEach(q => {
                // Find feedback for this question
                const feedback = this.feedbackHistory.filter(f => f.questionId === q.id);
                
                if (feedback.length > 0) {
                    modelStats[model].feedbackCount += feedback.length;
                    
                    // Calculate average score
                    const totalScore = feedback.reduce((sum, f) => {
                        // Convert feedback to numeric score
                        let score = 0;
                        if (f.feedbackType === 'relevance') {
                            score = f.value; // -1 to +1
                        } else if (f.feedbackType === 'accuracy') {
                            score = f.value / 5; // Convert 1-5 scale to 0.2-1.0
                        }
                        return sum + score;
                    }, 0);
                    
                    modelStats[model].feedbackScore += totalScore;
                }
            });
        });
        
        // Calculate averages and find best model
        let bestModel = null;
        let bestScore = -Infinity;
        let totalGenerations = 0;
        
        Object.entries(modelStats).forEach(([model, stats]) => {
            if (stats.generations === 0) return;
            
            // Calculate average metrics
            stats.avgDuplicateRate = stats.duplicateRate / stats.generations;
            stats.avgFeedbackScore = stats.feedbackCount > 0 ? 
                stats.feedbackScore / stats.feedbackCount : 0;
            
            // Combined score (lower duplicate rate is better, higher feedback score is better)
            stats.combinedScore = stats.avgFeedbackScore - (stats.avgDuplicateRate / 100);
            
            totalGenerations += stats.generations;
            
            // Check if this is the best model so far
            if (stats.combinedScore > bestScore && stats.generations >= 2) {
                bestScore = stats.combinedScore;
                bestModel = model;
            }
        });
        
        // Calculate confidence based on data amount
        const confidence = Math.min(totalGenerations / 15, 1) * 
                          (bestScore > 0 ? 0.8 : 0.5); // Reduce confidence if best score isn't positive
        
        return {
            bestModel,
            confidence,
            modelStats
        };
    }

    // Generate insights from feedback data
    generateFeedbackInsights() {
        const insights = [];
        
        // Need at least 10 feedback items for meaningful insights
        if (this.feedbackHistory.length < 10) {
            return ["Not enough feedback data collected yet for meaningful insights."];
        }
        
        // Calculate overall positive feedback rate
        const positiveFeedback = this.feedbackHistory.filter(item => item.value > 0).length;
        const positiveRate = positiveFeedback / this.feedbackHistory.length;
        
        if (positiveRate > 0.8) {
            insights.push("Questions are generally well-received with over 80% positive feedback.");
        } else if (positiveRate < 0.5) {
            insights.push("Questions have received mixed feedback. Consider applying recommended parameters.");
        }
        
        // Check improvement impact
        const improvedQuestionCount = Object.keys(this.improvedQuestions).length;
        if (improvedQuestionCount > 0) {
            const totalImprovements = Object.values(this.improvedQuestions).reduce((sum, item) => sum + item.count, 0);
            insights.push(`${improvedQuestionCount} questions have been improved ${totalImprovements} times based on feedback.`);
            
            // Check if improvements are making an impact
            const recentNegativeFeedback = this.feedbackHistory.slice(0, 20).filter(item => item.value === 0).length;
            const recentNegativeRate = recentNegativeFeedback / Math.min(20, this.feedbackHistory.length);
            
            if (recentNegativeRate < 0.2) {
                insights.push("Recent feedback shows improvements are having a positive impact.");
            } else if (recentNegativeRate > 0.5) {
                insights.push("Despite improvements, recent feedback suggests further refinement is needed.");
            }
        }
        
        // Question type insights
        const bestTypes = this.getBestPerformingTypes();
        if (bestTypes.length > 0) {
            insights.push(`Best performing question types: ${bestTypes.map(formatQuestionType).join(', ')}.`);
        }
        
        // Keyword recommendations
        const keywords = this.identifyMissingKeywords();
        if (keywords.length > 0) {
            insights.push(`Consider adding these focus keywords for better relevance: ${keywords.join(', ')}.`);
        }
        
        return insights;
    }

    // Get feedback statistics with enhanced metrics
    getFeedbackStats() {
        const improvementsByType = this.analyzeImprovementsByType();
        
        // Calculate average scores for different categories
        const averageScores = this.calculateAverageScores();
        
        return {
            totalFeedback: this.feedbackHistory.length,
            improved: Object.keys(this.improvedQuestions).length,
            improvementMetrics: this.improvementMetrics,
            totalImprovedQuestions: Object.keys(this.improvedQuestions).length,
            totalImprovementCount: Object.values(this.improvedQuestions).reduce((sum, item) => sum + item.count, 0),
            recommendedParameters: this.getRecommendedParameters(),
            improvementsByType: improvementsByType,
            averageFeedbackPerQuestion: this.calculateAverageFeedbackPerQuestion(),
            averageScores: averageScores,
            // Add metrics alias for backward compatibility
            metrics: {
                relevance: averageScores.relevance || 0,
                accuracy: averageScores.quality || 0,
                difficulty: averageScores.difficulty || 0,
                clarity: averageScores.clarity || 0
            }
        };
    }
    
    /**
     * Calculate average scores for different feedback categories
     */
    calculateAverageScores() {
        try {
            if (!this.feedbackHistory || this.feedbackHistory.length === 0) {
                return {
                    overall: 0,
                    relevance: 0,
                    quality: 0,
                    difficulty: 0,
                    clarity: 0
                };
            }

            const scores = {
                overall: [],
                relevance: [],
                quality: [],
                difficulty: [],
                clarity: []
            };

            // Collect scores from feedback history
            this.feedbackHistory.forEach(feedback => {
                if (feedback && feedback.type && feedback.value) {
                    // Convert feedback types to numeric scores
                    let score = 0;
                    switch (feedback.type) {
                        case 'thumbs-up':
                        case 'helpful':
                        case 'good':
                            score = 1;
                            break;
                        case 'thumbs-down':
                        case 'not-helpful':
                        case 'poor':
                            score = 0;
                            break;
                        case 'moderate':
                        case 'average':
                            score = 0.5;
                            break;
                        default:
                            // Try to parse numeric values
                            if (!isNaN(parseFloat(feedback.value))) {
                                score = Math.max(0, Math.min(1, parseFloat(feedback.value)));
                            }
                    }

                    // Categorize feedback
                    if (feedback.category) {
                        if (scores[feedback.category]) {
                            scores[feedback.category].push(score);
                        }
                    }
                    
                    // Add to overall score
                    scores.overall.push(score);
                }
            });

            // Calculate averages
            const averages = {};
            Object.keys(scores).forEach(category => {
                if (scores[category].length > 0) {
                    averages[category] = scores[category].reduce((sum, score) => sum + score, 0) / scores[category].length;
                } else {
                    averages[category] = 0;
                }
            });

            return averages;
        } catch (error) {
            console.warn('Error calculating average scores:', error);
            return {
                overall: 0,
                relevance: 0,
                quality: 0,
                difficulty: 0,
                clarity: 0
            };
        }
    }

    // Analyze improvements by question type
    analyzeImprovementsByType() {
        const typeMap = {};
        
        try {
            // Go through all improved questions
            Object.keys(this.improvedQuestions).forEach(questionId => {
                // Find the question in history
                let questionType = 'unknown';
                for (const record of this.questionHistory) {
                    if (record && record.questions && Array.isArray(record.questions)) {
                        const question = record.questions.find(q => q && q.id === questionId);
                        if (question) {
                            questionType = question.type || 'unknown';
                            break;
                        }
                    }
                }
                
                // Count by type
                if (!typeMap[questionType]) {
                    typeMap[questionType] = { count: 0, totalImprovements: 0 };
                }
                
                typeMap[questionType].count++;
                if (this.improvedQuestions[questionId] && this.improvedQuestions[questionId].count) {
                    typeMap[questionType].totalImprovements += this.improvedQuestions[questionId].count;
                } else {
                    typeMap[questionType].totalImprovements += 1; // Default count
                }
            });
        } catch (error) {
            console.warn('Error analyzing improvements by type:', error);
        }
        
        return typeMap;
    }

    // Analyze question type feedback patterns
    analyzeQuestionTypeFeedback() {
        const typeScores = {};
        const typeCounts = {};
        
        try {
            // Initialize type tracking
            this.feedbackHistory.forEach(feedback => {
                if (feedback && feedback.questionType) {
                    const type = feedback.questionType;
                    
                    if (!typeScores[type]) {
                        typeScores[type] = 0;
                        typeCounts[type] = 0;
                    }
                    
                    // Calculate score based on feedback value
                    let score = 0;
                    if (feedback.feedbackType === 'relevance') {
                        score = feedback.value > 0 ? 1 : 0;
                    } else if (feedback.feedbackType === 'accuracy') {
                        score = feedback.value / 5; // Normalize 1-5 rating to 0-1
                    } else if (feedback.feedbackType === 'difficulty') {
                        score = feedback.value === 'appropriate' ? 1 : 0.5;
                    } else if (feedback.feedbackType === 'clarity') {
                        score = feedback.value / 5; // Normalize 1-5 rating to 0-1
                    }
                    
                    typeScores[type] += score;
                    typeCounts[type]++;
                }
            });
            
            // Calculate averages
            Object.keys(typeScores).forEach(type => {
                if (typeCounts[type] > 0) {
                    typeScores[type] = typeScores[type] / typeCounts[type];
                }
            });
        } catch (error) {
            console.warn('Error analyzing question type feedback:', error);
        }
        
        return {
            typeScores,
            typeCounts,
            totalTypes: Object.keys(typeScores).length
        };
    }
    
    // Calculate average feedback per question
    calculateAverageFeedbackPerQuestion() {
        try {
            const totalQuestions = this.questionHistory.reduce((sum, record) => {
                if (record && record.questions && Array.isArray(record.questions)) {
                    return sum + record.questions.length;
                }
                return sum;
            }, 0);
            return totalQuestions > 0 ? this.feedbackHistory.length / totalQuestions : 0;
        } catch (error) {
            console.warn('Error calculating average feedback per question:', error);
            return 0;
        }
    }

    // Apply feedback-based recommendations to form
    applyRecommendations() {
        const recommendations = this.getRecommendedParameters();
        let changes = [];
        
        // Apply difficulty recommendations
        if (recommendations.difficulty) {
            const difficultySelect = document.getElementById('difficulty');
            if (difficultySelect) {
                // Set to recommended difficulty
                Array.from(difficultySelect.options).forEach((option, index) => {
                    if (option.value === recommendations.difficulty) {
                        difficultySelect.selectedIndex = index;
                        changes.push(`Difficulty set to ${formatQuestionType(recommendations.difficulty)}`);
                    }
                });
            }
        }
        
        // Apply question type recommendations
        if (recommendations.questionTypes && recommendations.questionTypes.length > 0) {
            // First reset all checkboxes
            document.querySelectorAll('[id^="type-"]:not(#type-all)').forEach(cb => {
                cb.checked = false;
            });
            
            // Then check recommended types
            const checkedTypes = [];
            recommendations.questionTypes.forEach(type => {
                const checkbox = document.getElementById(`type-${type}`);
                if (checkbox) {
                    checkbox.checked = true;
                    checkedTypes.push(formatQuestionType(type));
                }
            });
            
            // Update "Select All" checkbox state
            const typeAllCheckbox = document.getElementById('type-all');
            if (typeAllCheckbox) {
                const allTypeCheckboxes = document.querySelectorAll('[id^="type-"]:not(#type-all)');
                const allChecked = [...allTypeCheckboxes].every(cb => cb.checked);
                const someChecked = [...allTypeCheckboxes].some(cb => cb.checked);
                
                typeAllCheckbox.checked = allChecked;
                typeAllCheckbox.indeterminate = someChecked && !allChecked;
            }
            
            if (checkedTypes.length > 0) {
                changes.push(`Optimized question types: ${checkedTypes.join(', ')}`);
            }
        }
        
        // Apply focus keywords recommendations
        if (recommendations.focusKeywords && recommendations.focusKeywords.length > 0) {
            const focusInput = document.getElementById('focus-area');
            if (focusInput) {
                // Get current keywords
                const currentKeywords = focusInput.value.split(',').map(k => k.trim()).filter(k => k);
                
                // Add new keywords without duplicates
                recommendations.focusKeywords.forEach(keyword => {
                    if (!currentKeywords.some(k => k.toLowerCase() === keyword.toLowerCase())) {
                        currentKeywords.push(keyword);
                    }
                });
                
                // Update input
                focusInput.value = currentKeywords.join(', ');
                changes.push(`Added focus keywords: ${recommendations.focusKeywords.join(', ')}`);
            }
        }
        
        // Show notification with changes
        this.showRecommendationNotification(changes);
        
        // Track that we applied recommendations
        localStorage.setItem('ophthalmoqa_recommendations_applied', 
                            JSON.stringify({
                                timestamp: new Date().toISOString(),
                                changes: changes
                            }));
        
        // Emit event for recommendations applied
        document.dispatchEvent(new CustomEvent('recommendations-applied', {
            detail: {
                recommendations,
                changes
            }
        }));
        
        return changes;
    }

    // Show recommendation notification with specific changes
    showRecommendationNotification(changes) {
        // Remove any existing notification first
        const existingNotification = document.getElementById('recommendation-notification');
        if (existingNotification) {
            document.body.removeChild(existingNotification);
        }
        
        const notification = document.createElement('div');
        notification.id = 'recommendation-notification';
        notification.className = 'fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-3 rounded-md shadow-lg z-50';
        
        let changesHTML = '';
        if (changes && changes.length > 0) {
            changesHTML = `
                <ul class="text-sm mt-1 list-disc pl-5">
                    ${changes.map(change => `<li>${change}</li>`).join('')}
                </ul>
            `;
        }
        
        notification.innerHTML = `
            <div class="flex items-start">
                <i class="fas fa-lightbulb mr-3 mt-1"></i>
                <div class="flex-grow">
                    <p class="font-medium">Parameters Optimized!</p>
                    <p class="text-sm">Settings adjusted based on ${this.feedbackHistory.length} feedback points</p>
                    ${changesHTML}
                </div>
                <button class="ml-4 text-white hover:text-blue-200" id="close-recommendation-notification">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Add event listener to close button
        document.getElementById('close-recommendation-notification').addEventListener('click', () => {
            document.body.removeChild(notification);
        });
        
        // Auto-remove after 8 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 8000);
    }

    // Reset tracking when generating new questions from scratch
    resetTrackingForNewGeneration() {
        // Reset session questions for new generation
        this.sessionQuestions = new Set();
        this.logMessage('Reset question tracking for new generation', 'info');
    }

    /**
     * Prepare for regeneration of questions
     * This is called when the user clicks the regenerate button
     */
    prepareForRegeneration() {
        // We don't reset session questions for regeneration
        // Instead, we want to keep track of them to detect duplicates
        
        this.logMessage('Preparing for question regeneration', 'info');
        
        // Check all existing questions for duplicates before regeneration
        this.checkAllQuestionsForDuplicates();
        
        // Analyze feedback trends to optimize generation parameters
        try {
            this.analyzeFeedbackTrends();
        } catch (error) {
            this.logMessage(`Error analyzing feedback trends: ${error.message}`, 'error');
        }
    }

    /**
     * Check if a question has feedback status and mark it appropriately
     * @param {HTMLElement} questionElement - Question element to check
     */
    checkQuestionFeedbackStatus(questionElement) {
        if (!questionElement) return;
        
        const questionText = questionElement.querySelector('.question-text')?.textContent.trim();
        if (!questionText) return;
        
        // Generate question ID
        const questionId = this.normalizeText(questionText).substring(0, 50);
        
        // Check if this question has been improved based on feedback
        if (this.improvedQuestions[questionId]) {
            // Add improved status
            if (!questionElement.classList.contains('improved')) {
                questionElement.classList.add('improved');
                
                // Add improvement badge if it doesn't exist
                if (!questionElement.querySelector('.improvement-badge')) {
                    const badge = document.createElement('div');
                    badge.className = 'improvement-badge absolute top-2 right-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full';
                    badge.innerHTML = '<i class="fas fa-check-circle mr-1"></i> Improved';
                    
                    // Make sure the question has relative positioning
                    if (getComputedStyle(questionElement).position === 'static') {
                        questionElement.style.position = 'relative';
                    }
                    
                    questionElement.appendChild(badge);
                    
                    this.logMessage(`Marked question as improved: "${questionText.substring(0, 30)}..."`, 'info');
                }
            }
        }
    }
}


// Add event listener for "Optimize Parameters" button
document.addEventListener('DOMContentLoaded', () => {
    // Create the optimize parameters button
    const generateBtn = document.getElementById('generate-btn');
    if (generateBtn) {
        const optimizeBtn = document.createElement('button');
        optimizeBtn.id = 'optimize-parameters-btn';
        optimizeBtn.type = 'button';
        optimizeBtn.className = 'action-btn mt-2 w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-3 rounded-md shadow-sm transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 flex items-center justify-center';
        optimizeBtn.innerHTML = '<i class="fas fa-magic mr-2"></i> Optimize Parameters';
        
        // Insert after generate button
        generateBtn.parentNode.insertBefore(optimizeBtn, generateBtn.nextSibling);
        
        // Add event listener
        optimizeBtn.addEventListener('click', () => {
            if (window.feedbackLoop) window.feedbackLoop.applyRecommendations();
        });
    }
    
    // Emit an event when questions are generated
    const originalGenerateClick = generateBtn ? generateBtn.onclick : null;
    if (generateBtn) {
        generateBtn.onclick = function(e) {
            // Call the original handler
            if (originalGenerateClick) originalGenerateClick.call(this, e);
            
            // Wait for questions to be generated (using MutationObserver would be better in production)
            setTimeout(() => {
                const questionItems = document.querySelectorAll('.question-item');
                if (questionItems.length > 0) {
                    // Get questions data
                    const questions = [];
                    questionItems.forEach(item => {
                        const questionText = item.querySelector('.question-text')?.textContent || '';
                        const id = item.getAttribute('data-question-id') || `q_${Math.random().toString(36).substr(2, 9)}`;
                        
                        // Ensure question has an ID
                        if (!item.getAttribute('data-question-id')) {
                            item.setAttribute('data-question-id', id);
                        }
                        
                        questions.push({
                            id,
                            text: questionText,
                            type: item.getAttribute('data-type') || 'unknown'
                        });
                    });
                    
                    // Emit event
                    document.dispatchEvent(new CustomEvent('questions-generated', {
                        detail: { questions }
                    }));
                }
            }, 1000);
        };
    }
});

/**
 * Adds feedback UI to a question item
 * @param {HTMLElement} questionItem - Question item element
 */
function addFeedbackUI(questionItem) {
    // Skip if already has feedback UI
    if (questionItem.querySelector('.feedback-container')) {
        return;
    }
    
    // Get the question text
    const questionText = questionItem.querySelector('.question-text')?.textContent.trim() || '';
    if (!questionText) return;
    
    // Create normalized ID
    const questionId = normalizeText(questionText).substring(0, 50);
    
    // Create feedback container
    const feedbackContainer = document.createElement('div');
    feedbackContainer.className = 'feedback-container mt-4 flex flex-wrap items-center gap-2';
    
    // Create feedback question
    const feedbackQuestion = document.createElement('div');
    feedbackQuestion.className = 'text-sm text-gray-500';
    feedbackQuestion.textContent = 'Was this question helpful?';
    
    // Create feedback buttons container
    const feedbackBtnsContainer = document.createElement('div');
    feedbackBtnsContainer.className = 'flex items-center ml-2 space-x-2';
    
    // Create thumbs up button
    const thumbsUpBtn = document.createElement('button');
    thumbsUpBtn.className = 'feedback-btn hover:scale-110 transition-transform p-1.5 rounded-full bg-gray-100 hover:bg-green-100';
    thumbsUpBtn.dataset.feedback = 'positive';
    thumbsUpBtn.dataset.feedbackGroup = 'quality';
    thumbsUpBtn.dataset.questionId = questionId;
    thumbsUpBtn.innerHTML = '<i class="fas fa-thumbs-up text-gray-500 hover:text-green-600"></i>';
    
    // Create thumbs down button
    const thumbsDownBtn = document.createElement('button');
    thumbsDownBtn.className = 'feedback-btn hover:scale-110 transition-transform p-1.5 rounded-full bg-gray-100 hover:bg-red-100';
    thumbsDownBtn.dataset.feedback = 'negative';
    thumbsDownBtn.dataset.feedbackGroup = 'quality';
    thumbsDownBtn.dataset.questionId = questionId;
    thumbsDownBtn.innerHTML = '<i class="fas fa-thumbs-down text-gray-500 hover:text-red-600"></i>';
    
    // Add buttons to container
    feedbackBtnsContainer.appendChild(thumbsUpBtn);
    feedbackBtnsContainer.appendChild(thumbsDownBtn);
    
    // Add relevance buttons
    const relevanceContainer = document.createElement('div');
    relevanceContainer.className = 'flex items-center ml-4 space-x-2';
    
    const relevanceLabel = document.createElement('div');
    relevanceLabel.className = 'text-sm text-gray-500';
    relevanceLabel.textContent = 'Relevance:';
    
    const relevantBtn = document.createElement('button');
    relevantBtn.className = 'feedback-btn hover:scale-110 transition-transform p-1.5 rounded-full bg-gray-100 hover:bg-green-100';
    relevantBtn.dataset.feedback = 'relevant';
    relevantBtn.dataset.feedbackGroup = 'relevance';
    relevantBtn.dataset.questionId = questionId;
    relevantBtn.innerHTML = '<i class="fas fa-check text-gray-500 hover:text-green-600"></i>';
    
    const notRelevantBtn = document.createElement('button');
    notRelevantBtn.className = 'feedback-btn hover:scale-110 transition-transform p-1.5 rounded-full bg-gray-100 hover:bg-red-100';
    notRelevantBtn.dataset.feedback = 'not-relevant';
    notRelevantBtn.dataset.feedbackGroup = 'relevance';
    notRelevantBtn.dataset.questionId = questionId;
    notRelevantBtn.innerHTML = '<i class="fas fa-times text-gray-500 hover:text-red-600"></i>';
    
    relevanceContainer.appendChild(relevanceLabel);
    relevanceContainer.appendChild(relevantBtn);
    relevanceContainer.appendChild(notRelevantBtn);
    
    // Create improve question button
    const improveBtn = document.createElement('button');
    improveBtn.className = 'improve-question-btn ml-auto bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs px-2 py-1 rounded flex items-center';
    improveBtn.innerHTML = '<i class="fas fa-magic mr-1"></i> Improve Question';
    improveBtn.dataset.questionId = questionId;
    
    // Create feedback thank you message
    const thankYouMsg = document.createElement('div');
    thankYouMsg.className = 'feedback-thank-you hidden ml-2 text-sm text-green-600';
    thankYouMsg.textContent = 'Thank you for your feedback!';
    
    // Add elements to the feedback container
    feedbackContainer.appendChild(feedbackQuestion);
    feedbackContainer.appendChild(feedbackBtnsContainer);
    feedbackContainer.appendChild(relevanceContainer);
    feedbackContainer.appendChild(improveBtn);
    feedbackContainer.appendChild(thankYouMsg);
    
    // Check if question is already improved
            if (window.feedbackLoop && window.feedbackLoop.improvedQuestions && window.feedbackLoop.improvedQuestions[questionId]) {
        improveBtn.innerHTML = '<i class="fas fa-check mr-1"></i> Improved';
        improveBtn.classList.add('bg-green-600');
        improveBtn.classList.add('text-white');
        improveBtn.disabled = true;
        
        // Add improvement badge if not already present
        if (!questionItem.querySelector('.improvement-badge')) {
            const badge = document.createElement('div');
            badge.className = 'improvement-badge absolute top-2 right-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full';
            badge.innerHTML = '<i class="fas fa-check-circle mr-1"></i> Improved';
            
            // Make sure question has relative positioning
            if (getComputedStyle(questionItem).position === 'static') {
                questionItem.style.position = 'relative';
            }
            
            questionItem.appendChild(badge);
        }
    }
    
    // Add event listeners
    thumbsUpBtn.addEventListener('click', () => {
        if (window.feedbackLoop) {
            window.feedbackLoop.handleFeedbackClick(thumbsUpBtn);
        }
    });
    
    thumbsDownBtn.addEventListener('click', () => {
        if (window.feedbackLoop) {
            window.feedbackLoop.handleFeedbackClick(thumbsDownBtn);
        }
    });
    
    relevantBtn.addEventListener('click', () => {
        if (window.feedbackLoop) {
            window.feedbackLoop.handleFeedbackClick(relevantBtn);
        }
    });
    
    notRelevantBtn.addEventListener('click', () => {
        if (window.feedbackLoop) {
            window.feedbackLoop.handleFeedbackClick(notRelevantBtn);
        }
    });
    
    improveBtn.addEventListener('click', () => {
        if (window.feedbackLoop && !improveBtn.disabled) {
            window.feedbackLoop.suggestImprovement(questionId);
        }
    });
    
    // Find where to add the feedback container
    let targetElement = questionItem.querySelector('.answer-container');
    if (targetElement) {
        targetElement.appendChild(feedbackContainer);
    } else {
        // If there's no answer container, append to the question item
        questionItem.appendChild(feedbackContainer);
    }
    
    return feedbackContainer;
}

/**
 * Normalizes text for comparison (helper function)
 * @param {string} text - Text to normalize
 * @returns {string} - Normalized text
 */
function normalizeText(text) {
    return text
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .trim();
}

// Add function to display feedback improvement metrics
function addFeedbackMetricsDisplay() {
    if (!window.feedbackLoop || window.feedbackLoop.feedbackHistory.length < 5) return;
    
    // Find a good place to put the metrics
    const generateBtn = document.getElementById('generate-btn');
    if (!generateBtn) return;
    
    // Check if metrics display already exists
    if (document.getElementById('feedback-metrics-display')) return;
    
    // Create metrics container
    const metricsContainer = document.createElement('div');
    metricsContainer.id = 'feedback-metrics-display';
    metricsContainer.className = 'mt-4 p-3 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg border border-indigo-100';
    
    // Get stats
    const stats = window.feedbackLoop ? window.feedbackLoop.getFeedbackStats() : { totalFeedback: 0, positiveRate: 0, improvementMetrics: { relevance: 0, accuracy: 0 }, totalImprovedQuestions: 0 };
    
    // Create content
    metricsContainer.innerHTML = `
        <div class="flex items-center justify-between mb-2">
            <h4 class="text-sm font-medium text-indigo-800">Feedback-Driven Improvement</h4>
            <span class="text-xs text-indigo-600">${stats.totalFeedback} feedback points</span>
        </div>
        <div class="space-y-2">
            <div>
                <div class="flex justify-between items-center text-xs mb-1">
                    <span class="text-gray-700">Question Relevance</span>
                    <span class="font-medium">${Math.round(stats.improvementMetrics.relevance * 100)}%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-1.5">
                    <div class="bg-green-500 h-1.5 rounded-full" style="width: ${Math.round(stats.improvementMetrics.relevance * 100)}%"></div>
                </div>
            </div>
            <div>
                <div class="flex justify-between items-center text-xs mb-1">
                    <span class="text-gray-700">Question Accuracy</span>
                    <span class="font-medium">${Math.round(stats.improvementMetrics.accuracy * 100)}%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-1.5">
                    <div class="bg-blue-500 h-1.5 rounded-full" style="width: ${Math.round(stats.improvementMetrics.accuracy * 100)}%"></div>
                </div>
            </div>
        </div>
    `;
    
    // Add "Optimize" button if we have enough data
    if (stats.totalFeedback > 10) {
        const optimizeBtn = document.createElement('button');
        optimizeBtn.className = 'w-full mt-2 text-xs bg-indigo-600 hover:bg-indigo-700 text-white rounded px-2 py-1 flex items-center justify-center';
        optimizeBtn.innerHTML = '<i class="fas fa-magic mr-1"></i> Optimize Question Generation';
        optimizeBtn.addEventListener('click', () => {
            if (window.feedbackLoop) window.feedbackLoop.applyRecommendations();
        });
        
        metricsContainer.appendChild(optimizeBtn);
    }
    
    // Add after the generate button
    const parentElement = generateBtn.parentElement;
    if (parentElement && parentElement.nextElementSibling) {
        parentElement.parentNode.insertBefore(metricsContainer, parentElement.nextElementSibling);
    } else if (parentElement) {
        parentElement.parentNode.appendChild(metricsContainer);
    }
}

// Create a function to update feedback impact display in the UI
function updateFeedbackImpactDisplay() {
    if (!window.feedbackLoop || window.feedbackLoop.feedbackHistory.length < 3) return;
    
    // Find counter element
    const counterElement = document.getElementById('question-count');
    if (!counterElement) return;
    const stats = window.feedbackLoop ? window.feedbackLoop.getFeedbackStats() : { totalFeedback: 0, positiveRate: 0, improvementMetrics: { relevance: 0, accuracy: 0 }, totalImprovedQuestions: 0 };
    
    // Create or update impact element
    let impactElement = document.getElementById('feedback-impact-counter');
    
    if (!impactElement) {
        impactElement = document.createElement('span');
        impactElement.id = 'feedback-impact-counter';
        counterElement.parentNode.appendChild(document.createTextNode(' • '));
        counterElement.parentNode.appendChild(impactElement);
    }
    
    // Update content
    impactElement.className = 'text-green-600';
    impactElement.innerHTML = `<i class="fas fa-chart-line mr-1"></i> ${stats.totalImprovedQuestions} Improved`;
}

// Add event listeners for feedback system
document.addEventListener('DOMContentLoaded', () => {
    // Add metrics display when page loads
    setTimeout(addFeedbackMetricsDisplay, 1000);
    
    // Update feedback impact display
    setTimeout(updateFeedbackImpactDisplay, 1000);
    
    // Add event listeners for feedback-related events
    document.addEventListener('feedback-submitted', () => {
        // Update metrics display after feedback is submitted
        setTimeout(addFeedbackMetricsDisplay, 500);
        setTimeout(updateFeedbackImpactDisplay, 500);
    });
    
    document.addEventListener('question-improved', () => {
        // Update metrics display after a question is improved
        setTimeout(addFeedbackMetricsDisplay, 500);
        setTimeout(updateFeedbackImpactDisplay, 500);
        
        // Also update question status badges
        if (window.feedbackLoop) {
            setTimeout(() => window.feedbackLoop.addFeedbackStatusToQuestions(), 600);
        }
    });
    
    // Update when questions are generated
    document.addEventListener('questions-generated', () => {
        setTimeout(addFeedbackMetricsDisplay, 800);
        setTimeout(updateFeedbackImpactDisplay, 800);
    });
    
    // Set up mutation observer for adding feedback UI to new questions
    const qaContainer = document.getElementById('qa-container');
    if (qaContainer) {
        // Use MutationObserver to detect when new questions are added
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach(node => {
                        // Check if the added node is a question item
                        if (node.nodeType === 1 && node.classList.contains('question-item')) {
                            // Add feedback UI to the question
                            addFeedbackUI(node);
                            
                            // Add status badges if needed
                            if (window.feedbackLoop) {
                                setTimeout(() => window.feedbackLoop.addFeedbackStatusToQuestions(), 100);
                            }
                        } else if (node.nodeType === 1) {
                            // Check for question items inside the added node
                            const questionItems = node.querySelectorAll('.question-item');
                            questionItems.forEach(item => {
                                addFeedbackUI(item);
                            });
                            
                            // Add status badges if needed
                            if (window.feedbackLoop && questionItems.length > 0) {
                                setTimeout(() => window.feedbackLoop.addFeedbackStatusToQuestions(), 100);
                            }
                        }
                    });
                }
            });
        });
        
        // Start observing
        observer.observe(qaContainer, { childList: true, subtree: true });
        
        // Add feedback UI to existing questions
        qaContainer.querySelectorAll('.question-item').forEach(item => {
            addFeedbackUI(item);
        });
        
        // Add feedback status to existing questions
        if (window.feedbackLoop) {
            setTimeout(() => window.feedbackLoop.addFeedbackStatusToQuestions(), 200);
        }
    }
});

// Export the feedback loop (redundant but kept for clarity)
// window.feedbackLoop is already set above

// Add event listeners for Feedback Analytics modal
document.addEventListener('DOMContentLoaded', () => {
    // Add feedback analytics button to the header
    const userDisplayContainer = document.querySelector('.user-display-container');
    if (userDisplayContainer) {
        const analyticsButton = document.createElement('button');
        analyticsButton.id = 'open-feedback-analytics';
        analyticsButton.className = 'bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full flex items-center hover:bg-blue-200 transition-colors';
        analyticsButton.innerHTML = '<i class="fas fa-chart-line mr-1"></i> Feedback Analytics';
        userDisplayContainer.appendChild(analyticsButton);
        
        // Add event listener to open modal
        analyticsButton.addEventListener('click', openFeedbackAnalyticsModal);
    }
    
    // Modal close button event listener
    const closeModalBtn = document.getElementById('close-feedback-analytics-modal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeFeedbackAnalyticsModal);
    }
    
    // Modal backdrop click event listener
    const modalBackdrop = document.getElementById('feedback-analytics-modal-backdrop');
    if (modalBackdrop) {
        modalBackdrop.addEventListener('click', closeFeedbackAnalyticsModal);
    }
    
    // Apply recommendations button event listener
    const applyRecommendationsBtn = document.getElementById('apply-recommendations-btn');
    if (applyRecommendationsBtn) {
        applyRecommendationsBtn.addEventListener('click', () => {
            if (window.feedbackLoop) window.feedbackLoop.applyRecommendations();
            closeFeedbackAnalyticsModal();
        });
    }
    
    // Reset feedback data button event listener
    const resetFeedbackBtn = document.getElementById('reset-feedback-data');
    if (resetFeedbackBtn) {
        resetFeedbackBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to reset all feedback data? This cannot be undone.')) {
                resetFeedbackData();
            }
        });
    }
});

// Open feedback analytics modal
function openFeedbackAnalyticsModal() {
    const modal = document.getElementById('feedback-analytics-modal');
    if (modal) {
        modal.classList.remove('hidden');
        updateFeedbackAnalytics();
    }
}

// Close feedback analytics modal
function closeFeedbackAnalyticsModal() {
    const modal = document.getElementById('feedback-analytics-modal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

// Update feedback analytics dashboard with more detailed metrics
function updateFeedbackAnalytics() {
    if (!window.feedbackLoop) return;
    
    const stats = window.feedbackLoop.getFeedbackStats();
    
    // Update feedback counts
    document.getElementById('feedback-total-count').textContent = stats.totalFeedback || 0;
    document.getElementById('feedback-improved-count').textContent = stats.improvedQuestions || 0;
    
    // Calculate and display positive feedback rate
    const positiveRate = calculatePositiveFeedbackRate(window.feedbackLoop.feedbackHistory);
    document.getElementById('feedback-positive-rate').textContent = `${positiveRate}%`;
    
    // Update metrics display - use averageScores instead of metrics
    updateMetricDisplay('relevance', stats.averageScores?.relevance || 0);
    updateMetricDisplay('accuracy', stats.averageScores?.quality || 0);
    updateMetricDisplay('difficulty', stats.averageScores?.difficulty || 0);
    updateMetricDisplay('clarity', stats.averageScores?.clarity || 0);
    
    // Update question type performance
    updateQuestionTypePerformance();
    
    // Update parameter recommendations
    const recommendations = window.feedbackLoop.getRecommendedParameters();
    updateParameterRecommendations(recommendations);
    
    // Update feedback history
    updateFeedbackHistory();
    
    // Add trend visualization
    addFeedbackTrendVisualization(stats);
}

// Add trend visualization for feedback over time
function addFeedbackTrendVisualization(stats) {
    const container = document.getElementById('feedback-trends-visualization');
    if (!container) return;
    
    // Clear previous visualization
    container.innerHTML = '';
    
    // Check if we have enough data
    if (!window.feedbackLoop || !window.feedbackLoop.feedbackHistory || window.feedbackLoop.feedbackHistory.length < 5) {
        container.innerHTML = '<p class="text-center text-gray-500 py-3">Not enough feedback data to visualize trends</p>';
        return;
    }
    
    // Group feedback by date
    const feedbackByDate = {};
    window.feedbackLoop.feedbackHistory.forEach(item => {
        const date = new Date(item.timestamp).toLocaleDateString();
        if (!feedbackByDate[date]) {
            feedbackByDate[date] = { 
                positive: 0, 
                negative: 0, 
                total: 0,
                metrics: { relevance: 0, accuracy: 0, clarity: 0, difficulty: 0 },
                metricCounts: { relevance: 0, accuracy: 0, clarity: 0, difficulty: 0 }
            };
        }
        
        // Count by type
        feedbackByDate[date].total++;
        
        // Determine if positive or negative
        if (item.feedbackType === 'relevance') {
            if (item.value > 0) feedbackByDate[date].positive++;
            else feedbackByDate[date].negative++;
        }
        
        // Track metrics
        if (item.value !== 0) {
            feedbackByDate[date].metrics[item.feedbackType] += item.value;
            feedbackByDate[date].metricCounts[item.feedbackType]++;
        }
    });
    
    // Format data for visualization
    const dates = Object.keys(feedbackByDate).sort();
    const positiveData = dates.map(date => {
        const totalForDay = feedbackByDate[date].total;
        return totalForDay ? Math.round((feedbackByDate[date].positive / totalForDay) * 100) : 0;
    });
    
    // Create visualization header
    const header = document.createElement('h4');
    header.className = 'font-medium text-gray-800 mb-2';
    header.innerHTML = '<i class="fas fa-chart-line mr-1"></i> Feedback Trends';
    container.appendChild(header);
    
    // Create trend visualization
    const visualization = document.createElement('div');
    visualization.className = 'bg-white p-3 rounded-lg border border-gray-200';
    
    // Create bar chart
    const chart = document.createElement('div');
    chart.className = 'flex items-end h-32 gap-1 mb-2';
    
    // Define a minimum bar height
    const minBarHeight = 4;
    
    positiveData.forEach((value, index) => {
        const bar = document.createElement('div');
        bar.className = 'relative flex-1 bg-blue-500 rounded-t';
        
        // Calculate bar height (minimum 4px for visibility)
        const heightPercentage = Math.max(value, 5); // At least 5% for visibility
        const barHeight = Math.max((heightPercentage / 100) * 128, minBarHeight); // 128px is max height
        bar.style.height = `${barHeight}px`;
        
        // Add value label
        const label = document.createElement('div');
        label.className = 'absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-blue-700 font-medium';
        label.textContent = `${value}%`;
        bar.appendChild(label);
        
        // Add tooltip with date
        bar.setAttribute('title', dates[index]);
        bar.setAttribute('data-date', dates[index]);
        
        chart.appendChild(bar);
    });
    
    // Add date labels
    const dateLabels = document.createElement('div');
    dateLabels.className = 'flex justify-between text-xs text-gray-500 mt-1';
    
    if (dates.length > 1) {
        // Only show first and last date if we have multiple dates
        const firstDate = document.createElement('div');
        firstDate.textContent = formatShortDate(dates[0]);
        
        const lastDate = document.createElement('div');
        lastDate.textContent = formatShortDate(dates[dates.length - 1]);
        
        dateLabels.appendChild(firstDate);
        dateLabels.appendChild(lastDate);
    } else if (dates.length === 1) {
        // If only one date, center it
        const singleDate = document.createElement('div');
        singleDate.className = 'mx-auto';
        singleDate.textContent = formatShortDate(dates[0]);
        dateLabels.appendChild(singleDate);
    }
    
    visualization.appendChild(chart);
    visualization.appendChild(dateLabels);
    container.appendChild(visualization);
}

// Format date to short format
function formatShortDate(dateString) {
    const date = new Date(dateString);
    const month = date.toLocaleString('default', { month: 'short' });
    const day = date.getDate();
    return `${month} ${day}`;
}

// Calculate positive feedback rate
function calculatePositiveFeedbackRate(feedbackHistory) {
    if (feedbackHistory.length === 0) return 0;
    
    const positiveCount = feedbackHistory.filter(item => item.value > 0).length;
    return Math.round((positiveCount / feedbackHistory.length) * 100);
}

// Update metric display
function updateMetricDisplay(metricName, value) {
    if (value === undefined || value === null) value = 0;
    
    // Convert to percentage for display
    const percentage = Math.round(value * 100);
    
    // Update text
    const metricElement = document.getElementById(`metric-${metricName}`);
    if (metricElement) metricElement.textContent = `${percentage}%`;
    
    // Update bar
    const barElement = document.getElementById(`metric-${metricName}-bar`);
    if (barElement) barElement.style.width = `${percentage}%`;
}

// Update question type performance
function updateQuestionTypePerformance() {
    if (!window.feedbackLoop) return;
    
    const questionTypeAnalysis = window.feedbackLoop.analyzeQuestionTypeFeedback();
    const performanceContainer = document.getElementById('question-type-performance');
    
    if (performanceContainer) {
        // Clear existing content
        performanceContainer.innerHTML = '';
        
        // If no data, show placeholder
        if (Object.keys(questionTypeAnalysis.typeScores).length === 0) {
            const placeholder = document.createElement('div');
            placeholder.className = 'col-span-full text-center text-gray-500 py-3';
            placeholder.textContent = 'Not enough data to analyze question type performance';
            performanceContainer.appendChild(placeholder);
            return;
        }
        
        // Add each question type
        Object.entries(questionTypeAnalysis.typeScores).forEach(([type, score]) => {
            const typeEl = document.createElement('div');
            typeEl.className = 'flex justify-between items-center p-2 bg-white rounded border border-gray-100';
            
            const scorePercentage = Math.round(score * 100);
            const scoreColor = scorePercentage > 70 ? 'text-green-600' : 
                              scorePercentage > 50 ? 'text-blue-600' : 'text-amber-600';
            
            typeEl.innerHTML = `
                <span>${formatQuestionType(type)}:</span>
                <span class="font-semibold ${scoreColor}">${scorePercentage}%</span>
            `;
            
            performanceContainer.appendChild(typeEl);
        });
    }
}

// Update parameter recommendations
function updateParameterRecommendations(recommendations) {
    if (!recommendations) return;
    
    // Update difficulty recommendation
    const difficultyElement = document.getElementById('recommended-difficulty');
    if (difficultyElement) {
        if (recommendations.difficulty === 'harder') {
            difficultyElement.textContent = 'Increase difficulty level';
            difficultyElement.className = 'font-semibold text-amber-600';
        } else if (recommendations.difficulty === 'easier') {
            difficultyElement.textContent = 'Decrease difficulty level';
            difficultyElement.className = 'font-semibold text-blue-600';
        } else {
            difficultyElement.textContent = 'No change recommended';
            difficultyElement.className = 'font-semibold text-gray-600';
        }
    }
    
    // Update recommended question types
    const typesElement = document.getElementById('recommended-types');
    if (typesElement) {
        // Clear existing content
        typesElement.innerHTML = '';
        
        if (recommendations.questionTypes.length > 0) {
            recommendations.questionTypes.forEach(type => {
                const typeTag = document.createElement('span');
                typeTag.className = 'bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs';
                typeTag.textContent = formatQuestionType(type);
                typesElement.appendChild(typeTag);
            });
        } else {
            const placeholderTag = document.createElement('span');
            placeholderTag.className = 'bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs';
            placeholderTag.textContent = 'Not enough data yet';
            typesElement.appendChild(placeholderTag);
        }
    }
    
    // Update apply button status
    const applyBtn = document.getElementById('apply-recommendations-btn');
    if (applyBtn) {
        const hasRecommendations = recommendations.difficulty || recommendations.questionTypes.length > 0;
        applyBtn.disabled = !hasRecommendations;
        applyBtn.className = hasRecommendations 
            ? 'w-full mt-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md transition shadow-sm flex items-center justify-center'
            : 'w-full mt-2 bg-gray-400 text-white font-medium py-2 px-4 rounded-md transition shadow-sm flex items-center justify-center cursor-not-allowed';
    }
}

// Update feedback history
function updateFeedbackHistory() {
    if (!window.feedbackLoop || !window.feedbackLoop.feedbackHistory) return;
    
    const historyContainer = document.getElementById('feedback-history');
    if (!historyContainer) return;
    
    // Clear existing content
    historyContainer.innerHTML = '';
    
    // Get last 10 feedback items
    const recentFeedback = window.feedbackLoop.feedbackHistory.slice(0, 10);
    
    if (recentFeedback.length === 0) {
        const placeholder = document.createElement('p');
        placeholder.className = 'text-center text-gray-500';
        placeholder.textContent = 'No feedback activity yet';
        historyContainer.appendChild(placeholder);
        return;
    }
    
    // Add each feedback item
    recentFeedback.forEach(item => {
        const feedbackItem = document.createElement('div');
        feedbackItem.className = 'flex items-center justify-between p-2 bg-white rounded border border-gray-100';
        
        const date = new Date(item.timestamp);
        const formattedTime = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        // Get icon based on feedback type and value
        let icon, typeText, valueClass;
        
        switch (item.feedbackType) {
            case 'relevance':
                icon = item.value > 0 ? 'far fa-thumbs-up text-green-500' : 'far fa-thumbs-down text-red-500';
                typeText = 'Helpfulness';
                valueClass = item.value > 0 ? 'text-green-600' : 'text-red-600';
                break;
            case 'accuracy':
                icon = 'fas fa-check-circle text-blue-500';
                typeText = 'Quality Rating';
                valueClass = 'text-blue-600';
                break;
            case 'clarity':
                icon = 'fas fa-align-left text-yellow-500';
                typeText = 'Clarity';
                valueClass = 'text-yellow-600';
                break;
            case 'difficulty':
                icon = 'fas fa-balance-scale text-purple-500';
                typeText = 'Difficulty';
                valueClass = 'text-purple-600';
                break;
            default:
                icon = 'fas fa-comment text-gray-500';
                typeText = 'Feedback';
                valueClass = 'text-gray-600';
        }
        
        feedbackItem.innerHTML = `
            <div class="flex items-center">
                <i class="${icon} mr-2"></i>
                <span>${typeText}</span>
            </div>
            <div class="flex items-center">
                <span class="${valueClass} font-medium mr-3">
                    ${item.feedbackType === 'accuracy' ? `${item.value}/5` : (item.value > 0 ? 'Positive' : 'Negative')}
                </span>
                <span class="text-gray-400 text-xs">${formattedTime}</span>
            </div>
        `;
        
        historyContainer.appendChild(feedbackItem);
    });
}

// Format question type for display
function formatQuestionType(type) {
    if (!type) return 'Unknown';
    
    // Map internal type names to display names
    const typeMap = {
        'mcq': 'Multiple Choice',
        'tf': 'True/False',
        'matching': 'Matching',
        'short-answer': 'Short Answer',
        'clinical-case': 'Clinical Case',
        'differential': 'Differential',
        'management': 'Management',
        'viva': 'VIVA',
        'osce': 'OSCE'
    };
    
    return typeMap[type] || type.charAt(0).toUpperCase() + type.slice(1).replace(/-/g, ' ');
}

// Reset all feedback data - enhanced to clear improved questions
function resetFeedbackData() {
    localStorage.removeItem('ophthalmoqa_feedback_history');
    localStorage.removeItem('ophthalmoqa_question_history');
    localStorage.removeItem('ophthalmoqa_improved_questions');
    
        // Reload the feedback loop
    if (window.feedbackLoop) {
        window.feedbackLoop.feedbackHistory = [];
        window.feedbackLoop.questionHistory = [];
        window.feedbackLoop.improvedQuestions = {};
        window.feedbackLoop.improvementMetrics = {
            clarity: 0,
            difficulty: 0,
            relevance: 0,
            accuracy: 0
        };
    }
    
    // Update the analytics
    updateFeedbackAnalytics();
    
    // Remove improvement badges from current questions
    document.querySelectorAll('.question-item.improved').forEach(item => {
        item.classList.remove('improved');
        const badge = item.querySelector('.improvement-badge');
        if (badge) badge.remove();
    });
    
    // Show confirmation
    alert('Feedback data has been reset successfully.');
}

// Add feedback status summary to question container
function addFeedbackStatusSummary() {
    const qaContainer = document.getElementById('qa-container');
    if (!qaContainer || !feedbackLoop || qaContainer.querySelector('.feedback-status-summary')) return;
    
    // Create feedback status summary container
    const summaryContainer = document.createElement('div');
    summaryContainer.className = 'feedback-status-summary bg-gradient-to-r from-blue-50 to-indigo-50 p-3 md:p-4 rounded-lg mb-4 border border-blue-100';
    
    // Get stats for summary
    const stats = window.feedbackLoop ? window.feedbackLoop.getFeedbackStats() : { totalFeedback: 0, positiveRate: 0, improvementMetrics: { relevance: 0, accuracy: 0 }, totalImprovedQuestions: 0 };
    const hasHistory = stats.totalFeedback > 0;
    const hasRecommendations = 
        stats.recommendedParameters.difficulty || 
        stats.recommendedParameters.questionTypes.length > 0;
        
    // Create summary content
    let summaryContent = '';
    
    if (!hasHistory) {
        // No feedback history yet
        summaryContent = `
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-1.5 mr-3">
                    <i class="fas fa-lightbulb text-blue-600"></i>
                </div>
                <div>
                    <h4 class="font-medium text-blue-800 mb-1">Feedback-Driven Question Improvement</h4>
                    <p class="text-sm text-blue-700">Rate the quality and relevance of questions to help improve future generation. Your feedback shapes better questions over time.</p>
                </div>
            </div>
        `;
    } else {
        // Has feedback history - enhanced with more metrics
        summaryContent = `
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-green-100 rounded-full p-1.5 mr-3">
                    <i class="fas fa-check-circle text-green-600"></i>
                </div>
                <div class="flex-grow">
                    <h4 class="font-medium text-green-800 mb-1">Feedback-Optimized Questions</h4>
                    <p class="text-sm text-green-700 mb-2">
                        These questions are optimized based on ${stats.totalFeedback} feedback data points and 
                        ${stats.totalImprovementCount} improvements across ${stats.totalImprovedQuestions} questions.
                    </p>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2 text-xs">
                        <div class="bg-blue-50 p-1.5 rounded border border-blue-100 flex items-center">
                            <i class="fas fa-thumbs-up text-blue-600 mr-1.5"></i>
                            <span>Feedback Rate: <strong>${Math.round(stats.averageFeedbackPerQuestion * 100)/100}/question</strong></span>
                        </div>
                        <div class="bg-green-50 p-1.5 rounded border border-green-100 flex items-center">
                            <i class="fas fa-sync-alt text-green-600 mr-1.5"></i>
                            <span>Improved: <strong>${stats.totalImprovedQuestions} questions</strong></span>
                        </div>
                        <div class="bg-indigo-50 p-1.5 rounded border border-indigo-100 flex items-center col-span-2">
                            <i class="fas fa-magic text-indigo-600 mr-1.5"></i>
                            <span>Top performing question type: <strong>${getBestQuestionType(stats.improvementsByType)}</strong></span>
                        </div>
                    </div>
                    <div class="flex flex-wrap gap-2">
                        ${hasRecommendations ? `
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full flex items-center">
                            <i class="fas fa-magic mr-1"></i> Using recommended parameters
                        </span>` : ''}
                        <button id="view-feedback-analytics-btn" class="text-indigo-600 hover:text-indigo-800 text-xs underline flex items-center">
                            <i class="fas fa-chart-line mr-1"></i> View feedback analytics
                        </button>
                        <button id="selection-mode-btn" class="text-purple-600 hover:text-purple-800 text-xs underline flex items-center ml-auto">
                            <i class="fas fa-check-square mr-1"></i> Select questions
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Set content
    summaryContainer.innerHTML = summaryContent;
    
    // Add event listener to analytics button if it exists
    const analyticsBtn = summaryContainer.querySelector('#view-feedback-analytics-btn');
    if (analyticsBtn) {
        analyticsBtn.addEventListener('click', openFeedbackAnalyticsModal);
    }
    
    // Add to container before the first question
    const firstItem = qaContainer.querySelector('.question-item');
    if (firstItem) {
        qaContainer.insertBefore(summaryContainer, firstItem);
    } else {
        qaContainer.appendChild(summaryContainer);
    }
}

// Get best performing question type from improvement statistics
function getBestQuestionType(improvementsByType) {
    if (!improvementsByType || Object.keys(improvementsByType).length === 0) {
        return 'None yet';
    }
    
    let bestType = 'unknown';
    let bestCount = 0;
    
    Object.entries(improvementsByType).forEach(([type, data]) => {
        if (type !== 'unknown' && data.count > bestCount) {
            bestType = type;
            bestCount = data.count;
        }
    });
    
    return formatQuestionType(bestType);
}

/**
 * Adds a feedback metrics summary at the top of the questions container
 * This shows stats about improved questions and feedback collection
 */
function addFeedbackMetricsSummary() {
    // Get the questions container
    const qaContainer = document.getElementById('qa-container');
    if (!qaContainer) return;
    
    // Remove any existing summary
    const existingSummary = document.getElementById('feedback-metrics-summary');
    if (existingSummary) existingSummary.remove();
    
    // Get stats from feedback loop
    const stats = {
        improved: 0,
        repeated: 0,
        total: 0
    };
    
    if (window.feedbackLoop) {
        // Count improved questions
        stats.improved = Object.keys(window.feedbackLoop.improvedQuestions || {}).length;
        
        // Count questions in the current session
        const questionElements = qaContainer.querySelectorAll('.question-item:not(.deep-search-item)');
        stats.total = questionElements.length;
        
        // Count repeated questions
        stats.repeated = Array.from(questionElements).filter(el => 
            el.classList.contains('repeated-question')).length;
    }
    
    // Only show summary if we have questions and at least one improved or repeated
    if (stats.total === 0 || (stats.improved === 0 && stats.repeated === 0)) return;
    
    // Create summary element
    const summaryEl = document.createElement('div');
    summaryEl.id = 'feedback-metrics-summary';
    summaryEl.className = 'bg-blue-50 border border-blue-200 rounded-md p-3 mb-4 text-sm';
    
    // Create summary content
    let summaryHTML = '<div class="flex items-center justify-between">';
    summaryHTML += '<div class="flex items-center">';
    summaryHTML += '<i class="fas fa-chart-line text-blue-600 mr-2"></i>';
    summaryHTML += '<span class="font-medium text-blue-800">Question Metrics</span>';
    summaryHTML += '</div>';
    
    // Add metrics badges
    summaryHTML += '<div class="flex space-x-3">';
    
    // Total questions badge
    summaryHTML += `<div class="bg-gray-100 text-gray-800 px-2 py-1 rounded-md flex items-center">
        <i class="fas fa-list-alt mr-1"></i> ${stats.total} Questions
    </div>`;
    
    // Improved questions badge (only if > 0)
    if (stats.improved > 0) {
        summaryHTML += `<div class="bg-green-100 text-green-800 px-2 py-1 rounded-md flex items-center">
            <i class="fas fa-check-circle mr-1"></i> ${stats.improved} Improved
        </div>`;
    }
    
    // Repeated questions badge (only if > 0)
    if (stats.repeated > 0) {
        summaryHTML += `<div class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-md flex items-center">
            <i class="fas fa-exclamation-circle mr-1"></i> ${stats.repeated} Repeated
        </div>`;
    }
    
    summaryHTML += '</div></div>';
    
    // Add improvement rate if we have enough data
    if (stats.improved > 0 && stats.total > 0) {
        const improvementRate = Math.round((stats.improved / stats.total) * 100);
        
        summaryHTML += `<div class="mt-2 pt-2 border-t border-blue-200">
            <div class="flex justify-between items-center text-xs text-blue-700">
                <span>Improvement Rate:</span>
                <span class="font-medium">${improvementRate}%</span>
            </div>
            <div class="w-full bg-blue-200 rounded-full h-1.5 mt-1">
                <div class="bg-blue-600 h-1.5 rounded-full" style="width: ${improvementRate}%"></div>
            </div>
        </div>`;
    }
    
    summaryEl.innerHTML = summaryHTML;
    
    // Insert at the top of the container
    if (qaContainer.firstChild) {
        qaContainer.insertBefore(summaryEl, qaContainer.firstChild);
    } else {
        qaContainer.appendChild(summaryEl);
    }
} 
/**
 * Enhanced Feedback Collection System
 * Collects and processes user feedback for continuous improvement
 */

class EnhancedFeedbackSystem {
    constructor() {
        this.feedbackQueue = [];
        this.analyticsData = this.loadAnalyticsData();
        this.userPreferences = this.loadUserPreferences();
        this.sessionStartTime = Date.now();
        this.currentQuestionSet = [];
        
        // Track question improvements through feedback loop
        this.improvedQuestions = new Map(); // questionId -> improvement details
        this.improvementHistory = this.loadImprovementHistory();
        this.feedbackImprovements = this.loadFeedbackImprovements();
        
        this.initialize();
    }

    initialize() {
        console.log('🎯 Initializing Enhanced Feedback System...');
        this.setupFeedbackInterceptors();
        this.initializeAdaptiveFeedback();
        this.setupRealTimeMonitoring();
        console.log('✅ Enhanced Feedback System ready');
    }

    setupFeedbackInterceptors() {
        // Intercept existing feedback button clicks
        document.addEventListener('click', (event) => {
            if (event.target.classList.contains('feedback-btn')) {
                this.handleFeedbackClick(event);
            }
        });

        // Monitor question improvements
        document.addEventListener('click', (event) => {
            if (event.target.classList.contains('improve-question-btn')) {
                this.handleQuestionImprovement(event);
            }
        });

        // Track time spent on questions
        document.addEventListener('scroll', (event) => {
            this.trackQuestionViewTime(event);
        });
    }

    handleFeedbackClick(event) {
        const button = event.target;
        const questionDiv = button.closest('.question-item');
        const questionId = questionDiv?.dataset.questionId || this.generateQuestionId(questionDiv);
        
        const feedbackType = button.getAttribute('data-feedback');
        const feedbackValue = button.getAttribute('data-value');

        // Create enhanced feedback data
        const enhancedFeedback = {
            questionId: questionId,
            type: feedbackType,
            value: feedbackValue,
            timestamp: Date.now(),
            sessionId: this.getSessionId(),
            metadata: this.gatherQuestionMetadata(questionDiv),
            userContext: this.getUserContext(),
            interactionHistory: this.getQuestionInteractionHistory(questionId)
        };

        // Store and process feedback
        this.processFeedback(enhancedFeedback);

        // Update UI with immediate feedback
        this.showFeedbackAcknowledgment(button, enhancedFeedback);

        // Trigger real-time improvements if needed
        this.checkForImmediateImprovements(enhancedFeedback);
    }

    gatherQuestionMetadata(questionDiv) {
        if (!questionDiv) return {};

        const questionText = questionDiv.querySelector('.question-text')?.textContent || '';
        const answerText = questionDiv.querySelector('.answer-text')?.textContent || '';
        const options = Array.from(questionDiv.querySelectorAll('.question-option')).map(opt => opt.textContent);

        // Analyze question characteristics
        const metadata = {
            questionLength: questionText.length,
            answerLength: answerText.length,
            optionCount: options.length,
            hasImages: questionDiv.querySelector('img') !== null,
            hasTables: questionDiv.querySelector('table') !== null,
            complexity: this.analyzeComplexity(questionText),
            medicalTopic: this.extractMedicalTopic(questionText),
            questionType: this.classifyQuestionType(questionText, options),
            estimatedDifficulty: this.estimateDifficulty(questionText, answerText)
        };

        return metadata;
    }

    analyzeComplexity(questionText) {
        const complexityIndicators = {
            basic: ['what is', 'define', 'identify'],
            moderate: ['explain', 'describe', 'compare'],
            advanced: ['analyze', 'evaluate', 'synthesize'],
            expert: ['differential diagnosis', 'management plan', 'prognosis']
        };

        const text = questionText.toLowerCase();
        let maxComplexity = 'basic';

        Object.entries(complexityIndicators).forEach(([level, indicators]) => {
            if (indicators.some(indicator => text.includes(indicator))) {
                maxComplexity = level;
            }
        });

        return maxComplexity;
    }

    extractMedicalTopic(questionText) {
        const ophthalmologyTopics = {
            'retina': ['retina', 'macula', 'vitreous', 'diabetic retinopathy'],
            'glaucoma': ['glaucoma', 'iop', 'optic nerve', 'visual field'],
            'cataract': ['cataract', 'lens', 'phacoemulsification'],
            'cornea': ['cornea', 'keratitis', 'transplant', 'dystrophy'],
            'neuro-ophthalmology': ['optic nerve', 'visual pathway', 'diplopia'],
            'pediatric': ['pediatric', 'children', 'amblyopia', 'strabismus'],
            'oculoplastics': ['eyelid', 'orbit', 'ptosis', 'tear duct']
        };

        const text = questionText.toLowerCase();
        for (const [topic, keywords] of Object.entries(ophthalmologyTopics)) {
            if (keywords.some(keyword => text.includes(keyword))) {
                return topic;
            }
        }

        return 'general';
    }

    classifyQuestionType(questionText, options) {
        if (options.length > 0) {
            return 'multiple_choice';
        } else if (questionText.includes('true or false')) {
            return 'true_false';
        } else if (questionText.includes('describe') || questionText.includes('explain')) {
            return 'short_answer';
        } else {
            return 'other';
        }
    }

    estimateDifficulty(questionText, answerText) {
        const difficultyFactors = {
            questionComplexity: questionText.length > 200 ? 0.3 : 0.1,
            answerDepth: answerText.length > 300 ? 0.3 : 0.1,
            technicalTerms: this.countTechnicalTerms(questionText + ' ' + answerText) * 0.1,
            clinicalScenario: questionText.includes('patient') || questionText.includes('case') ? 0.2 : 0
        };

        const totalScore = Object.values(difficultyFactors).reduce((sum, factor) => sum + factor, 0);
        
        if (totalScore > 0.7) return 'expert';
        if (totalScore > 0.5) return 'advanced';
        if (totalScore > 0.3) return 'intermediate';
        return 'basic';
    }

    countTechnicalTerms(text) {
        const technicalTerms = [
            'phacoemulsification', 'trabeculectomy', 'vitrectomy', 'keratoplasty',
            'retinopathy', 'maculopathy', 'neuropathy', 'dystrophy',
            'angiography', 'tomography', 'perimetry', 'tonometry'
        ];

        const lowerText = text.toLowerCase();
        return technicalTerms.filter(term => lowerText.includes(term)).length;
    }

    getUserContext() {
        return {
            sessionDuration: Date.now() - this.sessionStartTime,
            questionsViewed: this.currentQuestionSet.length,
            currentScrollPosition: window.scrollY,
            viewportSize: {
                width: window.innerWidth,
                height: window.innerHeight
            },
            timestamp: Date.now()
        };
    }

    getQuestionInteractionHistory(questionId) {
        const interactions = this.analyticsData.interactions || [];
        return interactions.filter(interaction => 
            interaction.questionId === questionId
        ).slice(-10); // Last 10 interactions
    }

    processFeedback(feedbackData) {
        // Add to feedback queue for batch processing
        this.feedbackQueue.push(feedbackData);

        // Update analytics immediately
        this.updateAnalytics(feedbackData);

        // Process queue if it gets large
        if (this.feedbackQueue.length >= 5) {
            this.processQueuedFeedback();
        }

        // Emit event for feedback loop system
        document.dispatchEvent(new CustomEvent('feedbackRecorded', {
            detail: feedbackData
        }));
    }

    updateAnalytics(feedbackData) {
        const analytics = this.analyticsData;
        
        // Update counters
        analytics.totalFeedback = (analytics.totalFeedback || 0) + 1;
        analytics.sessionFeedback = (analytics.sessionFeedback || 0) + 1;

        // Update type-specific counters
        const typeKey = `${feedbackData.type}_${feedbackData.value}`;
        analytics[typeKey] = (analytics[typeKey] || 0) + 1;

        // Track trends
        if (!analytics.trends) analytics.trends = {};
        if (!analytics.trends[feedbackData.type]) analytics.trends[feedbackData.type] = [];
        
        analytics.trends[feedbackData.type].push({
            value: feedbackData.value,
            timestamp: feedbackData.timestamp
        });

        // Keep only recent trends (last 100 entries)
        if (analytics.trends[feedbackData.type].length > 100) {
            analytics.trends[feedbackData.type] = analytics.trends[feedbackData.type].slice(-100);
        }

        this.saveAnalyticsData();
    }

    showFeedbackAcknowledgment(button, feedbackData) {
        // Visual feedback on button
        button.classList.add('active');
        
        // Show appreciation message
        const appreciation = this.createAppreciationMessage(feedbackData);
        if (appreciation) {
            const questionDiv = button.closest('.question-item');
            this.showTemporaryMessage(questionDiv, appreciation);
        }

        // Update button states
        this.updateFeedbackButtons(button, feedbackData);
    }

    createAppreciationMessage(feedbackData) {
        const messages = {
            quality_good: "Thank you! This helps us understand what works well.",
            quality_poor: "Thanks for the feedback! We'll work on improving question quality.",
            relevance_yes: "Great! We'll prioritize similar content.",
            relevance_no: "Noted! We'll adjust topic relevance.",
            difficulty_appropriate: "Perfect! This difficulty level is working well.",
            difficulty_too_hard: "Thanks! We'll adjust the difficulty down.",
            difficulty_too_easy: "Got it! We'll increase the challenge level."
        };

        const key = `${feedbackData.type}_${feedbackData.value}`;
        return messages[key] || "Thank you for your feedback!";
    }

    showTemporaryMessage(container, message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'feedback-appreciation bg-green-50 border border-green-200 rounded p-2 mt-2 text-sm text-green-800';
        messageDiv.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-check-circle text-green-600 mr-2"></i>
                <span>${message}</span>
            </div>
        `;

        container.appendChild(messageDiv);

        // Remove after 3 seconds
        setTimeout(() => {
            if (messageDiv.parentElement) {
                messageDiv.remove();
            }
        }, 3000);
    }

    updateFeedbackButtons(clickedButton, feedbackData) {
        const questionDiv = clickedButton.closest('.question-item');
        const relatedButtons = questionDiv.querySelectorAll(`[data-feedback="${feedbackData.type}"]`);

        relatedButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn === clickedButton) {
                btn.classList.add('active');
            }
        });
    }

    checkForImmediateImprovements(feedbackData) {
        // Immediate response to critical feedback
        if (feedbackData.value === 'poor' || feedbackData.value === 'no') {
            this.triggerImmediateResponse(feedbackData);
        }

        // Check for patterns requiring immediate action
        const recentNegative = this.getRecentNegativeFeedback();
        if (recentNegative.length >= 3) {
            this.triggerPatternResponse(recentNegative);
        }
    }

    triggerImmediateResponse(feedbackData) {
        const questionDiv = document.querySelector(`[data-question-id="${feedbackData.questionId}"]`);
        if (!questionDiv) return;

        // Add improvement suggestion button
        this.addImprovementSuggestion(questionDiv, feedbackData);
    }

    addImprovementSuggestion(questionDiv, feedbackData) {
        const existingSuggestion = questionDiv.querySelector('.improvement-suggestion');
        if (existingSuggestion) return;

        const suggestion = document.createElement('div');
        suggestion.className = 'improvement-suggestion bg-blue-50 border border-blue-200 rounded p-3 mt-3';
        
        const suggestionText = this.generateImprovementSuggestion(feedbackData);
        
        suggestion.innerHTML = `
            <div class="flex items-start">
                <i class="fas fa-lightbulb text-blue-600 mr-2 mt-1"></i>
                <div class="flex-1">
                    <p class="text-sm text-blue-800 mb-2">${suggestionText}</p>
                    <button class="apply-suggestion-btn bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1 rounded transition"
                            data-suggestion-type="${feedbackData.type}" data-suggestion-action="apply">
                        Apply Improvement
                    </button>
                </div>
                <button class="dismiss-suggestion text-blue-400 hover:text-blue-600" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        questionDiv.appendChild(suggestion);

        // Add event listener for apply button
        const applyBtn = suggestion.querySelector('.apply-suggestion-btn');
        applyBtn.addEventListener('click', () => {
            this.applySuggestion(questionDiv, feedbackData);
            suggestion.remove();
        });
    }

    generateImprovementSuggestion(feedbackData) {
        const suggestions = {
            quality_poor: "This question could benefit from clearer wording or better answer options. Would you like to regenerate it with improved clarity?",
            relevance_no: "This question seems off-topic. We can replace it with more relevant content based on your study focus.",
            difficulty_too_hard: "This question might be too challenging. We can generate a similar but easier version.",
            difficulty_too_easy: "This question might be too simple. We can create a more challenging variant."
        };

        const key = `${feedbackData.type}_${feedbackData.value}`;
        return suggestions[key] || "We can improve this question based on your feedback.";
    }

    applySuggestion(questionDiv, feedbackData) {
        // Show improvement in progress
        const improvingMessage = document.createElement('div');
        improvingMessage.className = 'improvement-progress bg-yellow-50 border border-yellow-200 rounded p-2 text-sm text-yellow-800';
        improvingMessage.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Improving question...';
        questionDiv.appendChild(improvingMessage);

        // Simulate improvement process
        setTimeout(() => {
            this.completeQuestionImprovement(questionDiv, feedbackData);
            improvingMessage.remove();
        }, 2000);
    }

    completeQuestionImprovement(questionDiv, feedbackData) {
        // Mark question as improved
        questionDiv.classList.add('improved');
        
        // Show success message
        const successMessage = document.createElement('div');
        successMessage.className = 'improvement-success bg-green-50 border border-green-200 rounded p-2 text-sm text-green-800';
        successMessage.innerHTML = '<i class="fas fa-check mr-2"></i>Question improved based on your feedback!';
        questionDiv.appendChild(successMessage);

        // Record improvement
        this.recordImprovement(feedbackData.questionId, feedbackData);

        // Remove success message after 4 seconds
        setTimeout(() => {
            if (successMessage.parentElement) {
                successMessage.remove();
            }
        }, 4000);
    }

    recordImprovement(questionId, originalFeedback) {
        if (!this.analyticsData.improvements) {
            this.analyticsData.improvements = [];
        }

        this.analyticsData.improvements.push({
            questionId: questionId,
            originalFeedback: originalFeedback,
            improvementType: this.getImprovementType(originalFeedback),
            timestamp: Date.now(),
            sessionId: this.getSessionId()
        });

        this.saveAnalyticsData();
    }

    getImprovementType(feedbackData) {
        const types = {
            quality_poor: 'clarity_improvement',
            relevance_no: 'topic_adjustment',
            difficulty_too_hard: 'difficulty_reduction',
            difficulty_too_easy: 'difficulty_increase'
        };

        const key = `${feedbackData.type}_${feedbackData.value}`;
        return types[key] || 'general_improvement';
    }

    getRecentNegativeFeedback() {
        const recent = Date.now() - (10 * 60 * 1000); // Last 10 minutes
        return this.feedbackQueue.filter(feedback => 
            feedback.timestamp > recent && 
            (feedback.value === 'poor' || feedback.value === 'no')
        );
    }

    triggerPatternResponse(negativePatterns) {
        // Show pattern notification
        this.showPatternNotification(negativePatterns);
        
        // Trigger global improvements
        this.triggerGlobalImprovements(negativePatterns);
    }

    showPatternNotification(patterns) {
        const notification = document.createElement('div');
        notification.className = 'pattern-notification fixed top-4 right-4 bg-orange-100 border-l-4 border-orange-500 p-4 rounded shadow-lg z-50 max-w-sm';
        notification.innerHTML = `
            <div class="flex">
                <i class="fas fa-exclamation-triangle text-orange-500 mr-3 mt-1"></i>
                <div>
                    <h4 class="font-medium text-orange-800">Pattern Detected</h4>
                    <p class="text-sm text-orange-700 mt-1">
                        We've noticed some issues with recent questions. 
                        We're automatically adjusting the generation parameters.
                    </p>
                    <button class="mt-2 text-xs bg-orange-200 hover:bg-orange-300 px-2 py-1 rounded text-orange-800"
                            onclick="this.parentElement.parentElement.parentElement.remove()">
                        Got it
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(notification);

        // Auto-remove after 8 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 8000);
    }

    triggerGlobalImprovements(patterns) {
        // Emit event for global improvement system
        document.dispatchEvent(new CustomEvent('patternDetected', {
            detail: {
                patterns: patterns,
                timestamp: Date.now(),
                severity: 'moderate'
            }
        }));
    }

    // Adaptive feedback collection
    initializeAdaptiveFeedback() {
        // Adjust feedback frequency based on user engagement
        this.feedbackRequestInterval = this.calculateOptimalInterval();
        
        // Setup intelligent feedback prompts
        this.setupIntelligentPrompts();
    }

    calculateOptimalInterval() {
        const userEngagement = this.calculateUserEngagement();
        
        // More engaged users can handle more frequent feedback requests
        if (userEngagement > 0.8) return 3; // Every 3 questions
        if (userEngagement > 0.5) return 5; // Every 5 questions
        return 7; // Every 7 questions for less engaged users
    }

    calculateUserEngagement() {
        const totalFeedback = this.analyticsData.totalFeedback || 0;
        const questionsViewed = this.currentQuestionSet.length || 1;
        
        return Math.min(totalFeedback / questionsViewed, 1.0);
    }

    setupIntelligentPrompts() {
        // Prompt for feedback on questions that seem problematic
        document.addEventListener('click', (event) => {
            if (event.target.closest('.question-item')) {
                this.considerFeedbackPrompt(event.target.closest('.question-item'));
            }
        });
    }

    considerFeedbackPrompt(questionDiv) {
        const questionId = questionDiv.dataset.questionId;
        if (!questionId) return;

        // Check if this question type has been problematic
        const metadata = this.gatherQuestionMetadata(questionDiv);
        const isProblematic = this.isQuestionTypeProblematic(metadata);

        if (isProblematic && !questionDiv.querySelector('.feedback-prompt')) {
            this.addIntelligentFeedbackPrompt(questionDiv);
        }
    }

    isQuestionTypeProblematic(metadata) {
        const trends = this.analyticsData.trends || {};
        
        // Check if this topic/type has received negative feedback
        const topicFeedback = trends.relevance || [];
        const qualityFeedback = trends.quality || [];

        const recentNegative = [...topicFeedback, ...qualityFeedback]
            .filter(f => f.timestamp > Date.now() - (24 * 60 * 60 * 1000))
            .filter(f => f.value === 'no' || f.value === 'poor');

        return recentNegative.length >= 2;
    }

    addIntelligentFeedbackPrompt(questionDiv) {
        const prompt = document.createElement('div');
        prompt.className = 'feedback-prompt bg-blue-50 border border-blue-200 rounded p-2 mt-3 text-sm';
        prompt.innerHTML = `
            <div class="flex items-center justify-between">
                <span class="text-blue-800">
                    <i class="fas fa-question-circle mr-1"></i>
                    How was this question for you?
                </span>
                <div class="flex gap-2">
                    <button class="quick-feedback-btn bg-green-100 hover:bg-green-200 px-2 py-1 rounded text-green-800"
                            data-feedback="quality" data-value="good">
                        👍 Good
                    </button>
                    <button class="quick-feedback-btn bg-red-100 hover:bg-red-200 px-2 py-1 rounded text-red-800"
                            data-feedback="quality" data-value="poor">
                        👎 Poor
                    </button>
                    <button class="dismiss-prompt text-gray-400 hover:text-gray-600"
                            onclick="this.parentElement.parentElement.parentElement.remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `;

        questionDiv.appendChild(prompt);

        // Add event listeners to quick feedback buttons
        prompt.querySelectorAll('.quick-feedback-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleFeedbackClick(e);
                prompt.remove();
            });
        });
    }

    // Real-time monitoring
    setupRealTimeMonitoring() {
        this.timeTracker = new Map();
        this.setupViewTimeTracking();
        this.setupEngagementMetrics();
    }

    setupViewTimeTracking() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const questionId = entry.target.dataset.questionId;
                if (!questionId) return;

                if (entry.isIntersecting) {
                    this.timeTracker.set(questionId, Date.now());
                } else {
                    const startTime = this.timeTracker.get(questionId);
                    if (startTime) {
                        const viewTime = Date.now() - startTime;
                        this.recordViewTime(questionId, viewTime);
                        this.timeTracker.delete(questionId);
                    }
                }
            });
        }, { threshold: 0.5 });

        // Observe all question items
        document.querySelectorAll('.question-item').forEach(item => {
            observer.observe(item);
        });
    }

    recordViewTime(questionId, viewTime) {
        if (!this.analyticsData.viewTimes) {
            this.analyticsData.viewTimes = [];
        }

        this.analyticsData.viewTimes.push({
            questionId: questionId,
            viewTime: viewTime,
            timestamp: Date.now()
        });

        // Analyze if view time suggests difficulty
        if (viewTime > 60000) { // More than 1 minute
            this.considerDifficultyFeedback(questionId, 'too_hard');
        } else if (viewTime < 5000) { // Less than 5 seconds
            this.considerDifficultyFeedback(questionId, 'too_easy');
        }

        this.saveAnalyticsData();
    }

    considerDifficultyFeedback(questionId, suggestedDifficulty) {
        // Don't auto-suggest if user already provided feedback
        const existingFeedback = this.feedbackQueue.find(f => 
            f.questionId === questionId && f.type === 'difficulty'
        );

        if (!existingFeedback) {
            const questionDiv = document.querySelector(`[data-question-id="${questionId}"]`);
            if (questionDiv && !questionDiv.querySelector('.difficulty-suggestion')) {
                this.addDifficultySuggestion(questionDiv, suggestedDifficulty);
            }
        }
    }

    addDifficultySuggestion(questionDiv, suggestedDifficulty) {
        const suggestion = document.createElement('div');
        suggestion.className = 'difficulty-suggestion bg-purple-50 border border-purple-200 rounded p-2 mt-2 text-sm';
        
        const suggestionText = suggestedDifficulty === 'too_hard' 
            ? "This question seems challenging - was it too difficult?"
            : "You moved through this quickly - was it too easy?";

        suggestion.innerHTML = `
            <div class="flex items-center justify-between">
                <span class="text-purple-800">${suggestionText}</span>
                <div class="flex gap-2">
                    <button class="auto-feedback-btn bg-purple-100 hover:bg-purple-200 px-2 py-1 rounded text-purple-800"
                            data-feedback="difficulty" data-value="${suggestedDifficulty}">
                        Yes
                    </button>
                    <button class="auto-feedback-btn bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded text-gray-800"
                            data-feedback="difficulty" data-value="appropriate">
                        No, it was fine
                    </button>
                    <button class="dismiss-suggestion text-gray-400 hover:text-gray-600"
                            onclick="this.parentElement.parentElement.parentElement.remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `;

        questionDiv.appendChild(suggestion);

        // Add event listeners
        suggestion.querySelectorAll('.auto-feedback-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleFeedbackClick(e);
                suggestion.remove();
            });
        });
    }

    setupEngagementMetrics() {
        // Track scroll patterns
        let scrollTimeout;
        document.addEventListener('scroll', () => {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                this.analyzeScrollPattern();
            }, 1000);
        });

        // Track click patterns
        document.addEventListener('click', (event) => {
            this.recordClickPattern(event);
        });
    }

    analyzeScrollPattern() {
        const scrollPercent = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
        
        if (!this.analyticsData.scrollMetrics) {
            this.analyticsData.scrollMetrics = [];
        }

        this.analyticsData.scrollMetrics.push({
            scrollPercent: scrollPercent,
            timestamp: Date.now()
        });

        // Keep only recent data
        const recent = Date.now() - (5 * 60 * 1000);
        this.analyticsData.scrollMetrics = this.analyticsData.scrollMetrics.filter(
            metric => metric.timestamp > recent
        );
    }

    recordClickPattern(event) {
        const target = event.target;
        
        if (!this.analyticsData.clickPatterns) {
            this.analyticsData.clickPatterns = [];
        }

        this.analyticsData.clickPatterns.push({
            elementType: target.tagName.toLowerCase(),
            className: target.className,
            timestamp: Date.now()
        });

        // Keep only recent clicks
        const recent = Date.now() - (10 * 60 * 1000);
        this.analyticsData.clickPatterns = this.analyticsData.clickPatterns.filter(
            pattern => pattern.timestamp > recent
        );
    }

    // Batch processing
    processQueuedFeedback() {
        if (this.feedbackQueue.length === 0) return;

        console.log(`Processing ${this.feedbackQueue.length} queued feedback entries`);

        // Batch process all queued feedback
        const batch = [...this.feedbackQueue];
        this.feedbackQueue = [];

        // Analyze batch for patterns
        const patterns = this.analyzeFeedbackBatch(batch);
        
        // Apply batch improvements
        if (patterns.length > 0) {
            this.applyBatchImprovements(patterns);
        }

        // Update preferences based on batch
        this.updateUserPreferences(batch);
    }

    analyzeFeedbackBatch(batch) {
        const patterns = [];

        // Look for topic patterns
        const topicGroups = this.groupBy(batch, 'metadata.medicalTopic');
        Object.entries(topicGroups).forEach(([topic, feedbacks]) => {
            const negative = feedbacks.filter(f => f.value === 'poor' || f.value === 'no');
            if (negative.length / feedbacks.length > 0.6) {
                patterns.push({
                    type: 'topic_issue',
                    topic: topic,
                    severity: negative.length
                });
            }
        });

        // Look for difficulty patterns
        const difficultyFeedback = batch.filter(f => f.type === 'difficulty');
        if (difficultyFeedback.length > 0) {
            const tooHard = difficultyFeedback.filter(f => f.value === 'too_hard').length;
            const tooEasy = difficultyFeedback.filter(f => f.value === 'too_easy').length;
            
            if (tooHard > tooEasy * 2) {
                patterns.push({ type: 'too_difficult', severity: tooHard });
            } else if (tooEasy > tooHard * 2) {
                patterns.push({ type: 'too_easy', severity: tooEasy });
            }
        }

        return patterns;
    }

    groupBy(array, key) {
        return array.reduce((groups, item) => {
            const value = key.split('.').reduce((obj, k) => obj?.[k], item);
            const group = value || 'unknown';
            groups[group] = groups[group] || [];
            groups[group].push(item);
            return groups;
        }, {});
    }

    applyBatchImprovements(patterns) {
        patterns.forEach(pattern => {
            switch (pattern.type) {
                case 'topic_issue':
                    this.adjustTopicWeighting(pattern.topic, 0.8);
                    break;
                case 'too_difficult':
                    this.adjustGlobalDifficulty(-0.1);
                    break;
                case 'too_easy':
                    this.adjustGlobalDifficulty(0.1);
                    break;
            }
        });

        // Notify about batch improvements
        this.showBatchImprovementNotification(patterns);
    }

    adjustTopicWeighting(topic, weight) {
        if (!this.userPreferences.topicWeights) {
            this.userPreferences.topicWeights = {};
        }
        this.userPreferences.topicWeights[topic] = weight;
        this.saveUserPreferences();
    }

    adjustGlobalDifficulty(adjustment) {
        this.userPreferences.difficultyAdjustment = 
            (this.userPreferences.difficultyAdjustment || 0) + adjustment;
        this.saveUserPreferences();
    }

    showBatchImprovementNotification(patterns) {
        const notification = document.createElement('div');
        notification.className = 'batch-improvement-notification fixed bottom-4 right-4 bg-green-100 border-l-4 border-green-500 p-4 rounded shadow-lg z-50 max-w-sm';
        notification.innerHTML = `
            <div class="flex">
                <i class="fas fa-cogs text-green-500 mr-3 mt-1"></i>
                <div>
                    <h4 class="font-medium text-green-800">System Optimized</h4>
                    <p class="text-sm text-green-700 mt-1">
                        Applied ${patterns.length} improvement${patterns.length > 1 ? 's' : ''} based on your recent feedback.
                    </p>
                    <button class="mt-2 text-xs bg-green-200 hover:bg-green-300 px-2 py-1 rounded text-green-800"
                            onclick="this.parentElement.parentElement.parentElement.remove()">
                        Great!
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 6000);
    }

    updateUserPreferences(batch) {
        // Update preferences based on positive feedback
        const positiveFeedback = batch.filter(f => f.value === 'good' || f.value === 'yes');
        
        positiveFeedback.forEach(feedback => {
            const metadata = feedback.metadata;
            if (metadata.medicalTopic) {
                this.reinforceTopicPreference(metadata.medicalTopic);
            }
            if (metadata.questionType) {
                this.reinforceTypePreference(metadata.questionType);
            }
        });

        this.saveUserPreferences();
    }

    reinforceTopicPreference(topic) {
        if (!this.userPreferences.topicPreferences) {
            this.userPreferences.topicPreferences = {};
        }
        this.userPreferences.topicPreferences[topic] = 
            (this.userPreferences.topicPreferences[topic] || 1.0) + 0.1;
    }

    reinforceTypePreference(type) {
        if (!this.userPreferences.typePreferences) {
            this.userPreferences.typePreferences = {};
        }
        this.userPreferences.typePreferences[type] = 
            (this.userPreferences.typePreferences[type] || 1.0) + 0.1;
    }

    // Utility methods
    generateQuestionId(questionDiv) {
        const questionText = questionDiv.querySelector('.question-text')?.textContent || '';
        return 'q_' + Date.now() + '_' + questionText.substring(0, 20).replace(/\W/g, '');
    }

    getSessionId() {
        if (!window.sessionStorage.getItem('feedbackSessionId')) {
            window.sessionStorage.setItem('feedbackSessionId', 
                'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9));
        }
        return window.sessionStorage.getItem('feedbackSessionId');
    }

    // Data persistence
    saveAnalyticsData() {
        try {
            localStorage.setItem('enhancedFeedbackAnalytics', JSON.stringify(this.analyticsData));
        } catch (error) {
            console.error('Failed to save analytics data:', error);
        }
    }

    loadAnalyticsData() {
        try {
            const data = localStorage.getItem('enhancedFeedbackAnalytics');
            return data ? JSON.parse(data) : {
                totalFeedback: 0,
                sessionFeedback: 0,
                trends: {},
                improvements: [],
                viewTimes: [],
                scrollMetrics: [],
                clickPatterns: []
            };
        } catch (error) {
            console.error('Failed to load analytics data:', error);
            return {
                totalFeedback: 0,
                sessionFeedback: 0,
                trends: {},
                improvements: [],
                viewTimes: [],
                scrollMetrics: [],
                clickPatterns: []
            };
        }
    }

    saveUserPreferences() {
        try {
            localStorage.setItem('enhancedFeedbackPreferences', JSON.stringify(this.userPreferences));
        } catch (error) {
            console.error('Failed to save user preferences:', error);
        }
    }

    loadUserPreferences() {
        try {
            const data = localStorage.getItem('enhancedFeedbackPreferences');
            return data ? JSON.parse(data) : {
                topicWeights: {},
                typePreferences: {},
                topicPreferences: {},
                difficultyAdjustment: 0
            };
        } catch (error) {
            console.error('Failed to load user preferences:', error);
            return {
                topicWeights: {},
                typePreferences: {},
                topicPreferences: {},
                difficultyAdjustment: 0
            };
        }
    }

    // Public API
    getAnalytics() {
        return {
            totalFeedback: this.analyticsData.totalFeedback || 0,
            sessionFeedback: this.analyticsData.sessionFeedback || 0,
            improvements: this.analyticsData.improvements?.length || 0,
            userPreferences: this.userPreferences,
            trends: this.analyticsData.trends,
            engagement: this.calculateUserEngagement()
        };
    }

    clearAllData() {
        this.analyticsData = {
            totalFeedback: 0,
            sessionFeedback: 0,
            trends: {},
            improvements: [],
            viewTimes: [],
            scrollMetrics: [],
            clickPatterns: []
        };
        
        this.userPreferences = {
            topicWeights: {},
            typePreferences: {},
            topicPreferences: {},
            difficultyAdjustment: 0
        };

        this.feedbackQueue = [];
        this.improvedQuestions = new Map();
        this.improvementHistory = [];
        this.feedbackImprovements = new Map();
        
        this.saveAnalyticsData();
        this.saveUserPreferences();
        this.saveImprovementHistory();
        this.saveFeedbackImprovements();
        
        console.log('🗑️ Enhanced feedback data cleared');
    }

    // Question Improvement Tracking Methods
    markQuestionAsImproved(questionId, improvementDetails) {
        const improvement = {
            questionId: questionId,
            timestamp: Date.now(),
            improvementType: improvementDetails.type || 'feedback_driven',
            originalFeedback: improvementDetails.feedback || null,
            changes: improvementDetails.changes || [],
            confidenceScore: improvementDetails.confidence || 0.8,
            source: 'feedback_loop',
            session: this.getSessionId(),
            metadata: {
                beforeImprovement: improvementDetails.before || {},
                afterImprovement: improvementDetails.after || {},
                impactScore: improvementDetails.impact || 0.5
            }
        };

        this.improvedQuestions.set(questionId, improvement);
        this.improvementHistory.push(improvement);
        this.saveFeedbackImprovements();
        this.saveImprovementHistory();

        // Update UI to show improvement status
        this.updateQuestionImprovementStatus(questionId, improvement);

        console.log(`✅ Question ${questionId} marked as improved through feedback loop`);
        return improvement;
    }

    updateQuestionImprovementStatus(questionId, improvement) {
        const questionElement = document.querySelector(`[data-question-id="${questionId}"]`);
        if (!questionElement) return;

        // Remove existing improvement indicators
        const existingIndicators = questionElement.querySelectorAll('.feedback-improvement-status');
        existingIndicators.forEach(indicator => indicator.remove());

        // Create improvement status indicator
        const statusIndicator = this.createImprovementStatusIndicator(improvement);
        
        // Add to question header
        const questionHeader = questionElement.querySelector('h3');
        if (questionHeader) {
            questionHeader.appendChild(statusIndicator);
        }

        // Add improvement badge
        const improvementBadge = this.createImprovementBadge(improvement);
        questionElement.insertBefore(improvementBadge, questionElement.firstChild);

        // Update question styling
        questionElement.classList.add('improved-question');
    }

    createImprovementStatusIndicator(improvement) {
        const indicator = document.createElement('span');
        indicator.className = 'feedback-improvement-status ml-2';
        indicator.innerHTML = `
            <i class="fas fa-arrow-up text-green-600" title="Improved through feedback"></i>
            <span class="text-xs text-green-600 ml-1">Improved</span>
        `;
        return indicator;
    }

    createImprovementBadge(improvement) {
        const badge = document.createElement('div');
        badge.className = 'feedback-improvement-badge bg-gradient-to-r from-green-100 to-emerald-100 border-l-4 border-green-500 p-2 mb-3 rounded-r-lg';
        
        const improvementType = this.getImprovementTypeLabel(improvement.improvementType);
        const timeAgo = this.formatTimeAgo(improvement.timestamp);
        
        badge.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-600 mr-2"></i>
                    <div>
                        <div class="text-sm font-medium text-green-800">
                            Question Improved via Feedback Loop
                        </div>
                        <div class="text-xs text-green-600">
                            ${improvementType} • ${timeAgo}
                        </div>
                    </div>
                </div>
                <div class="flex items-center">
                    <div class="text-right mr-2">
                        <div class="text-xs text-green-600">Confidence</div>
                        <div class="text-sm font-bold text-green-800">
                            ${Math.round(improvement.confidenceScore * 100)}%
                        </div>
                    </div>
                    <button class="improvement-details-btn text-green-600 hover:text-green-800 p-1 rounded" 
                            data-question-id="${improvement.questionId}"
                            title="View improvement details">
                        <i class="fas fa-info-circle"></i>
                    </button>
                </div>
            </div>
        `;

        // Add click handler for improvement details
        badge.querySelector('.improvement-details-btn').addEventListener('click', () => {
            this.showImprovementDetails(improvement);
        });

        return badge;
    }

    getImprovementTypeLabel(type) {
        const labels = {
            'feedback_driven': 'User Feedback',
            'pattern_detected': 'Pattern Analysis',
            'difficulty_adjusted': 'Difficulty Tuning',
            'content_enhanced': 'Content Enhancement',
            'clarity_improved': 'Clarity Enhancement',
            'auto_optimized': 'Auto-Optimization'
        };
        return labels[type] || 'System Improvement';
    }

    formatTimeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        const minutes = Math.floor(diff / (1000 * 60));
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return 'Just now';
    }

    showImprovementDetails(improvement) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">
                        <i class="fas fa-chart-line text-green-600 mr-2"></i>
                        Improvement Details
                    </h3>
                    <button class="close-modal text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="space-y-4">
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h4 class="font-medium text-green-800 mb-2">Improvement Summary</h4>
                        <div class="grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <span class="text-green-600">Type:</span>
                                <span class="ml-2 font-medium">${this.getImprovementTypeLabel(improvement.improvementType)}</span>
                            </div>
                            <div>
                                <span class="text-green-600">Confidence:</span>
                                <span class="ml-2 font-medium">${Math.round(improvement.confidenceScore * 100)}%</span>
                            </div>
                            <div>
                                <span class="text-green-600">Impact Score:</span>
                                <span class="ml-2 font-medium">${Math.round(improvement.metadata.impactScore * 100)}%</span>
                            </div>
                            <div>
                                <span class="text-green-600">Improved:</span>
                                <span class="ml-2 font-medium">${this.formatTimeAgo(improvement.timestamp)}</span>
                            </div>
                        </div>
                    </div>
                    
                    ${improvement.changes.length > 0 ? `
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <h4 class="font-medium text-blue-800 mb-2">Changes Made</h4>
                            <ul class="text-sm text-blue-700 space-y-1">
                                ${improvement.changes.map(change => `<li>• ${change}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    
                    ${improvement.originalFeedback ? `
                        <div class="bg-yellow-50 p-4 rounded-lg">
                            <h4 class="font-medium text-yellow-800 mb-2">Original Feedback</h4>
                            <div class="text-sm text-yellow-700">
                                <span class="font-medium">Type:</span> ${improvement.originalFeedback.type}<br>
                                <span class="font-medium">Value:</span> ${improvement.originalFeedback.value}<br>
                                <span class="font-medium">Received:</span> ${this.formatTimeAgo(improvement.originalFeedback.timestamp)}
                            </div>
                        </div>
                    ` : ''}
                </div>
                
                <div class="flex justify-end mt-6">
                    <button class="close-modal bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                        Close
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Close handlers
        modal.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                document.body.removeChild(modal);
            });
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });
    }

    getImprovementStats() {
        const stats = {
            totalImproved: this.improvedQuestions.size,
            improvementsByType: {},
            recentImprovements: [],
            averageConfidence: 0,
            impactScore: 0
        };

        let totalConfidence = 0;
        let totalImpact = 0;

        this.improvedQuestions.forEach(improvement => {
            // Count by type
            const type = improvement.improvementType;
            stats.improvementsByType[type] = (stats.improvementsByType[type] || 0) + 1;

            // Calculate averages
            totalConfidence += improvement.confidenceScore;
            totalImpact += improvement.metadata.impactScore || 0;

            // Recent improvements (last 24 hours)
            if (Date.now() - improvement.timestamp < 24 * 60 * 60 * 1000) {
                stats.recentImprovements.push(improvement);
            }
        });

        if (stats.totalImproved > 0) {
            stats.averageConfidence = totalConfidence / stats.totalImproved;
            stats.impactScore = totalImpact / stats.totalImproved;
        }

        return stats;
    }

    // Data persistence methods
    loadImprovementHistory() {
        try {
            const stored = localStorage.getItem('frcs_improvement_history');
            return stored ? JSON.parse(stored) : [];
        } catch (error) {
            console.warn('Failed to load improvement history:', error);
            return [];
        }
    }

    saveImprovementHistory() {
        try {
            localStorage.setItem('frcs_improvement_history', JSON.stringify(this.improvementHistory));
        } catch (error) {
            console.warn('Failed to save improvement history:', error);
        }
    }

    loadFeedbackImprovements() {
        try {
            const stored = localStorage.getItem('frcs_feedback_improvements');
            if (stored) {
                const data = JSON.parse(stored);
                const map = new Map();
                Object.entries(data).forEach(([key, value]) => {
                    map.set(key, value);
                });
                return map;
            }
            return new Map();
        } catch (error) {
            console.warn('Failed to load feedback improvements:', error);
            return new Map();
        }
    }

    saveFeedbackImprovements() {
        try {
            const data = Object.fromEntries(this.improvedQuestions);
            localStorage.setItem('frcs_feedback_improvements', JSON.stringify(data));
        } catch (error) {
            console.warn('Failed to save feedback improvements:', error);
        }
    }

    // Check if a question has been improved
    hasQuestionBeenImproved(questionId) {
        return this.improvedQuestions.has(questionId);
    }

    getQuestionImprovementDetails(questionId) {
        return this.improvedQuestions.get(questionId) || null;
    }
}

// Initialize the enhanced feedback system
window.enhancedFeedbackSystem = new EnhancedFeedbackSystem();

// Export for global access with safety checks
window.getEnhancedFeedbackAnalytics = () => {
    return window.enhancedFeedbackSystem ? window.enhancedFeedbackSystem.getAnalytics() : {};
};

window.clearEnhancedFeedbackData = () => {
    if (window.enhancedFeedbackSystem) {
        return window.enhancedFeedbackSystem.clearAllData();
    }
};

window.markQuestionAsImproved = (questionId, details) => {
    if (window.enhancedFeedbackSystem) {
        return window.enhancedFeedbackSystem.markQuestionAsImproved(questionId, details);
    }
};

window.hasQuestionBeenImproved = (questionId) => {
    return window.enhancedFeedbackSystem ? window.enhancedFeedbackSystem.hasQuestionBeenImproved(questionId) : false;
};

window.getImprovementStats = () => {
    return window.enhancedFeedbackSystem ? window.enhancedFeedbackSystem.getImprovementStats() : {
        totalImproved: 0,
        improvementsByType: {},
        recentImprovements: [],
        averageConfidence: 0,
        impactScore: 0
    };
};

// Add the missing global function that's causing the error
window.getQuestionImprovementDetails = (questionId) => {
    if (window.enhancedFeedbackSystem && typeof window.enhancedFeedbackSystem.getQuestionImprovementDetails === 'function') {
        return window.enhancedFeedbackSystem.getQuestionImprovementDetails(questionId);
    }
    return null;
};

// Additional utility functions
window.getFeedbackAnalytics = () => {
    return window.enhancedFeedbackSystem ? window.enhancedFeedbackSystem.getAnalytics() : {};
};

window.getImprovementRecommendations = () => {
    if (!window.enhancedFeedbackSystem) return [];
    
    const analytics = window.enhancedFeedbackSystem.getAnalytics();
    const recommendations = [];
    
    // Generate recommendations based on feedback patterns
    if (analytics.feedback && analytics.feedback.length > 0) {
        const negativeCount = analytics.feedback.filter(f => 
            (f.type === 'quality' && f.value === 'poor') ||
            (f.type === 'relevance' && f.value === 'no') ||
            (f.type === 'difficulty' && f.value === 'too_hard')
        ).length;
        
        if (negativeCount > analytics.feedback.length * 0.3) {
            recommendations.push({
                type: 'difficulty',
                suggestion: 'Consider reducing question difficulty',
                confidence: 0.8
            });
        }
    }
    
    return recommendations;
};

console.log('🎯 Enhanced Feedback System loaded and ready!');
/**
 * Enhanced Feedback System for Continuous Improvement
 * Comprehensive feedback loop with intelligent parameter refinement and learning
 */

class EnhancedFeedbackSystem {
    constructor() {
        this.feedbackData = this.loadFeedbackData();
        this.generationHistory = this.loadGenerationHistory();
        this.feedbackPatterns = this.loadFeedbackPatterns();
        this.improvementTracking = this.loadImprovementTracking();
        this.parameterEvolution = this.loadParameterEvolution();
        this.learningModel = this.initializeLearningModel();
        
        // Enhanced feedback weights for better scoring
        this.feedbackWeights = {
            quality: 0.35,
            relevance: 0.30,
            difficulty: 0.20,
            clarity: 0.15
        };
        
        // Improvement thresholds with dynamic adjustment
        this.improvementThresholds = {
            critical: 40,  // Immediate improvement needed
            low: 60,       // Should be improved
            moderate: 75,  // Could be improved
            good: 85       // Performing well
        };
        
        // Learning parameters
        this.learningRate = 0.1;
        this.adaptationSpeed = 0.05;
        this.minimumSamples = 5;
        
        this.initializeSystem();
    }

    /**
     * Initialize the enhanced feedback system
     */
    initializeSystem() {
        this.setupAutomaticLearning();
        this.startContinuousImprovement();
        log('Enhanced Feedback System with Continuous Learning initialized', 'success');
    }

    /**
     * Initialize learning model for pattern recognition
     */
    initializeLearningModel() {
        return {
            difficultyPreferences: {
                easy: { success: 0, total: 0 },
                intermediate: { success: 0, total: 0 },
                advanced: { success: 0, total: 0 }
            },
            questionTypePerformance: {
                'multiple-choice': { score: 0, samples: 0 },
                'short-answer': { score: 0, samples: 0 },
                'clinical-case': { score: 0, samples: 0 },
                'management': { score: 0, samples: 0 }
            },
            subspecialtyEffectiveness: {},
            temporalPatterns: {
                hourly: Array(24).fill(0).map(() => ({ score: 0, count: 0 })),
                daily: Array(7).fill(0).map(() => ({ score: 0, count: 0 })),
                monthly: Array(12).fill(0).map(() => ({ score: 0, count: 0 }))
            },
            userBehaviorPatterns: {
                sessionLength: { optimal: 15, current: 0 },
                questionsPerSession: { optimal: 10, current: 0 },
                improvementRate: 0
            }
        };
    }

    /**
     * Record enhanced feedback with intelligent processing
     */
    recordFeedback(questionId, feedbackType, feedbackValue, metadata = {}) {
        if (!this.feedbackData[questionId]) {
            this.feedbackData[questionId] = {
                id: questionId,
                feedbacks: [],
                totalScore: 0,
                averageScore: 0,
                improvementStatus: 'pending',
                improvementHistory: [],
                firstFeedbackDate: new Date().toISOString(),
                lastFeedbackDate: new Date().toISOString(),
                feedbackCount: 0,
                metadata: metadata
            };
        }

        const questionData = this.feedbackData[questionId];
        
        // Record feedback with enhanced data
        const feedbackEntry = {
            type: feedbackType,
            value: feedbackValue,
            timestamp: new Date().toISOString(),
            sessionId: this.getCurrentSessionId(),
            userContext: this.getCurrentUserContext(),
            questionContext: this.getQuestionContext(questionId),
            numericValue: this.convertToNumericValue(feedbackType, feedbackValue)
        };
        
        questionData.feedbacks.push(feedbackEntry);
        questionData.feedbackCount++;
        questionData.lastFeedbackDate = feedbackEntry.timestamp;
        
        // Update scores and patterns
        this.updateQuestionScores(questionId);
        this.updateLearningModel(feedbackEntry, questionId);
        this.detectFeedbackPatterns(questionId);
        this.evaluateImprovementNeed(questionId);
        
        // Trigger real-time learning
        this.processRealTimeLearning(feedbackEntry, questionId);
        
        this.saveFeedbackData();
        
        log(`Enhanced feedback recorded for ${questionId}: ${feedbackType}=${feedbackValue}`, 'info');
        
        return this.generateFeedbackInsights(questionId);
    }

    /**
     * Convert feedback to numeric value for processing
     */
    convertToNumericValue(feedbackType, feedbackValue) {
        const conversionMap = {
            quality: { good: 100, poor: 20 },
            relevance: { yes: 100, no: 0 },
            difficulty: { easy: 100, appropriate: 80, hard: 40 },
            clarity: { clear: 100, unclear: 30 }
        };
        
        // For star ratings (1-5)
        if (typeof feedbackValue === 'number' && feedbackValue >= 1 && feedbackValue <= 5) {
            return feedbackValue * 20; // Convert to 0-100 scale
        }
        
        return conversionMap[feedbackType]?.[feedbackValue] || 50;
    }

    /**
     * Update question scores with weighted calculation
     */
    updateQuestionScores(questionId) {
        const questionData = this.feedbackData[questionId];
        const feedbacks = questionData.feedbacks;
        
        // Calculate weighted average by feedback type
        const scoresByType = {};
        Object.keys(this.feedbackWeights).forEach(type => {
            const typeFeedbacks = feedbacks.filter(f => f.type === type);
            if (typeFeedbacks.length > 0) {
                scoresByType[type] = typeFeedbacks.reduce((sum, f) => sum + f.numericValue, 0) / typeFeedbacks.length;
            }
        });
        
        // Calculate overall weighted score
        let totalWeightedScore = 0;
        let totalWeight = 0;
        
        Object.keys(scoresByType).forEach(type => {
            const weight = this.feedbackWeights[type];
            totalWeightedScore += scoresByType[type] * weight;
            totalWeight += weight;
        });
        
        questionData.averageScore = totalWeight > 0 ? totalWeightedScore / totalWeight : 0;
        questionData.scoresByType = scoresByType;
        
        // Update improvement status based on score
        this.updateImprovementStatus(questionId);
    }

    /**
     * Update improvement status with intelligent classification
     */
    updateImprovementStatus(questionId) {
        const questionData = this.feedbackData[questionId];
        const score = questionData.averageScore;
        const previousStatus = questionData.improvementStatus;
        
        let newStatus;
        if (score < this.improvementThresholds.critical) {
            newStatus = 'critical';
        } else if (score < this.improvementThresholds.low) {
            newStatus = 'needs-improvement';
        } else if (score < this.improvementThresholds.moderate) {
            newStatus = 'could-improve';
        } else if (score < this.improvementThresholds.good) {
            newStatus = 'good';
        } else {
            newStatus = 'excellent';
        }
        
        // Record status change
        if (newStatus !== previousStatus) {
            questionData.improvementHistory.push({
                timestamp: new Date().toISOString(),
                previousStatus: previousStatus,
                newStatus: newStatus,
                score: score,
                reason: 'feedback-based-update'
            });
            
            questionData.improvementStatus = newStatus;
            
            // Trigger improvement actions for critical cases
            if (newStatus === 'critical') {
                this.triggerImmediateImprovement(questionId);
            }
        }
    }

    /**
     * Update learning model with new feedback
     */
    updateLearningModel(feedbackEntry, questionId) {
        const context = feedbackEntry.questionContext;
        const score = feedbackEntry.numericValue;
        
        // Update difficulty preferences
        if (context.difficulty) {
            const diffData = this.learningModel.difficultyPreferences[context.difficulty];
            if (diffData) {
                diffData.total++;
                if (score >= 70) diffData.success++;
            }
        }
        
        // Update question type performance
        if (context.type) {
            const typeData = this.learningModel.questionTypePerformance[context.type];
            if (typeData) {
                typeData.score = (typeData.score * typeData.samples + score) / (typeData.samples + 1);
                typeData.samples++;
            }
        }
        
        // Update subspecialty effectiveness
        if (context.subspecialty) {
            if (!this.learningModel.subspecialtyEffectiveness[context.subspecialty]) {
                this.learningModel.subspecialtyEffectiveness[context.subspecialty] = { score: 0, samples: 0 };
            }
            const subData = this.learningModel.subspecialtyEffectiveness[context.subspecialty];
            subData.score = (subData.score * subData.samples + score) / (subData.samples + 1);
            subData.samples++;
        }
        
        // Update temporal patterns
        const now = new Date();
        const hour = now.getHours();
        const day = now.getDay();
        const month = now.getMonth();
        
        this.learningModel.temporalPatterns.hourly[hour].score = 
            (this.learningModel.temporalPatterns.hourly[hour].score * this.learningModel.temporalPatterns.hourly[hour].count + score) / 
            (this.learningModel.temporalPatterns.hourly[hour].count + 1);
        this.learningModel.temporalPatterns.hourly[hour].count++;
        
        this.learningModel.temporalPatterns.daily[day].score = 
            (this.learningModel.temporalPatterns.daily[day].score * this.learningModel.temporalPatterns.daily[day].count + score) / 
            (this.learningModel.temporalPatterns.daily[day].count + 1);
        this.learningModel.temporalPatterns.daily[day].count++;
        
        this.learningModel.temporalPatterns.monthly[month].score = 
            (this.learningModel.temporalPatterns.monthly[month].score * this.learningModel.temporalPatterns.monthly[month].count + score) / 
            (this.learningModel.temporalPatterns.monthly[month].count + 1);
        this.learningModel.temporalPatterns.monthly[month].count++;
    }

    /**
     * Record question generation session with comprehensive metadata
     */
    recordGenerationSession(parameters, results, sessionMetadata = {}) {
        const sessionId = this.generateSessionId();
        const timestamp = new Date().toISOString();
        
        const session = {
            id: sessionId,
            timestamp: timestamp,
            parameters: {
                ...parameters,
                userProfile: this.getCurrentUserProfile()
            },
            results: {
                questionsGenerated: results.questions?.length || 0,
                questionIds: results.questions?.map(q => q.id) || [],
                averageConfidence: results.averageConfidence || 0,
                generationTime: results.generationTime || 0,
                errors: results.errors || []
            },
            environment: {
                userAgent: navigator.userAgent,
                timestamp: timestamp,
                sessionLength: sessionMetadata.sessionLength || 0,
                previousSessions: this.generationHistory.length
            },
            feedbackMetrics: {
                expectedPerformance: this.predictSessionPerformance(parameters),
                actualPerformance: null, // Will be updated as feedback comes in
                performanceGap: null
            }
        };
        
        this.generationHistory.push(session);
        
        // Keep only last 100 sessions
        if (this.generationHistory.length > 100) {
            this.generationHistory = this.generationHistory.slice(-100);
        }
        
        this.saveGenerationHistory();
        
        // Schedule performance evaluation
        this.scheduleSessionEvaluation(sessionId);
        
        log(`Generation session recorded: ${sessionId} with ${session.results.questionsGenerated} questions`, 'info');
        
        return sessionId;
    }

    /**
     * Predict session performance based on parameters and historical data
     */
    predictSessionPerformance(parameters) {
        const difficultyData = this.learningModel.difficultyPreferences[parameters.difficulty];
        const typeData = this.learningModel.questionTypePerformance[parameters.questionType];
        const subspecialtyData = this.learningModel.subspecialtyEffectiveness[parameters.subspecialty];
        
        let prediction = 70; // Base prediction
        
        if (difficultyData && difficultyData.total > 0) {
            prediction += (difficultyData.success / difficultyData.total - 0.7) * 30;
        }
        
        if (typeData && typeData.samples > 0) {
            prediction += (typeData.score - 70) * 0.3;
        }
        
        if (subspecialtyData && subspecialtyData.samples > 0) {
            prediction += (subspecialtyData.score - 70) * 0.2;
        }
        
        return Math.max(0, Math.min(100, prediction));
    }

    /**
     * Intelligent parameter refinement based on feedback patterns
     */
    refineGenerationParameters(currentParameters) {
        const refinedParameters = { ...currentParameters };
        const recommendations = [];
        
        // Analyze difficulty effectiveness
        const difficultyAnalysis = this.analyzeDifficultyEffectiveness();
        if (difficultyAnalysis.recommendation !== currentParameters.difficulty) {
            refinedParameters.difficulty = difficultyAnalysis.recommendation;
            recommendations.push({
                type: 'difficulty',
                action: 'adjust',
                from: currentParameters.difficulty,
                to: difficultyAnalysis.recommendation,
                reason: difficultyAnalysis.reason,
                confidence: difficultyAnalysis.confidence
            });
        }
        
        // Analyze question type performance
        const typeAnalysis = this.analyzeQuestionTypePerformance();
        if (typeAnalysis.recommendations.length > 0) {
            typeAnalysis.recommendations.forEach(rec => {
                recommendations.push({
                    type: 'questionType',
                    action: rec.action,
                    target: rec.type,
                    reason: rec.reason,
                    confidence: rec.confidence
                });
            });
        }
        
        // Analyze subspecialty effectiveness
        const subspecialtyAnalysis = this.analyzeSubspecialtyEffectiveness();
        if (subspecialtyAnalysis.recommendation !== currentParameters.subspecialty) {
            refinedParameters.subspecialty = subspecialtyAnalysis.recommendation;
            recommendations.push({
                type: 'subspecialty',
                action: 'adjust',
                from: currentParameters.subspecialty,
                to: subspecialtyAnalysis.recommendation,
                reason: subspecialtyAnalysis.reason,
                confidence: subspecialtyAnalysis.confidence
            });
        }
        
        // Temporal optimization
        const temporalAnalysis = this.analyzeTemporalPatterns();
        if (temporalAnalysis.suggestions.length > 0) {
            recommendations.push(...temporalAnalysis.suggestions);
        }
        
        // Record parameter evolution
        this.recordParameterEvolution(currentParameters, refinedParameters, recommendations);
        
        return {
            parameters: refinedParameters,
            recommendations: recommendations,
            confidence: this.calculateRefinementConfidence(recommendations),
            basedOnSamples: this.getTotalFeedbackSamples()
        };
    }

    /**
     * Analyze difficulty effectiveness
     */
    analyzeDifficultyEffectiveness() {
        const difficulties = Object.keys(this.learningModel.difficultyPreferences);
        let bestDifficulty = null;
        let bestScore = 0;
        let confidence = 0;
        
        difficulties.forEach(difficulty => {
            const data = this.learningModel.difficultyPreferences[difficulty];
            if (data.total >= this.minimumSamples) {
                const successRate = data.success / data.total;
                if (successRate > bestScore) {
                    bestScore = successRate;
                    bestDifficulty = difficulty;
                    confidence = Math.min(0.9, data.total / 20); // Confidence based on sample size
                }
            }
        });
        
        return {
            recommendation: bestDifficulty || 'intermediate',
            reason: `${Math.round(bestScore * 100)}% success rate with ${bestDifficulty} difficulty`,
            confidence: confidence
        };
    }

    /**
     * Analyze question type performance
     */
    analyzeQuestionTypePerformance() {
        const types = Object.keys(this.learningModel.questionTypePerformance);
        const recommendations = [];
        const averageScore = this.calculateAverageTypeScore();
        
        types.forEach(type => {
            const data = this.learningModel.questionTypePerformance[type];
            if (data.samples >= this.minimumSamples) {
                if (data.score < averageScore - 10) {
                    recommendations.push({
                        action: 'reduce',
                        type: type,
                        reason: `Below average performance: ${Math.round(data.score)}% vs ${Math.round(averageScore)}%`,
                        confidence: Math.min(0.8, data.samples / 15)
                    });
                } else if (data.score > averageScore + 10) {
                    recommendations.push({
                        action: 'increase',
                        type: type,
                        reason: `Above average performance: ${Math.round(data.score)}% vs ${Math.round(averageScore)}%`,
                        confidence: Math.min(0.8, data.samples / 15)
                    });
                }
            }
        });
        
        return { recommendations };
    }

    /**
     * Analyze subspecialty effectiveness
     */
    analyzeSubspecialtyEffectiveness() {
        const subspecialties = Object.keys(this.learningModel.subspecialtyEffectiveness);
        let bestSubspecialty = null;
        let bestScore = 0;
        let confidence = 0;
        
        subspecialties.forEach(subspecialty => {
            const data = this.learningModel.subspecialtyEffectiveness[subspecialty];
            if (data.samples >= this.minimumSamples && data.score > bestScore) {
                bestScore = data.score;
                bestSubspecialty = subspecialty;
                confidence = Math.min(0.9, data.samples / 20);
            }
        });
        
        return {
            recommendation: bestSubspecialty || 'general-ophthalmology',
            reason: `Highest performance: ${Math.round(bestScore)}% average score`,
            confidence: confidence
        };
    }

    /**
     * Analyze temporal patterns
     */
    analyzeTemporalPatterns() {
        const suggestions = [];
        
        // Find best hours
        const bestHours = this.learningModel.temporalPatterns.hourly
            .map((data, hour) => ({ hour, score: data.score, count: data.count }))
            .filter(h => h.count >= 3)
            .sort((a, b) => b.score - a.score)
            .slice(0, 3);
        
        if (bestHours.length > 0) {
            suggestions.push({
                type: 'temporal',
                action: 'optimize-timing',
                target: 'hour',
                recommendation: bestHours.map(h => h.hour),
                reason: `Best performance hours: ${bestHours.map(h => `${h.hour}:00 (${Math.round(h.score)}%)`).join(', ')}`,
                confidence: 0.6
            });
        }
        
        return { suggestions };
    }

    /**
     * Record parameter evolution
     */
    recordParameterEvolution(oldParams, newParams, recommendations) {
        const evolution = {
            timestamp: new Date().toISOString(),
            oldParameters: oldParams,
            newParameters: newParams,
            recommendations: recommendations,
            sampleSize: this.getTotalFeedbackSamples(),
            confidence: this.calculateRefinementConfidence(recommendations)
        };
        
        this.parameterEvolution.push(evolution);
        
        // Keep only last 50 evolutions
        if (this.parameterEvolution.length > 50) {
            this.parameterEvolution = this.parameterEvolution.slice(-50);
        }
        
        this.saveParameterEvolution();
    }

    /**
     * Setup automatic learning and adaptation
     */
    setupAutomaticLearning() {
        // Auto-adapt thresholds based on overall performance
        setInterval(() => {
            this.adaptThresholds();
        }, 300000); // Every 5 minutes
        
        // Auto-refine parameters for active users
        setInterval(() => {
            this.autoRefineForActiveUsers();
        }, 900000); // Every 15 minutes
    }

    /**
     * Start continuous improvement processes
     */
    startContinuousImprovement() {
        // Monitor for improvement opportunities
        setInterval(() => {
            this.detectImprovementOpportunities();
        }, 60000); // Every minute
        
        // Update learning model
        setInterval(() => {
            this.updateLearningModelPatterns();
        }, 180000); // Every 3 minutes
    }

    /**
     * Generate comprehensive feedback insights
     */
    generateFeedbackInsights(questionId) {
        const questionData = this.feedbackData[questionId];
        if (!questionData) return null;
        
        const insights = {
            questionId: questionId,
            currentStatus: questionData.improvementStatus,
            score: Math.round(questionData.averageScore),
            feedbackCount: questionData.feedbackCount,
            trends: this.analyzeFeedbackTrends(questionId),
            predictions: this.predictQuestionPerformance(questionId),
            actionRecommendations: this.generateActionRecommendations(questionId),
            improvementHistory: questionData.improvementHistory.slice(-5), // Last 5 changes
            nextSteps: this.generateNextSteps(questionId)
        };
        
        return insights;
    }

    /**
     * Enhanced feedback status display
     */
    getImprovementStatusDisplay(questionId) {
        const questionData = this.feedbackData[questionId];
        if (!questionData) {
            return {
                status: 'unknown',
                display: 'No feedback data',
                color: 'gray',
                icon: 'question',
                details: 'No feedback has been collected for this question yet.'
            };
        }
        
        const status = questionData.improvementStatus;
        const score = Math.round(questionData.averageScore);
        const feedbackCount = questionData.feedbackCount;
        
        const statusMap = {
            'critical': {
                display: `Critical (${score}%)`,
                color: 'red',
                icon: 'exclamation-triangle',
                details: `Requires immediate attention. Based on ${feedbackCount} feedback entries.`
            },
            'needs-improvement': {
                display: `Needs Improvement (${score}%)`,
                color: 'orange',
                icon: 'arrow-up',
                details: `Should be improved. Based on ${feedbackCount} feedback entries.`
            },
            'could-improve': {
                display: `Could Improve (${score}%)`,
                color: 'yellow',
                icon: 'edit',
                details: `Minor improvements possible. Based on ${feedbackCount} feedback entries.`
            },
            'good': {
                display: `Good (${score}%)`,
                color: 'blue',
                icon: 'thumbs-up',
                details: `Performing well. Based on ${feedbackCount} feedback entries.`
            },
            'excellent': {
                display: `Excellent (${score}%)`,
                color: 'green',
                icon: 'star',
                details: `Outstanding performance. Based on ${feedbackCount} feedback entries.`
            }
        };
        
        const statusInfo = statusMap[status] || statusMap['unknown'];
        
        return {
            status: status,
            ...statusInfo,
            lastImprovement: questionData.improvementHistory.length > 0 ? 
                questionData.improvementHistory[questionData.improvementHistory.length - 1] : null
        };
    }

    /**
     * Utility functions
     */
    getCurrentSessionId() {
        if (!this.currentSessionId) {
            this.currentSessionId = this.generateSessionId();
        }
        return this.currentSessionId;
    }
    
    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    getCurrentUserContext() {
        return {
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            screenResolution: `${screen.width}x${screen.height}`,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        };
    }
    
    getQuestionContext(questionId) {
        // Try to extract context from question element in DOM
        const questionElement = document.querySelector(`[data-question-id="${questionId}"]`);
        if (questionElement) {
            return {
                type: questionElement.getAttribute('data-type') || 'unknown',
                source: questionElement.getAttribute('data-source') || 'unknown',
                difficulty: questionElement.getAttribute('data-difficulty') || 'unknown',
                subspecialty: questionElement.getAttribute('data-subspecialty') || 'unknown'
            };
        }
        return {};
    }
    
    getCurrentUserProfile() {
        return {
            totalSessions: this.generationHistory.length,
            averageFeedbackScore: this.calculateUserAverageFeedbackScore(),
            preferredDifficulty: this.getUserPreferredDifficulty(),
            activeTime: this.calculateActiveTime()
        };
    }
    
    calculateUserAverageFeedbackScore() {
        const allScores = Object.values(this.feedbackData)
            .map(q => q.averageScore)
            .filter(score => score > 0);
        
        return allScores.length > 0 ? allScores.reduce((sum, score) => sum + score, 0) / allScores.length : 0;
    }
    
    getUserPreferredDifficulty() {
        const difficulties = Object.keys(this.learningModel.difficultyPreferences);
        let bestDifficulty = 'intermediate';
        let bestScore = 0;
        
        difficulties.forEach(difficulty => {
            const data = this.learningModel.difficultyPreferences[difficulty];
            if (data.total > 0) {
                const score = data.success / data.total;
                if (score > bestScore) {
                    bestScore = score;
                    bestDifficulty = difficulty;
                }
            }
        });
        
        return bestDifficulty;
    }
    
    calculateActiveTime() {
        if (this.generationHistory.length < 2) return 0;
        
        const firstSession = new Date(this.generationHistory[0].timestamp);
        const lastSession = new Date(this.generationHistory[this.generationHistory.length - 1].timestamp);
        
        return Math.round((lastSession - firstSession) / (1000 * 60 * 60 * 24)); // Days
    }
    
    calculateAverageTypeScore() {
        const types = Object.values(this.learningModel.questionTypePerformance);
        const validTypes = types.filter(t => t.samples > 0);
        
        return validTypes.length > 0 ? 
            validTypes.reduce((sum, t) => sum + t.score, 0) / validTypes.length : 70;
    }
    
    calculateRefinementConfidence(recommendations) {
        if (recommendations.length === 0) return 0;
        
        const totalConfidence = recommendations.reduce((sum, rec) => sum + (rec.confidence || 0.5), 0);
        return totalConfidence / recommendations.length;
    }
    
    getTotalFeedbackSamples() {
        return Object.values(this.feedbackData).reduce((sum, q) => sum + q.feedbackCount, 0);
    }

    /**
     * Storage methods
     */
    loadFeedbackData() {
        try {
            return JSON.parse(localStorage.getItem('enhancedFeedbackData') || '{}');
        } catch (error) {
            log('Error loading feedback data', 'warning');
            return {};
        }
    }

    loadGenerationHistory() {
        try {
            return JSON.parse(localStorage.getItem('generationHistory') || '[]');
        } catch (error) {
            return [];
        }
    }

    loadFeedbackPatterns() {
        try {
            return JSON.parse(localStorage.getItem('feedbackPatterns') || '{}');
        } catch (error) {
            return {};
        }
    }

    loadImprovementTracking() {
        try {
            return JSON.parse(localStorage.getItem('improvementTracking') || '{}');
        } catch (error) {
            return {};
        }
    }

    loadParameterEvolution() {
        try {
            return JSON.parse(localStorage.getItem('parameterEvolution') || '[]');
        } catch (error) {
            return [];
        }
    }

    saveFeedbackData() {
        try {
            localStorage.setItem('enhancedFeedbackData', JSON.stringify(this.feedbackData));
        } catch (error) {
            log('Error saving feedback data', 'error');
        }
    }

    saveGenerationHistory() {
        try {
            localStorage.setItem('generationHistory', JSON.stringify(this.generationHistory));
        } catch (error) {
            log('Error saving generation history', 'error');
        }
    }

    saveFeedbackPatterns() {
        try {
            localStorage.setItem('feedbackPatterns', JSON.stringify(this.feedbackPatterns));
        } catch (error) {
            log('Error saving feedback patterns', 'error');
        }
    }

    saveImprovementTracking() {
        try {
            localStorage.setItem('improvementTracking', JSON.stringify(this.improvementTracking));
        } catch (error) {
            log('Error saving improvement tracking', 'error');
        }
    }

    saveParameterEvolution() {
        try {
            localStorage.setItem('parameterEvolution', JSON.stringify(this.parameterEvolution));
        } catch (error) {
            log('Error saving parameter evolution', 'error');
        }
    }

    /**
     * Clear all data
     */
    clearAllData() {
        this.feedbackData = {};
        this.generationHistory = [];
        this.feedbackPatterns = {};
        this.improvementTracking = {};
        this.parameterEvolution = [];
        this.learningModel = this.initializeLearningModel();
        
        localStorage.removeItem('enhancedFeedbackData');
        localStorage.removeItem('generationHistory');
        localStorage.removeItem('feedbackPatterns');
        localStorage.removeItem('improvementTracking');
        localStorage.removeItem('parameterEvolution');
        
        log('All feedback data cleared', 'warning');
    }

    // Placeholder methods for missing functionality (to be implemented)
    analyzeFeedbackTrends(questionId) { return { trend: 'stable' }; }
    predictQuestionPerformance(questionId) { return { prediction: 'stable' }; }
    generateActionRecommendations(questionId) { return []; }
    generateNextSteps(questionId) { return []; }
    scheduleSessionEvaluation(sessionId) { }
    triggerImmediateImprovement(questionId) { }
    detectFeedbackPatterns(questionId) { }
    evaluateImprovementNeed(questionId) { }
    processRealTimeLearning(feedbackEntry, questionId) { }
    adaptThresholds() { }
    autoRefineForActiveUsers() { }
    detectImprovementOpportunities() { }
    updateLearningModelPatterns() { }
}

// Global instance
window.enhancedFeedbackSystem = new EnhancedFeedbackSystem();

// Global helper functions
window.recordFeedback = function(questionId, feedbackType, feedbackValue, metadata = {}) {
    return window.enhancedFeedbackSystem.recordFeedback(questionId, feedbackType, feedbackValue, metadata);
};

window.recordGenerationSession = function(parameters, results, sessionMetadata = {}) {
    return window.enhancedFeedbackSystem.recordGenerationSession(parameters, results, sessionMetadata);
};

window.refineGenerationParameters = function(currentParameters) {
    return window.enhancedFeedbackSystem.refineGenerationParameters(currentParameters);
};

window.getImprovementStatusDisplay = function(questionId) {
    return window.enhancedFeedbackSystem.getImprovementStatusDisplay(questionId);
};

window.getFeedbackInsights = function(questionId) {
    return window.enhancedFeedbackSystem.generateFeedbackInsights(questionId);
};

window.getFeedbackAnalytics = function() {
    const system = window.enhancedFeedbackSystem;
    const data = Object.values(system.feedbackData);
    
    return {
        totalFeedback: data.reduce((sum, q) => sum + q.feedbackCount, 0),
        totalQuestions: data.length,
        averageScore: data.length > 0 ? data.reduce((sum, q) => sum + q.averageScore, 0) / data.length : 0,
        improved: data.filter(q => q.improvementHistory.length > 0).length,
        generationSessions: system.generationHistory.length,
        parameterEvolutions: system.parameterEvolution.length
    };
}; 
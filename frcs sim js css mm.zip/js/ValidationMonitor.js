/**
 * Validation Monitoring System
 * Monitors accuracy validation results and provides comprehensive analytics
 */

class ValidationMonitor {
    constructor() {
        this.monitoringData = this.loadMonitoringData();
        this.validationSystem = null;
        this.validationUI = null;
        this.monitoringInterval = null;
        this.alertThresholds = {
            lowAccuracy: 0.6,
            lowConfidence: 0.5,
            highFailureRate: 0.3
        };
        
        // Delay initialization to allow other systems to load
        this.initializationTimeout = setTimeout(() => {
            this.initializeMonitoring();
        }, 2000);
    }

    /**
     * Initialize monitoring system
     */
    initializeMonitoring() {
        // Try to get references to validation systems
        this.validationSystem = window.medicalValidationSystem || window.validationSystem;
        this.validationUI = window.validationUI;
        
        // Create fallback validationUI if it doesn't exist
        if (!this.validationUI) {
            this.validationUI = {
                getUserRatingAnalytics: () => ({
                    totalRatings: 0,
                    averageRatings: {},
                    ratingDistribution: {}
                })
            };
            console.warn('ValidationMonitor: Created fallback validationUI');
        }
        
        this.startContinuousMonitoring();
        this.setupPerformanceTracking();
        log('Validation monitoring system initialized', 'success');
    }

    /**
     * Start continuous monitoring
     */
    startContinuousMonitoring() {
        // Monitor every 30 seconds
        this.monitoringInterval = setInterval(() => {
            this.collectMetrics();
            this.checkAlertConditions();
        }, 30000);
        
        // Initial collection
        this.collectMetrics();
    }

    /**
     * Stop monitoring
     */
    stopMonitoring() {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
    }

    /**
     * Collect current metrics
     */
    collectMetrics() {
        try {
            const timestamp = new Date().toISOString();
            
            // Safely get validation analytics
            let validationAnalytics = {};
            try {
                if (this.validationSystem && typeof this.validationSystem.getValidationAnalytics === 'function') {
                    validationAnalytics = this.validationSystem.getValidationAnalytics() || {};
                }
            } catch (error) {
                console.warn('Error getting validation analytics:', error);
                validationAnalytics = {};
            }
            
            // Safely get user rating analytics
            let userRatingAnalytics = {};
            try {
                if (this.validationUI && typeof this.validationUI.getUserRatingAnalytics === 'function') {
                    userRatingAnalytics = this.validationUI.getUserRatingAnalytics() || {};
                } else {
                    // Fallback: try to get global ValidationUI instance
                    if (window.validationUI && typeof window.validationUI.getUserRatingAnalytics === 'function') {
                        userRatingAnalytics = window.validationUI.getUserRatingAnalytics() || {};
                    } else {
                        // Default empty analytics
                        userRatingAnalytics = {
                            totalRatings: 0,
                            averageRatings: {},
                            ratingDistribution: {}
                        };
                    }
                }
            } catch (error) {
                console.warn('Error getting user rating analytics:', error);
                userRatingAnalytics = {
                    totalRatings: 0,
                    averageRatings: {},
                    ratingDistribution: {}
                };
            }
            
            const metrics = {
                timestamp: timestamp,
                validation: {
                    totalValidations: validationAnalytics.totalValidations || 0,
                    averageScore: validationAnalytics.averageScore || 0,
                    averageConfidence: validationAnalytics.averageConfidence || 0,
                    highQualityCount: validationAnalytics.highQualityCount || 0,
                    lowQualityCount: validationAnalytics.lowQualityCount || 0,
                    totalCitations: validationAnalytics.totalCitations || 0,
                    sourceBreakdown: validationAnalytics.sourceBreakdown || {}
                },
                userRatings: {
                    totalRatings: userRatingAnalytics.totalRatings || 0,
                    averageRatings: userRatingAnalytics.averageRatings || {},
                    ratingDistribution: userRatingAnalytics.ratingDistribution || {}
                },
                system: {
                    memoryUsage: this.getMemoryUsage(),
                    cacheSize: this.getCacheSize(),
                    errorRate: this.calculateErrorRate()
                }
            };
            
            this.storeMetrics(metrics);
            return metrics;
        } catch (error) {
            console.error('Error collecting metrics:', error);
            // Return minimal metrics in case of error
            return {
                timestamp: new Date().toISOString(),
                validation: {
                    totalValidations: 0,
                    averageScore: 0,
                    averageConfidence: 0,
                    highQualityCount: 0,
                    lowQualityCount: 0,
                    totalCitations: 0,
                    sourceBreakdown: {}
                },
                userRatings: {
                    totalRatings: 0,
                    averageRatings: {},
                    ratingDistribution: {}
                },
                system: {
                    memoryUsage: 0,
                    cacheSize: 0,
                    errorRate: 0
                }
            };
        }
    }

    /**
     * Store metrics data
     */
    storeMetrics(metrics) {
        // Keep only last 100 metric entries
        if (this.monitoringData.metrics.length >= 100) {
            this.monitoringData.metrics = this.monitoringData.metrics.slice(-99);
        }
        
        this.monitoringData.metrics.push(metrics);
        this.monitoringData.lastUpdated = metrics.timestamp;
        
        this.saveMonitoringData();
    }

    /**
     * Check alert conditions
     */
    checkAlertConditions() {
        const latestMetrics = this.getLatestMetrics();
        if (!latestMetrics) return;
        
        const alerts = [];
        
        // Check accuracy thresholds
        if (latestMetrics.validation.averageScore < this.alertThresholds.lowAccuracy) {
            alerts.push({
                type: 'warning',
                category: 'accuracy',
                message: `Low average validation score: ${(latestMetrics.validation.averageScore * 100).toFixed(1)}%`,
                threshold: this.alertThresholds.lowAccuracy,
                value: latestMetrics.validation.averageScore,
                timestamp: latestMetrics.timestamp
            });
        }
        
        // Check confidence thresholds
        if (latestMetrics.validation.averageConfidence < this.alertThresholds.lowConfidence) {
            alerts.push({
                type: 'warning',
                category: 'confidence',
                message: `Low average confidence score: ${(latestMetrics.validation.averageConfidence * 100).toFixed(1)}%`,
                threshold: this.alertThresholds.lowConfidence,
                value: latestMetrics.validation.averageConfidence,
                timestamp: latestMetrics.timestamp
            });
        }
        
        // Check failure rate
        const totalValidations = latestMetrics.validation.totalValidations;
        const lowQualityCount = latestMetrics.validation.lowQualityCount;
        const failureRate = totalValidations > 0 ? lowQualityCount / totalValidations : 0;
        
        if (failureRate > this.alertThresholds.highFailureRate) {
            alerts.push({
                type: 'error',
                category: 'failure_rate',
                message: `High failure rate: ${(failureRate * 100).toFixed(1)}% of validations are low quality`,
                threshold: this.alertThresholds.highFailureRate,
                value: failureRate,
                timestamp: latestMetrics.timestamp
            });
        }
        
        // Store and process alerts
        if (alerts.length > 0) {
            this.processAlerts(alerts);
        }
    }

    /**
     * Process alerts
     */
    processAlerts(alerts) {
        alerts.forEach(alert => {
            // Store alert
            this.monitoringData.alerts.push(alert);
            
            // Log alert
            log(`Validation Alert: ${alert.message}`, alert.type === 'error' ? 'error' : 'warning');
            
            // Show user notification if needed
            if (alert.type === 'error') {
                this.showUserAlert(alert);
            }
        });
        
        // Keep only last 50 alerts
        if (this.monitoringData.alerts.length > 50) {
            this.monitoringData.alerts = this.monitoringData.alerts.slice(-50);
        }
        
        this.saveMonitoringData();
    }

    /**
     * Show user alert
     */
    showUserAlert(alert) {
        // Create alert notification
        const alertDiv = document.createElement('div');
        alertDiv.className = 'validation-alert';
        alertDiv.innerHTML = `
            <div class="alert alert-${alert.type === 'error' ? 'danger' : 'warning'} alert-dismissible" 
                 style="position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;">
                <strong>Validation System Alert:</strong><br>
                ${alert.message}
                <button type="button" class="btn-close" onclick="this.parentElement.parentElement.remove()"></button>
            </div>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (alertDiv.parentElement) {
                alertDiv.remove();
            }
        }, 10000);
    }

    /**
     * Setup performance tracking
     */
    setupPerformanceTracking() {
        // Track validation performance
        const originalValidate = this.validationSystem?.validateQuestionAnswer;
        if (originalValidate) {
            this.validationSystem.validateQuestionAnswer = async (...args) => {
                const startTime = performance.now();
                
                try {
                    const result = await originalValidate.apply(this.validationSystem, args);
                    const endTime = performance.now();
                    
                    this.recordPerformanceMetric('validation', endTime - startTime, true);
                    return result;
                } catch (error) {
                    const endTime = performance.now();
                    this.recordPerformanceMetric('validation', endTime - startTime, false);
                    throw error;
                }
            };
        }
    }

    /**
     * Record performance metric
     */
    recordPerformanceMetric(operation, duration, success) {
        if (!this.monitoringData.performance[operation]) {
            this.monitoringData.performance[operation] = {
                totalCalls: 0,
                successCalls: 0,
                totalDuration: 0,
                averageDuration: 0,
                minDuration: Infinity,
                maxDuration: 0
            };
        }
        
        const perf = this.monitoringData.performance[operation];
        perf.totalCalls++;
        if (success) perf.successCalls++;
        
        perf.totalDuration += duration;
        perf.averageDuration = perf.totalDuration / perf.totalCalls;
        perf.minDuration = Math.min(perf.minDuration, duration);
        perf.maxDuration = Math.max(perf.maxDuration, duration);
        
        this.saveMonitoringData();
    }

    /**
     * Get system memory usage (approximate)
     */
    getMemoryUsage() {
        try {
            if (performance.memory) {
                return {
                    used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024),
                    total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024),
                    limit: Math.round(performance.memory.jsHeapSizeLimit / 1024 / 1024)
                };
            }
        } catch (error) {
            // Memory API not available
        }
        return null;
    }

    /**
     * Get cache size
     */
    getCacheSize() {
        try {
            const validationCache = localStorage.getItem('medicalValidationCache');
            const userRatings = localStorage.getItem('userQuestionRatings');
            const monitoringData = localStorage.getItem('validationMonitoringData');
            
            const totalSize = (validationCache?.length || 0) + 
                            (userRatings?.length || 0) + 
                            (monitoringData?.length || 0);
            
            return Math.round(totalSize / 1024); // KB
        } catch (error) {
            return 0;
        }
    }

    /**
     * Calculate error rate
     */
    calculateErrorRate() {
        const recentMetrics = this.getRecentMetrics(10); // Last 10 metrics
        if (recentMetrics.length === 0) return 0;
        
        let totalValidations = 0;
        let failedValidations = 0;
        
        recentMetrics.forEach(metric => {
            const total = metric.validation.totalValidations;
            const failed = metric.validation.lowQualityCount;
            totalValidations += total;
            failedValidations += failed;
        });
        
        return totalValidations > 0 ? failedValidations / totalValidations : 0;
    }

    /**
     * Get latest metrics
     */
    getLatestMetrics() {
        return this.monitoringData.metrics[this.monitoringData.metrics.length - 1] || null;
    }

    /**
     * Get recent metrics
     */
    getRecentMetrics(count = 10) {
        return this.monitoringData.metrics.slice(-count);
    }

    /**
     * Generate monitoring report
     */
    generateMonitoringReport() {
        const latestMetrics = this.getLatestMetrics();
        const recentAlerts = this.monitoringData.alerts.slice(-10);
        const performance = this.monitoringData.performance;
        
        return {
            summary: {
                totalValidations: latestMetrics?.validation.totalValidations || 0,
                averageAccuracy: latestMetrics?.validation.averageScore || 0,
                averageConfidence: latestMetrics?.validation.averageConfidence || 0,
                totalUserRatings: latestMetrics?.userRatings.totalRatings || 0,
                activeAlerts: recentAlerts.filter(a => 
                    new Date(a.timestamp).getTime() > Date.now() - 24 * 60 * 60 * 1000
                ).length
            },
            trends: this.calculateTrends(),
            alerts: recentAlerts,
            performance: performance,
            recommendations: this.generateRecommendations()
        };
    }

    /**
     * Calculate trends
     */
    calculateTrends() {
        const recentMetrics = this.getRecentMetrics(20);
        if (recentMetrics.length < 2) return {};
        
        const firstHalf = recentMetrics.slice(0, Math.floor(recentMetrics.length / 2));
        const secondHalf = recentMetrics.slice(Math.floor(recentMetrics.length / 2));
        
        const avgFirst = (metrics) => {
            const sum = metrics.reduce((acc, m) => acc + (m.validation.averageScore || 0), 0);
            return sum / metrics.length;
        };
        
        const firstAvg = avgFirst(firstHalf);
        const secondAvg = avgFirst(secondHalf);
        
        return {
            accuracy: {
                trend: secondAvg > firstAvg ? 'improving' : 'declining',
                change: Math.abs(secondAvg - firstAvg),
                current: secondAvg
            }
        };
    }

    /**
     * Generate recommendations
     */
    generateRecommendations() {
        const recommendations = [];
        const latestMetrics = this.getLatestMetrics();
        const recentAlerts = this.monitoringData.alerts.slice(-5);
        
        if (!latestMetrics) return recommendations;
        
        // Accuracy recommendations
        if (latestMetrics.validation.averageScore < 0.7) {
            recommendations.push({
                type: 'accuracy',
                priority: 'high',
                message: 'Consider reviewing question sources and validation criteria',
                action: 'review_sources'
            });
        }
        
        // Confidence recommendations
        if (latestMetrics.validation.averageConfidence < 0.6) {
            recommendations.push({
                type: 'confidence',
                priority: 'medium',
                message: 'Validation confidence is low - consider adding more data sources',
                action: 'add_sources'
            });
        }
        
        // User engagement recommendations
        if (latestMetrics.userRatings.totalRatings < latestMetrics.validation.totalValidations * 0.1) {
            recommendations.push({
                type: 'engagement',
                priority: 'low',
                message: 'Low user rating participation - consider improving rating UI',
                action: 'improve_ui'
            });
        }
        
        // Performance recommendations
        const validationPerf = this.monitoringData.performance.validation;
        if (validationPerf && validationPerf.averageDuration > 5000) {
            recommendations.push({
                type: 'performance',
                priority: 'medium',
                message: 'Validation taking too long - consider optimizing or caching',
                action: 'optimize_performance'
            });
        }
        
        return recommendations;
    }

    /**
     * Create monitoring dashboard
     */
    createMonitoringDashboard() {
        const report = this.generateMonitoringReport();
        
        // Add dashboard styles if not already present
        this.addDashboardStyles();
        
        return `
            <div class="monitoring-dashboard">
                <h3>Validation System Monitor</h3>
                
                <div class="dashboard-summary">
                    <div class="metric-card">
                        <h4>Total Validations</h4>
                        <div class="metric-value">${report.summary.totalValidations}</div>
                    </div>
                    <div class="metric-card">
                        <h4>Average Accuracy</h4>
                        <div class="metric-value">${(report.summary.averageAccuracy * 100).toFixed(1)}%</div>
                    </div>
                    <div class="metric-card">
                        <h4>Average Confidence</h4>
                        <div class="metric-value">${(report.summary.averageConfidence * 100).toFixed(1)}%</div>
                    </div>
                    <div class="metric-card">
                        <h4>User Ratings</h4>
                        <div class="metric-value">${report.summary.totalUserRatings}</div>
                    </div>
                </div>
                
                <div class="dashboard-alerts">
                    <h4>Recent Alerts (${report.alerts.length})</h4>
                    ${this.renderAlerts(report.alerts)}
                </div>
                
                <div class="dashboard-recommendations">
                    <h4>Recommendations</h4>
                    ${this.renderRecommendations(report.recommendations)}
                </div>
            </div>
        `;
    }

    /**
     * Render alerts
     */
    renderAlerts(alerts) {
        if (alerts.length === 0) {
            return '<div class="no-alerts">No recent alerts</div>';
        }
        
        return alerts.map(alert => `
            <div class="alert-item alert-${alert.type}">
                <div class="alert-message">${alert.message}</div>
                <div class="alert-time">${new Date(alert.timestamp).toLocaleString()}</div>
            </div>
        `).join('');
    }

    /**
     * Render recommendations
     */
    renderRecommendations(recommendations) {
        if (recommendations.length === 0) {
            return '<div class="no-recommendations">System running optimally</div>';
        }
        
        return recommendations.map(rec => `
            <div class="recommendation-item priority-${rec.priority}">
                <div class="recommendation-message">${rec.message}</div>
                <div class="recommendation-type">${rec.type.toUpperCase()}</div>
            </div>
        `).join('');
    }

    /**
     * Add dashboard styles
     */
    addDashboardStyles() {
        if (document.getElementById('validation-monitor-styles')) return;
        
        const styles = `
            <style id="validation-monitor-styles">
                .monitoring-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    z-index: 10000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .modal-backdrop {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    backdrop-filter: blur(4px);
                }
                
                .modal-content {
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                    width: 90vw;
                    max-width: 900px;
                    max-height: 90vh;
                    overflow: auto;
                    position: relative;
                    z-index: 1;
                }
                
                .monitoring-dashboard {
                    padding: 24px;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                }
                
                .monitoring-dashboard h3 {
                    margin: 0 0 24px 0;
                    color: #1f2937;
                    font-size: 24px;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                
                .monitoring-dashboard h3::before {
                    content: "📊";
                    font-size: 28px;
                }
                
                .dashboard-summary {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 16px;
                    margin-bottom: 24px;
                }
                
                .metric-card {
                    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    padding: 20px;
                    text-align: center;
                    transition: transform 0.2s ease, box-shadow 0.2s ease;
                }
                
                .metric-card:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
                }
                
                .metric-card h4 {
                    margin: 0 0 8px 0;
                    color: #64748b;
                    font-size: 14px;
                    font-weight: 500;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
                
                .metric-value {
                    font-size: 32px;
                    font-weight: 700;
                    color: #1e293b;
                    margin: 0;
                }
                
                .dashboard-alerts, .dashboard-recommendations {
                    background: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    padding: 20px;
                    margin-bottom: 20px;
                }
                
                .dashboard-alerts h4, .dashboard-recommendations h4 {
                    margin: 0 0 16px 0;
                    color: #1e293b;
                    font-size: 18px;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                
                .alert-item {
                    background: white;
                    border-radius: 6px;
                    padding: 12px;
                    margin-bottom: 8px;
                    border-left: 4px solid #e5e7eb;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                }
                
                .alert-item.alert-warning {
                    border-left-color: #f59e0b;
                    background: #fffbeb;
                }
                
                .alert-item.alert-error {
                    border-left-color: #ef4444;
                    background: #fef2f2;
                }
                
                .alert-message {
                    font-weight: 500;
                    color: #374151;
                    margin-bottom: 4px;
                }
                
                .alert-time {
                    font-size: 12px;
                    color: #6b7280;
                }
                
                .recommendation-item {
                    background: white;
                    border-radius: 6px;
                    padding: 12px;
                    margin-bottom: 8px;
                    border-left: 4px solid #e5e7eb;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .recommendation-item.priority-high {
                    border-left-color: #ef4444;
                    background: #fef2f2;
                }
                
                .recommendation-item.priority-medium {
                    border-left-color: #f59e0b;
                    background: #fffbeb;
                }
                
                .recommendation-item.priority-low {
                    border-left-color: #10b981;
                    background: #f0fdf4;
                }
                
                .recommendation-message {
                    color: #374151;
                    font-weight: 500;
                    flex: 1;
                }
                
                .recommendation-type {
                    font-size: 11px;
                    font-weight: 600;
                    color: #6b7280;
                    background: #f3f4f6;
                    padding: 4px 8px;
                    border-radius: 12px;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
                
                .no-alerts, .no-recommendations {
                    text-align: center;
                    color: #10b981;
                    font-weight: 500;
                    padding: 20px;
                    background: #f0fdf4;
                    border-radius: 6px;
                    border: 1px solid #bbf7d0;
                }
                
                .modal-actions {
                    display: flex;
                    justify-content: flex-end;
                    gap: 12px;
                    padding: 20px 24px;
                    border-top: 1px solid #e5e7eb;
                    background: #f9fafb;
                    border-radius: 0 0 12px 12px;
                }
                
                .btn {
                    padding: 8px 16px;
                    border-radius: 6px;
                    border: none;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    font-size: 14px;
                }
                
                .btn-primary {
                    background: #3b82f6;
                    color: white;
                }
                
                .btn-primary:hover {
                    background: #2563eb;
                    transform: translateY(-1px);
                    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
                }
                
                .btn-secondary {
                    background: #f3f4f6;
                    color: #374151;
                    border: 1px solid #d1d5db;
                }
                
                .btn-secondary:hover {
                    background: #e5e7eb;
                    transform: translateY(-1px);
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
                }
            </style>
        `;
        
        document.head.insertAdjacentHTML('beforeend', styles);
    }

    /**
     * Storage methods
     */
    loadMonitoringData() {
        try {
            const data = JSON.parse(localStorage.getItem('validationMonitoringData') || '{}');
            return {
                metrics: data.metrics || [],
                alerts: data.alerts || [],
                performance: data.performance || {},
                lastUpdated: data.lastUpdated || null
            };
        } catch (error) {
            log('Error loading monitoring data', 'warning');
            return {
                metrics: [],
                alerts: [],
                performance: {},
                lastUpdated: null
            };
        }
    }

    saveMonitoringData() {
        try {
            localStorage.setItem('validationMonitoringData', JSON.stringify(this.monitoringData));
        } catch (error) {
            log('Error saving monitoring data', 'error');
        }
    }

    /**
     * Clear monitoring data
     */
    clearMonitoringData() {
        this.monitoringData = {
            metrics: [],
            alerts: [],
            performance: {},
            lastUpdated: null
        };
        localStorage.removeItem('validationMonitoringData');
        log('Monitoring data cleared', 'warning');
    }

    /**
     * Export monitoring data
     */
    exportMonitoringData() {
        const data = {
            monitoringData: this.monitoringData,
            report: this.generateMonitoringReport(),
            exportDate: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `validation-monitoring-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
        log('Monitoring data exported', 'success');
    }
}

// Delayed global instance initialization
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit longer for all systems to load
    setTimeout(() => {
        if (!window.validationMonitor) {
            window.validationMonitor = new ValidationMonitor();
        }
    }, 3000);
});

// Global helper functions
window.getMonitoringReport = function() {
    if (!window.validationMonitor) return null;
    return window.validationMonitor.generateMonitoringReport();
};

window.showMonitoringDashboard = function() {
    if (!window.validationMonitor) {
        console.warn('ValidationMonitor not initialized yet');
        return;
    }
    
    const dashboard = window.validationMonitor.createMonitoringDashboard();
    
    // Create modal to show dashboard
    const modal = document.createElement('div');
    modal.className = 'monitoring-modal';
    modal.innerHTML = `
        <div class="modal-backdrop" onclick="this.parentElement.remove()"></div>
        <div class="modal-content">
            ${dashboard}
            <div class="modal-actions">
                <button onclick="window.validationMonitor?.exportMonitoringData()" class="btn btn-primary">
                    Export Data
                </button>
                <button onclick="this.closest('.monitoring-modal').remove()" class="btn btn-secondary">
                    Close
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}; 
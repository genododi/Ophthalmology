class FileHandler {
    constructor() {
        this.currentPdfFile = null;
        this.extractedPdfText = null;
        this.fileInput = document.getElementById('pdf-upload');
        this.fileDropArea = document.getElementById('file-drop-area');
        this.fileInfo = document.getElementById('file-info');
        this.fileNameElement = document.getElementById('file-name');
        this.fileProcessingStatus = document.getElementById('file-processing-status');
        this.progressBarContainer = document.getElementById('progress-bar-container');
        this.progressBar = document.getElementById('progress-bar');
        
        // Current selected subspecialty for smart content extraction
        this.currentSubspecialty = null;
        
        // Map of subspecialties to their keywords for smart filtering
        this.subspecialtyKeywords = {
            'retinal-disorders': ['retina', 'macula', 'vitreous', 'AMD', 'PVD', 'retinal detachment', 'diabetic retinopathy', 'VEGF', 'OCT', 'FAF', 'angiography'],
            'corneal-diseases': ['cornea', 'keratoconus', 'dystrophy', 'keratitis', 'transplant', 'DALK', 'DSEK', 'DMEK', 'PKP', 'LASIK', 'PRK'],
            'glaucoma': ['glaucoma', 'IOP', 'trabeculectomy', 'POAG', 'PACG', 'angle', 'optic nerve', 'visual field', 'OCT', 'RNFL', 'medication', 'drops', 'SLT'],
            'cataract': ['cataract', 'lens', 'phaco', 'IOL', 'capsule', 'phacoemulsification', 'presbyopia', 'multifocal'],
            'refractive-errors': ['myopia', 'hyperopia', 'astigmatism', 'presbyopia', 'LASIK', 'PRK', 'SMILE', 'refractive', 'correction'],
            'neuro-ophthalmology': ['optic nerve', 'optic neuropathy', 'papilledema', 'visual field', 'pupil', 'RAPD', 'cranial nerve', 'palsy', 'diplopia', 'neuritis'],
            'ocular-inflammation': ['uveitis', 'scleritis', 'inflammation', 'iritis', 'immunosuppression', 'steroid', 'immunomodulatory', 'keratouveitis'],
            'pediatric': ['pediatric', 'strabismus', 'amblyopia', 'retinopathy of prematurity', 'ROP', 'congenital', 'children', 'infantile'],
            'oculoplastics-oncology': ['oculoplastic', 'orbit', 'eyelid', 'ptosis', 'dermatochalasis', 'tumor', 'cancer', 'lacrimation', 'dacryocystitis']
        };
        
        // Bind method to ensure 'this' context is preserved when used as event handler
        this.preventDefaults = this.preventDefaults.bind(this);
        this.handleDrop = this.handleDrop.bind(this);
        this.handleFileSelection = this.handleFileSelection.bind(this);
    }

    initializeFileHandling() {
        // Make the drop area clickable to trigger file input
        this.fileDropArea.addEventListener('click', () => this.fileInput.click());
        
        // Handle file selection through the input field
        this.fileInput.addEventListener('change', this.handleFileSelection);

        // Prevent default browser behavior for drag events
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            this.fileDropArea.addEventListener(eventName, this.preventDefaults, false);
            document.body.addEventListener(eventName, this.preventDefaults, false);
        });

        // Highlight drop area when file is dragged over it
        ['dragenter', 'dragover'].forEach(eventName => {
            this.fileDropArea.addEventListener(eventName, () => {
                this.fileDropArea.classList.add('drag-over');
            }, false);
        });

        // Remove highlight when file is dragged away or dropped
        ['dragleave', 'drop'].forEach(eventName => {
            this.fileDropArea.addEventListener(eventName, () => {
                this.fileDropArea.classList.remove('drag-over');
            }, false);
        });

        // Handle file drop
        this.fileDropArea.addEventListener('drop', this.handleDrop, false);
        
        // Connect to clear button if present
        const clearBtn = document.getElementById('clear-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearFileInput());
        }
        
        // Listen for subspecialty changes to update our filter
        const knowledgeAreaSelect = document.getElementById('knowledge-area');
        if (knowledgeAreaSelect) {
            knowledgeAreaSelect.addEventListener('change', (e) => {
                this.currentSubspecialty = e.target.value;
                console.log(`Subspecialty changed to: ${this.currentSubspecialty}`);
                
                // If we already have a file loaded, we could re-extract with the new filter
                // but that might be confusing to users, so we'll just log a message
                if (this.currentPdfFile) {
                    console.log("PDF already loaded. New subspecialty filter will apply on next generation.");
                }
            });
            // Set initial value
            this.currentSubspecialty = knowledgeAreaSelect.value;
        }
    }

    preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            // Directly use the file from the drop event
            console.log('File dropped:', files[0].name, 'Size:', (files[0].size / 1024 / 1024).toFixed(2) + 'MB', 'Type:', files[0].type);
            this.handleFileFromDrop(files[0]);
        }
    }
    
    handleFileFromDrop(file) {
        this.resetProgress();
        this.extractedPdfText = null;
        
        if (!this.validateFile(file)) {
            return;
        }
        
        this.currentPdfFile = file;
        this.fileNameElement.textContent = `File: ${file.name}`;
        this.fileInfo.classList.remove('hidden');
        this.processFile(file);
    }

    handleFileSelection() {
        this.resetProgress();
        this.extractedPdfText = null;

        if (this.fileInput.files.length > 0) {
            const file = this.fileInput.files[0];
            console.log('File selected:', file.name, 'Size:', (file.size / 1024 / 1024).toFixed(2) + 'MB', 'Type:', file.type);
            if (!this.validateFile(file)) {
                return;
            }

            this.currentPdfFile = file;
            this.fileNameElement.textContent = `File: ${file.name}`;
            this.fileInfo.classList.remove('hidden');
            this.processFile(file);
        } else {
            this.clearFileInput();
        }
    }

    validateFile(file) {
        // Check file type
        if (file.type !== 'application/pdf' && 
            file.type !== 'text/plain' && 
            file.type !== 'application/rtf' && 
            file.type !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' && 
            file.type !== 'text/markdown' &&
            !file.name.endsWith('.txt') && 
            !file.name.endsWith('.pdf') && 
            !file.name.endsWith('.rtf') && 
            !file.name.endsWith('.docx') &&
            !file.name.endsWith('.md')) {
            this.showError('Please upload a valid PDF, TXT, RTF, DOCX, or Markdown file.');
            return false;
        }

        // Check file size (5000 MB max)
        const maxSize = 5000 * 1024 * 1024;
        if (file.size > maxSize) {
            this.showError(`File size exceeds the 5000MB limit.`);
            return false;
        }

        return true;
    }
    
    showError(message) {
        if (this.ui) {
            this.ui.showStatus(message, 'error');
        } else {
            this.fileProcessingStatus.textContent = message;
            this.fileProcessingStatus.className = 'text-red-600 mt-1';
            
            // Reset error message after 5 seconds
            setTimeout(() => {
                this.fileProcessingStatus.textContent = '';
                this.fileProcessingStatus.className = 'text-gray-600 mt-1';
            }, 5000);
        }
        this.clearFileInput();
    }

    processFile(file) {
        this.progressBarContainer.classList.remove('hidden');
        this.updateProgress(1, 'Starting file processing...');
        
        if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
            // Process PDF file
            this.processPdfFile(file);
        } else if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
            // Process TXT file
            this.processTxtFile(file)
                .then(textContent => {
                    this.extractedPdfText = textContent;
                    this.updateProgress(100, 'TXT file processed successfully. Ready to generate questions.');
                    if (this.ui) {
                        this.ui.showStatus('TXT file processed. Click "Generate Questions".', 'success');
                    }
                })
                .catch(error => {
                    console.error('TXT processing error:', error);
                    this.updateProgress(100, 'Error processing TXT file.');
                    if (this.ui) {
                        this.ui.showStatus('Issue processing TXT file: ' + error.message, 'error');
                    }
                });
        } else if (file.type === 'application/rtf' || file.name.endsWith('.rtf')) {
            // Process RTF file
            this.processRtfFile(file)
                .then(textContent => {
                    this.extractedPdfText = textContent;
                    this.updateProgress(100, 'RTF file processed successfully. Ready to generate questions.');
                    if (this.ui) {
                        this.ui.showStatus('RTF file processed. Click "Generate Questions".', 'success');
                    }
                })
                .catch(error => {
                    console.error('RTF processing error:', error);
                    this.updateProgress(100, 'Error processing RTF file.');
                    if (this.ui) {
                        this.ui.showStatus('Issue processing RTF file: ' + error.message, 'error');
                    }
                });
        } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || file.name.endsWith('.docx')) {
            // Process DOCX file
            this.processDocxFile(file)
                .then(textContent => {
                    this.extractedPdfText = textContent;
                    this.updateProgress(100, 'DOCX file processed successfully. Ready to generate questions.');
                    if (this.ui) {
                        this.ui.showStatus('DOCX file processed. Click "Generate Questions".', 'success');
                    }
                })
                .catch(error => {
                    console.error('DOCX processing error:', error);
                    this.updateProgress(100, 'Error processing DOCX file.');
                    if (this.ui) {
                        this.ui.showStatus('Issue processing DOCX file: ' + error.message, 'error');
                    }
                });
        } else if (file.type === 'text/markdown' || file.name.endsWith('.md')) {
            // Process Markdown file
            this.processMdFile(file)
                .then(textContent => {
                    this.extractedPdfText = textContent;
                    this.updateProgress(100, 'Markdown file processed successfully. Ready to generate questions.');
                    if (this.ui) {
                        this.ui.showStatus('Markdown file processed. Click "Generate Questions".', 'success');
                    }
                })
                .catch(error => {
                    console.error('Markdown processing error:', error);
                    this.updateProgress(100, 'Error processing Markdown file.');
                    if (this.ui) {
                        this.ui.showStatus('Issue processing Markdown file: ' + error.message, 'error');
                    }
                });
        } else {
            this.showError('Unsupported file type.');
        }
    }
    
    processPdfFile(file) {
        this.updateProgress(5, 'Starting PDF processing...');
        
        // Pre-extract text in the background to speed up generation later
        this.extractPdfText(file)
            .then(extractedText => {
                this.extractedPdfText = extractedText;
                this.updateProgress(100, 'PDF processed successfully. Ready to generate questions.');
                if (this.ui) {
                    this.ui.showStatus('PDF file processed. Click "Generate Questions".', 'success');
                }
            })
            .catch(error => {
                console.error('PDF processing error:', error);
                this.updateProgress(100, 'Error processing PDF. Using alternative method.');
                if (this.ui) {
                    this.ui.showStatus('Issue processing PDF. Will try alternative method during generation.', 'warning');
                }
            });
    }
    
    processTxtFile(file) {
        this.updateProgress(10, 'Reading TXT file...');
        
        // Return a Promise to handle the asynchronous nature of FileReader
        return new Promise((resolve, reject) => {
            // Read TXT file as text
            const reader = new FileReader();
            
            reader.onprogress = (event) => {
                if (event.lengthComputable) {
                    const loadProgress = Math.floor((event.loaded / event.total) * 40) + 10; // 10% to 50%
                    this.updateProgress(loadProgress, 'Loading TXT file data...');
                }
            };
            
            reader.onload = () => {
                this.updateProgress(60, 'Processing TXT content...');
                
                try {
                    let textContent = reader.result;
                    
                    // Process the text content
                    textContent = this.processExtractedText(textContent);
                    
                    // Get max content size from QuotaManager if available
                    const maxContentSize = (window.quotaManager && window.quotaManager.maxContentSize) 
                        ? window.quotaManager.maxContentSize
                        : 100000; // Default 100k chars
                    
                    // Check if user is creator to bypass quota limits
                    const isCreator = window.quotaManager && window.quotaManager.isCreator;
                    
                    // Apply safe truncation through QuotaManager if available, but bypass for creator
                    if (window.quotaManager && textContent.length > maxContentSize && !isCreator) {
                        textContent = window.quotaManager.safelyTruncateContent(textContent);
                        if (this.ui) {
                            this.ui.showStatus(`The TXT content was automatically truncated to prevent API quota issues.`, 'warning');
                        }
                        console.log(`TXT content was truncated to ${textContent.length} characters`);
                    } else if (textContent.length > maxContentSize && isCreator) {
                        // Log but don't truncate for creator
                        console.log(`Content length (${textContent.length}) exceeds default limit but not truncated because user is creator`);
                    }
                    
                    // Resolve the promise with the processed text
                    resolve(textContent);
                    
                } catch (error) {
                    console.error('TXT content processing error:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                console.error('FileReader error:', error);
                reject(new Error('Failed to read the TXT file. Please try again.'));
            };
            
            reader.readAsText(file);
        });
    }
    
    processRtfFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const text = event.target.result;
                    
                    // Basic RTF text extraction - removes RTF markup
                    let plainText = this.stripRtfMarkup(text);
                    
                    // Filter by subspecialty if one is selected
                    if (this.currentSubspecialty && this.currentSubspecialty !== 'general' && this.currentSubspecialty !== 'all') {
                        plainText = this.filterTextBySubspecialty(plainText, this.currentSubspecialty);
                    }
                    
                    this.updateProgress(90, 'Extracted text from RTF');
                    resolve(plainText);
                } catch (error) {
                    console.error('Error processing RTF file:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                console.error('FileReader error:', error);
                reject(error);
            };
            
            reader.readAsText(file);
        });
    }
    
    stripRtfMarkup(rtfText) {
        // Basic RTF stripping - removes common RTF markup
        // This is a simple implementation and may not handle all RTF features
        let plainText = rtfText;
        
        // Remove RTF headers and commands
        plainText = plainText.replace(/\{\\rtf1.*?\\viewkind4/, '');
        
        // Remove control words and groups
        plainText = plainText.replace(/\{\\.*?\}|\\w+\s?/g, '');
        
        // Remove curly braces
        plainText = plainText.replace(/[\{\}]/g, '');
        
        // Replace escaped characters
        plainText = plainText.replace(/\\\'/g, '\'');
        
        // Clean up whitespace
        plainText = plainText.replace(/\s+/g, ' ').trim();
        
        return plainText;
    }
    
    processDocxFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = async (event) => {
                try {
                    const arrayBuffer = event.target.result;
                    
                    // Since we can't directly process DOCX in browser without a library,
                    // we'll use a simplified approach that extracts text from XML content
                    const text = await this.extractTextFromDocx(arrayBuffer);
                    
                    // Filter by subspecialty if one is selected
                    let processedText = text;
                    if (this.currentSubspecialty && this.currentSubspecialty !== 'general' && this.currentSubspecialty !== 'all') {
                        processedText = this.filterTextBySubspecialty(text, this.currentSubspecialty);
                    }
                    
                    this.updateProgress(90, 'Extracted text from DOCX');
                    resolve(processedText);
                } catch (error) {
                    console.error('Error processing DOCX file:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                console.error('FileReader error:', error);
                reject(error);
            };
            
            reader.readAsArrayBuffer(file);
        });
    }
    
    async extractTextFromDocx(arrayBuffer) {
        try {
            // DOCX files are ZIP archives containing XML files
            // We need to use a ZIP library to extract the content
            // Since we may not have direct access to libraries, we'll use a simplified approach
            
            // For production, you should use a proper DOCX parsing library
            // This is a placeholder implementation
            this.updateProgress(50, 'Extracting DOCX content (simplified method)...');
            
            // For now, we'll extract text from the ZIP using basic techniques
            // Get the document.xml content which contains the main text
            const textContent = await this.extractDocxContent(arrayBuffer);
            
            return textContent || "Failed to extract text from DOCX. Please consider converting to PDF or TXT format.";
        } catch (error) {
            console.error('DOCX extraction error:', error);
            throw new Error('Unable to process DOCX file: ' + error.message);
        }
    }
    
    async extractDocxContent(arrayBuffer) {
        // This is a simplified implementation to extract text from DOCX files
        // For production use, consider libraries like docx-parser, mammoth.js or docx4js
        
        try {
            // Convert ArrayBuffer to string (looking for text content)
            const textDecoder = new TextDecoder('utf-8');
            const fileContent = textDecoder.decode(arrayBuffer);
            
            // Look for text content between XML tags
            let extractedText = '';
            
            // Extract text from <w:t> tags which contain the document text in DOCX files
            const regex = /<w:t[^>]*>(.*?)<\/w:t>/g;
            let match;
            
            while ((match = regex.exec(fileContent)) !== null) {
                extractedText += match[1] + ' ';
            }
            
            // If we couldn't extract any text with the basic method
            if (!extractedText.trim()) {
                // Try a more general approach to find any text in the document
                const textMatches = fileContent.match(/>([^<]+)</g);
                if (textMatches) {
                    extractedText = textMatches.map(m => m.replace(/[><]/g, '')).join(' ');
                }
            }
            
            return extractedText.trim() || "Unable to extract text from DOCX. Please try a different format.";
        } catch (error) {
            console.error('Error in DOCX content extraction:', error);
            return "Error extracting DOCX content: " + error.message;
        }
    }
    
    // Helper method to filter text by subspecialty
    filterTextBySubspecialty(text, subspecialty) {
        if (!text || !subspecialty || subspecialty === 'general' || subspecialty === 'all') {
            return text;
        }
        
        const keywords = this.subspecialtyKeywords[subspecialty] || [];
        if (keywords.length === 0) {
            return text;
        }
        
        // Split text into paragraphs
        const paragraphs = text.split(/\n\s*\n/);
        
        // Filter paragraphs that contain subspecialty keywords
        const relevantParagraphs = paragraphs.filter(paragraph => {
            const lowerParagraph = paragraph.toLowerCase();
            return keywords.some(keyword => lowerParagraph.includes(keyword.toLowerCase()));
        });
        
        // If no relevant paragraphs found, return the whole text
        if (relevantParagraphs.length === 0) {
            return text;
        }
        
        return relevantParagraphs.join('\n\n');
    }
    
    updateProgress(percentage, statusText = '') {
        this.progressBar.style.width = `${percentage}%`;
        if (statusText) {
            this.fileProcessingStatus.textContent = statusText;
            this.fileProcessingStatus.className = 'text-gray-600 mt-1';
        }
    }

    resetProgress() {
        this.progressBar.style.width = '0%';
        this.progressBarContainer.classList.add('hidden');
        this.fileProcessingStatus.textContent = '';
        this.fileProcessingStatus.className = 'text-gray-600 mt-1';
    }

    clearFileInput() {
        this.fileInput.value = '';
        this.currentPdfFile = null;
        this.extractedPdfText = null;
        this.fileNameElement.textContent = '';
        this.fileProcessingStatus.textContent = '';
        this.progressBar.style.width = '0%';
        this.progressBarContainer.classList.add('hidden');
        this.fileInfo.classList.add('hidden');
    }

    async extractPdfText(file, subspecialty = null) {
        return new Promise(async (resolve, reject) => {
            // Use provided subspecialty or fall back to the current selection
            const targetSubspecialty = subspecialty || this.currentSubspecialty || 'general';
            
            // Check if PDF.js is available
            if (typeof pdfjsLib === 'undefined') {
                if (this.ui) {
                    this.ui.showStatus('PDF.js library not available. Using fallback extraction.', 'warning');
                }
                // Fall back to placeholder text
                setTimeout(() => {
                    resolve(`(Placeholder text extracted from PDF: ${file.name}. Full content parsing needed for accurate results.)\n\nExample Content: Uveitis involves inflammation of the uveal tract...`);
                }, 300);
                return;
            }
            
            try {
                // Convert file to ArrayBuffer for PDF.js
                const arrayBuffer = await this.readFileAsArrayBuffer(file);
                this.updateProgress(10, 'Reading PDF data...');
                
                // Load PDF document using PDF.js
                const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
                const pdfDocument = await loadingTask.promise;
                
                const totalPages = pdfDocument.numPages;
                
                // Check if CONFIG is defined, otherwise use default max pages
                const defaultMaxPages = 5000; // Increased to 5000 pages
                const maxPages = (typeof CONFIG !== 'undefined' && CONFIG.PDF_PARSER && CONFIG.PDF_PARSER.MAX_PAGES)
                    ? CONFIG.PDF_PARSER.MAX_PAGES 
                    : defaultMaxPages;
                
                // Get max content size from QuotaManager if available
                const maxContentSize = (window.quotaManager && window.quotaManager.maxContentSize) 
                    ? window.quotaManager.maxContentSize
                    : 100000; // Default 100k chars
                
                this.updateProgress(20, `PDF loaded with ${totalPages} pages. Analyzing content relevance...`);

                // Smart extraction based on subspecialty
                let relevantPages = [];
                let fullText = '';
                let isContentLimitReached = false;
                
                // First scan: If subspecialty is specified and not 'general' or 'all', 
                // quickly scan pages to determine relevance
                const shouldFilter = targetSubspecialty !== 'general' && 
                                    targetSubspecialty !== 'all' &&
                                    this.subspecialtyKeywords[targetSubspecialty];
                
                if (shouldFilter) {
                    const keywords = this.subspecialtyKeywords[targetSubspecialty];
                    const pageLimit = Math.min(totalPages, maxPages);
                    
                    this.updateProgress(25, `Analyzing pages for ${targetSubspecialty} content...`);
                    console.log(`Analyzing PDF for content relevant to: ${targetSubspecialty}`);
                    console.log(`Using keywords: ${keywords.join(', ')}`);
                    
                    // First pass: scan headers and key sections for relevance
                    for (let i = 1; i <= pageLimit; i++) {
                        // Update progress for analysis phase - scale from 25% to 40%
                        const analysisProgress = 25 + Math.floor((i / pageLimit) * 15);
                        this.updateProgress(analysisProgress, `Analyzing page ${i} of ${pageLimit}...`);
                        
                        try {
                            // Get page and extract text content
                            const page = await pdfDocument.getPage(i);
                            const textContent = await page.getTextContent();
                            const pageText = textContent.items.map(item => item.str).join(' ').toLowerCase();
                            
                            // Check if this page is relevant to the selected subspecialty
                            const isRelevant = keywords.some(keyword => 
                                pageText.includes(keyword.toLowerCase())
                            );
                            
                            if (isRelevant) {
                                relevantPages.push(i);
                            }
                            
                            // Add table of contents and index pages
                            if (pageText.includes('contents') || 
                                pageText.includes('index') || 
                                pageText.includes('chapter') ||
                                i <= 10) { // Include first 10 pages for TOC, etc.
                                if (!relevantPages.includes(i)) {
                                    relevantPages.push(i);
                                }
                            }
                        } catch (pageError) {
                            console.warn(`Error analyzing page ${i}:`, pageError);
                        }
                    }
                    
                    console.log(`Found ${relevantPages.length} pages relevant to ${targetSubspecialty}`);
                    
                    // If no relevant pages found or almost all pages are relevant,
                    // fall back to standard sequential processing
                    if (relevantPages.length === 0 || relevantPages.length > maxPages * 0.8) {
                        console.log("No specific relevant pages found or too many matches. Processing sequentially.");
                        relevantPages = [];
                        for (let i = 1; i <= Math.min(totalPages, maxPages); i++) {
                            relevantPages.push(i);
                        }
                    } else {
                        // Sort pages in ascending order
                        relevantPages.sort((a, b) => a - b);
                    }
                } else {
                    // Default sequential processing for 'general' or 'all' subspecialty
                    console.log("Using standard sequential processing for general content");
                    for (let i = 1; i <= Math.min(totalPages, maxPages); i++) {
                        relevantPages.push(i);
                    }
                }
                
                // Limit to maximum pages if we found too many relevant pages
                if (relevantPages.length > maxPages) {
                    console.log(`Limiting to ${maxPages} most relevant pages`);
                    relevantPages = relevantPages.slice(0, maxPages);
                }
                
                // Second pass: extract content from relevant pages
                this.updateProgress(40, `Extracting content from ${relevantPages.length} relevant pages...`);
                let processedPages = 0;
                
                for (let i = 0; i < relevantPages.length; i++) {
                    const pageNum = relevantPages[i];
                    
                    // Update progress for extraction phase - scale from 40% to 90%
                    const extractionProgress = 40 + Math.floor((i / relevantPages.length) * 50);
                    this.updateProgress(extractionProgress, `Extracting page ${pageNum} (${i+1} of ${relevantPages.length})...`);
                    
                    try {
                        // Get page and extract text content
                        const page = await pdfDocument.getPage(pageNum);
                        const textContent = await page.getTextContent();
                        const pageText = textContent.items.map(item => item.str).join(' ');
                        
                        fullText += `[Page ${pageNum}]\n${pageText}\n\n`;
                        processedPages++;
                        
                        // Check if we've exceeded safe content size
                        if (fullText.length > maxContentSize) {
                            console.log(`Content size limit reached at page ${pageNum}. Stopping extraction.`);
                            isContentLimitReached = true;
                            break;
                        }
                    } catch (pageError) {
                        console.warn(`Error extracting text from page ${pageNum}:`, pageError);
                        fullText += `[Error extracting text from page ${pageNum}]\n\n`;
                    }
                }
                
                // Process and clean text
                const processedText = this.processExtractedText(fullText);
                this.updateProgress(95, 'Finalizing text extraction...');
                
                // Show appropriate warnings based on what limited the extraction
                if (isContentLimitReached) {
                    // Only show content limit message for non-creators
                    if (this.ui && !(window.quotaManager && window.quotaManager.isCreator)) {
                        this.ui.showStatus(`Note: Content size limit reached after processing ${processedPages} pages.`, 'warning');
                    }
                } else if (totalPages > relevantPages.length) {
                    if (this.ui) {
                        this.ui.showStatus(`Processed ${relevantPages.length} pages relevant to ${targetSubspecialty} out of ${totalPages} total pages.`, 'info');
                    }
                }
                
                // Apply safe truncation through QuotaManager if available
                let safeText = processedText;
                if (window.quotaManager && safeText.length > maxContentSize && !(window.quotaManager.isCreator)) {
                    safeText = window.quotaManager.safelyTruncateContent(safeText);
                    if (this.ui) {
                        this.ui.showStatus(`The PDF content was automatically truncated to prevent API quota issues.`, 'warning');
                    }
                    console.log(`PDF content was truncated from ${processedText.length} to ${safeText.length} characters`);
                } else {
                    // For creators, don't truncate content
                    safeText = processedText;
                }
                
                resolve(safeText);
            } catch (error) {
                console.error('PDF.js extraction error:', error);
                reject(error);
            }
        });
    }
    
    // Helper function to process and clean extracted text
    processExtractedText(text) {
        // Remove excess whitespace and fix common OCR issues
        return text
            .replace(/\s+/g, ' ')                  // Normalize whitespace
            .replace(/(\w)-\s+(\w)/g, '$1$2')      // Fix hyphenated words
            .replace(/â€™/g, "'")                  // Fix common encoding issues
            .replace(/â€œ|â€/g, '"')               // Fix quotation marks
            .replace(/\f/g, '\n\n')                // Replace form feeds with paragraph breaks
            .trim();                               // Trim whitespace
    }
    
    // Helper to read file as ArrayBuffer for PDF.js
    readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onprogress = (event) => {
                if (event.lengthComputable) {
                    const loadProgress = Math.floor((event.loaded / event.total) * 10); // Up to 10%
                    this.updateProgress(loadProgress, 'Loading file data...');
                }
            };
            
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => {
                console.error('FileReader error:', error);
                reject(new Error('Failed to read the file. Please try again.'));
            };
            
            reader.readAsArrayBuffer(file);
        });
    }
    
    // Update getPdfText to handle TXT files better
    async getPdfText(file = null, subspecialty = null) {
        // If we're requesting a different subspecialty than what we extracted for,
        // we need to re-extract the text for PDF files (not needed for TXT)
        const fileToProcess = file || this.currentPdfFile;
        if (!fileToProcess) {
            throw new Error('No file available to extract text from');
        }
        
        const isPdfFile = fileToProcess && (fileToProcess.type === 'application/pdf' || fileToProcess.name.endsWith('.pdf'));
        const isTxtFile = fileToProcess && (fileToProcess.type === 'text/plain' || fileToProcess.name.endsWith('.txt'));
        const isRtfFile = fileToProcess && (fileToProcess.type === 'application/rtf' || fileToProcess.name.endsWith('.rtf'));
        const isDocxFile = fileToProcess && (
            fileToProcess.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
            fileToProcess.name.endsWith('.docx')
        );
        const isMarkdownFile = fileToProcess && (fileToProcess.type === 'text/markdown' || fileToProcess.name.endsWith('.md'));
        
        if (isPdfFile && subspecialty && 
            this.currentSubspecialty !== subspecialty && 
            subspecialty !== 'general' &&
            this.currentSubspecialty !== 'general') {
            console.log(`Re-extracting PDF for subspecialty: ${subspecialty} (previous extraction was for: ${this.currentSubspecialty || 'none'})`);
            this.extractedPdfText = null; // Clear cache to force re-extraction
            // Update the current subspecialty to match what we're extracting for
            this.currentSubspecialty = subspecialty;
        }
        
        // If we already have extracted text, return it
        if (this.extractedPdfText) {
            console.log(`Using cached text for subspecialty: ${this.currentSubspecialty || 'general'}`);
            return this.extractedPdfText;
        }
        
        console.log(`Extracting new text for subspecialty: ${subspecialty || this.currentSubspecialty || 'general'}`);
        
        // For PDF files, extract and filter by subspecialty
        if (isPdfFile) {
            this.extractedPdfText = await this.extractPdfText(fileToProcess, subspecialty);
            return this.extractedPdfText;
        } else if (isTxtFile) {
            // For TXT files, process it now if it hasn't been processed yet
            try {
                this.extractedPdfText = await this.processTxtFile(fileToProcess);
                return this.extractedPdfText;
            } catch (error) {
                console.error('Error processing TXT file in getPdfText:', error);
                throw new Error('Error processing TXT file: ' + error.message);
            }
        } else if (isRtfFile) {
            // For RTF files, process it now if it hasn't been processed yet
            try {
                this.extractedPdfText = await this.processRtfFile(fileToProcess);
                return this.extractedPdfText;
            } catch (error) {
                console.error('Error processing RTF file in getPdfText:', error);
                throw new Error('Error processing RTF file: ' + error.message);
            }
        } else if (isDocxFile) {
            // For DOCX files, process it now if it hasn't been processed yet
            try {
                this.extractedPdfText = await this.processDocxFile(fileToProcess);
                return this.extractedPdfText;
            } catch (error) {
                console.error('Error processing DOCX file in getPdfText:', error);
                throw new Error('Error processing DOCX file: ' + error.message);
            }
        } else if (isMarkdownFile) {
            // For Markdown files, process it now if it hasn't been processed yet
            try {
                this.extractedPdfText = await this.processMdFile(fileToProcess);
                return this.extractedPdfText;
            } catch (error) {
                console.error('Error processing Markdown file in getPdfText:', error);
                throw new Error('Error processing Markdown file: ' + error.message);
            }
        } else {
            throw new Error('Unsupported file type. Please upload a PDF, TXT, RTF, DOCX, or Markdown file.');
        }
    }

    setUI(ui) {
        this.ui = ui;
    }

    // Add new method to handle Markdown files
    processMdFile(file) {
        return new Promise((resolve, reject) => {
            this.updateProgress(20, 'Reading Markdown file...');
            
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const textContent = event.target.result;
                    this.updateProgress(80, 'Extracting content from Markdown...');
                    
                    // For markdown, we can use the raw text content
                    let processedText = textContent;
                    
                    // Apply subspecialty filtering if specified
                    if (this.currentSubspecialty && this.currentSubspecialty !== 'general' && this.currentSubspecialty !== 'all') {
                        processedText = this.filterTextBySubspecialty(processedText, this.currentSubspecialty);
                        console.log(`Filtered Markdown text by subspecialty: ${this.currentSubspecialty}`);
                    }
                    
                    this.updateProgress(100, 'Markdown processing complete');
                    resolve(processedText);
                } catch (error) {
                    console.error('Error processing Markdown:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                console.error('FileReader error:', error);
                reject(new Error('Failed to read the Markdown file.'));
            };
            
            reader.readAsText(file);
        });
    }
}

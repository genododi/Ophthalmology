/**
 * Enhanced Validation UI System
 * Provides comprehensive interface for displaying validation results and collecting user ratings
 */

class ValidationUI {
    constructor() {
        this.initializeUI();
        this.setupEventListeners();
    }

    /**
     * Initialize UI styles and components
     */
    initializeUI() {
        this.addValidationStyles();
        this.setupTooltips();
        console.log('Enhanced Validation UI initialized');
    }

    /**
     * Add comprehensive CSS styles for validation displays
     */
    addValidationStyles() {
        const styles = `
            <style id="validation-ui-styles">
                /* Validation Container */
                .validation-container {
                    margin: 15px 0;
                    padding: 16px;
                    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                    border: 1px solid #e2e8f0;
                    border-radius: 12px;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
                    transition: all 0.3s ease;
                }

                .validation-container:hover {
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                    border-color: #cbd5e0;
                }

                /* Validation Header */
                .validation-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 12px;
                    padding-bottom: 8px;
                    border-bottom: 1px solid #e2e8f0;
                }

                .validation-title {
                    display: flex;
                    align-items: center;
                    font-weight: 600;
                    color: #2d3748;
                    font-size: 14px;
                }

                .validation-title i {
                    margin-right: 8px;
                    color: #4a5568;
                }

                /* Accuracy Display */
                .accuracy-display {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }

                .accuracy-percentage {
                    display: flex;
                    align-items: center;
                    padding: 6px 12px;
                    border-radius: 20px;
                    font-weight: 700;
                    font-size: 13px;
                    min-width: 60px;
                    justify-content: center;
                    position: relative;
                }

                .accuracy-high {
                    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                    color: white;
                    box-shadow: 0 2px 4px rgba(72, 187, 120, 0.3);
                }

                .accuracy-moderate {
                    background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
                    color: white;
                    box-shadow: 0 2px 4px rgba(237, 137, 54, 0.3);
                }

                .accuracy-low {
                    background: linear-gradient(135deg, #e53e3e 0%, #c53030 100%);
                    color: white;
                    box-shadow: 0 2px 4px rgba(229, 62, 62, 0.3);
                }

                .accuracy-unknown {
                    background: linear-gradient(135deg, #a0aec0 0%, #718096 100%);
                    color: white;
                    box-shadow: 0 2px 4px rgba(160, 174, 192, 0.3);
                }

                .confidence-indicator {
                    display: flex;
                    align-items: center;
                    font-size: 12px;
                    color: #4a5568;
                    gap: 4px;
                }

                .confidence-bar {
                    width: 40px;
                    height: 4px;
                    background: #e2e8f0;
                    border-radius: 2px;
                    overflow: hidden;
                }

                .confidence-fill {
                    height: 100%;
                    background: linear-gradient(90deg, #48bb78 0%, #38a169 100%);
                    border-radius: 2px;
                    transition: width 0.3s ease;
                }

                /* Source Quality Indicators */
                .source-quality-section {
                    margin: 12px 0;
                }

                .source-quality-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
                    gap: 8px;
                    margin-top: 8px;
                }

                .quality-badge {
                    display: flex;
                    align-items: center;
                    padding: 6px 10px;
                    border-radius: 8px;
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    transition: all 0.2s ease;
                }

                .quality-badge:hover {
                    transform: translateY(-1px);
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
                }

                .quality-badge i {
                    margin-right: 6px;
                    font-size: 12px;
                }

                .quality-peer-reviewed {
                    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                    color: white;
                }

                .quality-clinical-guideline {
                    background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
                    color: white;
                }

                .quality-systematic-review {
                    background: linear-gradient(135deg, #805ad5 0%, #6b46c1 100%);
                    color: white;
                }

                .quality-journal {
                    background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
                    color: white;
                }

                /* Source Results */
                .source-results {
                    margin: 12px 0;
                }

                .source-result {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 8px 12px;
                    margin: 4px 0;
                    background: white;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    font-size: 12px;
                }

                .source-name {
                    font-weight: 600;
                    color: #2d3748;
                }

                .source-accuracy {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                }

                .source-score {
                    padding: 2px 6px;
                    border-radius: 10px;
                    font-weight: 600;
                    font-size: 10px;
                }

                .source-high { background: #c6f6d5; color: #22543d; }
                .source-moderate { background: #fed7ad; color: #7b341e; }
                .source-low { background: #fed7d7; color: #742a2a; }

                /* Citations Section */
                .citations-section {
                    margin: 12px 0;
                }

                .citations-grid {
                    display: grid;
                    gap: 8px;
                    margin-top: 8px;
                }

                .citation-item {
                    padding: 10px 12px;
                    background: white;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    transition: all 0.2s ease;
                }

                .citation-item:hover {
                    border-color: #cbd5e0;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
                }

                .citation-title {
                    font-weight: 600;
                    color: #2d3748;
                    font-size: 12px;
                    margin-bottom: 4px;
                    line-height: 1.3;
                }

                .citation-meta {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    font-size: 10px;
                    color: #718096;
                    margin-top: 6px;
                }

                .citation-link {
                    color: #4299e1;
                    text-decoration: none;
                    font-weight: 500;
                }

                .citation-link:hover {
                    color: #3182ce;
                    text-decoration: underline;
                }

                .citation-reliability {
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }

                .reliability-stars {
                    color: #ecc94b;
                }

                /* User Rating Section */
                .user-rating-section {
                    margin: 16px 0;
                    padding: 14px;
                    background: white;
                    border: 1px solid #e2e8f0;
                    border-radius: 10px;
                }

                .rating-header {
                    display: flex;
                    align-items: center;
                    justify-content: between;
                    margin-bottom: 12px;
                }

                .rating-categories {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
                    gap: 12px;
                }

                .rating-category {
                    text-align: center;
                }

                .rating-category-label {
                    font-size: 11px;
                    font-weight: 600;
                    color: #4a5568;
                    margin-bottom: 6px;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }

                .star-rating {
                    display: flex;
                    justify-content: center;
                    gap: 2px;
                    margin-bottom: 4px;
                }

                .star {
                    font-size: 16px;
                    color: #e2e8f0;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    user-select: none;
                }

                .star:hover,
                .star.active {
                    color: #ecc94b;
                    transform: scale(1.1);
                }

                .star.active {
                    text-shadow: 0 0 4px rgba(236, 201, 75, 0.4);
                }

                .rating-value {
                    font-size: 10px;
                    color: #718096;
                    font-weight: 500;
                }

                .rating-summary {
                    margin-top: 12px;
                    padding-top: 12px;
                    border-top: 1px solid #e2e8f0;
                    display: flex;
                    align-items: center;
                    justify-content: between;
                    gap: 12px;
                }

                .overall-rating {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    font-weight: 600;
                    color: #2d3748;
                }

                .submit-rating-btn {
                    background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
                    color: white;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }

                .submit-rating-btn:hover {
                    transform: translateY(-1px);
                    box-shadow: 0 2px 6px rgba(66, 153, 225, 0.3);
                }

                .submit-rating-btn:disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                    transform: none;
                }

                /* Validation Status */
                .validation-status {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    font-size: 12px;
                    margin-top: 8px;
                }

                .status-icon {
                    font-size: 14px;
                }

                .status-high { color: #48bb78; }
                .status-moderate { color: #ed8936; }
                .status-low { color: #e53e3e; }
                .status-unknown { color: #a0aec0; }

                /* Validation Timeline */
                .validation-timeline {
                    font-size: 10px;
                    color: #718096;
                    margin-top: 8px;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }

                /* Expandable sections */
                .expandable-section {
                    margin-top: 8px;
                }

                .expand-toggle {
                    background: none;
                    border: none;
                    color: #4299e1;
                    font-size: 11px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    padding: 4px 0;
                    font-weight: 500;
                }

                .expand-toggle:hover {
                    color: #3182ce;
                }

                .expand-content {
                    max-height: 0;
                    overflow: hidden;
                    transition: max-height 0.3s ease;
                }

                .expand-content.expanded {
                    max-height: 500px;
                }

                /* Loading states */
                .validation-loading {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                    color: #718096;
                    font-size: 12px;
                }

                .loading-spinner {
                    width: 16px;
                    height: 16px;
                    border: 2px solid #e2e8f0;
                    border-top: 2px solid #4299e1;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin-right: 8px;
                }

                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                /* Responsive design */
                @media (max-width: 768px) {
                    .accuracy-display {
                        flex-direction: column;
                        align-items: flex-start;
                        gap: 8px;
                    }

                    .source-quality-grid {
                        grid-template-columns: 1fr;
                    }

                    .rating-categories {
                        grid-template-columns: repeat(2, 1fr);
                    }
                }

                /* Accessibility */
                .validation-container:focus-within {
                    outline: 2px solid #4299e1;
                    outline-offset: 2px;
                }

                .star:focus {
                    outline: 2px solid #4299e1;
                    outline-offset: 1px;
                    border-radius: 2px;
                }

                /* Animation for new validations */
                .validation-container.new-validation {
                    animation: slideInUp 0.3s ease-out;
                }

                @keyframes slideInUp {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        `;

        // Remove existing styles and add new ones
        const existingStyles = document.getElementById('validation-ui-styles');
        if (existingStyles) {
            existingStyles.remove();
        }

        document.head.insertAdjacentHTML('beforeend', styles);
    }

    /**
     * Create validation display for a question
     */
    createValidationDisplay(questionElement, validationResult) {
        // Remove existing validation display
        const existingValidation = questionElement.querySelector('.validation-container');
        if (existingValidation) {
            existingValidation.remove();
        }

        if (!validationResult || validationResult.error) {
            return this.createErrorDisplay(questionElement, validationResult);
        }

        const validationContainer = document.createElement('div');
        validationContainer.className = 'validation-container new-validation';
        
        validationContainer.innerHTML = `
            ${this.createValidationHeader(validationResult)}
            ${this.createAccuracyDisplay(validationResult)}
            ${this.createSourceQualityDisplay(validationResult)}
            ${this.createSourceResultsDisplay(validationResult)}
            ${this.createCitationsDisplay(validationResult)}
            ${this.createUserRatingDisplay(validationResult.questionId)}
            ${this.createValidationFooter(validationResult)}
        `;

        questionElement.appendChild(validationContainer);
        
        // Setup interactive elements
        this.setupValidationInteractions(validationContainer, validationResult);
        
        return validationContainer;
    }

    /**
     * Create validation header
     */
    createValidationHeader(validationResult) {
        const levelIcon = this.getValidationLevelIcon(validationResult.validationLevel);
        const timestamp = new Date(validationResult.timestamp).toLocaleString();
        
        return `
            <div class="validation-header">
                <div class="validation-title">
                    <i class="fas fa-shield-alt"></i>
                    Medical Validation Results
                </div>
                <div class="validation-timeline">
                    <i class="fas fa-clock"></i>
                    Validated ${timestamp}
                </div>
            </div>
        `;
    }

    /**
     * Create accuracy percentage display
     */
    createAccuracyDisplay(validationResult) {
        const accuracy = validationResult.accuracy || 0;
        const confidence = validationResult.confidence || 0;
        const accuracyClass = this.getAccuracyClass(accuracy);
        const confidenceWidth = Math.min(100, confidence);

        return `
            <div class="accuracy-display">
                <div class="accuracy-percentage ${accuracyClass}" title="Validation Accuracy Score">
                    ${accuracy}%
                </div>
                <div class="confidence-indicator" title="Validation Confidence Level">
                    <span>Confidence:</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" style="width: ${confidenceWidth}%"></div>
                    </div>
                    <span>${confidence}%</span>
                </div>
                <div class="validation-status">
                    <i class="fas ${this.getValidationLevelIcon(validationResult.validationLevel)} status-icon status-${validationResult.validationLevel}"></i>
                    <span>${this.getValidationLevelText(validationResult.validationLevel)}</span>
                </div>
            </div>
        `;
    }

    /**
     * Create source quality indicators
     */
    createSourceQualityDisplay(validationResult) {
        if (!validationResult.qualityIndicators || validationResult.qualityIndicators.length === 0) {
            return '';
        }

        const qualityBadges = validationResult.qualityIndicators.map(indicator => `
            <div class="quality-badge quality-${indicator.type}" title="${indicator.label}">
                <i class="${indicator.icon}"></i>
                ${indicator.count} ${indicator.label}
            </div>
        `).join('');

        return `
            <div class="source-quality-section">
                <div class="validation-title" style="font-size: 12px; margin-bottom: 8px;">
                    <i class="fas fa-award"></i>
                    Source Quality Indicators
                </div>
                <div class="source-quality-grid">
                    ${qualityBadges}
                </div>
            </div>
        `;
    }

    /**
     * Create source results display
     */
    createSourceResultsDisplay(validationResult) {
        if (!validationResult.sources || validationResult.sources.length === 0) {
            return '';
        }

        const sourceResults = validationResult.sources.map(source => {
            const scoreClass = this.getSourceScoreClass(source.accuracy);
            const reliabilityStars = this.generateReliabilityStars(source.reliability);
            
            return `
                <div class="source-result">
                    <div>
                        <div class="source-name">${source.name}</div>
                        <div class="citation-reliability">
                            <span class="reliability-stars">${reliabilityStars}</span>
                            <span style="font-size: 10px; color: #718096;">${Math.round(source.reliability * 100)}% reliable</span>
                        </div>
                    </div>
                    <div class="source-accuracy">
                        <div class="source-score ${scoreClass}">${source.accuracy}%</div>
                        <i class="fas fa-external-link-alt" style="color: #a0aec0; font-size: 10px;"></i>
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div class="source-results">
                <div class="validation-title" style="font-size: 12px; margin-bottom: 8px;">
                    <i class="fas fa-database"></i>
                    Source Validation Results (${validationResult.sources.length} sources)
                </div>
                ${sourceResults}
            </div>
        `;
    }

    /**
     * Create citations display
     */
    createCitationsDisplay(validationResult) {
        if (!validationResult.citations || validationResult.citations.length === 0) {
            return '';
        }

        const citations = validationResult.citations.slice(0, 5).map(citation => {
            const reliabilityStars = this.generateReliabilityStars(citation.reliability || 0.8);
            
            return `
                <div class="citation-item">
                    <div class="citation-title">${this.truncateText(citation.title, 80)}</div>
                    <div class="citation-meta">
                        <div>
                            <a href="${citation.url}" target="_blank" class="citation-link" rel="noopener noreferrer">
                                ${citation.source}
                            </a>
                            ${citation.year ? ` (${citation.year})` : ''}
                        </div>
                        <div class="citation-reliability">
                            <span class="reliability-stars">${reliabilityStars}</span>
                        </div>
                    </div>
                    ${citation.authors ? `<div style="font-size: 10px; color: #718096; margin-top: 2px;">${this.truncateText(citation.authors, 60)}</div>` : ''}
                </div>
            `;
        }).join('');

        const hasMoreCitations = validationResult.citations.length > 5;
        const expandSection = hasMoreCitations ? `
            <button class="expand-toggle" data-expand="citations">
                <i class="fas fa-chevron-down"></i>
                Show ${validationResult.citations.length - 5} more citations
            </button>
            <div class="expand-content" id="citations-expanded">
                ${validationResult.citations.slice(5).map(citation => `
                    <div class="citation-item">
                        <div class="citation-title">${this.truncateText(citation.title, 80)}</div>
                        <div class="citation-meta">
                            <a href="${citation.url}" target="_blank" class="citation-link" rel="noopener noreferrer">
                                ${citation.source}
                            </a>
                            ${citation.year ? ` (${citation.year})` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        ` : '';

        return `
            <div class="citations-section">
                <div class="validation-title" style="font-size: 12px; margin-bottom: 8px;">
                    <i class="fas fa-quote-left"></i>
                    Supporting Citations (${validationResult.citations.length} found)
                </div>
                <div class="citations-grid">
                    ${citations}
                </div>
                ${expandSection}
            </div>
        `;
    }

    /**
     * Create user rating display
     */
    createUserRatingDisplay(questionId) {
        const existingRating = window.validationSystem.getUserRatings(questionId);
        
        return `
            <div class="user-rating-section">
                <div class="rating-header">
                    <div class="validation-title" style="font-size: 12px;">
                        <i class="fas fa-star"></i>
                        Rate Question Quality
                    </div>
                    ${existingRating ? `<div style="font-size: 10px; color: #718096;">${existingRating.count} rating(s)</div>` : ''}
                </div>
                <div class="rating-categories">
                    <div class="rating-category">
                        <div class="rating-category-label">Accuracy</div>
                        <div class="star-rating" data-category="accuracy">
                            ${this.generateStarRating('accuracy', existingRating)}
                        </div>
                        <div class="rating-value" id="accuracy-value">${this.getRatingValue('accuracy', existingRating)}</div>
                    </div>
                    <div class="rating-category">
                        <div class="rating-category-label">Relevance</div>
                        <div class="star-rating" data-category="relevance">
                            ${this.generateStarRating('relevance', existingRating)}
                        </div>
                        <div class="rating-value" id="relevance-value">${this.getRatingValue('relevance', existingRating)}</div>
                    </div>
                    <div class="rating-category">
                        <div class="rating-category-label">Clarity</div>
                        <div class="star-rating" data-category="clarity">
                            ${this.generateStarRating('clarity', existingRating)}
                        </div>
                        <div class="rating-value" id="clarity-value">${this.getRatingValue('clarity', existingRating)}</div>
                    </div>
                    <div class="rating-category">
                        <div class="rating-category-label">Difficulty</div>
                        <div class="star-rating" data-category="difficulty">
                            ${this.generateStarRating('difficulty', existingRating)}
                        </div>
                        <div class="rating-value" id="difficulty-value">${this.getRatingValue('difficulty', existingRating)}</div>
                    </div>
                </div>
                <div class="rating-summary">
                    <div class="overall-rating">
                        <span>Overall:</span>
                        <div class="star-rating" data-category="overall">
                            ${this.generateStarRating('overall', existingRating)}
                        </div>
                        <span id="overall-value">${this.getRatingValue('overall', existingRating)}</span>
                    </div>
                    <button class="submit-rating-btn" data-question-id="${questionId}">
                        Submit Rating
                    </button>
                </div>
            </div>
        `;
    }

    /**
     * Create validation footer
     */
    createValidationFooter(validationResult) {
        const validationTime = validationResult.validationTime ? `in ${validationResult.validationTime}ms` : '';
        const termsFound = validationResult.medicalTermsFound || 0;
        
        return `
            <div class="validation-timeline">
                <i class="fas fa-info-circle"></i>
                Validated against ${validationResult.sourceCount || 0} sources • 
                ${termsFound} medical terms analyzed ${validationTime}
            </div>
        `;
    }

    /**
     * Create error display
     */
    createErrorDisplay(questionElement, errorResult) {
        const errorContainer = document.createElement('div');
        errorContainer.className = 'validation-container';
        errorContainer.innerHTML = `
            <div class="validation-header">
                <div class="validation-title">
                    <i class="fas fa-exclamation-triangle" style="color: #e53e3e;"></i>
                    Validation Error
                </div>
            </div>
            <div style="padding: 12px; background: #fed7d7; color: #742a2a; border-radius: 8px; font-size: 12px;">
                <i class="fas fa-times-circle"></i>
                ${errorResult?.message || 'Unable to validate question against medical sources'}
            </div>
        `;
        
        questionElement.appendChild(errorContainer);
        return errorContainer;
    }

    /**
     * Setup interactive elements
     */
    setupValidationInteractions(container, validationResult) {
        // Setup star ratings
        this.setupStarRatings(container);
        
        // Setup expand/collapse
        this.setupExpandToggle(container);
        
        // Setup rating submission
        this.setupRatingSubmission(container, validationResult);
    }

    /**
     * Setup star rating interactions
     */
    setupStarRatings(container) {
        const starRatings = container.querySelectorAll('.star-rating');
        
        starRatings.forEach(rating => {
            const stars = rating.querySelectorAll('.star');
            const category = rating.dataset.category;
            
            stars.forEach((star, index) => {
                star.addEventListener('click', () => {
                    this.setStarRating(rating, index + 1);
                    this.updateRatingValue(category, index + 1);
                    this.updateOverallRating(container);
                });
                
                star.addEventListener('mouseover', () => {
                    this.highlightStars(rating, index + 1);
                });
            });
            
            rating.addEventListener('mouseleave', () => {
                this.resetStarHighlight(rating);
            });
        });
    }

    /**
     * Set star rating value
     */
    setStarRating(ratingElement, value) {
        const stars = ratingElement.querySelectorAll('.star');
        stars.forEach((star, index) => {
            if (index < value) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
        
        ratingElement.dataset.value = value;
    }

    /**
     * Highlight stars on hover
     */
    highlightStars(ratingElement, value) {
        const stars = ratingElement.querySelectorAll('.star');
        stars.forEach((star, index) => {
            if (index < value) {
                star.style.color = '#ecc94b';
            } else {
                star.style.color = '#e2e8f0';
            }
        });
    }

    /**
     * Reset star highlight
     */
    resetStarHighlight(ratingElement) {
        const currentValue = parseInt(ratingElement.dataset.value) || 0;
        this.setStarRating(ratingElement, currentValue);
    }

    /**
     * Update rating value display
     */
    updateRatingValue(category, value) {
        const valueElement = document.getElementById(`${category}-value`);
        if (valueElement) {
            const labels = ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
            valueElement.textContent = `${value}/5 (${labels[value - 1] || 'None'})`;
        }
    }

    /**
     * Update overall rating
     */
    updateOverallRating(container) {
        const categories = ['accuracy', 'relevance', 'clarity', 'difficulty'];
        let total = 0;
        let count = 0;
        
        categories.forEach(category => {
            const rating = container.querySelector(`[data-category="${category}"]`);
            const value = parseInt(rating?.dataset.value) || 0;
            if (value > 0) {
                total += value;
                count++;
            }
        });
        
        const overall = count > 0 ? Math.round(total / count) : 0;
        const overallRating = container.querySelector('[data-category="overall"]');
        if (overallRating) {
            this.setStarRating(overallRating, overall);
            this.updateRatingValue('overall', overall);
        }
    }

    /**
     * Setup expand/collapse functionality
     */
    setupExpandToggle(container) {
        const toggles = container.querySelectorAll('.expand-toggle');
        
        toggles.forEach(toggle => {
            toggle.addEventListener('click', () => {
                const targetId = toggle.dataset.expand;
                const content = container.querySelector(`#${targetId}-expanded`);
                const icon = toggle.querySelector('i');
                
                if (content) {
                    content.classList.toggle('expanded');
                    icon.classList.toggle('fa-chevron-down');
                    icon.classList.toggle('fa-chevron-up');
                    
                    if (content.classList.contains('expanded')) {
                        toggle.innerHTML = toggle.innerHTML.replace('Show', 'Hide');
                    } else {
                        toggle.innerHTML = toggle.innerHTML.replace('Hide', 'Show');
                    }
                }
            });
        });
    }

    /**
     * Setup rating submission
     */
    setupRatingSubmission(container, validationResult) {
        const submitBtn = container.querySelector('.submit-rating-btn');
        if (!submitBtn) return;
        
        submitBtn.addEventListener('click', () => {
            const questionId = submitBtn.dataset.questionId;
            const ratings = this.collectRatings(container);
            
            if (Object.keys(ratings).length === 0) {
                alert('Please provide at least one rating before submitting.');
                return;
            }
            
            // Record the rating
            const ratingData = {
                ...ratings,
                validationAccuracy: validationResult.accuracy,
                validationConfidence: validationResult.confidence,
                sourceCount: validationResult.sourceCount
            };
            
            window.validationSystem.recordUserRating(questionId, ratingData);
            
            // Update UI
            submitBtn.textContent = 'Rating Submitted!';
            submitBtn.disabled = true;
            
            setTimeout(() => {
                submitBtn.textContent = 'Update Rating';
                submitBtn.disabled = false;
            }, 2000);
        });
    }

    /**
     * Collect ratings from UI
     */
    collectRatings(container) {
        const categories = ['accuracy', 'relevance', 'clarity', 'difficulty', 'overall'];
        const ratings = {};
        
        categories.forEach(category => {
            const rating = container.querySelector(`[data-category="${category}"]`);
            const value = parseInt(rating?.dataset.value) || 0;
            if (value > 0) {
                ratings[category] = value;
            }
        });
        
        return ratings;
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Global validation events can be set up here
        console.log('Validation UI event listeners initialized');
    }

    /**
     * Setup tooltips
     */
    setupTooltips() {
        // Add tooltip functionality if needed
    }

    /**
     * Utility functions
     */
    getAccuracyClass(accuracy) {
        if (accuracy >= 85) return 'accuracy-high';
        if (accuracy >= 70) return 'accuracy-moderate';
        if (accuracy > 0) return 'accuracy-low';
        return 'accuracy-unknown';
    }

    getSourceScoreClass(score) {
        if (score >= 85) return 'source-high';
        if (score >= 70) return 'source-moderate';
        return 'source-low';
    }

    getValidationLevelIcon(level) {
        const icons = {
            high: 'fa-shield-alt',
            moderate: 'fa-shield-alt',
            low: 'fa-exclamation-triangle',
            unreliable: 'fa-times-circle'
        };
        return icons[level] || 'fa-question-circle';
    }

    getValidationLevelText(level) {
        const texts = {
            high: 'High Quality',
            moderate: 'Moderate Quality',
            low: 'Limited Quality',
            unreliable: 'Unreliable'
        };
        return texts[level] || 'Unknown';
    }

    generateReliabilityStars(reliability) {
        const stars = Math.round(reliability * 5);
        return '★'.repeat(stars) + '☆'.repeat(5 - stars);
    }

    generateStarRating(category, existingRating) {
        const value = existingRating?.averages?.[category] || 0;
        const roundedValue = Math.round(value);
        
        return Array.from({length: 5}, (_, i) => {
            const starClass = i < roundedValue ? 'star active' : 'star';
            return `<span class="${starClass}" tabindex="0">★</span>`;
        }).join('');
    }

    getRatingValue(category, existingRating) {
        const value = existingRating?.averages?.[category] || 0;
        if (value === 0) return 'Not rated';
        
        const labels = ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
        const roundedValue = Math.round(value);
        return `${value.toFixed(1)}/5 (${labels[roundedValue - 1] || 'None'})`;
    }

    truncateText(text, maxLength) {
        if (!text || text.length <= maxLength) return text;
        return text.substring(0, maxLength - 3) + '...';
    }

    /**
     * Show loading state
     */
    showValidationLoading(questionElement) {
        const loadingContainer = document.createElement('div');
        loadingContainer.className = 'validation-container validation-loading';
        loadingContainer.innerHTML = `
            <div class="loading-spinner"></div>
            Validating against medical databases...
        `;
        
        questionElement.appendChild(loadingContainer);
        return loadingContainer;
    }

    /**
     * Remove loading state
     */
    removeValidationLoading(questionElement) {
        const loadingElement = questionElement.querySelector('.validation-loading');
        if (loadingElement) {
            loadingElement.remove();
        }
    }

    /**
     * Get user rating analytics for monitoring
     * This method collects and returns analytics about user ratings
     */
    getUserRatingAnalytics() {
        try {
            // Get stored ratings from localStorage
            const storedRatings = localStorage.getItem('userRatings');
            const ratings = storedRatings ? JSON.parse(storedRatings) : {};
            
            let totalRatings = 0;
            const categoryTotals = {
                accuracy: { sum: 0, count: 0 },
                clarity: { sum: 0, count: 0 },
                difficulty: { sum: 0, count: 0 },
                usefulness: { sum: 0, count: 0 }
            };
            const ratingDistribution = {
                1: 0, 2: 0, 3: 0, 4: 0, 5: 0
            };

            // Process all ratings
            Object.values(ratings).forEach(questionRatings => {
                if (questionRatings && typeof questionRatings === 'object') {
                    Object.entries(questionRatings).forEach(([category, rating]) => {
                        if (categoryTotals[category] && typeof rating === 'number' && rating >= 1 && rating <= 5) {
                            categoryTotals[category].sum += rating;
                            categoryTotals[category].count += 1;
                            totalRatings++;
                            
                            // Track distribution
                            ratingDistribution[Math.round(rating)]++;
                        }
                    });
                }
            });

            // Calculate averages
            const averageRatings = {};
            Object.entries(categoryTotals).forEach(([category, data]) => {
                averageRatings[category] = data.count > 0 ? data.sum / data.count : 0;
            });

            return {
                totalRatings,
                averageRatings,
                ratingDistribution,
                categoryBreakdown: categoryTotals,
                questionsRated: Object.keys(ratings).length
            };
        } catch (error) {
            console.error('Error getting user rating analytics:', error);
            return {
                totalRatings: 0,
                averageRatings: {},
                ratingDistribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
                categoryBreakdown: {},
                questionsRated: 0
            };
        }
    }
}

// Initialize global validation UI
window.validationUI = new ValidationUI();

// Global helper functions
window.addValidationToQuestion = function() {
    // Support multiple call signatures:
    // 1) (questionElement, questionId, questionData)
    // 2) (questionElement, questionText, answerText, questionId)
    let questionElement;
    let questionId;
    let questionData;

    if (arguments.length >= 4 && typeof arguments[1] === 'string' && typeof arguments[2] === 'string') {
        // Signature 2
        questionElement = arguments[0];
        const questionText = arguments[1];
        const answerText = arguments[2];
        questionId = arguments[3];
        questionData = { question: questionText, answer: answerText };
    } else {
        // Assume signature 1
        questionElement = arguments[0];
        questionId = arguments[1];
        questionData = arguments[2];
    }

    if (!window.validationUI || !window.validationSystem) {
        console.warn('Validation system not available');
        // Return a resolved Promise so callers can safely chain .catch without errors
        return Promise.resolve();
    }
    
    // Show loading state
    window.validationUI.showValidationLoading(questionElement);
    
    // Validate question and return the promise chain for caller chaining
    return window.validationSystem.validateQuestion(questionId, questionData)
        .then(validationResult => {
            // Remove loading state
            window.validationUI.removeValidationLoading(questionElement);
            
            // Display validation results
            window.validationUI.createValidationDisplay(questionElement, validationResult);
            return validationResult;
        })
        .catch(error => {
            console.error('Validation failed:', error);
            
            // Remove loading state
            window.validationUI.removeValidationLoading(questionElement);
            
            // Show error
            window.validationUI.createErrorDisplay(questionElement, { 
                message: error.message 
            });
            // Re-throw to allow external catch handlers if needed
            throw error;
        });
};

window.getValidationDisplay = function(validationResult) {
    return window.validationUI.createValidationDisplay(validationResult);
}; 
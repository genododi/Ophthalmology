class QuestionGenerator {
    constructor() {
        this.generatedQuestions = [];
        this.lastSettings = null;
        this.geminiApiKey = CONFIG.API_KEYS.GEMINI;
        this.openaiApiKey = CONFIG.API_KEYS.OPENAI;
        this.claudeApiKey = CONFIG.API_KEYS.CLAUDE;
        // Cursor AI uses user credentials
        this.geminiApiUrl = CONFIG.API_ENDPOINTS.GEMINI;
        this.openaiApiUrl = CONFIG.API_ENDPOINTS.OPENAI;
        this.claudeApiUrl = CONFIG.API_ENDPOINTS.CLAUDE;
        this.cursorAiApiUrl = CONFIG.API_ENDPOINTS.CURSOR_AI;
        this.preferredModel = CONFIG.DEFAULT_MODEL || 'gemini'; // Use Gemini as default
        this.modelSelectElement = null;
        this.isRegeneration = false; // Flag to track if we're regenerating questions
        
        // Track previous questions for regeneration purposes
        // This set is used to prevent generating similar questions when clicking "Regenerate"
        this.previouslyGeneratedQuestions = new Set();
        
        // Track previous questions from prior sessions for duplicate indication 
        // This set is used for displaying the exclamation mark icon
        this.priorSessionQuestions = new Set();
        
        // Try to load prior session questions from localStorage if available
        try {
            const savedQuestions = localStorage.getItem('ophthalmoqa_prior_questions');
            if (savedQuestions) {
                const questionArray = JSON.parse(savedQuestions);
                questionArray.forEach(q => this.priorSessionQuestions.add(q));
                console.log(`Loaded ${this.priorSessionQuestions.size} questions from prior sessions`);
            }
        } catch (err) {
            console.error('Error loading prior session questions:', err);
        }
        
        // Connect to database and ML processor if available
        this.database = window.questionDatabase || null;
        this.mlProcessor = window.medicalMLProcessor || null;
        
        // Initialize ML processor if available
        if (this.mlProcessor) {
            this.mlProcessor.initialize().catch(err => {
                console.warn('Failed to initialize ML processor:', err);
            });
        }
        
        // Set up event listener to save questions when user leaves
        this.setupBeforeUnloadHandler();
    }

    setUI(ui) {
        this.ui = ui;
        this.initializeEventListeners();
    }

    setFileHandler(fileHandler) {
        this.fileHandler = fileHandler;
    }

    setMedicalNLP(medicalNLP) {
        this.medicalNLP = medicalNLP;
    }

    initializeEventListeners() {
        if (!this.ui) {
            console.error('UI must be set before initializing event listeners');
            return;
        }
        this.ui.generateBtn.addEventListener('click', () => this.handleGenerateClick());
        this.ui.regenerateBtn.addEventListener('click', () => this.regenerateQuestions());
        
        // Connect to the AI model selection dropdown
        this.modelSelectElement = document.getElementById('ai-model');
        if (this.modelSelectElement) {
            this.modelSelectElement.addEventListener('change', () => {
                this.preferredModel = this.modelSelectElement.value;
                console.log(`AI model changed to: ${this.preferredModel}`);
                // Save user preference
                localStorage.setItem('ophthalmoqa_preferred_model', this.preferredModel);
            });
            
            // Set initial value - first check if user has a saved preference
            const savedModel = localStorage.getItem('ophthalmoqa_preferred_model');
            if (savedModel) {
                this.preferredModel = savedModel;
                this.modelSelectElement.value = savedModel;
            } else {
                this.preferredModel = CONFIG.DEFAULT_MODEL || 'gemini';
                this.modelSelectElement.value = this.preferredModel;
            }
            
            console.log(`Initial AI model set to: ${this.preferredModel}`);
        }
    }

    async handleGenerateClick() {
        if (this.ui.isProcessing) return;

        const settings = this.gatherSettings();
        if (!this.validateSettings(settings)) return;

        // Check if user is trying to use premium features
        const isPremiumFeature = this.isPremiumFeatureRequest(settings);
        
        // If requesting premium features, check access
        if (isPremiumFeature) {
            const donationHandler = window.donationHandler;
            if (donationHandler && !donationHandler.checkPremiumAccess()) {
                return; // Premium check failed and message was shown
            }
        }

        try {
            const sourceContent = await this.prepareSourceContent(settings);
            if (!sourceContent) return;

            this.lastSettings = settings;
            await this.generateQuestions(sourceContent, settings);
        } catch (error) {
            console.error('Generation Error:', error);
            this.ui.showStatus(`Error generating questions: ${error.message}`, 'error');
        }
    }

    gatherSettings() {
        return {
            inputType: this.ui.inputTypeSelect.value,
            source: '',  // Will be set during content preparation
            subspecialty: this.ui.knowledgeAreaSelect.value,
            subspecialtyText: this.ui.knowledgeAreaSelect.options[this.ui.knowledgeAreaSelect.selectedIndex].text,
            questionTypes: Object.keys(this.ui.questionTypeCheckboxes).reduce((acc, key) => {
                if (this.ui.questionTypeCheckboxes[key].checked) acc[key] = true;
                return acc;
            }, {}),
            difficulty: this.ui.difficultySelect.value,
            numQuestions: parseInt(this.ui.numQuestionsInput.value, 10),
            focusArea: this.ui.focusAreaInput.value.trim(),
            showAnswersDefault: this.ui.showAnswersDefaultCheckbox.checked
        };
    }

    validateSettings(settings) {
        if (Object.keys(settings.questionTypes).length === 0) {
            this.ui.showStatus('Please select at least one question type.', 'warning');
            return false;
        }
        if (settings.numQuestions < 1 || settings.numQuestions > 50) {
            this.ui.showStatus('Please enter a number of questions between 1 and 50.', 'warning');
            return false;
        }
        return true;
    }

    async prepareSourceContent(settings) {
        let sourceContent = '';
        
        if (settings.inputType === 'upload') {
            if (!this.fileHandler.currentPdfFile) {
                this.ui.showStatus('Please select a document first.', 'warning');
                return null;
            }
            
            const fileName = this.fileHandler.currentPdfFile.name;
            settings.source = fileName;
            
            // Check file extension
            const isPdf = fileName.toLowerCase().endsWith('.pdf');
            const isTxt = fileName.toLowerCase().endsWith('.txt');
            const isRtf = fileName.toLowerCase().endsWith('.rtf');
            const isDocx = fileName.toLowerCase().endsWith('.docx');
            const isMd = fileName.toLowerCase().endsWith('.md');
            
            if (isPdf || isTxt || isRtf || isDocx || isMd) {
                // Pass the subspecialty to the extraction process for filtering
                sourceContent = await this.fileHandler.getPdfText(
                    this.fileHandler.currentPdfFile, 
                    settings.subspecialty
                );
                console.log(`Retrieved ${fileName.split('.').pop().toUpperCase()} text with subspecialty filter: ${settings.subspecialty}`);
            } else {
                this.ui.showStatus('Unsupported file type. Please upload a PDF, TXT, RTF, DOCX, or Markdown file.', 'warning');
                return null;
            }
        } 
        else if (settings.inputType === 'text') {
            sourceContent = this.ui.inputTextElement.value.trim();
            if (!sourceContent) {
                this.ui.showStatus('Please enter some text content.', 'warning');
                return null;
            }
            settings.source = "Entered Text";
        }
        else if (settings.inputType === 'notebooklm') {
            if (!window.notebookLmHandler || (typeof window.notebookLmHandler.isInitialized === 'function' && !window.notebookLmHandler.isInitialized())) {
                this.ui.showStatus('Please connect to NotebookLM first.', 'warning');
                return null;
            }
            
            const selectedNotebookId = this.ui.notebookSelect.value;
            if (!selectedNotebookId) {
                this.ui.showStatus('Please select a notebook from the dropdown.', 'warning');
                return null;
            }
            
            try {
                this.ui.showStatus('Fetching content from NotebookLM...', 'info');
                let notebookContent = null;
                if (typeof window.notebookLmHandler.getNotebookContent === 'function') {
                    notebookContent = await window.notebookLmHandler.getNotebookContent(selectedNotebookId);
                } else if (typeof window.notebookLmHandler.getNotebookContentById === 'function') {
                    notebookContent = await window.notebookLmHandler.getNotebookContentById(selectedNotebookId);
                } else {
                    // Fallback: try to read from pasted HTML textarea in the modal
                    const pasted = document.getElementById('notebooklm-code')?.value?.trim();
                    if (pasted && pasted.length > 0) {
                        notebookContent = pasted;
                    }
                }
                if (!notebookContent) {
                    this.ui.showStatus('Failed to retrieve notebook content.', 'error');
                    return null;
                }
                
                sourceContent = notebookContent;
                const notebookTitle = this.ui.notebookSelect.options[this.ui.notebookSelect.selectedIndex].text;
                settings.source = `NotebookLM: ${notebookTitle}`;
                
                this.ui.showStatus('NotebookLM content retrieved successfully.', 'success', 2000);
            } catch (error) {
                console.error('Error fetching NotebookLM content:', error);
                this.ui.showStatus(`Error fetching NotebookLM content: ${error.message}`, 'error');
                return null;
            }
        }
        else if (settings.inputType === 'knowledge-base') {
            if (settings.subspecialty === 'all') {
                settings.source = "All Listed Subspecialties";
                sourceContent = `Generate questions covering various ophthalmology topics suitable for the selected difficulty level.`;
            } else {
                settings.source = settings.subspecialtyText;
                sourceContent = `Generate questions about the ophthalmology subspecialty: ${settings.source}`;
            }
        }
        else if (settings.inputType === 'journal-search') {
            // Check if content was set by the journal search functionality
            if (this.currentContent && this.currentContentSource === 'journal-search') {
                sourceContent = this.currentContent;
                settings.source = "Journal Search Results";
                
                // Clear the content after use
                this.currentContent = null;
                this.currentContentSource = null;
            } else {
                this.ui.showStatus('Please search for papers and select some to generate questions from.', 'warning');
                return null;
            }
        }
        
        // Apply focus keyword filtering if specified
        if (settings.focusArea && settings.focusArea.trim()) {
            console.log(`Filtering content for focus keywords: ${settings.focusArea}`);
            sourceContent = this.filterContentByKeywords(sourceContent, settings.focusArea);
        }

        return sourceContent;
    }
    
    // Helper method to filter content by focus keywords
    filterContentByKeywords(content, keywords) {
        if (!content || !keywords) return content;
        
        // Split the keywords string into individual keywords
        const keywordArray = keywords.split(/[,\s]+/).filter(k => k.length > 2);
        if (keywordArray.length === 0) return content;
        
        console.log(`Filtering content for ${keywordArray.length} keywords: ${keywordArray.join(', ')}`);
        
        // Split content into paragraphs
        const paragraphs = content.split(/\n\s*\n/);
        
        // Filter paragraphs containing at least one keyword
        const relevantParagraphs = paragraphs.filter(paragraph => {
            const lowerParagraph = paragraph.toLowerCase();
            return keywordArray.some(keyword => 
                lowerParagraph.includes(keyword.toLowerCase())
            );
        });
        
        // If no relevant paragraphs found, return the original content
        if (relevantParagraphs.length === 0) {
            console.log('No paragraphs found containing focus keywords. Using full content.');
            return content;
        }
        
        console.log(`Found ${relevantParagraphs.length} paragraphs containing focus keywords out of ${paragraphs.length} total.`);
        return relevantParagraphs.join('\n\n');
    }

    async generateQuestions(sourceContent, settings) {
        this.ui.setProcessingState(true);
        this.ui.qaContainer.innerHTML = '';
        this.ui.showStatus('Generating questions via AI...', 'info');
        
        // Dispatch event for parameter optimization
        const optimizationEvent = new CustomEvent('beforeQuestionsGenerated', {
            detail: {
                parameters: settings,
                sourceContent: sourceContent
            }
        });
        document.dispatchEvent(optimizationEvent);
        
        // Record generation start time for session tracking
        const startTime = Date.now();
        
        // Apply parameter refinement if available
        let refinedSettings = settings;
        if (window.refineGenerationParameters) {
            try {
                const refinement = window.refineGenerationParameters(settings);
                if (refinement.parameters && refinement.confidence > 0.3) {
                    refinedSettings = { ...settings, ...refinement.parameters };
                    
                    // Show refinement notification if significant changes
                    if (refinement.recommendations.length > 0) {
                        this.ui.showStatus(
                            `Applying learned improvements: ${refinement.recommendations.length} optimizations`, 
                            'info'
                        );
                        console.log('Applied parameter refinements:', refinement.recommendations);
                    }
                }
            } catch (error) {
                console.warn('Parameter refinement failed:', error.message);
                // Continue with original settings
            }
        }
        
        try {
            // Use lighter prompt for large content
            const isLargeContent = sourceContent && sourceContent.length > (window.quotaManager ? window.quotaManager.maxContentSize : 50000);
            
            const prompt = this.constructPrompt(sourceContent, refinedSettings);
            let response;
            
            // Safe truncation for AI models that don't handle long content well
            if (isLargeContent && window.quotaManager) {
                console.log("Using truncation safety measures for large content to prevent API errors.");
            }
            
            // Call the appropriate API based on selected model
            switch (this.preferredModel) {
                case 'openai':
                    this.ui.showStatus('Generating questions via OpenAI API...', 'info');
                    response = await this.callOpenAIApi(prompt, settings);
                    break;
                case 'claude':
                    this.ui.showStatus('Generating questions via Claude API...', 'info');
                    response = await this.callClaudeApi(prompt, settings);
                    break;
                case 'biomistral':
                    this.ui.showStatus('Generating questions via BioMistral API...', 'info');
                    response = await this.callBioMistralApi(prompt, settings);
                    break;
                case 'biogpt':
                    this.ui.showStatus('Generating questions via BioGPT API...', 'info');
                    response = await this.callBioGPTApi(prompt, settings);
                    break;
                case 'huggingface':
                    this.ui.showStatus('Generating questions via Hugging Face model...', 'info');
                    response = await window.huggingFaceAPI.generateQuestions(prompt, settings);
                    break;
                case 'cursor-ai':
                    this.ui.showStatus('Generating questions via Cursor AI...', 'info');
                    response = await this.callCursorAiApi(prompt, settings);
                    break;
                case 'gemini':
                default:
                    this.ui.showStatus('Generating questions via Gemini API...', 'info');
                    response = await this.callGeminiApi(prompt, settings);
            }
            
            if (!response) throw new Error('No response from AI API.');
            
            await this.processApiResponse(response, refinedSettings);
            
            // Record generation session for feedback analysis
            if (window.recordGenerationSession) {
                try {
                    const endTime = Date.now();
                    const sessionResults = {
                        questions: this.generatedQuestions,
                        averageConfidence: this.calculateAverageConfidence(),
                        generationTime: endTime - startTime,
                        errors: []
                    };
                    
                    const sessionMetadata = {
                        sessionLength: endTime - startTime,
                        apiModel: this.preferredModel,
                        contentLength: sourceContent ? sourceContent.length : 0
                    };
                    
                    const sessionId = window.recordGenerationSession(
                        refinedSettings, 
                        sessionResults, 
                        sessionMetadata
                    );
                    
                    console.log(`Generation session recorded: ${sessionId}`);
                } catch (error) {
                    console.warn('Failed to record generation session:', error.message);
                }
            }
            
        } catch (error) {
            this.handleApiError(error);
        } finally {
            this.ui.setProcessingState(false);
        }
    }

    async callOpenAIApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('OPENAI')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('OPENAI');
            throw new Error(`OpenAI API quota exceeded. ${quotaMessage}`);
        }
        
        const modelConfig = CONFIG.MODELS.OPENAI;
        const requestBody = {
            model: modelConfig.model,
            messages: [
                {
                    role: "system",
                    content: "You are an expert ophthalmology question generator for medical professionals. Generate questions in perfect JSON format with no additional text."
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            temperature: modelConfig.temperature,
            max_tokens: modelConfig.max_tokens,
            top_p: modelConfig.top_p,
            response_format: { type: "json_object" }
        };

        try {
            const response = await axios.post(this.openaiApiUrl, requestBody, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.openaiApiKey}`
                }
            });
            
            // Consume quota on successful API call
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('OPENAI');
            }
            
            return {
                type: 'openai',
                data: response.data
            };
        } catch (error) {
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'OPENAI')) {
                throw new Error(`OpenAI API quota exceeded. Please upgrade to premium for more requests or try again after logging in.`);
            }
            throw error;
        }
    }

    async callGeminiApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('GEMINI')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('GEMINI');
            throw new Error(`Gemini API quota exceeded. ${quotaMessage}`);
        }
        
        const requestBody = {
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
                responseMimeType: "application/json"
            }
        };

        try {
            const response = await axios.post(`${this.geminiApiUrl}?key=${this.geminiApiKey}`, requestBody, {
                headers: { 'Content-Type': 'application/json' }
            });
            
            // Consume quota on successful API call
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('GEMINI');
            }
            
            return {
                type: 'gemini',
                data: response.data
            };
        } catch (error) {
            console.error('Gemini API error:', error);
            
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'GEMINI')) {
                const quotaMessage = window.quotaManager.getQuotaMessage('GEMINI');
                throw new Error(`Gemini API quota exceeded. ${quotaMessage}`);
            }
            
            // Check for content-related errors that might be due to large input
            if (error.response && (error.response.status === 400 || error.response.status === 413)) {
                console.warn("Possible large content error detected. Attempting to retry with truncated content.");
                
                // If we have a quotaManager, try with severely truncated content as a fallback
                if (window.quotaManager) {
                    const truncatedPrompt = window.quotaManager.safelyTruncateContent(prompt.substring(0, 30000));
                    console.log("Retrying with severely truncated content...");
                    
                    // Create a simplified requestBody with truncated content
                    const retryRequestBody = {
                        contents: [{ parts: [{ text: truncatedPrompt }] }],
                        generationConfig: {
                            responseMimeType: "application/json"
                        }
                    };
                    
                    try {
                        const retryResponse = await axios.post(`${this.geminiApiUrl}?key=${this.geminiApiKey}`, retryRequestBody, {
                            headers: { 'Content-Type': 'application/json' }
                        });
                        
                        // If retry succeeds, consume quota and return
                        window.quotaManager.consumeQuota('GEMINI');
                        return {
                            type: 'gemini',
                            data: retryResponse.data
                        };
                    } catch (retryError) {
                        // If retry also fails, continue to main error handler
                        console.error('Retry with truncated content also failed:', retryError);
                    }
                }
            }
            
            throw error;
        }
    }

    async callClaudeApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('CLAUDE')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('CLAUDE');
            throw new Error(`Claude API quota exceeded. ${quotaMessage}`);
        }
        
        const modelConfig = CONFIG.MODELS.CLAUDE;
        const requestBody = {
            model: modelConfig.model,
            messages: [
                {
                    role: "user",
                    content: prompt
                }
            ],
            temperature: modelConfig.temperature,
            max_tokens: modelConfig.max_tokens,
            system: "You are an expert ophthalmology question generator for medical professionals. Generate questions in perfect JSON format with no additional text."
        };

        try {
            const response = await axios.post(this.claudeApiUrl, requestBody, {
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': this.claudeApiKey,
                    'anthropic-version': '2023-06-01'
                }
            });
            
            // Consume quota on successful API call
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('CLAUDE');
            }
            
            return {
                type: 'claude',
                data: response.data
            };
        } catch (error) {
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'CLAUDE')) {
                throw new Error(`Claude API quota exceeded. Please upgrade to premium for more requests or try again after logging in.`);
            }
            throw error;
        }
    }

    async callBioMistralApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('BIOMISTRAL')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('BIOMISTRAL');
            throw new Error(`BioMistral API quota exceeded. ${quotaMessage}`);
        }
        
        // Verify that the BioMistral API is initialized
        if (!window.bioMistralAPI || !window.bioMistralAPI.isInitialized) {
            if (window.bioMistralAPI) {
                try {
                    await window.bioMistralAPI.initialize();
                } catch (error) {
                    console.error("Failed to initialize BioMistral API:", error);
                    throw new Error("BioMistral server is not available. Please start the server using run_biomistral_server.sh");
                }
            } else {
                throw new Error("BioMistral API is not available");
            }
        }
        
        // Get relevant feedback examples if available
        let feedbackExamples = [];
        if (window.bioMistralAPI.feedbackEnabled && window.questionDatabase) {
            feedbackExamples = window.bioMistralAPI.selectRelevantFeedbackExamples(
                settings.subspecialty,
                settings.questionTypes
            );
        }
        
        try {
            // Make the API call through the BioMistral module
            const responseText = await window.bioMistralAPI.callBioMistralAPI(prompt, feedbackExamples);
            
            // Consume quota if applicable
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('BIOMISTRAL');
            }
            
            return {
                type: 'biomistral',
                data: { content: responseText }
            };
        } catch (error) {
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'BIOMISTRAL')) {
                throw new Error(`BioMistral API quota exceeded. Please try again later.`);
            }
            throw error;
        }
    }

    async callBioGPTApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('BIOGPT')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('BIOGPT');
            throw new Error(`BioGPT API quota exceeded. ${quotaMessage}`);
        }
        
        // Verify that the BioGPT API is initialized
        if (!window.bioGPTAPI || !window.bioGPTAPI.isInitialized) {
            if (window.bioGPTAPI) {
                try {
                    await window.bioGPTAPI.initialize();
                } catch (error) {
                    console.error("Failed to initialize BioGPT API:", error);
                    throw new Error("BioGPT server is not available. Please start the server using run_biogpt_server.sh");
                }
            } else {
                throw new Error("BioGPT API is not available");
            }
        }
        
        try {
            // Prepare configuration for BioGPT API
            const config = {
                content: prompt,
                questionTypes: settings.questionTypes,
                difficulty: settings.difficulty,
                subspecialty: settings.subspecialty,
                focusKeywords: settings.focusArea,
                numQuestions: settings.numQuestions
            };
            
            // Generate questions through the BioGPT API
            const questions = await window.bioGPTAPI.generateQuestions(config);
            
            // Consume quota if applicable
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('BIOGPT');
            }
            
            // Format the response in the expected structure
            return {
                type: 'biogpt',
                data: { 
                    content: JSON.stringify({ questions: questions }),
                    model: 'biogpt-large'
                }
            };
        } catch (error) {
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'BIOGPT')) {
                throw new Error(`BioGPT API quota exceeded. Please try again later.`);
            }
            throw error;
        }
    }

    async callCursorAiApi(prompt, settings) {
        // Check quota before making API call
        if (window.quotaManager && !window.quotaManager.hasQuotaRemaining('CURSOR_AI')) {
            const quotaMessage = window.quotaManager.getQuotaMessage('CURSOR_AI');
            throw new Error(`Cursor AI API quota exceeded. ${quotaMessage}`);
        }
        
        const modelConfig = CONFIG.MODELS.CURSOR_AI;
        
        // Cursor AI uses the user's existing authentication
        try {
            // Construct a request for the Cursor AI API
            const requestBody = {
                messages: [
                    {
                        role: "system",
                        content: "You are an expert ophthalmology question generator for medical professionals. Generate questions in perfect JSON format with no additional text."
                    },
                    {
                        role: "user",
                        content: prompt
                    }
                ],
                model: modelConfig.model,
                temperature: modelConfig.temperature,
                max_tokens: modelConfig.max_tokens,
                format: "json" // Request JSON formatted response
            };

            const response = await axios.post(this.cursorAiApiUrl, requestBody, {
                headers: {
                    'Content-Type': 'application/json',
                    // Uses existing Cursor authentication cookies
                }
            });
            
            // Consume quota on successful API call
            if (window.quotaManager) {
                window.quotaManager.consumeQuota('CURSOR_AI');
            }
            
            return {
                type: 'cursor-ai',
                data: response.data
            };
        } catch (error) {
            console.error('Cursor AI API Error:', error);
            
            // If it's an authentication error, show special message
            if (error.response && error.response.status === 401) {
                throw new Error('Authentication required for Cursor AI. Please ensure you are logged in to Cursor.');
            }
            
            // Check if error is related to quota
            if (window.quotaManager && window.quotaManager.handleApiError(error, 'CURSOR_AI')) {
                throw new Error(`Cursor AI API quota exceeded. Please upgrade to premium for more requests or try again after logging in.`);
            }
            
            throw error;
        }
    }

    constructPrompt(sourceContent, settings) {
        // Safe truncation of source content to prevent quota issues with large files
        let safeContent = sourceContent;
        if (window.quotaManager) {
            safeContent = window.quotaManager.safelyTruncateContent(sourceContent);
            if (safeContent !== sourceContent) {
                console.log("Content was truncated to prevent API quota issues with large file.");
            }
        }
        
        const includedTypes = Object.keys(settings.questionTypes).filter(key => settings.questionTypes[key]);
        const formattedTypes = includedTypes.map(type => {
            switch (type) {
                case 'tf': return 'True/False';
                case 'mcq': return 'Multiple Choice';
                case 'matching': return 'Matching';
                case 'short-answer': return 'Short Answer';
                case 'clinical-case': return 'Clinical Case';
                case 'differential': return 'Differential Diagnosis';
                case 'management': return 'Management';
                case 'viva': return 'VIVA';
                case 'osce': return 'OSCE Stations';
                default: return type;
            }
        }).join(', ');
        
        const outputFormat = this.getOutputFormatSpecification();
        
        // Enhanced subspecialty emphasis - make this strict for ALL input types
        let subspecialtyFocus = '';
        if (settings.subspecialty && settings.subspecialty !== 'general' && settings.subspecialty !== 'all') {
            subspecialtyFocus = `
CRITICAL REQUIREMENT: This is a strict instruction to generate questions ONLY about the ${settings.subspecialtyText} subspecialty of ophthalmology.
- You MUST ONLY generate questions about ${settings.subspecialtyText}
- You MUST ignore ANY content that is not specifically related to ${settings.subspecialtyText}
- If the source content contains minimal information about ${settings.subspecialtyText}, you should use your expert knowledge to generate appropriate questions about ${settings.subspecialtyText}
- Every single question MUST be directly related to ${settings.subspecialtyText}
- Do NOT generate questions about other ophthalmology topics even if they appear in the source content
`;
        }
        
        // Focus keyword emphasis - make this strict for ALL input types
        let focusKeywordEmphasis = '';
        if (settings.focusArea && settings.focusArea.trim()) {
            focusKeywordEmphasis = `
CRITICAL REQUIREMENT: This is a strict instruction to generate questions that focus SPECIFICALLY on: ${settings.focusArea}
- You MUST generate questions that directly involve ${settings.focusArea}
- Every question MUST explicitly mention or address concepts related to ${settings.focusArea}
- If the source content contains limited information about ${settings.focusArea}, use your expert knowledge to create detailed questions about ${settings.focusArea}
- Do NOT generate questions about topics that are unrelated to ${settings.focusArea}, even if they appear in the source content
`;
        }
        
        // Special instructions for management questions
        let managementInstructions = '';
        if (settings.questionTypes['management']) {
            managementInstructions = `
For Management questions:
1. Each question MUST explicitly begin with "How would you manage" or "Describe the management of" a specific condition
2. Answers MUST follow this EXACT structure with these headings:
   - History: (key symptoms and history to obtain)
   - Examination: (specific techniques and findings to look for)
   - Investigations: (appropriate tests and diagnostics)
   - Treatment: (comprehensive management plan)
   - Follow-up: (monitoring plan and follow-up timeline)
3. Make sure each section has 3-5 key points in bullet point format
4. For multiple choice management questions, ensure options represent comprehensive management approaches
5. Management questions MUST focus on conditions that require a multi-step approach
`;
        }
        
        // Special instructions for VIVA questions
        let vivaInstructions = '';
        if (settings.questionTypes['viva']) {
            vivaInstructions = `
For VIVA questions:
1. Create detailed interview-style questions that simulate an oral examination
2. Each VIVA question should:
   - Probe deep understanding of ophthalmology concepts
   - Require detailed explanations of pathophysiology, mechanisms, or clinical reasoning
   - Simulate realistic examiner follow-up questions (e.g., "What if..." scenarios)
3. Answers should be comprehensive, detailed, and demonstrate expert-level knowledge
4. Include both basic opening questions and follow-up questions that challenge the candidate
5. VIVA questions should assess clinical judgment and decision-making skills
`;
        }
        
        // Special instructions for OSCE station questions
        let osceInstructions = '';
        if (settings.questionTypes['osce']) {
            osceInstructions = `
For OSCE Station questions:
1. Create realistic clinical scenarios structured as OSCE stations
2. Each OSCE station should:
   - Begin with a brief scenario and patient information
   - Include specific tasks to be performed (examination, interpretation, communication)
   - Have clear marking criteria in the answer section
3. Cover various skill types: clinical examination, investigation interpretation, communication skills, procedural skills
4. Include time constraints and specific equipment needed for each station
5. Ensure scenarios are realistic and commonly encountered in ophthalmology practice
`;
        }
        
        // Construct the prompt
        return `Generate ${settings.numQuestions} high-quality, medically accurate ophthalmology questions based on the following content. 
${settings.subspecialty && settings.subspecialty !== 'general' && settings.subspecialty !== 'all' ? `Focus ONLY on the ${settings.subspecialtyText} subspecialty.` : 'Focus on general ophthalmology.'}
Question types should be limited to: ${formattedTypes}.
Difficulty level: ${settings.difficulty}.
${settings.focusArea ? `Particularly focus on aspects related to: ${settings.focusArea}.` : ''}
${subspecialtyFocus}
${focusKeywordEmphasis}
${managementInstructions}
${vivaInstructions}
${osceInstructions}

Source content:
${safeContent}

${outputFormat}

Additional requirements:
1. Each question should test understanding of key concepts from the source material
2. Include detailed explanations that cite relevant evidence or guidelines where appropriate
3. Ensure all questions are accurate according to current ophthalmology standards
4. For multiple choice questions, include 4-5 options labeled A, B, C, D, (E)
5. For matching questions, provide 4-6 pairs to match
6. For clinical cases, include relevant history, exam findings, and diagnostic considerations`;
    }

    getOutputFormatSpecification() {
        return `**CRITICAL:** Format the entire output STRICTLY as a single, valid JSON array. Each object in the array represents one question and MUST have these keys:\n
- "type": (string) The type of question (e.g., "mcq", "tf", "matching", "short-answer", "clinical-case", "differential", "management", "viva", "osce"). MUST be one of the requested types.\n
- "question": (string) The full question text.\n
- "options": (array of strings, REQUIRED for "mcq" type, otherwise omit or use null) Multiple-choice options.\n
- "pairs": (array of objects {item: string, match: string}, REQUIRED for "matching" type, otherwise omit or use null) Items and their matches.\n
- "answer": (string) The correct answer.\n
- "explanation": (string) A brief explanation.\n\n
Output ONLY the JSON array. Do not include any introductory text, markdown formatting, or anything else before or after the JSON array itself.`;
    }

    async processApiResponse(response, settings) {
        let jsonText;
        
        if (response.type === 'openai') {
            if (response.data?.choices?.[0]?.message?.content) {
                jsonText = response.data.choices[0].message.content;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        } else if (response.type === 'gemini') {
            if (response.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
                jsonText = response.data.candidates[0].content.parts[0].text;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        } else if (response.type === 'claude') {
            if (response.data?.content?.[0]?.text) {
                jsonText = response.data.content[0].text;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        } else if (response.type === 'biogpt') {
            // BioGPT already returns structured data that we prepared in the callBioGPTApi function
            if (response.data?.content) {
                jsonText = response.data.content;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        } else if (response.type === 'cursor-ai') {
            if (response.data?.response) {
                jsonText = response.data.response;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        }
        
        try {
            // Handle the case where the API returns a JSON object with an array inside
            let parsedContent = JSON.parse(jsonText);
            
            // Check if we got an object with a questions array inside
            if (parsedContent.questions && Array.isArray(parsedContent.questions)) {
                this.generatedQuestions = parsedContent.questions;
            } 
            // Check if we got an array directly
            else if (Array.isArray(parsedContent)) {
                this.generatedQuestions = parsedContent;
            }
            // If we got an object but not array format, try to normalize it
            else if (typeof parsedContent === 'object') {
                // Try to extract an array of questions
                const possibleQuestions = Object.values(parsedContent).find(val => 
                    Array.isArray(val) && val.length > 0 && val[0].type && val[0].question
                );
                
                if (possibleQuestions) {
                    this.generatedQuestions = possibleQuestions;
                } else {
                    throw new Error("API response is not a JSON array or object with questions.");
                }
            } else {
                throw new Error("API response is not a valid JSON array or object.");
            }
            
            if (!this.generatedQuestions || !Array.isArray(this.generatedQuestions)) {
                throw new Error("API response is not a JSON array.");
            }

            // Add unique question IDs to each question for tracking in feedback system
            const timestamp = Date.now();
            this.generatedQuestions = this.generatedQuestions.map((question, index) => {
                return {
                    ...question,
                    id: `q-${timestamp}-${index}`,
                    generatedAt: new Date().toISOString(),
                    model: response.type,
                    settings: {
                        difficulty: settings.difficulty,
                        subspecialty: settings.subspecialty,
                        focusArea: settings.focusArea
                    }
                };
            });

            // Apply ML filtering if available to enhance questions
            if (this.mlProcessor) {
                // Process the questions to add ML-derived insights or improvements
                const enhancedQuestions = this.enhanceQuestionsWithML(this.generatedQuestions);
                if (enhancedQuestions && enhancedQuestions.length > 0) {
                    this.generatedQuestions = enhancedQuestions;
                }
            }
            
            // Do NOT store questions in tracking set yet - they'll be marked as duplicates in future generations
            // We only want to mark questions from previous generations as duplicates
            // The questions will be added to the tracking set when regenerateQuestions is called
            
            // Add generated questions to the database (requirement #2)
            if (this.database) {
                const metadata = {
                    source: settings.source,
                    subspecialty: settings.subspecialty,
                    difficulty: settings.difficulty,
                    generated: new Date().toISOString(),
                    model: response.type
                };
                
                const addedCount = this.database.addQuestions(this.generatedQuestions, metadata);
                console.log(`Added ${addedCount} new questions to database`);
            }

            const validationResult = this.validateGeneratedQuestions(settings);
            if (validationResult.warnings.length > 0) {
                this.ui.showStatus(`Generated ${this.generatedQuestions.length} questions. Note: ${validationResult.warnings.join(' ')}`, 'warning');
            } else {
                this.ui.showStatus(`Successfully generated ${this.generatedQuestions.length} questions.`, 'success');
            }

            this.displayQuestions(settings.showAnswersDefault);
            this.ui.updateButtonStates(true);

        } catch (parseError) {
            console.error('JSON Parsing Error:', parseError);
            console.error('Raw API Response Text:', jsonText);
            this.ui.showStatus('Error: API response was not valid JSON. Check console.', 'error');
            this.ui.qaContainer.innerHTML = `<p class="empty-state text-red-600">Failed to parse API response. Raw response logged to console.</p>`;
            this.ui.updateButtonStates(false);
        }
    }
    
    /**
     * Enhance questions with ML-derived insights
     * @param {Array} questions - Questions to enhance
     * @returns {Array} - Enhanced questions
     */
    enhanceQuestionsWithML(questions) {
        if (!this.mlProcessor || !questions || !Array.isArray(questions)) {
            return questions;
        }
        
        try {
            // Apply ML enhancements to each question
            return questions.map(question => {
                // Extract key medical entities from question text and explanation
                const questionEntities = this.mlProcessor.extractMedicalEntities(question.question);
                let explanationEntities = {};
                
                if (question.explanation) {
                    explanationEntities = this.mlProcessor.extractMedicalEntities(question.explanation);
                }
                
                // Enhance explanation with additional entities if they're mentioned in the question
                // but not in the explanation
                if (question.explanation) {
                    // Find drugs mentioned in question but not in explanation
                    const missingDrugs = questionEntities.drugs?.filter(drug => 
                        !explanationEntities.drugs?.includes(drug)
                    );
                    
                    // Find conditions mentioned in question but not in explanation
                    const missingConditions = questionEntities.conditions?.filter(condition => 
                        !explanationEntities.conditions?.includes(condition)
                    );
                    
                    // Add detail about missing entities if needed
                    if ((missingDrugs && missingDrugs.length > 0) || 
                        (missingConditions && missingConditions.length > 0)) {
                        
                        let additionalInfo = '';
                        
                        if (missingDrugs && missingDrugs.length > 0) {
                            additionalInfo += ` Note: ${missingDrugs.join(', ')} ${missingDrugs.length === 1 ? 'is' : 'are'} an important medication to consider in this context.`;
                        }
                        
                        if (missingConditions && missingConditions.length > 0) {
                            additionalInfo += ` Note that ${missingConditions.join(', ')} ${missingConditions.length === 1 ? 'is' : 'are'} particularly relevant here.`;
                        }
                        
                        question.explanation += additionalInfo;
                    }
                }
                
                return question;
            });
        } catch (error) {
            console.error('Error enhancing questions with ML:', error);
            return questions; // Return original questions if enhancement fails
        }
    }

    validateGeneratedQuestions(settings) {
        const warnings = [];
        if (this.generatedQuestions.length !== settings.numQuestions) {
            warnings.push(`Generated ${this.generatedQuestions.length} questions (requested ${settings.numQuestions}).`);
        }

        // Use the feedback parameter optimizer to correct question types
        if (window.feedbackParameterOptimizer) {
            const result = window.feedbackParameterOptimizer.validateAndCorrectQuestionTypes(
                this.generatedQuestions, 
                settings.questionTypes
            );
            
            this.generatedQuestions = result.questions;
            
            if (result.corrections.size > 0) {
                const correctionsList = Array.from(result.corrections.entries())
                    .map(([orig, corrected]) => `${orig} → ${corrected}`)
                    .join(', ');
                warnings.push(`Auto-corrected question types: ${correctionsList}.`);
            }
        } else {
            // Fallback to original validation
            const generatedTypes = new Set(this.generatedQuestions.map(q => q.type));
            const requestedTypes = new Set(Object.keys(settings.questionTypes));
            const unexpectedTypes = [...generatedTypes].filter(t => !requestedTypes.has(t));
            if (unexpectedTypes.length > 0) {
                warnings.push(`Generated unexpected question types: ${unexpectedTypes.join(', ')}.`);
            }
        }

        return { warnings };
    }

    handleApiError(error) {
        console.error('API Call Error:', error);
        let errorMsg = 'An error occurred during the API call.';
        
        // Check if error message contains quota information
        const isQuotaError = error.message && (
            error.message.includes('quota') || 
            error.message.includes('API quota exceeded')
        );
        
        if (isQuotaError) {
            errorMsg = error.message;
            
            // Check if user is the creator (no quota limit)
            const isCreator = window.quotaManager && window.quotaManager.isCreator;
            if (isCreator) {
                errorMsg = "An unexpected API error occurred even with creator privileges. Please try again with a different model or smaller content.";
            } 
            // Otherwise suggest logging in to reset quota or upgrading to premium
            else {
                // Suggest logging in to reset quota
                const authManager = window.authManager;
                if (authManager && !authManager.isLoggedIn) {
                    errorMsg += ' Please log in to reset your API quota.';
                    
                    // Show login modal after a short delay
                    setTimeout(() => {
                        authManager.showLoginModal();
                    }, 2000);
                }
                
                // Suggest premium upgrade for more quota
                if (window.donationHandler && (!authManager || !authManager.currentUser?.premium)) {
                    errorMsg += ' Consider upgrading to premium for higher API limits.';
                    
                    // Highlight donation section
                    window.donationHandler.showDonationMessage();
                }
            }
        }
        // Special handling for large file errors
        else if (error.message && error.message.includes('large')) {
            errorMsg = `The content is too large for processing. Please try with a smaller document or text selection.`;
        }
        // Regular API errors
        else if (error.response) {
            console.error('API Error Data:', error.response.data);
            errorMsg = `API Error (${error.response.status}): ${error.response.data?.error?.message || 'Check console.'}`;
        } else if (error.request) {
            errorMsg = 'API Error: No response received from the server.';
        } else {
            errorMsg = `API Setup Error: ${error.message}`;
        }
        
        this.ui.showStatus(errorMsg, isQuotaError ? 'warning' : 'error');
        this.ui.qaContainer.innerHTML = `<p class="empty-state text-red-600">${errorMsg}</p>`;
        this.ui.updateButtonStates(false);
    }

    handleInvalidApiResponse(response) {
        console.error('Unexpected API response structure:', response.data);
        let errorMessage = 'Error: Unexpected API response structure.';
        
        if (response.data?.error?.message) {
            errorMessage = `API Error: ${response.data.error.message}`;
        } else if(response.data?.promptFeedback?.blockReason) {
            errorMessage = `API Error: Request blocked - ${response.data.promptFeedback.blockReason}. Reason: ${response.data.promptFeedback.safetyRatings?.map(r => `${r.category}: ${r.probability}`).join(', ') ?? 'Unknown'}`;
        }
        
        this.ui.showStatus(errorMessage, 'error');
        this.ui.qaContainer.innerHTML = `<p class="empty-state text-red-600">${errorMessage}</p>`;
        this.ui.updateButtonStates(false);
    }

    displayQuestions(showAnswersDefault) {
        if (!this.generatedQuestions || this.generatedQuestions.length === 0) {
            this.ui.qaContainer.innerHTML = '<p class="empty-state">No questions generated yet.</p>';
            return;
        }

        let html = '';
        this.generatedQuestions.forEach((item, index) => {
            // We'll check for duplicates but not add to the tracking set yet
            // This ensures only questions from previous generations are considered duplicates
            html += this.generateQuestionHTML(item, index, showAnswersDefault);
        });

        this.ui.qaContainer.innerHTML = html;
        
        // We no longer need to add event listeners here as they're handled by UI.handleQuestionClick
        // which uses event delegation on the qa-container
        
        console.log(`Displayed ${this.generatedQuestions.length} questions. ${this.previouslyGeneratedQuestions.size} questions in duplicate tracking.`);
        
        // Dispatch event for question generation tracking
        const eventName = this.isRegeneration ? 'questionsRegenerated' : 'questionsGenerated';
        const settings = this.lastSettings || {};
        
        // Create and dispatch custom event with question data
        const event = new CustomEvent(eventName, {
            detail: {
                questions: this.generatedQuestions.map(q => ({
                    id: q.id || `q-${Date.now()}-${Math.random().toString(36).substring(2)}`,
                    question: q.question || q.text || '',
                    type: q.type || 'unknown',
                    answer: q.answer || '',
                    generatedAt: q.generatedAt || new Date().toISOString(),
                    model: q.model || 'unknown',
                    settings: q.settings || {
                        difficulty: settings.difficulty || 'unknown',
                        subspecialty: settings.subspecialty || 'general',
                        focusArea: settings.focusArea || ''
                    }
                })),
                metadata: {
                    difficulty: settings.difficulty || 'unknown',
                    numQuestions: this.generatedQuestions.length,
                    knowledgeArea: settings.subspecialty || 'general',
                    questionTypes: settings.questionTypes || {},
                    focusArea: settings.focusArea || '',
                    timestamp: new Date().toISOString(),
                    isRegeneration: this.isRegeneration,
                    aiModel: this.preferredModel || 'unknown'
                }
            }
        });
        
        document.dispatchEvent(event);
        console.log(`Dispatched ${eventName} event with ${this.generatedQuestions.length} questions`);
        
        // Reset regeneration flag
        this.isRegeneration = false;
    }

    generateQuestionHTML(item, index, showAnswersDefault) {
        const questionId = item.id || `question-${Date.now()}-${index}`;
        const type = item.type || 'mcq';
        const isRepeat = this.isFromPriorSession(item.question);
        
        // Add the question to our tracking set
        this.previouslyGeneratedQuestions.add(item.question);
        
        // Check if this is a management question to format the answer appropriately
        let formattedAnswer = item.answer;
        if (type === 'management' && this.ui) {
            // Format the management answer with proper section highlighting
            formattedAnswer = this.formatManagementAnswer(item.answer);
        } else if (this.ui) {
            formattedAnswer = this.ui.sanitizeHTML(item.answer);
        }
        
        let html = `
            <div class="question-item rounded-lg border border-gray-200 p-4 relative" 
                data-id="${questionId}" 
                data-type="${type}" 
                data-question-id="${questionId}" 
                data-generation-time="${item.generatedAt || new Date().toISOString()}" 
                data-model="${item.model || 'unknown'}"
                data-difficulty="${item.settings?.difficulty || 'unknown'}">
                <div class="question-select-checkbox-container hidden">
                    <input type="checkbox" class="question-select-checkbox h-5 w-5 text-purple-600 focus:ring-purple-500 border-gray-300 rounded">
                </div>
                <div class="flex justify-between items-start mb-2">
                    <div class="flex items-center"><span class="inline-block bg-gray-700 text-white text-sm font-bold px-2.5 py-0.5 rounded-full mr-2">${index + 1}</span><span class="inline-block bg-primary text-white text-xs px-2 py-1 rounded-md">${type.toUpperCase()}</span></div>
                    <div class="flex items-center space-x-2">
                        ${isRepeat ? `<i class="fas fa-exclamation-circle text-amber-500 text-lg" title="Similar question seen before"></i>` : ''}
                        <div class="feedback-container flex items-center">
                            <button class="feedback-btn text-gray-400 hover:text-green-500 px-1" data-feedback="like" data-id="${questionId}">
                                <i class="far fa-thumbs-up"></i>
                            </button>
                            <button class="feedback-btn text-gray-400 hover:text-red-500 px-1" data-feedback="dislike" data-id="${questionId}">
                                <i class="far fa-thumbs-down"></i>
                            </button>
                            <span class="feedback-thank-you text-green-500 text-sm ml-2 hidden">Thank you!</span>
                        </div>
                    </div>
                </div>
                <div class="question-text mb-3 text-gray-800">${this.ui ? this.ui.sanitizeHTML(item.question) : item.question}</div>
                ${this.generateOptionsOrPairsHTML(item, type)}
                <div class="answer-container mt-3 pt-3 border-t border-gray-200 ${showAnswersDefault ? '' : 'hidden'}">
                    <div class="font-semibold text-primary mb-1">Answer:</div>
                    <div class="answer-text">${formattedAnswer}</div>
                    <div class="explanation-text mt-2 text-sm text-gray-700">${this.ui ? this.ui.sanitizeHTML(item.explanation || '') : (item.explanation || '')}</div>
                </div>
                
                <!-- Image container for displaying generated images -->
                <div class="ophthalmic-image-container mt-3 pt-3 border-t border-gray-200 hidden">
                    <div class="text-center">
                        <img src="" alt="Ophthalmic Image" class="ophthalmic-image max-w-full max-h-[300px] mx-auto object-contain rounded-lg border border-gray-200 shadow-sm">
                        <p class="text-sm text-gray-600 mt-2 image-caption"></p>
                    </div>
                </div>
                
                <div class="mt-3 flex flex-wrap gap-2 items-center justify-between">
                    <div class="flex flex-wrap gap-2">
                        <button class="toggle-answer text-sm bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded-md transition flex items-center">
                            <i class="fas fa-eye${showAnswersDefault ? '-slash' : ''} mr-1"></i>
                            ${showAnswersDefault ? 'Hide' : 'Show'} Answer
                        </button>
                        <button class="deep-search-btn text-sm bg-indigo-100 hover:bg-indigo-200 text-indigo-800 px-3 py-1 rounded-md transition flex items-center" data-id="${questionId}">
                            <i class="fas fa-search-plus mr-1"></i>
                            Deep Search
                        </button>
                    </div>
                    <button class="show-image-btn text-sm bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1 rounded-md transition flex items-center" data-id="${questionId}">
                        <i class="fas fa-image mr-1"></i>
                        Show Image
                    </button>
                </div>
                <div class="deep-search-result mt-3 pt-3 border-t border-gray-200 hidden"></div>
            </div>
        `;
        
        return html;
    }

    generateOptionsOrPairsHTML(item, type) {
        let html = '';
        if (type === 'mcq' && Array.isArray(item.options)) {
            html += '<div class="options space-y-1 pl-6 mt-2 mb-2">';
            item.options.forEach((option, i) => {
                html += `<div class="text-sm text-gray-700"><strong class="mr-1">${String.fromCharCode(65 + i)}.</strong> ${this.ui.sanitizeHTML(option)}</div>`;
            });
            html += '</div>';
        } else if (type === 'matching' && Array.isArray(item.pairs)) {
            html += '<div class="matching-pairs grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 pl-6 mt-2 mb-2">';
            item.pairs.forEach((pair) => {
                if (pair && pair.item && pair.match) {
                    html += `<div class="text-sm text-gray-700">${this.ui.sanitizeHTML(pair.item)}</div><div class="text-sm text-gray-700">→ ${this.ui.sanitizeHTML(pair.match)}</div>`;
                }
            });
            html += '</div>';
        } else {
            html += '<div class="mb-2"></div>';
        }
        return html;
    }

    async regenerateQuestions() {
        if (!this.lastSettings) {
            this.ui.showStatus('No previous settings found to regenerate.', 'warning');
            return;
        }
        if (this.ui.isProcessing) return;
        
        // Set regeneration flag to true
        this.isRegeneration = true;
        
        this.ui.setProcessingState(true);
        this.ui.qaContainer.innerHTML = '';
        this.ui.showStatus('Regenerating new questions via Gemini API...', 'info');
        
        try {
            // Store current questions in the tracking set to avoid repetition in THIS session
            if (this.generatedQuestions && this.generatedQuestions.length > 0) {
                this.generatedQuestions.forEach(q => {
                    if (q.question) this.previouslyGeneratedQuestions.add(q.question);
                    else if (q.text) this.previouslyGeneratedQuestions.add(q.text);
                });
                
                // Log the total number of tracked questions
                console.log(`Added current questions to tracking. Now tracking ${this.previouslyGeneratedQuestions.size} questions for regeneration.`);
                
                // Save to localStorage for future sessions
                this.saveQuestionsToLocalStorage();
            }
            
            // Clear extracted PDF text cache to ensure we get fresh content with correct subspecialty filtering
            if (this.fileHandler && this.lastSettings.inputType === 'upload') {
                console.log(`Clearing cached PDF text to ensure subspecialty filter "${this.lastSettings.subspecialty}" is applied`);
                this.fileHandler.extractedPdfText = null;
            }
            
            // Prepare source content again - this will now apply the subspecialty filter correctly
            const sourceContent = await this.prepareSourceContent(this.lastSettings);
            if (!sourceContent) {
                this.ui.setProcessingState(false);
                return;
            }
            
            // Force using Gemini API for regeneration as per requirements
            const originalModel = this.preferredModel;
            this.preferredModel = 'gemini';
            
            // Create enhanced prompt that specifies not to repeat questions
            const basePrompt = this.constructPrompt(sourceContent, this.lastSettings);
            let enhancedPrompt = basePrompt + "\n\nIMPORTANT: Generate entirely NEW questions that are different from previously generated ones. Avoid similar patterns, wording, or scenarios. Ensure each question explores different aspects of the topic.";
            
            // Apply ML enhancements if available
            if (this.mlProcessor) {
                // Process the source content with ML techniques
                const processedContent = this.mlProcessor.processContent(sourceContent);
                
                // Enhance the prompt with ML-derived insights
                enhancedPrompt = this.mlProcessor.enhancePromptWithML(enhancedPrompt, processedContent);
            }
            
            // Add strict constraints for subspecialty focus
            if (this.lastSettings.subspecialty && this.lastSettings.subspecialty !== 'general' && this.lastSettings.subspecialty !== 'all') {
                enhancedPrompt += `\n\nSTRICT REQUIREMENT: Generate questions EXCLUSIVELY about the ${this.lastSettings.subspecialtyText} subspecialty. 
- Each and every question MUST be clearly related to ${this.lastSettings.subspecialtyText}
- DO NOT generate any questions about other ophthalmology topics, even if they appear in the source material
- If needed, modify aspects of the source content to make it relevant to ${this.lastSettings.subspecialtyText}
- I will reject any questions that are not specifically about ${this.lastSettings.subspecialtyText}`;
                
                console.log(`Added strict subspecialty focus requirement for: ${this.lastSettings.subspecialtyText}`);
            }
            
            // Add strict constraints for focus keywords
            if (this.lastSettings.focusArea && this.lastSettings.focusArea.trim()) {
                const focusKeywords = this.lastSettings.focusArea.trim();
                enhancedPrompt += `\n\nSTRICT REQUIREMENT: Generate questions EXCLUSIVELY about: ${focusKeywords}. 
- Each and every question MUST directly involve ${focusKeywords}
- Every question MUST explicitly mention or address ${focusKeywords} or directly related concepts
- DO NOT generate questions about other topics, even if they appear in the source material
- If needed, use your expert knowledge to create detailed questions about ${focusKeywords}
- I will reject any questions that do not specifically address ${focusKeywords}`;
                
                console.log(`Added strict focus keyword requirement for: "${focusKeywords}"`);
            }
            
            // Call the Gemini API with enhanced prompt
            const response = await this.callGeminiApi(enhancedPrompt, this.lastSettings);
            
            // Process response
            await this.processRegeneratedResponse(response, this.lastSettings);
            
            // Restore original model preference
            this.preferredModel = originalModel;
            
        } catch (error) {
            console.error('Regeneration Error:', error);
            this.handleApiError(error);
        } finally {
            this.ui.setProcessingState(false);
        }
    }
    
    /**
     * Save current questions to localStorage for future sessions
     * This allows us to mark duplicates across sessions
     */
    saveQuestionsToLocalStorage() {
        try {
            // Only store a reasonable number of questions (max 500)
            const questionsToStore = [];
            
            // First add questions from current generation
            if (this.generatedQuestions && this.generatedQuestions.length > 0) {
                this.generatedQuestions.forEach(q => {
                    if (q.question && !questionsToStore.includes(q.question)) {
                        questionsToStore.push(q.question);
                        // Also add to priorSessionQuestions for immediate use
                        this.priorSessionQuestions.add(q.question);
                    } else if (q.text && !questionsToStore.includes(q.text)) {
                        questionsToStore.push(q.text);
                        // Also add to priorSessionQuestions for immediate use
                        this.priorSessionQuestions.add(q.text);
                    }
                });
            }
            
            // Then add questions from prior sessions
            this.priorSessionQuestions.forEach(q => {
                if (!questionsToStore.includes(q)) {
                    questionsToStore.push(q);
                }
            });
            
            // Limit to 500 questions
            const limitedQuestions = questionsToStore.slice(0, 500);
            
            // Save to localStorage
            localStorage.setItem('ophthalmoqa_prior_questions', JSON.stringify(limitedQuestions));
            console.log(`Saved ${limitedQuestions.length} questions to localStorage for future sessions`);
        } catch (err) {
            console.error('Error saving questions to localStorage:', err);
        }
    }

    /**
     * Add event listener for beforeunload to save questions when user leaves
     */
    setupBeforeUnloadHandler() {
        window.addEventListener('beforeunload', () => {
            this.saveQuestionsToLocalStorage();
        });
    }

    /**
     * Process API response specifically for regenerated questions
     * @param {Object} response - API response from Gemini
     * @param {Object} settings - Question generation settings
     */
    async processRegeneratedResponse(response, settings) {
        let jsonText;
        
        // Extract response text based on API type (should be Gemini in this case)
        if (response.type === 'gemini') {
            if (response.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
                jsonText = response.data.candidates[0].content.parts[0].text;
            } else {
                this.handleInvalidApiResponse(response);
                return;
            }
        } else {
            console.warn('Unexpected API type for regeneration:', response.type);
            jsonText = await this.extractJsonFromResponse(response);
        }
        
        if (!jsonText) {
            this.ui.showStatus('Error: Could not extract valid JSON from API response.', 'error');
            return;
        }
        
        try {
            // Parse the JSON response
            let parsedQuestions = this.parseQuestionsFromJson(jsonText);
            if (!parsedQuestions || !Array.isArray(parsedQuestions) || parsedQuestions.length === 0) {
                throw new Error('Failed to parse questions from API response');
            }
            
            console.log(`Parsed ${parsedQuestions.length} questions from API response`);
            
            // Filter out questions that are too similar to previously generated ones
            let filteredQuestions = parsedQuestions;
            
            // Check subspecialty relevance if a specific subspecialty is selected
            if (settings.subspecialty && settings.subspecialty !== 'general' && settings.subspecialty !== 'all') {
                console.log(`Validating regenerated questions for relevance to ${settings.subspecialtyText}`);
                
                // Get the subspecialty keywords to check against
                const subspecialtyKeywords = this.fileHandler?.subspecialtyKeywords?.[settings.subspecialty] || [];
                
                if (subspecialtyKeywords.length > 0) {
                    // Create regex patterns from keywords for matching
                    const keywordRegexes = subspecialtyKeywords.map(keyword => 
                        new RegExp('\\b' + keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'i')
                    );
                    
                    // Filter questions that contain at least one subspecialty keyword
                    filteredQuestions = parsedQuestions.filter(question => {
                        const fullText = (question.question || '') + 
                                        (question.answer || '') + 
                                        (question.explanation || '');
                        
                        // Check if any keyword matches
                        return keywordRegexes.some(regex => regex.test(fullText));
                    });
                    
                    console.log(`After subspecialty validation: ${filteredQuestions.length}/${parsedQuestions.length} questions retained`);
                    
                    // If we filtered too many questions, restore some to meet the requested number
                    if (filteredQuestions.length < settings.numQuestions * 0.5 && parsedQuestions.length > 0) {
                        console.log(`Too many questions filtered out by subspecialty. Using original set.`);
                        filteredQuestions = parsedQuestions;
                    }
                }
            }
            
            // Check focus keyword relevance if specified
            if (settings.focusArea && settings.focusArea.trim()) {
                console.log(`Validating regenerated questions for relevance to focus keywords: ${settings.focusArea}`);
                
                // Split focus keywords by commas or spaces for more precise matching
                const focusKeywords = settings.focusArea.split(/[,\s]+/).filter(k => k.length > 2);
                
                if (focusKeywords.length > 0) {
                    // Create regex patterns from keywords for matching
                    const keywordRegexes = focusKeywords.map(keyword => 
                        new RegExp('\\b' + keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'i')
                    );
                    
                    // Filter questions that contain at least one focus keyword
                    const keywordFilteredQuestions = filteredQuestions.filter(question => {
                        const fullText = (question.question || '') + 
                                        (question.answer || '') + 
                                        (question.explanation || '');
                        
                        // Check if any keyword matches
                        return keywordRegexes.some(regex => regex.test(fullText));
                    });
                    
                    console.log(`After focus keyword validation: ${keywordFilteredQuestions.length}/${filteredQuestions.length} questions retained`);
                    
                    // If we filtered too many questions, restore some to meet the requested number
                    if (keywordFilteredQuestions.length < settings.numQuestions * 0.5 && filteredQuestions.length > 0) {
                        console.log(`Too many questions filtered out by focus keywords. Using previous set.`);
                    } else {
                        filteredQuestions = keywordFilteredQuestions;
                    }
                }
            }
            
            // Filter out questions that are too similar to previously generated ones
            if (this.previouslyGeneratedQuestions.size > 0) {
                const originalCount = filteredQuestions.length;
                const similarityThreshold = 0.8; // Adjust threshold as needed
                
                filteredQuestions = filteredQuestions.filter(question => {
                    const questionText = question.question || '';
                    
                    // Check if this question is too similar to any previously generated ones
                    for (const prevQuestion of this.previouslyGeneratedQuestions) {
                        const similarity = this.calculateBasicSimilarity(questionText, prevQuestion);
                        if (similarity > similarityThreshold) {
                            return false; // Filter out this question
                        }
                    }
                    
                    return true; // Keep this question
                });
                
                console.log(`After similarity filtering: ${filteredQuestions.length}/${originalCount} questions retained`);
                
                // If we filtered too many questions, restore some to meet the requested number
                if (filteredQuestions.length === 0 && parsedQuestions.length > 0) {
                    console.log('All questions were filtered out. Using a few from original set.');
                    filteredQuestions = parsedQuestions.slice(0, Math.min(3, parsedQuestions.length));
                }
            }
            
            // Update the generated questions and display them
            this.generatedQuestions = filteredQuestions;
            this.displayQuestions(settings.showAnswersDefault);
            
            // Show success message with appropriate counts
            if (filteredQuestions.length < parsedQuestions.length) {
                this.ui.showStatus(`Generated ${filteredQuestions.length} new questions (${parsedQuestions.length - filteredQuestions.length} filtered out for relevance).`, 'success');
            } else {
                this.ui.showStatus(`Generated ${filteredQuestions.length} new questions.`, 'success');
            }
            
        } catch (error) {
            console.error('Error processing regenerated response:', error);
            this.ui.showStatus(`Error processing regenerated questions: ${error.message}`, 'error');
        }
    }
    
    /**
     * Check if a question is from a prior session (for exclamation mark display)
     * @param {string} questionText - Question text to check
     * @returns {boolean} - True if the question is from a prior session
     */
    isFromPriorSession(questionText) {
        if (!questionText || this.priorSessionQuestions.size === 0) {
            return false;
        }
        
        // First check for exact matches (case-insensitive but otherwise exact)
        const normalizedQuestion = questionText.toLowerCase().trim().replace(/\s+/g, ' ');
        
        for (const prevQuestion of this.priorSessionQuestions) {
            const normalizedPrev = prevQuestion.toLowerCase().trim().replace(/\s+/g, ' ');
            
            // Only consider actual duplicates or extremely similar questions (95%+ similarity)
            if (normalizedQuestion === normalizedPrev) {
                return true;
            }
            
            // For near-exact matches, require at least 95% similarity
            // and only compare questions with similar length (within 10%)
            const lengthRatio = Math.max(normalizedQuestion.length, normalizedPrev.length) / 
                               Math.min(normalizedQuestion.length, normalizedPrev.length);
                               
            if (lengthRatio <= 1.1) { // Questions of similar length (within 10%)
                const similarity = this.calculateBasicSimilarity(normalizedQuestion, normalizedPrev);
                if (similarity > 0.95) { // Only flag if >95% similar
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Calculate basic similarity between two question strings
     * @param {string} str1 - First string
     * @param {string} str2 - Second string
     * @returns {number} - Similarity score (0-1)
     */
    calculateBasicSimilarity(str1, str2) {
        // If strings are identical
        if (str1 === str2) return 1.0;
        
        // More sophisticated similarity calculation for medical questions
        // Focus on significant terms and normalize medical terminology
        
        // Extract significant words (keep important medical terms regardless of length)
        const significantWords = word => {
            // Keep medical abbreviations and specialized terms regardless of length
            const isMedicalTerm = /^(iop|amd|ocl|ocr|oct|icg|fa|rvo|armd|iol|od|os|ou|va|rv|lv|rpe|cme|pdr|pst|oht|pcg|aion|crao|crvo|brvo|dr|dme|hm|cf|pl|dpa|npa|ac|pc|pxg|prp|mk|rx|dx|tx|fx|hx|cx)$/i.test(word) || 
                                /^(glauc|retin|macula|papil|conjunct|kerato|uvei|catar|prism|endo)/i.test(word);
            
            return word.length > 3 || isMedicalTerm;
        };
        
        // Split into words and keep only significant ones
        const words1 = new Set(str1.split(/\s+/)
            .map(w => w.replace(/[.,?;:!()]/g, '').toLowerCase())
            .filter(significantWords));
            
        const words2 = new Set(str2.split(/\s+/)
            .map(w => w.replace(/[.,?;:!()]/g, '').toLowerCase())
            .filter(significantWords));
        
        if (words1.size === 0 || words2.size === 0) return 0;
        
        // Count intersections
        let intersection = 0;
        for (const word of words1) {
            if (words2.has(word)) intersection++;
        }
        
        // Calculate Jaccard similarity
        const union = words1.size + words2.size - intersection;
        return intersection / union;
    }
    
    /**
     * Parse questions from JSON response
     * @param {string} jsonText - JSON response from API
     * @returns {Array} - Array of question objects
     */
    parseQuestionsFromJson(jsonText) {
        const parsedContent = JSON.parse(jsonText);
        
        // Check if we got an object with a questions array inside
        if (parsedContent.questions && Array.isArray(parsedContent.questions)) {
            return parsedContent.questions;
        } 
        // Check if we got an array directly
        else if (Array.isArray(parsedContent)) {
            return parsedContent;
        }
        // If we got an object but not array format, try to normalize it
        else if (typeof parsedContent === 'object') {
            // Try to extract an array of questions
            const possibleQuestions = Object.values(parsedContent).find(val => 
                Array.isArray(val) && val.length > 0 && val[0].type && val[0].question
            );
            
            if (possibleQuestions) {
                return possibleQuestions;
            }
        }
        
        // If we couldn't parse questions, return empty array
        return [];
    }
    
    /**
     * Extract JSON from any API response format
     * @param {Object} response - API response object
     * @returns {string} - JSON string or null if not found
     */
    async extractJsonFromResponse(response) {
        if (!response || !response.data) return null;
        
        if (response.type === 'openai') {
            return response.data?.choices?.[0]?.message?.content || null;
        } else if (response.type === 'gemini') {
            return response.data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
        } else if (response.type === 'claude') {
            return response.data?.content?.[0]?.text || null;
        } else if (response.type === 'cursor-ai') {
            return response.data?.response || null;
        }
        
        return null;
    }

    /**
     * Determine if the request requires premium features
     * @param {Object} settings - Question generation settings
     * @returns {boolean} - Whether premium features are being requested
     */
    isPremiumFeatureRequest(settings) {
        // Check if using specialized question types (clinical case, differential)
        if (settings.questionTypes.clinicalCase || settings.questionTypes.differential) {
            return true;
        }
        
        // Check if using advanced difficulty
        if (settings.difficulty === 'specialist' || settings.difficulty === 'advanced') {
            return true;
        }
        
        // Check if generating more than 15 questions
        if (settings.numQuestions > 15) {
            return true;
        }
        
        // Check if using specialized subspecialties
        const specializedSubtypes = ['retinal-disorders', 'neuro-ophthalmology', 'ocular-inflammation'];
        if (specializedSubtypes.includes(settings.subspecialty)) {
            return true;
        }
        
        return false;
    }

    loadQuestionSet(questionSet) {
        if (!questionSet || !questionSet.questions || questionSet.questions.length === 0) {
            console.error('Invalid question set or no questions in the set');
            return;
        }

        try {
            // Store the questions
            this.generatedQuestions = questionSet.questions;
            
            // Set the subspecialty if available
            if (questionSet.subspecialty) {
                this.subspecialty = questionSet.subspecialty;
                
                // Also update the subspecialty select element
                const knowledgeAreaSelect = document.getElementById('knowledge-area');
                if (knowledgeAreaSelect) {
                    knowledgeAreaSelect.value = questionSet.subspecialty;
                }
            }
            
            // Clear the existing question container
            if (this.ui && this.ui.questionContainer) {
                this.ui.questionContainer.innerHTML = '';
            }
            
            // Render the loaded questions
            this.displayQuestions();
            
            // Enable export and other buttons if needed
            if (this.ui && this.ui.updateButtonStates) {
                this.ui.updateButtonStates(true);
            }
            
            // Show success message
            if (this.ui && this.ui.showStatus) {
                this.ui.showStatus(`Loaded ${questionSet.questions.length} questions from "${questionSet.title}"`, 'success');
            }
        } catch (error) {
            console.error('Error loading question set:', error);
            
            // Show error message
            if (this.ui && this.ui.showStatus) {
                this.ui.showStatus('Error loading question set', 'error');
            }
        }
    }

    // Helper method to format management answers with proper section highlighting
    formatManagementAnswer(answer) {
        if (!answer) return '';
        
        // Create formatted sections for the management answer
        let formattedAnswer = answer;
        
        // First check if the answer has proper section headers
        const hasProperSections = 
            /history:/i.test(formattedAnswer) && 
            /examination:/i.test(formattedAnswer) && 
            /investigation(s)?:/i.test(formattedAnswer) &&
            /treatment:/i.test(formattedAnswer);
            
        // If answer lacks proper sections, add section headings as needed
        if (!hasProperSections) {
            // Try to identify and structure content into appropriate sections
            const paragraphs = formattedAnswer.split(/\n\n+/);
            
            if (paragraphs.length >= 3) {
                // Create a properly structured answer
                let structuredAnswer = '';
                
                // Extract or create section content based on keywords
                const historyContent = paragraphs.find(p => /history|symptom|present|complaint/i.test(p)) || paragraphs[0];
                const examContent = paragraphs.find(p => /examin|inspect|assess|test|check/i.test(p)) || paragraphs[1];
                const invContent = paragraphs.find(p => /investig|test|scan|imaging|lab|blood/i.test(p)) || paragraphs[2];
                const treatContent = paragraphs.find(p => /treat|therap|interven|surg|medic|drug|dos/i.test(p)) || (paragraphs[3] || '');
                const followContent = paragraphs.find(p => /follow|monitor|review|visit/i.test(p)) || '';
                
                // Build structured answer
                structuredAnswer += '**History:**\n' + historyContent + '\n\n';
                structuredAnswer += '**Examination:**\n' + examContent + '\n\n';
                structuredAnswer += '**Investigations:**\n' + invContent + '\n\n';
                structuredAnswer += '**Treatment:**\n' + treatContent + '\n\n';
                
                if (followContent) {
                    structuredAnswer += '**Follow-up:**\n' + followContent;
                }
                
                formattedAnswer = structuredAnswer;
            }
        }
        
        // Format section headers with colored styling
        formattedAnswer = formattedAnswer.replace(/\*\*?History:?\*\*?|History:/gi, 
            '<div class="font-semibold text-blue-700 mt-3 mb-1 border-b border-blue-200 pb-1">History:</div>');
        
        formattedAnswer = formattedAnswer.replace(/\*\*?Examination:?\*\*?|Examination:/gi, 
            '<div class="font-semibold text-green-700 mt-3 mb-1 border-b border-green-200 pb-1">Examination:</div>');
        
        formattedAnswer = formattedAnswer.replace(/\*\*?Investigation(s)?:?\*\*?|Investigation(s)?:/gi, 
            '<div class="font-semibold text-purple-700 mt-3 mb-1 border-b border-purple-200 pb-1">Investigations:</div>');
        
        formattedAnswer = formattedAnswer.replace(/\*\*?Treatment:?\*\*?|Treatment:/gi, 
            '<div class="font-semibold text-red-700 mt-3 mb-1 border-b border-red-200 pb-1">Treatment:</div>');
        
        formattedAnswer = formattedAnswer.replace(/\*\*?Management:?\*\*?|Management:/gi, 
            '<div class="font-semibold text-orange-700 mt-3 mb-1 border-b border-orange-200 pb-1">Management:</div>');
        
        formattedAnswer = formattedAnswer.replace(/\*\*?Follow-up:?\*\*?|Follow-up:/gi, 
            '<div class="font-semibold text-indigo-700 mt-3 mb-1 border-b border-indigo-200 pb-1">Follow-up:</div>');
        
        // Convert lists to bullet points if they exist
        const listItemRegex = /^\s*[\-\*•]\s+(.+)$/gm;
        formattedAnswer = formattedAnswer.replace(listItemRegex, '<li class="ml-5 mb-1">$1</li>');
        
        // Add <ul> tags around list items (handle consecutive list items)
        let parts = formattedAnswer.split('<li');
        if (parts.length > 1) {
            formattedAnswer = parts[0];
            for (let i = 1; i < parts.length; i++) {
                if (i === 1) {
                    formattedAnswer += '<ul class="list-disc mt-1 mb-2"><li' + parts[i];
                } else if (i === parts.length - 1 && !parts[i].includes('</li></ul>')) {
                    formattedAnswer += '<li' + parts[i] + '</ul>';
                } else {
                    formattedAnswer += '<li' + parts[i];
                }
            }
        }
        
        // Ensure there are no duplicate </ul> tags
        formattedAnswer = formattedAnswer.replace(/<\/ul>\s*<\/ul>/g, '</ul>');
        
        // Handle potential numbered lists (convert to HTML ordered list)
        formattedAnswer = formattedAnswer.replace(/^\s*(\d+)[\.\)]\s+(.+)$/gm, '<li class="ml-5 mb-1">$2</li>');
        
        // Format key medical terms for emphasis
        const medicalTerms = [
            'glaucoma', 'cataract', 'retinopathy', 'macular degeneration', 'uveitis', 
            'keratitis', 'corneal', 'optic', 'choroidal', 'intraocular', 'iol', 'iop', 
            'visual acuity', 'visual field', 'slit lamp', 'tonometry', 'gonioscopy',
            'fundoscopy', 'oct', 'retinal', 'topical', 'systemic'
        ];
        
        medicalTerms.forEach(term => {
            const regex = new RegExp(`\\b${term}\\b`, 'gi');
            formattedAnswer = formattedAnswer.replace(regex, '<span class="text-indigo-700 font-medium">$&</span>');
        });
        
        return formattedAnswer;
    }

    /**
     * Calculate average confidence of generated questions
     */
    calculateAverageConfidence() {
        if (!this.generatedQuestions || this.generatedQuestions.length === 0) {
            return 0;
        }
        
        const questionsWithConfidence = this.generatedQuestions.filter(q => 
            q.confidence && typeof q.confidence === 'number'
        );
        
        if (questionsWithConfidence.length === 0) {
            return 0.75; // Default confidence if not available
        }
        
        const totalConfidence = questionsWithConfidence.reduce((sum, q) => 
            sum + q.confidence, 0
        );
        
        return totalConfidence / questionsWithConfidence.length;
    }
}
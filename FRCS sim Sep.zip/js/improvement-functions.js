/**
 * Improvement Functions - Missing functions for question improvement system
 * Fixes missing function errors
 */

// Wait for safe storage to be available
function waitForSafeStorage(callback, maxAttempts = 10) {
    let attempts = 0;
    const checkInterval = setInterval(() => {
        if (window.safeSetItem && window.safeGetItem) {
            clearInterval(checkInterval);
            callback();
        } else if (++attempts >= maxAttempts) {
            clearInterval(checkInterval);
            console.warn('⚠️ Safe storage functions not available, using fallback methods');
            // Define fallback functions
            window.safeSetItem = window.safeSetItem || ((key, value) => {
                try {
                    localStorage.setItem(key, JSON.stringify(value));
                    return true;
                } catch (e) {
                    console.warn(`Storage failed for ${key}:`, e);
                    return false;
                }
            });
            window.safeGetItem = window.safeGetItem || ((key, defaultValue = null) => {
                try {
                    const value = localStorage.getItem(key);
                    return value ? JSON.parse(value) : defaultValue;
                } catch (e) {
                    return defaultValue;
                }
            });
            callback();
        }
    }, 100);
}

// Wait for safe storage and then define functions
waitForSafeStorage(() => {
    /**
     * Mark a question as improved
     */
    window.markQuestionAsImproved = function(questionId, improvementDetails) {
    try {
        let improvedQuestions = window.safeGetItem('ophthalmoQA_improvedQuestions', {});
        // Ensure we have a mutable plain object
        if (!improvedQuestions || typeof improvedQuestions !== 'object' || Array.isArray(improvedQuestions)) {
            improvedQuestions = {};
        }
        
        const improvement = {
            id: questionId,
            timestamp: Date.now(),
            type: improvementDetails.type || 'manual',
            confidence: improvementDetails.confidence || 0.5,
            changes: improvementDetails.changes || [],
            impact: improvementDetails.impact || 0.5,
            feedback: improvementDetails.feedback || null,
            ...improvementDetails
        };
        
        improvedQuestions[questionId] = improvement;
        
        const success = window.safeSetItem('ophthalmoQA_improvedQuestions', improvedQuestions);
        
        if (success) {
            console.log(`✅ Question ${questionId} marked as improved:`, improvement);
            
            // Dispatch event for UI updates
            window.dispatchEvent(new CustomEvent('questionImproved', {
                detail: { questionId, improvement }
            }));
            
            return improvement;
        } else {
            console.error(`❌ Failed to save improvement for question ${questionId}`);
            return null;
        }
    } catch (error) {
        console.error('Error marking question as improved:', error);
        return null;
    }
};

/**
 * Check if a question has been improved
 */
window.hasQuestionBeenImproved = function(questionId) {
    try {
        const improvedQuestions = window.safeGetItem('ophthalmoQA_improvedQuestions', {});
        return questionId in improvedQuestions;
    } catch (error) {
        console.error('Error checking question improvement status:', error);
        return false;
    }
};

/**
 * Get improvement details for a question
 */
window.getQuestionImprovementDetails = function(questionId) {
    try {
        const improvedQuestions = window.safeGetItem('ophthalmoQA_improvedQuestions', {});
        return improvedQuestions[questionId] || null;
    } catch (error) {
        console.error('Error getting question improvement details:', error);
        return null;
    }
};

/**
 * Get improvement statistics
 */
window.getImprovementStats = function() {
    try {
        const improvedQuestions = window.safeGetItem('ophthalmoQA_improvedQuestions', {});
        const improvements = Object.values(improvedQuestions);
        
        if (improvements.length === 0) {
            return {
                totalImproved: 0,
                averageConfidence: 0,
                impactScore: 0,
                recentImprovements: [],
                improvementsByType: {},
                improvementsByDay: {}
            };
        }
        
        // Calculate statistics
        const totalImproved = improvements.length;
        const averageConfidence = improvements.reduce((sum, imp) => sum + (imp.confidence || 0), 0) / totalImproved;
        const impactScore = improvements.reduce((sum, imp) => sum + (imp.impact || 0), 0) / totalImproved;
        
        // Recent improvements (last 24 hours)
        const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
        const recentImprovements = improvements.filter(imp => imp.timestamp > oneDayAgo);
        
        // Group by type
        const improvementsByType = {};
        improvements.forEach(imp => {
            const type = imp.type || 'unknown';
            improvementsByType[type] = (improvementsByType[type] || 0) + 1;
        });
        
        // Group by day (last 7 days)
        const improvementsByDay = {};
        const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
        improvements.forEach(imp => {
            if (imp.timestamp > sevenDaysAgo) {
                const day = new Date(imp.timestamp).toDateString();
                improvementsByDay[day] = (improvementsByDay[day] || 0) + 1;
            }
        });
        
        return {
            totalImproved,
            averageConfidence: Math.round(averageConfidence * 100) / 100,
            impactScore: Math.round(impactScore * 100) / 100,
            recentImprovements,
            improvementsByType,
            improvementsByDay
        };
    } catch (error) {
        console.error('Error getting improvement stats:', error);
        return {
            totalImproved: 0,
            averageConfidence: 0,
            impactScore: 0,
            recentImprovements: [],
            improvementsByType: {},
            improvementsByDay: {}
        };
    }
};

/**
 * Get improvement status display for UI
 */
window.getImprovementStatusDisplay = function(questionId) {
    try {
        const improvement = window.getQuestionImprovementDetails(questionId);
        
        if (!improvement) {
            return null;
        }
        
        const confidencePercent = Math.round((improvement.confidence || 0) * 100);
        const impactPercent = Math.round((improvement.impact || 0) * 100);
        
        return {
            hasImprovement: true,
            type: improvement.type,
            confidence: confidencePercent,
            impact: impactPercent,
            badge: `✨ Improved (${confidencePercent}% confidence)`,
            tooltip: `Question improved via ${improvement.type} with ${impactPercent}% impact`,
            timestamp: improvement.timestamp,
            changes: improvement.changes || []
        };
    } catch (error) {
        console.error('Error getting improvement status display:', error);
        return null;
    }
};

/**
 * Get improvement status for a question
 */
window.getImprovementStatus = function(questionId) {
    try {
        const improvement = window.getQuestionImprovementDetails(questionId);
        
        if (!improvement) {
            return { improved: false };
        }
        
        return {
            improved: true,
            type: improvement.type,
            confidence: improvement.confidence,
            impact: improvement.impact,
            timestamp: improvement.timestamp,
            timeAgo: window.getTimeAgo ? window.getTimeAgo(improvement.timestamp) : 'recently'
        };
    } catch (error) {
        console.error('Error getting improvement status:', error);
        return { improved: false };
    }
};

/**
 * Enhanced QA extraction with feedback
 */
window.extractQuestionsWithFeedback = async function(text, options = {}) {
    try {
        // Use enhanced extractor if available, fallback to basic extraction
        let extractedQuestions;
        
        if (window.enhancedQAExtractor && typeof window.enhancedQAExtractor.extractFromText === 'function') {
            extractedQuestions = await window.enhancedQAExtractor.extractFromText(text, options);
        } else if (window.extractQuestionsEnhanced) {
            extractedQuestions = await window.extractQuestionsEnhanced(text, options);
        } else {
            // Fallback basic extraction
            extractedQuestions = await window.basicQuestionExtraction(text, options);
        }
        
        // Ensure we have the expected structure
        if (!extractedQuestions || !extractedQuestions.questions) {
            return {
                questions: [],
                metadata: {
                    source: 'fallback',
                    extractedAt: Date.now(),
                    confidence: 0.3
                }
            };
        }
        
        // Add IDs to questions if missing
        extractedQuestions.questions.forEach((question, index) => {
            if (!question.id) {
                question.id = `extracted_${Date.now()}_${index}`;
            }
        });
        
        return extractedQuestions;
    } catch (error) {
        console.error('Error in extractQuestionsWithFeedback:', error);
        return {
            questions: [],
            metadata: {
                source: 'error',
                extractedAt: Date.now(),
                confidence: 0,
                error: error.message
            }
        };
    }
};

/**
 * Basic question extraction fallback
 */
window.basicQuestionExtraction = async function(text, options = {}) {
    try {
        const questions = [];
        
        // Simple regex-based extraction for demonstration
        const questionPattern = /(?:Question\s*\d+[:.]\s*)(.*?)(?=Question\s*\d+|$)/gis;
        const matches = text.match(questionPattern);
        
        if (matches) {
            matches.forEach((match, index) => {
                const questionText = match.trim();
                if (questionText.length > 10) { // Basic validation
                    questions.push({
                        id: `basic_${Date.now()}_${index}`,
                        question: questionText,
                        type: 'unknown',
                        confidence: 0.5,
                        source: 'basic_extraction'
                    });
                }
            });
        }
        
        return {
            questions,
            metadata: {
                source: 'basic_extraction',
                extractedAt: Date.now(),
                confidence: 0.5,
                totalQuestions: questions.length
            }
        };
    } catch (error) {
        console.error('Error in basic question extraction:', error);
        return {
            questions: [],
            metadata: {
                source: 'basic_extraction_error',
                extractedAt: Date.now(),
                confidence: 0,
                error: error.message
            }
        };
    }
};

/**
 * Utility function for time ago display
 */
window.getTimeAgo = function(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    const week = 7 * day;
    
    if (diff < minute) return 'just now';
    if (diff < hour) return `${Math.floor(diff / minute)} minutes ago`;
    if (diff < day) return `${Math.floor(diff / hour)} hours ago`;
    if (diff < week) return `${Math.floor(diff / day)} days ago`;
    return `${Math.floor(diff / week)} weeks ago`;
};

/**
 * Clear all improvement data (for testing/reset)
 */
window.clearImprovementData = function() {
    try {
        localStorage.removeItem('ophthalmoQA_improvedQuestions');
        console.log('✅ Cleared all improvement data');
        
        // Dispatch event for UI updates
        window.dispatchEvent(new CustomEvent('improvementDataCleared'));
        
        return true;
    } catch (error) {
        console.error('Error clearing improvement data:', error);
        return false;
    }
};

    console.log('✅ Improvement functions loaded and ready');
});

// End of waitForSafeStorage callback 
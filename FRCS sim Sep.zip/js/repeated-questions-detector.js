/**
 * Enhanced Repeated Questions Detector
 * 
 * This module provides advanced detection and analysis of repeated questions,
 * using more sophisticated similarity algorithms and providing detailed insights.
 */

// Initialize the system when the document is ready
document.addEventListener('DOMContentLoaded', () => {
    initRepeatedQuestionsDetector();
});

// Global state for tracking question history
const questionState = {
    questionHistory: [],          // Full history of all questions
    detectedDuplicates: [],       // Log of detected duplicates
    similarityThreshold: 0.70,    // Default threshold for marking duplicates (70%)
    isDeepSearchActive: false,    // Flag for deep search mode
    isSelectionModeActive: false, // Flag for selection mode
    repetitionInsights: {         // Analysis of repetition patterns
        highRepetitionTopics: {},
        repetitionByType: {},
        repetitionBySource: {}
    }
};

/**
 * Initialize the repeated questions detector
 */
function initRepeatedQuestionsDetector() {
    // Load question history from localStorage if available
    loadQuestionHistory();
    
    // Setup event listeners
    setupEventListeners();
    
    // Log initialization
    console.log('Repeated Questions Detector initialized with', questionState.questionHistory.length, 'questions in history');
}

/**
 * Setup event listeners for the question detector
 */
function setupEventListeners() {
    // Monitor the question container for new questions
    const qaContainer = document.getElementById('qa-container');
    if (qaContainer) {
        // Create a mutation observer to monitor for new questions
        const questionObserver = new MutationObserver((mutations) => {
            handleQuestionContainerMutations(mutations);
        });
        
        // Start observing the question container
        questionObserver.observe(qaContainer, { 
            childList: true, 
            subtree: true,
            attributes: true,
            attributeFilter: ['class']
        });
    }
    
    // Monitor generation buttons to reset/preserve history appropriately
    const generateBtn = document.getElementById('generate-btn');
    if (generateBtn) {
        const originalGenerateClick = generateBtn.onclick;
        generateBtn.onclick = function(e) {
            // Reset special mode flags
            questionState.isDeepSearchActive = false;
            questionState.isSelectionModeActive = false;
            
            console.log('Generate button clicked - resetting history');
            
            // Clear history when generating new questions from scratch
            questionState.questionHistory = [];
            saveQuestionHistory();
            
            // Call the original click handler if it exists
            if (originalGenerateClick) originalGenerateClick.call(this, e);
        };
    }
    
    // For regenerate button, preserve history
    const regenerateBtn = document.getElementById('regenerate-btn');
    if (regenerateBtn) {
        const originalRegenerateClick = regenerateBtn.onclick;
        regenerateBtn.onclick = function(e) {
            // Reset special mode flags
            questionState.isDeepSearchActive = false;
            questionState.isSelectionModeActive = false;
            
            console.log('Regenerate button clicked - preserving history');
            
            // Call the original click handler if it exists
            if (originalRegenerateClick) originalRegenerateClick.call(this, e);
        };
    }
    
    // Listen for clear history button
    document.addEventListener('click', function(e) {
        if (e.target.closest('#clear-history-btn')) {
            console.log('Clear History button clicked - resetting question history');
            
            // Reset the question history
            questionState.questionHistory = [];
            questionState.detectedDuplicates = [];
            saveQuestionHistory();
            
            // Remove duplicate warnings from all existing questions
            clearAllDuplicateWarnings();
            
            // Show confirmation message
            showStatusMessage('Question history cleared. Future duplicates will be detected based on new questions.', 'success');
        }
        
        // Handle deep search button click
        if (e.target.closest('.deep-search-btn, [data-action="deep-search"]')) {
            questionState.isDeepSearchActive = true;
            console.log('Deep search active, pausing duplicate detection');
            
            // Reset deep search flag after a delay
            setTimeout(() => {
                questionState.isDeepSearchActive = false;
                console.log('Deep search flag reset');
            }, 3000);
        }
        
        // Handle selection mode toggle
        if (e.target.closest('#selection-mode-btn, [data-action="selection-mode"]')) {
            questionState.isSelectionModeActive = !questionState.isSelectionModeActive;
            console.log('Selection mode toggled:', questionState.isSelectionModeActive ? 'ON' : 'OFF');
            
            // Handle hiding/showing duplicate warnings in selection mode
            if (questionState.isSelectionModeActive) {
                hideAllDuplicateWarnings();
            } else {
                restoreAllDuplicateWarnings();
            }
        }
    });
}

/**
 * Handle mutations to the question container
 */
function handleQuestionContainerMutations(mutations) {
    // Check if any special modes are active
    const specialModeActivated = mutations.some(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            // Check if added nodes contain deep search results
            for (let i = 0; i < mutation.addedNodes.length; i++) {
                const node = mutation.addedNodes[i];
                if (node.nodeType === Node.ELEMENT_NODE) {
                    if (node.classList && 
                        (node.classList.contains('deep-search-result') || 
                        node.querySelector('.deep-search-result'))) {
                        return true;
                    }
                }
            }
        } else if (mutation.type === 'attributes' && 
                  mutation.attributeName === 'class' && 
                  mutation.target.id === 'qa-container') {
            // Check if selection mode was toggled
            if (mutation.target.classList.contains('selection-mode')) {
                questionState.isSelectionModeActive = true;
                return true;
            } else if (questionState.isSelectionModeActive) {
                questionState.isSelectionModeActive = false;
            }
        }
        return false;
    });
    
    // Skip analyzing questions if special modes are active
    if (specialModeActivated || questionState.isDeepSearchActive || questionState.isSelectionModeActive) {
        return;
    }
    
    // Check if questions were added
    const questionsAdded = mutations.some(mutation => 
        mutation.type === 'childList' && mutation.addedNodes.length > 0);
    
    if (questionsAdded) {
        // Get all questions in the container
        const qaContainer = document.getElementById('qa-container');
        if (!qaContainer) return;
        
        // Find all new questions not in deep search sections
        const questionElements = Array.from(qaContainer.querySelectorAll('.question-item')).filter(el => {
            return !el.closest('.deep-search-result') && 
                   !el.hasAttribute('data-deep-search-result') &&
                   !el.classList.contains('deep-search-item') &&
                   !el.hasAttribute('data-analyzed');  // Only process new questions
        });
        
        // Mark each question as analyzed
        questionElements.forEach(el => el.setAttribute('data-analyzed', 'true'));
        
        // Process the new questions
        if (questionElements.length > 0) {
            processNewQuestions(questionElements);
        }
    }
}

/**
 * Process new questions for duplicate detection
 */
function processNewQuestions(questionElements) {
    console.log(`Processing ${questionElements.length} new questions for duplicates`);
    
    // Current questions in this batch
    const currentBatchQuestions = [];
    
    questionElements.forEach(questionEl => {
        // Get the question text
        const questionTextEl = questionEl.querySelector('.question-text');
        if (!questionTextEl) return;
        
        const questionText = questionTextEl.textContent.trim();
        const questionType = determineQuestionType(questionEl);
        
        // Create a structured question object
        const questionObject = {
            text: questionText,
            type: questionType,
            timestamp: Date.now(),
            element: questionEl,
            topic: extractTopicFromQuestion(questionText),
            source: getCurrentGenerationSource()
        };
        
        // Check for duplicates
        const dupeCheck = checkForDuplicate(questionObject);
        
        // If it's a duplicate, mark it
        if (dupeCheck.isDuplicate) {
            markQuestionAsDuplicate(questionEl, dupeCheck);
            logDuplicateDetection(questionObject, dupeCheck);
            
            // Dispatch event for feedback loop system
            dispatchRepeatedQuestionEvent(questionObject, dupeCheck);
        }
        
        // Add to current batch to check for intra-batch duplicates
        currentBatchQuestions.push(questionObject);
        
        // Add to history for future checks
        questionState.questionHistory.push({
            text: questionText,
            type: questionType,
            timestamp: Date.now(),
            topic: questionObject.topic,
            source: questionObject.source
        });
    });
    
    // Save updated history
    saveQuestionHistory();
    
    // Update repetition insights
    updateRepetitionInsights();
}

/**
 * Determine the question type
 */
function determineQuestionType(questionEl) {
    // Check for common question type indicators
    if (questionEl.hasAttribute('data-type')) {
        return questionEl.getAttribute('data-type');
    }
    
    // Check for question structure indicators
    const options = questionEl.querySelectorAll('.question-option, .option');
    if (options.length > 0) {
        return 'mcq'; // Multiple choice
    }
    
    const tfMarkers = questionEl.textContent.match(/true.*false|false.*true/i);
    if (tfMarkers) {
        return 'tf'; // True/False
    }
    
    // Look for specific keywords in the question text
    const questionText = questionEl.textContent.toLowerCase();
    
    if (questionText.includes('differential diagnosis') || 
        questionText.includes('differentials') ||
        questionText.match(/list.{1,20}differential/i)) {
        return 'differential';
    }
    
    if (questionText.includes('management') || 
        questionText.includes('treat') || 
        questionText.includes('therapy') ||
        questionText.match(/how.{1,10}(manage|treat)/i)) {
        return 'management';
    }
    
    if (questionText.includes('case') || 
        questionText.includes('patient') || 
        questionText.includes('presents with')) {
        return 'clinical-case';
    }
    
    if (questionText.includes('station') || 
        questionText.includes('examine') || 
        questionText.includes('examination')) {
        return 'osce';
    }
    
    if (questionText.match(/discuss|explain|describe|elaborate|viva/i)) {
        return 'viva';
    }
    
    // Default to short answer if no other type detected
    return 'short-answer';
}

/**
 * Extract likely topic from question text
 */
function extractTopicFromQuestion(text) {
    // Common ophthalmology topics to look for
    const topics = [
        'retina', 'retinal', 'macular', 'vitreous',
        'cornea', 'corneal', 'keratoconus', 'keratitis',
        'glaucoma', 'intraocular pressure', 'iop',
        'cataract', 'lens', 'phacoemulsification', 'iol',
        'refractive', 'myopia', 'hyperopia', 'astigmatism',
        'neuro-ophthalmology', 'optic nerve', 'cranial nerve',
        'uveitis', 'inflammation', 'iritis', 'scleritis',
        'pediatric', 'strabismus', 'amblyopia',
        'oculoplastics', 'eyelid', 'orbit', 'lacrimal',
        'oncology', 'tumor', 'melanoma',
        'diabetes', 'diabetic retinopathy', 'hypertensive retinopathy',
        'amd', 'age-related macular degeneration'
    ];
    
    // Convert text to lowercase for easier matching
    const lowerText = text.toLowerCase();
    
    // Try to find matches
    for (const topic of topics) {
        if (lowerText.includes(topic)) {
            return topic;
        }
    }
    
    // Try regex for more complex patterns
    if (lowerText.match(/\b(amd|armd|dmr|pdr|npdr|cscr)\b/i)) {
        return 'retinal disorders';
    }
    
    if (lowerText.match(/\b(poag|pacg|ntn|oht|ltp|trabeculectomy)\b/i)) {
        return 'glaucoma';
    }
    
    // If no specific topic found, try to get the knowledge area from UI
    const knowledgeArea = document.getElementById('knowledge-area');
    return knowledgeArea?.value || 'general ophthalmology';
}

/**
 * Get the current generation source
 */
function getCurrentGenerationSource() {
    const inputType = document.getElementById('input-type')?.value;
    
    switch(inputType) {
        case 'upload':
            const fileName = document.getElementById('file-name')?.textContent;
            return fileName ? `Upload: ${fileName}` : 'File upload';
        
        case 'text':
            return 'Manual text input';
            
        case 'knowledge-base':
            const knowledgeArea = document.getElementById('knowledge-area')?.value;
            return `Knowledge base: ${knowledgeArea || 'general'}`;
            
        case 'notebooklm':
            const notebookTitle = document.getElementById('selected-notebook-title')?.textContent;
            return notebookTitle ? `NotebookLM: ${notebookTitle}` : 'NotebookLM';
            
        default:
            return 'Unknown source';
    }
}

/**
 * Check if a question is a duplicate of a previously seen question
 */
function checkForDuplicate(questionObject) {
    // Normalize the question text
    const normalizedQuestion = normalizeQuestionText(questionObject.text);
    
    // Skip very short questions
    if (normalizedQuestion.length < 20) {
        return { isDuplicate: false, similarityScore: 0 };
    }
    
    // Prepare result object
    let result = {
        isDuplicate: false,
        similarityScore: 0,
        matchedQuestion: null,
        similarityMethod: null
    };
    
    // First check for exact duplicates (excluding very short questions)
    for (const historyQuestion of questionState.questionHistory) {
        const normalizedHistoryQuestion = normalizeQuestionText(historyQuestion.text);
        
        // For exact matches
        if (normalizedQuestion === normalizedHistoryQuestion && normalizedQuestion.length > 20) {
            result = {
                isDuplicate: true,
                similarityScore: 1.0,
                matchedQuestion: historyQuestion,
                similarityMethod: 'exact'
            };
            return result;
        }
    }
    
    // If no exact match, check for semantic similarity
    for (const historyQuestion of questionState.questionHistory) {
        // Skip comparing to very short questions
        if (historyQuestion.text.length < 20) continue;
        
        // Calculate different similarity scores
        const normalizedHistoryQuestion = normalizeQuestionText(historyQuestion.text);
        
        // Calculate semantic similarity scores
        const wordOverlapScore = calculateWordOverlapSimilarity(normalizedQuestion, normalizedHistoryQuestion);
        const jaccardScore = calculateJaccardSimilarity(normalizedQuestion, normalizedHistoryQuestion);
        const levenshteinScore = calculateLevenshteinSimilarity(normalizedQuestion, normalizedHistoryQuestion);
        
        // Use a weighted combination
        const combinedScore = (wordOverlapScore * 0.4) + (jaccardScore * 0.4) + (levenshteinScore * 0.2);
        
        // Check if this is the best match so far
        if (combinedScore > result.similarityScore) {
            result = {
                similarityScore: combinedScore,
                matchedQuestion: historyQuestion,
                similarityMethod: 'semantic'
            };
        }
    }
    
    // Mark as duplicate if score is above threshold
    result.isDuplicate = result.similarityScore >= questionState.similarityThreshold;
    
    return result;
}

/**
 * Normalize question text for comparison
 */
function normalizeQuestionText(text) {
    return text
        .toLowerCase()
        .trim()
        .replace(/\s+/g, ' ')                 // Normalize whitespace
        .replace(/[^\w\s]/g, '')              // Remove punctuation
        .replace(/\b(a|an|the|in|on|at|to|of|for|with)\b/g, '') // Remove common stop words
        .trim();
}

/**
 * Calculate word overlap similarity between two texts
 */
function calculateWordOverlapSimilarity(text1, text2) {
    // Extract meaningful words (longer than 3 chars)
    const words1 = new Set(text1.split(' ').filter(word => word.length > 3));
    const words2 = new Set(text2.split(' ').filter(word => word.length > 3));
    
    if (words1.size === 0 || words2.size === 0) return 0;
    
    // Count shared words
    let sharedCount = 0;
    for (const word of words1) {
        if (words2.has(word)) sharedCount++;
    }
    
    // Calculate overlap coefficient: |A ∩ B| / min(|A|, |B|)
    return sharedCount / Math.min(words1.size, words2.size);
}

/**
 * Calculate Jaccard similarity between two texts
 */
function calculateJaccardSimilarity(text1, text2) {
    const words1 = new Set(text1.split(' ').filter(word => word.length > 2));
    const words2 = new Set(text2.split(' ').filter(word => word.length > 2));
    
    if (words1.size === 0 || words2.size === 0) return 0;
    
    // Calculate intersection size
    const intersection = new Set([...words1].filter(word => words2.has(word)));
    
    // Calculate union size
    const union = new Set([...words1, ...words2]);
    
    // Jaccard similarity: |A ∩ B| / |A ∪ B|
    return intersection.size / union.size;
}

/**
 * Calculate Levenshtein similarity (edit distance) between two texts
 */
function calculateLevenshteinSimilarity(text1, text2) {
    // If one string is empty, the edit distance is just the length of the other
    if (text1.length === 0) return 0;
    if (text2.length === 0) return 0;
    
    // For long texts, use a sample to avoid performance issues
    if (text1.length > 100 || text2.length > 100) {
        text1 = text1.substring(0, 100);
        text2 = text2.substring(0, 100);
    }
    
    // Create distance matrix
    const matrix = Array(text1.length + 1).fill().map(() => Array(text2.length + 1).fill(0));
    
    // Initialize first row and column
    for (let i = 0; i <= text1.length; i++) matrix[i][0] = i;
    for (let j = 0; j <= text2.length; j++) matrix[0][j] = j;
    
    // Fill the matrix
    for (let i = 1; i <= text1.length; i++) {
        for (let j = 1; j <= text2.length; j++) {
            const cost = text1[i - 1] === text2[j - 1] ? 0 : 1;
            matrix[i][j] = Math.min(
                matrix[i - 1][j] + 1,          // deletion
                matrix[i][j - 1] + 1,          // insertion
                matrix[i - 1][j - 1] + cost    // substitution
            );
        }
    }
    
    // Get the edit distance
    const distance = matrix[text1.length][text2.length];
    
    // Convert to similarity score (0-1 range)
    // Using: 1 - (distance / max possible distance)
    const maxDistance = Math.max(text1.length, text2.length);
    return 1 - (distance / maxDistance);
}

/**
 * Mark a question element as a duplicate
 */
function markQuestionAsDuplicate(questionEl, dupeCheck) {
    // Add the repeated-question class
    questionEl.classList.add('repeated-question');
    
    // Create warning icon
    const warningEl = document.createElement('div');
    warningEl.className = 'duplicate-warning absolute top-3 right-3 text-warning';
    warningEl.innerHTML = '<i class="fas fa-exclamation-circle" title="This appears to be a repeated question"></i>';
    
    // Add badge that says "Repeated"
    const repeatedBadge = document.createElement('div');
    repeatedBadge.className = 'repeated-badge absolute top-3 right-12 bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full';
    repeatedBadge.textContent = 'Repeated';
    
    // Add similarity score data if available
    if (dupeCheck.similarityScore) {
        const score = Math.round(dupeCheck.similarityScore * 100);
        questionEl.setAttribute('data-similarity-score', score);
        repeatedBadge.setAttribute('title', `${score}% similar to a previous question`);
        
        // For very high similarity, add extra warning
        if (score > 90) {
            repeatedBadge.classList.add('bg-red-100');
            repeatedBadge.classList.add('text-red-800');
            repeatedBadge.textContent = `${score}% Duplicate`;
        }
    }
    
    // Make sure the question element has relative positioning
    questionEl.style.position = 'relative';
    
    // Add the warning elements
    questionEl.appendChild(warningEl);
    questionEl.appendChild(repeatedBadge);
    
    // Add a button to view the original question
    if (dupeCheck.matchedQuestion) {
        const viewOriginalBtn = document.createElement('button');
        viewOriginalBtn.className = 'view-original-btn absolute bottom-3 right-3 text-xs text-blue-600 hover:text-blue-800 underline';
        viewOriginalBtn.textContent = 'View similar question';
        viewOriginalBtn.addEventListener('click', (e) => {
            e.preventDefault();
            showSimilarQuestionDialog(dupeCheck.matchedQuestion);
        });
        questionEl.appendChild(viewOriginalBtn);
    }
}

/**
 * Log duplicate detection for analysis
 */
function logDuplicateDetection(questionObject, dupeCheck) {
    questionState.detectedDuplicates.push({
        timestamp: Date.now(),
        newQuestion: {
            text: questionObject.text,
            type: questionObject.type,
            topic: questionObject.topic
        },
        matchedQuestion: dupeCheck.matchedQuestion ? {
            text: dupeCheck.matchedQuestion.text,
            type: dupeCheck.matchedQuestion.type,
            topic: dupeCheck.matchedQuestion.topic,
            timestamp: dupeCheck.matchedQuestion.timestamp
        } : null,
        similarityScore: dupeCheck.similarityScore,
        similarityMethod: dupeCheck.similarityMethod
    });
    
    saveDuplicatesLog();
}

/**
 * Dispatch event for the feedback loop system
 */
function dispatchRepeatedQuestionEvent(questionObject, dupeCheck) {
    const event = new CustomEvent('question:repeated', {
        detail: {
            question: questionObject,
            similarityScore: dupeCheck.similarityScore,
            matchedQuestion: dupeCheck.matchedQuestion,
            timestamp: Date.now()
        }
    });
    
    document.dispatchEvent(event);
}

/**
 * Show a dialog with information about similar questions
 */
function showSimilarQuestionDialog(matchedQuestion) {
    // Create modal elements
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 flex items-center justify-center z-50';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    
    const dialog = document.createElement('div');
    dialog.className = 'bg-white rounded-lg shadow-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto';
    
    // Format the date
    const date = new Date(matchedQuestion.timestamp);
    const formattedDate = date.toLocaleString();
    
    // Create content
    dialog.innerHTML = `
        <div class="flex justify-between items-center mb-4 pb-2 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-800">Similar Question Found</h3>
            <button class="text-gray-400 hover:text-gray-600 focus:outline-none close-btn">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="mb-4">
            <p class="text-sm text-gray-500 mb-1">This question was originally generated:</p>
            <p class="text-sm font-medium">${formattedDate}</p>
        </div>
        <div class="mb-4">
            <p class="font-medium mb-2">Original Question:</p>
            <div class="bg-gray-50 p-3 rounded-md border border-gray-200">
                ${matchedQuestion.text}
            </div>
        </div>
        <div class="mb-4">
            <p class="text-sm">
                <span class="font-medium">Question Type:</span> 
                <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">${matchedQuestion.type || 'Unknown'}</span>
            </p>
            <p class="text-sm mt-1">
                <span class="font-medium">Topic:</span> 
                <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">${matchedQuestion.topic || 'Unknown'}</span>
            </p>
        </div>
        <div class="text-right">
            <button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 close-btn">Close</button>
        </div>
    `;
    
    // Add to document
    modal.appendChild(dialog);
    document.body.appendChild(modal);
    
    // Add close handler
    modal.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.body.removeChild(modal);
        });
    });
    
    // Close on background click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

/**
 * Show status message to user
 */
function showStatusMessage(message, type = 'info') {
    const statusMessage = document.getElementById('status-message');
    if (!statusMessage) return;
    
    // Set message and styling
    statusMessage.textContent = message;
    
    // Set appropriate styling based on message type
    switch (type) {
        case 'success':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-green-100 text-green-800';
            break;
        case 'error':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-red-100 text-red-800';
            break;
        case 'warning':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-yellow-100 text-yellow-800';
            break;
        default:
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-blue-100 text-blue-800';
    }
    
    // Display the message
    statusMessage.style.display = 'block';
    
    // Hide after a few seconds
    setTimeout(() => {
        statusMessage.style.display = 'none';
    }, 4000);
}

/**
 * Remove all duplicate warnings from questions
 */
function clearAllDuplicateWarnings() {
    const questionElements = document.querySelectorAll('.question-item');
    questionElements.forEach(question => {
        // Remove the warning icon
        const warningElement = question.querySelector('.duplicate-warning');
        if (warningElement) {
            question.removeChild(warningElement);
        }
        
        // Remove the repeated badge
        const repeatedBadge = question.querySelector('.repeated-badge');
        if (repeatedBadge) {
            question.removeChild(repeatedBadge);
        }
        
        // Remove the view original button
        const viewOriginalBtn = question.querySelector('.view-original-btn');
        if (viewOriginalBtn) {
            question.removeChild(viewOriginalBtn);
        }
        
        // Remove the repeated-question class
        question.classList.remove('repeated-question');
    });
}

/**
 * Hide duplicate warnings (for selection mode)
 */
function hideAllDuplicateWarnings() {
    document.querySelectorAll('.duplicate-warning, .repeated-badge, .view-original-btn').forEach(el => {
        el.style.display = 'none';
    });
}

/**
 * Restore duplicate warnings after selection mode
 */
function restoreAllDuplicateWarnings() {
    document.querySelectorAll('.duplicate-warning, .repeated-badge, .view-original-btn').forEach(el => {
        el.style.display = '';
    });
}

/**
 * Update insights about repetition patterns
 */
function updateRepetitionInsights() {
    if (questionState.detectedDuplicates.length < 3) return; // Need minimum data
    
    // Group repetitions by topic
    const topicCounts = {};
    const typeCounts = {};
    const sourceCounts = {};
    
    // Process all duplicates
    questionState.detectedDuplicates.forEach(dupe => {
        // Count by topic
        const topic = dupe.newQuestion.topic || 'unknown';
        topicCounts[topic] = (topicCounts[topic] || 0) + 1;
        
        // Count by question type
        const type = dupe.newQuestion.type || 'unknown';
        typeCounts[type] = (typeCounts[type] || 0) + 1;
        
        // Count by source/input type
        const source = dupe.source || getCurrentGenerationSource();
        sourceCounts[source] = (sourceCounts[source] || 0) + 1;
    });
    
    // Sort to get top repeating areas
    const sortedTopics = Object.entries(topicCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3);
    
    const sortedTypes = Object.entries(typeCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3);
    
    const sortedSources = Object.entries(sourceCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3);
    
    // Store results
    questionState.repetitionInsights = {
        highRepetitionTopics: sortedTopics.map(([topic, count]) => ({ topic, count })),
        repetitionByType: sortedTypes.map(([type, count]) => ({ type, count })),
        repetitionBySource: sortedSources.map(([source, count]) => ({ source, count }))
    };
    
    // Save insights
    saveRepetitionInsights();
    
    // Generate improvement suggestions
    const suggestions = generateRepetitionImprovementSuggestions();
    
    // Log insights
    console.log('Repetition insights updated:', questionState.repetitionInsights);
    console.log('Improvement suggestions:', suggestions);
}

/**
 * Generate suggestions to improve repetition
 */
function generateRepetitionImprovementSuggestions() {
    const insights = questionState.repetitionInsights;
    const suggestions = [];
    
    // Suggest diversifying topics
    if (insights.highRepetitionTopics.length > 0 && insights.highRepetitionTopics[0].count > 3) {
        suggestions.push({
            type: 'topic',
            message: `Try diversifying away from "${insights.highRepetitionTopics[0].topic}" topics`
        });
    }
    
    // Suggest changing question types
    if (insights.repetitionByType.length > 0 && insights.repetitionByType[0].count > 3) {
        suggestions.push({
            type: 'questionType',
            message: `Consider reducing "${insights.repetitionByType[0].type}" question types`
        });
    }
    
    // Suggest changing input source
    if (insights.repetitionBySource.length > 0 && insights.repetitionBySource[0].count > 3) {
        suggestions.push({
            type: 'source',
            message: `Try changing input source from "${insights.repetitionBySource[0].source}"`
        });
    }
    
    return suggestions;
}

/**
 * Load question history from localStorage
 */
function loadQuestionHistory() {
    try {
        const history = localStorage.getItem('questionHistory');
        if (history) {
            questionState.questionHistory = JSON.parse(history);
        }
        
        const duplicates = localStorage.getItem('detectedDuplicates');
        if (duplicates) {
            questionState.detectedDuplicates = JSON.parse(duplicates);
        }
        
        const insights = localStorage.getItem('repetitionInsights');
        if (insights) {
            questionState.repetitionInsights = JSON.parse(insights);
        }
        
        // Get custom threshold if set
        const threshold = localStorage.getItem('similarityThreshold');
        if (threshold) {
            questionState.similarityThreshold = parseFloat(threshold);
        }
        
        console.log('Question history loaded from localStorage');
    } catch (error) {
        console.error('Error loading question history:', error);
    }
}

/**
 * Save question history to localStorage
 */
function saveQuestionHistory() {
    try {
        localStorage.setItem('questionHistory', JSON.stringify(questionState.questionHistory));
    } catch (error) {
        console.error('Error saving question history:', error);
        
        // If storage limit reached, prune older items
        if (error.name === 'QuotaExceededError') {
            pruneQuestionHistory();
            try {
                localStorage.setItem('questionHistory', JSON.stringify(questionState.questionHistory));
            } catch (e) {
                console.error('Failed to save even after pruning:', e);
            }
        }
    }
}

/**
 * Save duplicates log to localStorage
 */
function saveDuplicatesLog() {
    try {
        localStorage.setItem('detectedDuplicates', JSON.stringify(questionState.detectedDuplicates));
    } catch (error) {
        console.error('Error saving duplicates log:', error);
        
        // If storage limit reached, prune older items
        if (error.name === 'QuotaExceededError') {
            // Keep only the 50 most recent entries
            questionState.detectedDuplicates = questionState.detectedDuplicates.slice(-50);
            try {
                localStorage.setItem('detectedDuplicates', JSON.stringify(questionState.detectedDuplicates));
            } catch (e) {
                console.error('Failed to save even after pruning:', e);
            }
        }
    }
}

/**
 * Save repetition insights to localStorage
 */
function saveRepetitionInsights() {
    try {
        localStorage.setItem('repetitionInsights', JSON.stringify(questionState.repetitionInsights));
    } catch (error) {
        console.error('Error saving repetition insights:', error);
    }
}

/**
 * Prune question history to save space
 */
function pruneQuestionHistory() {
    console.log('Pruning question history due to storage limits');
    
    // Keep only most recent 500 questions
    if (questionState.questionHistory.length > 500) {
        questionState.questionHistory = questionState.questionHistory.slice(-500);
    }
}

// Export public API
window.RepeatedQuestionsDetector = {
    clearHistory: () => {
        questionState.questionHistory = [];
        questionState.detectedDuplicates = [];
        saveQuestionHistory();
        saveDuplicatesLog();
        clearAllDuplicateWarnings();
    },
    setSimilarityThreshold: (threshold) => {
        const newThreshold = parseFloat(threshold);
        if (!isNaN(newThreshold) && newThreshold >= 0 && newThreshold <= 1) {
            questionState.similarityThreshold = newThreshold;
            localStorage.setItem('similarityThreshold', newThreshold.toString());
            return true;
        }
        return false;
    },
    getRepetitionInsights: () => ({ ...questionState.repetitionInsights }),
    getDetectedDuplicatesCount: () => questionState.detectedDuplicates.length,
    checkForDuplicate, // Expose for external use
    getCurrentQuestionCount: () => questionState.questionHistory.length
}; 
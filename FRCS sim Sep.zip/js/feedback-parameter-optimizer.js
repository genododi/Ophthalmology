/**
 * Feedback-Based Parameter Optimizer
 * Uses feedback data to automatically refine question generation parameters
 */
class FeedbackParameterOptimizer {
    constructor() {
        this.optimizationRules = new Map();
        this.adaptiveSettings = {
            enabled: true,
            learningRate: 0.1,
            minSamples: 5, // Minimum feedback samples before optimization
            confidenceThreshold: 0.7
        };
        
        this.questionTypeMapping = this.initializeQuestionTypeMapping();
        this.loadOptimizationState();
        this.initializeEventListeners();
    }

    initializeQuestionTypeMapping() {
        // Map various question type names to standardized types
        return new Map([
            // Standard types
            ['multiple_choice', 'mcq'],
            ['mcq', 'mcq'],
            ['true_false', 'true_false'],
            ['fill_blank', 'fill_blank'],
            ['essay', 'essay'],
            ['short_answer', 'short_answer'],
            ['management', 'management'],
            
            // Alternative names that might be generated
            ['differential_diagnosis', 'differential'],
            ['differential diagnosis', 'differential'],
            ['case_based', 'case_study'],
            ['case-based', 'case_study'],
            ['case based', 'case_study'],
            ['clinical_case', 'case_study'],
            ['clinical case', 'case_study'],
            ['matching', 'matching'],
            ['ordering', 'ordering'],
            ['calculation', 'calculation'],
            ['image_based', 'image'],
            ['image based', 'image'],
            ['diagram', 'image'],
            
            // Medical-specific types
            ['surgical_technique', 'management'],
            ['surgical technique', 'management'],
            ['treatment_plan', 'management'],
            ['treatment plan', 'management'],
            ['diagnostic', 'diagnosis'],
            ['pathology', 'pathology'],
            ['anatomy', 'anatomy'],
            ['pharmacology', 'pharmacology']
        ]);
    }

    initializeEventListeners() {
        // Listen for feedback events to trigger optimization
        document.addEventListener('questionFeedback', (event) => {
            this.processFeedbackForOptimization(event.detail);
        });

        // Listen for generation events to apply optimizations
        document.addEventListener('beforeQuestionsGenerated', (event) => {
            if (this.adaptiveSettings.enabled) {
                this.optimizeParameters(event.detail);
            }
        });
    }

    processFeedbackForOptimization(feedbackData) {
        if (!this.adaptiveSettings.enabled) return;

        // Get the question and session context
        const questionId = feedbackData.questionId;
        const session = this.findSessionContext(questionId);
        
        if (!session) {
            console.warn('Could not find session context for question:', questionId);
            return;
        }

        // Record the feedback impact
        this.recordFeedbackImpact(session, feedbackData);
        
        // Update optimization rules based on feedback
        this.updateOptimizationRules(session, feedbackData);
        
        console.log('Updated optimization rules based on feedback:', feedbackData.type);
    }

    findSessionContext(questionId) {
        const history = window.questionGenerationHistory;
        if (!history) return null;

        return history.findSessionByQuestionId(questionId);
    }

    recordFeedbackImpact(session, feedbackData) {
        const parameters = session.parameters;
        const ruleKey = this.generateRuleKey(parameters);
        
        if (!this.optimizationRules.has(ruleKey)) {
            this.optimizationRules.set(ruleKey, {
                parameters: { ...parameters },
                feedback: {
                    likes: 0,
                    dislikes: 0,
                    improvements: 0,
                    total: 0
                },
                adjustments: {
                    difficulty: 0,
                    questionTypes: new Map(),
                    focusAdjustment: 0
                },
                confidence: 0,
                lastUpdated: new Date().toISOString()
            });
        }

        const rule = this.optimizationRules.get(ruleKey);
        
        // Update feedback counts
        if (feedbackData.type === 'like') {
            rule.feedback.likes++;
        } else if (feedbackData.type === 'dislike') {
            rule.feedback.dislikes++;
        } else if (feedbackData.type === 'improvement') {
            rule.feedback.improvements++;
        }
        rule.feedback.total++;
        
        // Calculate confidence based on feedback ratio and sample size
        const likeRatio = rule.feedback.likes / rule.feedback.total;
        const sampleConfidence = Math.min(rule.feedback.total / 20, 1); // Full confidence at 20+ samples
        rule.confidence = likeRatio * sampleConfidence;
        
        rule.lastUpdated = new Date().toISOString();
        
        this.saveOptimizationState();
    }

    updateOptimizationRules(session, feedbackData) {
        const parameters = session.parameters;
        const ruleKey = this.generateRuleKey(parameters);
        const rule = this.optimizationRules.get(ruleKey);
        
        if (!rule || rule.feedback.total < this.adaptiveSettings.minSamples) {
            return; // Not enough data for reliable optimization
        }

        const likeRatio = rule.feedback.likes / rule.feedback.total;
        const dislikeRatio = rule.feedback.dislikes / rule.feedback.total;
        
        // Adjust difficulty based on feedback patterns
        if (dislikeRatio > 0.6) {
            // High dislike ratio - questions might be too hard or too easy
            if (parameters.difficulty === 'expert' || parameters.difficulty === 'advanced') {
                rule.adjustments.difficulty = -0.1; // Suggest easier questions
            } else if (parameters.difficulty === 'basic') {
                rule.adjustments.difficulty = 0.1; // Suggest harder questions
            }
        } else if (likeRatio > 0.8) {
            // High like ratio - current difficulty is good, maybe slightly increase
            rule.adjustments.difficulty = 0.05;
        }

        // Adjust question type preferences
        const questionData = this.getQuestionFromSession(session, feedbackData.questionId);
        if (questionData) {
            const questionType = this.normalizeQuestionType(questionData.type);
            const currentAdjustment = rule.adjustments.questionTypes.get(questionType) || 0;
            
            if (feedbackData.type === 'like') {
                rule.adjustments.questionTypes.set(questionType, currentAdjustment + 0.1);
            } else if (feedbackData.type === 'dislike') {
                rule.adjustments.questionTypes.set(questionType, currentAdjustment - 0.1);
            }
        }

        // Adjust focus area suggestions
        if (feedbackData.type === 'dislike' && parameters.focusArea) {
            rule.adjustments.focusAdjustment = -0.1; // Suggest broader focus
        } else if (feedbackData.type === 'like' && !parameters.focusArea) {
            rule.adjustments.focusAdjustment = 0.1; // Suggest more focused content
        }
    }

    normalizeQuestionType(type) {
        if (!type) return 'unknown';
        
        const lowerType = type.toLowerCase().trim();
        return this.questionTypeMapping.get(lowerType) || lowerType;
    }

    getQuestionFromSession(session, questionId) {
        return session.questions.find(q => q.id === questionId);
    }

    generateRuleKey(parameters) {
        return JSON.stringify({
            difficulty: parameters.difficulty,
            knowledgeArea: parameters.knowledgeArea,
            aiModel: parameters.aiModel
        });
    }

    optimizeParameters(generationRequest) {
        const currentParams = generationRequest.parameters;
        const recommendations = this.getParameterRecommendations(currentParams);
        
        if (!recommendations || Object.keys(recommendations).length === 0) {
            return; // No optimizations available
        }

        // Apply recommendations to the request
        this.applyRecommendations(generationRequest, recommendations);
        
        console.log('Applied parameter optimizations:', recommendations);
    }

    getParameterRecommendations(currentParams) {
        const recommendations = {};
        const relevantRules = this.findRelevantRules(currentParams);
        
        if (relevantRules.length === 0) {
            return recommendations;
        }

        // Aggregate recommendations from multiple rules
        const aggregatedAdjustments = this.aggregateAdjustments(relevantRules);
        
        // Convert adjustments to recommendations
        if (Math.abs(aggregatedAdjustments.difficulty) > 0.05) {
            recommendations.difficulty = this.adjustDifficulty(
                currentParams.difficulty, 
                aggregatedAdjustments.difficulty
            );
        }

        if (aggregatedAdjustments.questionTypes.size > 0) {
            recommendations.questionTypes = this.adjustQuestionTypes(
                currentParams.questionTypes,
                aggregatedAdjustments.questionTypes
            );
        }

        if (Math.abs(aggregatedAdjustments.focusAdjustment) > 0.1) {
            recommendations.focusAdjustment = aggregatedAdjustments.focusAdjustment > 0 
                ? 'increase_focus' : 'decrease_focus';
        }

        return recommendations;
    }

    findRelevantRules(currentParams) {
        const relevantRules = [];
        
        for (const [ruleKey, rule] of this.optimizationRules) {
            if (rule.confidence < this.adaptiveSettings.confidenceThreshold) {
                continue; // Skip low-confidence rules
            }

            // Check if rule is relevant to current parameters
            const similarity = this.calculateParameterSimilarity(currentParams, rule.parameters);
            if (similarity > 0.7) { // 70% similarity threshold
                relevantRules.push({
                    ...rule,
                    similarity,
                    weight: rule.confidence * similarity
                });
            }
        }

        // Sort by weight (confidence * similarity)
        return relevantRules.sort((a, b) => b.weight - a.weight);
    }

    calculateParameterSimilarity(params1, params2) {
        let matchScore = 0;
        let totalFactors = 0;

        // Compare each parameter
        if (params1.difficulty && params2.difficulty) {
            totalFactors++;
            if (params1.difficulty === params2.difficulty) {
                matchScore++;
            } else {
                // Partial credit for similar difficulties
                const difficultyOrder = ['basic', 'intermediate', 'advanced', 'expert'];
                const index1 = difficultyOrder.indexOf(params1.difficulty);
                const index2 = difficultyOrder.indexOf(params2.difficulty);
                if (Math.abs(index1 - index2) <= 1) {
                    matchScore += 0.5;
                }
            }
        }

        if (params1.knowledgeArea && params2.knowledgeArea) {
            totalFactors++;
            if (params1.knowledgeArea === params2.knowledgeArea) {
                matchScore++;
            }
        }

        if (params1.aiModel && params2.aiModel) {
            totalFactors++;
            if (params1.aiModel === params2.aiModel) {
                matchScore++;
            }
        }

        return totalFactors > 0 ? matchScore / totalFactors : 0;
    }

    aggregateAdjustments(rules) {
        const aggregated = {
            difficulty: 0,
            questionTypes: new Map(),
            focusAdjustment: 0
        };

        let totalWeight = 0;

        rules.forEach(rule => {
            const weight = rule.weight;
            totalWeight += weight;

            // Aggregate difficulty adjustments
            aggregated.difficulty += rule.adjustments.difficulty * weight;

            // Aggregate question type adjustments
            for (const [type, adjustment] of rule.adjustments.questionTypes) {
                const current = aggregated.questionTypes.get(type) || 0;
                aggregated.questionTypes.set(type, current + adjustment * weight);
            }

            // Aggregate focus adjustments
            aggregated.focusAdjustment += rule.adjustments.focusAdjustment * weight;
        });

        // Normalize by total weight
        if (totalWeight > 0) {
            aggregated.difficulty /= totalWeight;
            aggregated.focusAdjustment /= totalWeight;
            
            for (const [type, adjustment] of aggregated.questionTypes) {
                aggregated.questionTypes.set(type, adjustment / totalWeight);
            }
        }

        return aggregated;
    }

    adjustDifficulty(currentDifficulty, adjustment) {
        const difficultyOrder = ['basic', 'intermediate', 'advanced', 'expert'];
        const currentIndex = difficultyOrder.indexOf(currentDifficulty);
        
        if (currentIndex === -1) return currentDifficulty;

        let newIndex = currentIndex;
        if (adjustment > 0.05) {
            newIndex = Math.min(difficultyOrder.length - 1, currentIndex + 1);
        } else if (adjustment < -0.05) {
            newIndex = Math.max(0, currentIndex - 1);
        }

        return difficultyOrder[newIndex];
    }

    adjustQuestionTypes(currentTypes, adjustments) {
        const adjusted = { ...currentTypes };
        
        for (const [type, adjustment] of adjustments) {
            if (adjustment > 0.1) {
                // Recommend enabling this question type
                adjusted[type] = true;
            } else if (adjustment < -0.1 && adjusted[type]) {
                // Recommend reducing this question type (but don't disable completely)
                // This could be implemented as a weight reduction
                console.log(`Consider reducing ${type} questions based on feedback`);
            }
        }

        return adjusted;
    }

    applyRecommendations(generationRequest, recommendations) {
        // Apply difficulty recommendation
        if (recommendations.difficulty && 
            recommendations.difficulty !== generationRequest.parameters.difficulty) {
            
            generationRequest.parameters.originalDifficulty = generationRequest.parameters.difficulty;
            generationRequest.parameters.difficulty = recommendations.difficulty;
            
            console.log(`Optimized difficulty: ${generationRequest.parameters.originalDifficulty} -> ${recommendations.difficulty}`);
        }

        // Apply question type recommendations
        if (recommendations.questionTypes) {
            generationRequest.parameters.originalQuestionTypes = { ...generationRequest.parameters.questionTypes };
            Object.assign(generationRequest.parameters.questionTypes, recommendations.questionTypes);
            
            console.log('Optimized question types based on feedback');
        }

        // Apply focus adjustments
        if (recommendations.focusAdjustment) {
            const currentFocus = generationRequest.parameters.focusArea || '';
            if (recommendations.focusAdjustment === 'increase_focus' && !currentFocus) {
                // Suggest adding focus keywords based on successful patterns
                const suggestedFocus = this.getSuggestedFocusKeywords(generationRequest.parameters);
                if (suggestedFocus) {
                    generationRequest.parameters.suggestedFocusArea = suggestedFocus;
                }
            }
        }
    }

    getSuggestedFocusKeywords(parameters) {
        // Get high-performing focus areas for this parameter combination
        const history = window.questionGenerationHistory;
        if (!history) return null;

        const performanceTrends = history.getPerformanceTrends(30);
        if (!performanceTrends) return null;

        const topParams = performanceTrends.topPerformingParameters
            .filter(p => p.parameters.knowledgeArea === parameters.knowledgeArea)
            .slice(0, 3);

        const focusAreas = topParams
            .map(p => p.parameters.focusArea)
            .filter(f => f && f.trim().length > 0);

        return focusAreas.length > 0 ? focusAreas[0] : null;
    }

    // Question type validation and correction
    validateAndCorrectQuestionTypes(questions, requestedTypes) {
        const correctedQuestions = [];
        const typeCorrections = new Map();

        for (const question of questions) {
            const originalType = question.type;
            const normalizedType = this.normalizeQuestionType(originalType);
            
            // Check if the normalized type is in requested types
            const validType = this.findValidType(normalizedType, requestedTypes);
            
            if (validType) {
                question.type = validType;
                if (originalType !== validType) {
                    typeCorrections.set(originalType, validType);
                }
            } else {
                // Try to map to the closest valid type
                const closestType = this.findClosestValidType(normalizedType, requestedTypes);
                if (closestType) {
                    question.type = closestType;
                    typeCorrections.set(originalType, closestType);
                } else {
                    // Default to the first requested type
                    const firstValidType = Object.keys(requestedTypes)[0];
                    question.type = firstValidType;
                    typeCorrections.set(originalType, firstValidType);
                }
            }
            
            correctedQuestions.push(question);
        }

        // Log corrections made
        if (typeCorrections.size > 0) {
            console.log('Question type corrections made:', Array.from(typeCorrections.entries()));
        }

        return {
            questions: correctedQuestions,
            corrections: typeCorrections
        };
    }

    findValidType(normalizedType, requestedTypes) {
        // Direct match
        if (requestedTypes[normalizedType]) {
            return normalizedType;
        }

        // Check aliases
        for (const requestedType of Object.keys(requestedTypes)) {
            if (this.questionTypeMapping.get(normalizedType) === requestedType) {
                return requestedType;
            }
        }

        return null;
    }

    findClosestValidType(normalizedType, requestedTypes) {
        const requestedTypesList = Object.keys(requestedTypes);
        
        // Similarity mappings
        const similarities = {
            'differential': ['essay', 'case_study', 'management'],
            'case_study': ['management', 'essay'],
            'calculation': ['short_answer'],
            'image': ['mcq', 'short_answer'],
            'anatomy': ['mcq', 'matching'],
            'pathology': ['mcq', 'essay'],
            'pharmacology': ['mcq', 'short_answer']
        };

        const similar = similarities[normalizedType];
        if (similar) {
            for (const simType of similar) {
                if (requestedTypesList.includes(simType)) {
                    return simType;
                }
            }
        }

        return null;
    }

    loadOptimizationState() {
        try {
            const saved = localStorage.getItem('feedbackParameterOptimizer_state');
            if (saved) {
                const data = JSON.parse(saved);
                this.optimizationRules = new Map(data.optimizationRules || []);
                this.adaptiveSettings = { ...this.adaptiveSettings, ...(data.adaptiveSettings || {}) };
                
                console.log(`Loaded ${this.optimizationRules.size} optimization rules from storage`);
            }
        } catch (error) {
            console.error('Error loading optimization state:', error);
        }
    }

    saveOptimizationState() {
        try {
            const data = {
                optimizationRules: Array.from(this.optimizationRules.entries()),
                adaptiveSettings: this.adaptiveSettings,
                lastSaved: new Date().toISOString()
            };
            
            localStorage.setItem('feedbackParameterOptimizer_state', JSON.stringify(data));
        } catch (error) {
            console.error('Error saving optimization state:', error);
        }
    }

    getOptimizationInsights() {
        const insights = {
            totalRules: this.optimizationRules.size,
            highConfidenceRules: 0,
            recommendations: {},
            topPerformingCombinations: [],
            improvementOpportunities: []
        };

        // Analyze rules
        for (const [ruleKey, rule] of this.optimizationRules) {
            if (rule.confidence >= this.adaptiveSettings.confidenceThreshold) {
                insights.highConfidenceRules++;
                
                const likeRatio = rule.feedback.likes / rule.feedback.total;
                insights.topPerformingCombinations.push({
                    parameters: rule.parameters,
                    performance: likeRatio,
                    samples: rule.feedback.total
                });
            } else if (rule.feedback.total >= this.adaptiveSettings.minSamples) {
                insights.improvementOpportunities.push({
                    parameters: rule.parameters,
                    issues: this.identifyIssues(rule)
                });
            }
        }

        // Sort by performance
        insights.topPerformingCombinations.sort((a, b) => b.performance - a.performance);
        insights.topPerformingCombinations = insights.topPerformingCombinations.slice(0, 5);

        return insights;
    }

    identifyIssues(rule) {
        const issues = [];
        const likeRatio = rule.feedback.likes / rule.feedback.total;
        const dislikeRatio = rule.feedback.dislikes / rule.feedback.total;

        if (dislikeRatio > 0.5) {
            issues.push('High dislike ratio - consider adjusting parameters');
        }
        if (rule.feedback.total < 10) {
            issues.push('Low sample size - need more feedback');
        }
        if (likeRatio < 0.3) {
            issues.push('Low satisfaction - major parameter adjustment needed');
        }

        return issues;
    }

    clearOptimizationData() {
        this.optimizationRules.clear();
        localStorage.removeItem('feedbackParameterOptimizer_state');
        console.log('Cleared all optimization data');
    }
}

// Initialize the system globally
if (typeof window !== 'undefined') {
    window.feedbackParameterOptimizer = new FeedbackParameterOptimizer();
}
class MedicalNLP {
    constructor() {
        this.ncbiApiKey = CONFIG.API_KEYS.NCBI;
        this.cachedMedicalContext = {};
        this.isPremiumUser = this.checkPremiumStatus();
    }

    /**
     * Check if the user has donated to upgrade to premium status
     * @returns {boolean} - Whether the user has premium status
     */
    checkPremiumStatus() {
        // Check localStorage for premium status
        const premiumStatus = localStorage.getItem('ophthalmoqa_premium');
        return premiumStatus === 'true';
    }

    /**
     * Set premium status for a user after donation
     * @param {boolean} status - Premium status to set
     */
    setPremiumStatus(status) {
        this.isPremiumUser = status;
        localStorage.setItem('ophthalmoqa_premium', status.toString());
    }

    /**
     * Get premium features for enhanced question generation
     * @returns {object} - Premium features and capabilities
     */
    getPremiumFeatures() {
        return {
            enhancedQuestionBanks: true,
            specializedSubtopics: true,
            advancedDifficulty: true,
            customizableExplanations: true
        };
    }

    /**
     * Enhance medical text content with relevant context from NCBI PubMed
     * @param {string} text - Source medical text to be enhanced
     * @param {string} subspecialty - Medical subspecialty for targeted enhancement
     * @param {string} additionalKeywords - Optional additional focus keywords
     * @returns {Promise<object>} - Enhanced text and medical context
     */
    async enhanceMedicalContext(text, subspecialty, additionalKeywords = '') {
        try {
            // Check if we have cached results for this combination
            const cacheKey = this.generateCacheKey(text.substring(0, 200), subspecialty, additionalKeywords);
            if (this.cachedMedicalContext[cacheKey]) {
                console.log('Using cached medical context');
                return this.cachedMedicalContext[cacheKey];
            }

            // Step 1: Extract key medical terms from the text
            const keyTerms = await this.extractKeyMedicalTerms(text, subspecialty, additionalKeywords);
            
            // Step 2: Get relevant research from NCBI for those terms
            const pubmedResults = await this.fetchNCBIContext(keyTerms, subspecialty);
            
            // Step 3: Generate enhanced knowledge context
            const enhancedContext = this.generateEnhancedContext(text, pubmedResults, subspecialty);
            
            // Cache the results
            this.cachedMedicalContext[cacheKey] = enhancedContext;
            
            return enhancedContext;
        } catch (error) {
            console.error('Error enhancing medical context:', error);
            // Return original text if enhancement fails
            return {
                enhancedText: text,
                pubmedReferences: [],
                subspecialtyContext: this.getSubspecialtyContext(subspecialty)
            };
        }
    }

    /**
     * Generate a unique cache key for medical context
     */
    generateCacheKey(textSample, subspecialty, keywords) {
        return `${textSample}_${subspecialty}_${keywords}`.replace(/\s+/g, '').toLowerCase();
    }

    /**
     * Extract key medical terms from the text for targeted research
     */
    async extractKeyMedicalTerms(text, subspecialty, additionalKeywords) {
        // Start with subspecialty-specific terms if available
        let subspecialtyTerms = this.getSubspecialtyTerms(subspecialty);
        let extractedTerms = [];
        
        // Add additional keywords if provided
        if (additionalKeywords) {
            const keywords = additionalKeywords.split(',').map(k => k.trim());
            subspecialtyTerms = [...subspecialtyTerms, ...keywords];
        }
        
        // Find which subspecialty terms appear in the text
        extractedTerms = subspecialtyTerms.filter(term => 
            text.toLowerCase().includes(term.toLowerCase())
        );
        
        // If we have at least some terms, use those
        if (extractedTerms.length >= 2) {
            return extractedTerms.slice(0, 5); // Limit to top 5 terms
        }
        
        // Otherwise, attempt basic NLP extraction (simplified)
        // In a production environment, this would use a more sophisticated NLP approach
        const commonMedicalPatterns = [
            /\b(?:[A-Z][a-z]+ )+syndrome\b/g,   // Named syndromes
            /\b[A-Z][a-z]+ (disease|disorder)\b/g, // Named diseases
            /\b(?:acute|chronic) [a-z]+(?:itis|osis|emia|opathy)\b/gi, // Medical conditions
            /\b[a-z]+(?:ectomy|otomy|oplasty|oscopy)\b/gi // Medical procedures
        ];
        
        let patternMatches = [];
        for (const pattern of commonMedicalPatterns) {
            const matches = text.match(pattern) || [];
            patternMatches = [...patternMatches, ...matches];
        }
        
        // Combine extracted terms, removing duplicates
        extractedTerms = [...new Set([...extractedTerms, ...patternMatches])];
        
        // If we still don't have enough terms, add the subspecialty itself
        if (extractedTerms.length < 2) {
            extractedTerms.push(subspecialty);
        }
        
        // Limit to 5 terms and return
        return extractedTerms.slice(0, 5);
    }

    /**
     * Get predefined terms for a specific subspecialty
     */
    getSubspecialtyTerms(subspecialty) {
        const subspecialtyMap = CONFIG.MEDICAL_SUBSPECIALTIES;
        return subspecialtyMap[subspecialty] || [];
    }
    
    /**
     * Get rich context about a subspecialty
     */
    getSubspecialtyContext(subspecialty) {
        const contextMap = {
            "retinal-disorders": "Retinal disorders involve pathologies affecting the light-sensitive tissue at the back of the eye, including conditions like retinal detachment, macular degeneration, and diabetic retinopathy.",
            "corneal-diseases": "Corneal diseases affect the transparent front surface of the eye, including infections, degenerative conditions, and injuries that can impact vision clarity.",
            "glaucoma": "Glaucoma represents a group of eye conditions characterized by optic nerve damage, often associated with increased intraocular pressure, leading to progressive vision loss.",
            "cataract": "Cataracts involve clouding of the eye's natural lens, causing progressive vision deterioration typically associated with aging, trauma, or certain medications.",
            "refractive-errors": "Refractive errors occur when the eye cannot properly focus light, resulting in blurred vision, and include myopia, hyperopia, astigmatism, and presbyopia.",
            "neuro-ophthalmology": "Neuro-ophthalmology bridges neurology and ophthalmology, focusing on visual problems related to the nervous system rather than the eyes themselves.",
            "ocular-inflammation": "Ocular inflammation encompasses various inflammatory conditions affecting different eye structures, including uveitis, scleritis, and inflammatory orbital disease.",
            "pediatric": "Pediatric ophthalmology focuses on eye disorders in children, including strabismus, amblyopia, genetic disorders, and developmental abnormalities.",
            "oculoplastics-oncology": "Oculoplastic surgery and oncology involve reconstructive procedures of the eye area and management of ocular tumors and cancer.",
            "general": "General ophthalmology covers the diagnosis, treatment, and management of various eye conditions and visual system disorders."
        };
        
        return contextMap[subspecialty] || "General ophthalmology encompasses the diagnosis and treatment of eye disorders and diseases.";
    }

    /**
     * Fetch relevant medical research context from NCBI PubMed
     */
    async fetchNCBIContext(keywords, subspecialty) {
        try {
            // Create search query from keywords
            const searchQuery = `${keywords.join(' OR ')} AND ophthalmology[MeSH Terms] AND ${subspecialty.replace('-', ' ')}`;
            
            // Step 1: Search NCBI PubMed for relevant articles
            const searchUrl = `${CONFIG.API_ENDPOINTS.NCBI_ESEARCH}?db=pubmed&term=${encodeURIComponent(searchQuery)}&retmax=5&usehistory=y&api_key=${this.ncbiApiKey}&retmode=json`;
            
            const searchResponse = await axios.get(searchUrl);
            
            if (!searchResponse.data?.esearchresult?.idlist || 
                searchResponse.data.esearchresult.idlist.length === 0) {
                console.log('No PubMed results found');
                return [];
            }
            
            // Get the IDs of found articles
            const pubmedIds = searchResponse.data.esearchresult.idlist.slice(0, 3); // Limit to top 3
            
            // Step 2: Fetch article summaries using the retrieved IDs
            const summaryUrl = `${CONFIG.API_ENDPOINTS.NCBI_ESUMMARY}?db=pubmed&id=${pubmedIds.join(',')}&api_key=${this.ncbiApiKey}&retmode=json`;
            const summaryResponse = await axios.get(summaryUrl);
            
            if (!summaryResponse.data?.result) {
                return [];
            }
            
            // Extract and format the results
            const pubmedResults = pubmedIds.map(id => {
                const article = summaryResponse.data.result[id];
                if (!article) return null;
                
                return {
                    title: article.title || '',
                    abstract: article.abstract || '',
                    authors: (article.authors || []).map(a => a.name).join(', '),
                    journal: article.fulljournalname || '',
                    pubDate: article.pubdate || '',
                    pmid: id
                };
            }).filter(result => result !== null);
            
            return pubmedResults;
            
        } catch (error) {
            console.error('Error fetching NCBI context:', error);
            return [];
        }
    }

    /**
     * Generate enhanced context by combining original text with research findings
     */
    generateEnhancedContext(originalText, pubmedResults, subspecialty) {
        let enhancedText = originalText;
        
        // Add subspecialty context if available
        const subspecialtyContext = this.getSubspecialtyContext(subspecialty);
        
        // Extract key insights from PubMed results
        const extractedInsights = [];
        const references = [];
        
        pubmedResults.forEach(result => {
            if (result.abstract) {
                // Extract just the first 2-3 sentences from each abstract
                const sentences = result.abstract.split(/\.\s+/).filter(s => s.length > 20);
                const condensedAbstract = sentences.slice(0, 2).join('. ') + '.';
                
                extractedInsights.push(condensedAbstract);
                references.push({
                    title: result.title,
                    authors: result.authors,
                    journal: result.journal,
                    pubDate: result.pubDate,
                    pmid: result.pmid
                });
            }
        });
        
        // Combine everything into enhanced context
        if (extractedInsights.length > 0) {
            enhancedText = `${originalText}\n\n// Medical Context:\n${subspecialtyContext}\n\n// Recent Research Insights:\n${extractedInsights.join('\n\n')}`;
        } else {
            enhancedText = `${originalText}\n\n// Medical Context:\n${subspecialtyContext}`;
        }
        
        return {
            enhancedText,
            pubmedReferences: references,
            subspecialtyContext
        };
    }
    
    /**
     * Optimize a medical prompt for specialized NLP models
     */
    optimizeMedicalPrompt(prompt, context, subspecialty, questionTypes, difficulty) {
        // Add medical context and subspecialty-specific guidance
        const enhancedPrompt = `${prompt}\n\n// MEDICAL KNOWLEDGE CONTEXT:\n${context.subspecialtyContext}\n\n`;
        
        // Add references if available
        if (context.pubmedReferences && context.pubmedReferences.length > 0) {
            const medicalSpecificGuidance = this.getMedicalTypeGuidance(questionTypes, difficulty, subspecialty);
            
            return `${enhancedPrompt}${medicalSpecificGuidance}`;
        }
        
        return enhancedPrompt;
    }
    
    /**
     * Get specialized guidance for different medical question types
     */
    getMedicalTypeGuidance(questionTypes, difficulty, subspecialty) {
        let guidance = "// SPECIALIZED OPHTHALMOLOGY QUESTION GUIDANCE:\n";
        
        // Add difficulty-specific guidance
        if (difficulty === 'specialist' || difficulty === 'advanced') {
            guidance += "Focus on nuanced clinical decision-making, rare presentations, and challenging diagnostic scenarios. Include recent advances in treatment modalities.\n";
        } else if (difficulty === 'board') {
            guidance += "Focus on high-yield topics frequently tested in board examinations. Include classical presentations and key diagnostic criteria.\n";
        } else {
            guidance += "Focus on fundamental concepts and common conditions with their typical presentations and first-line management.\n";
        }
        
        // Add question type-specific guidance
        if (questionTypes.clinicalCase) {
            guidance += `For clinical case questions: Create realistic patient scenarios involving ${subspecialty.replace('-', ' ')} conditions with appropriate clinical findings, diagnostic results, and management options.\n`;
        }
        
        if (questionTypes.differential) {
            guidance += `For differential diagnosis questions: Include key distinguishing features between similar ${subspecialty.replace('-', ' ')} conditions, focusing on diagnostic pearls.\n`;
        }
        
        return guidance;
    }
    
    /**
     * Process and enhance questions with medical accuracy improvements
     */
    enhanceGeneratedQuestions(questions, subspecialty) {
        return questions.map(question => {
            // Process MCQ options for better clarity and accuracy
            if (question.type === 'mcq' && Array.isArray(question.options)) {
                // Ensure options are distinct and well-formatted
                question.options = question.options.map(option => {
                    return option.trim().replace(/\.$/, ''); // Remove trailing periods
                });
                
                // If all options are single words, consider adding more detail
                const allSingleWords = question.options.every(opt => !opt.includes(' '));
                if (allSingleWords && question.options[0].length < 15) {
                    console.log('Enhancing brief MCQ options');
                    // This would be expanded in a real implementation
                }
            }
            
            // Enhance explanations with more detail if they're too brief
            if (question.explanation && question.explanation.length < 50) {
                // In a real implementation, this would use another API call
                // to expand the explanation with medical knowledge
                console.log('Explanation too brief, would enhance in production');
            }
            
            return question;
        });
    }
} 
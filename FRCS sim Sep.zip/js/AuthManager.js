/**
 * AuthManager - Manages user authentication and premium access verification
 * for OphthalmoQA application.
 */
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.isLoggedIn = false;
        this.loginModal = null;
        this.registerModal = null;
        this.loginForm = null;
        this.registerForm = null;
        this.logoutButton = null;
        this.userDisplay = null;
        
        // System admin/creator user credentials - stored for demo purposes only
        // In a real app, this would be server-side
        this.creatorUser = {
            id: 'admin_creator',
            name: 'genododi',
            email: 'genododi@gmail.com',
            password: '2030', // Storing password in plain text only for demo
            premium: true,
            isCreator: true,
            createdAt: '2023-01-01T00:00:00.000Z'
        };
        
        // Security salt for encryption (in production, this would be stored server-side)
        // Using a fixed salt rather than one that depends on user agent to avoid recursion issues
        this.securitySalt = 'ophthalmoqa_secure_fixed_salt_2024';
        
        // Auth state - must be after security salt is defined
        this.authToken = this.getStoredAuthToken();
        
        // Initialize components
        this.initializeComponents();
        
        // Check login status on load
        this.checkLoginStatus();

        // Add event listener for page unload
        window.addEventListener('beforeunload', this.handlePageUnload.bind(this));
    }
    
    /**
     * Initialize all authentication related UI components
     */
    initializeComponents() {
        // Create login modal
        this.createLoginUI();
        
        // Create user display area in header
        this.createUserDisplay();
        
        // Bind events
        this.bindEvents();
    }
    
    /**
     * Creates the login UI elements
     */
    createLoginUI() {
        // Create login modal
        const loginModal = document.createElement('div');
        loginModal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        loginModal.id = 'login-modal';
        
        // Login form HTML
        loginModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative">
                <button id="close-login-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-6 flex items-center">
                    <i class="fas fa-lock mr-2"></i> Login to OphthalmoQA
                </h2>
                <form id="login-form">
                    <div class="mb-4">
                        <label for="login-email" class="block text-gray-700 font-medium mb-2">Email Address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input type="email" id="login-email" name="email" required autocomplete="email"
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="login-password" class="block text-gray-700 font-medium mb-2">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input type="password" id="login-password" name="password" required 
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition">
                            <button type="button" id="toggle-password-visibility" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="mt-1 text-right">
                            <a href="#" id="forgot-password-link" class="text-sm text-primary hover:text-accent">Forgot Password?</a>
                        </div>
                    </div>
                    <div class="mb-6">
                        <label class="flex items-center">
                            <input type="checkbox" id="keep-logged-in" name="keepLoggedIn" 
                                class="h-4 w-4 text-primary focus:ring-secondary border-gray-300 rounded">
                            <span class="ml-2 block text-sm text-gray-700">Keep me logged in</span>
                        </label>
                        <p class="text-xs text-gray-500 mt-1 ml-6">If unchecked, you'll be logged out when you refresh or close the page</p>
                    </div>
                    <div id="login-error" class="text-red-500 text-sm mb-4 hidden"></div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="submit" class="w-full bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                            <i class="fas fa-sign-in-alt mr-2"></i> Log In
                        </button>
                        <button type="button" id="switch-to-register" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition">
                            Create Account
                        </button>
                    </div>
                    <div class="mt-5 pt-5 border-t border-gray-200 text-center">
                        <p class="text-xs text-gray-500">
                            By logging in, you agree to our 
                            <a href="#" class="text-primary hover:underline">Terms of Service</a> and 
                            <a href="#" class="text-primary hover:underline">Privacy Policy</a>
                        </p>
                    </div>
                </form>
            </div>
        `;
        
        // Create password reset modal
        const passwordResetModal = document.createElement('div');
        passwordResetModal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        passwordResetModal.id = 'password-reset-modal';
        
        // Password reset form HTML
        passwordResetModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative">
                <button id="close-password-reset-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-4 flex items-center">
                    <i class="fas fa-key mr-2"></i> Reset Your Password
                </h2>
                <form id="password-reset-form">
                    <div class="mb-5 bg-blue-50 p-4 rounded-md border-l-4 border-blue-500 text-sm text-gray-700">
                        <p class="mb-2"><strong>Password recovery steps:</strong></p>
                        <ol class="list-decimal pl-5 space-y-1">
                            <li>Enter your registered email address below</li>
                            <li>We'll send a temporary access code to your email</li>
                            <li>Use the code to log in and update your password</li>
                        </ol>
                    </div>
                    <div class="mb-4">
                        <label for="reset-email" class="block text-gray-700 font-medium mb-2">Your Email Address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input type="email" id="reset-email" name="email" required autocomplete="email"
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                                placeholder="Enter your registered email">
                        </div>
                    </div>
                    <div id="reset-message" class="mb-4 p-3 rounded-md text-sm hidden"></div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="submit" id="reset-submit-btn" class="w-full bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                            <i class="fas fa-paper-plane mr-2"></i> Send Recovery Code
                        </button>
                        <button type="button" id="back-to-login" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition">
                            Back to Login
                        </button>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-200 text-xs text-gray-500">
                        <p class="flex items-center mb-1"><i class="fas fa-shield-alt mr-2"></i> For your security, we never store passwords in plain text.</p>
                        <p>If you continue to have trouble, please contact <a href="mailto:support@ophthalmoqa.com" class="text-primary hover:underline">support@ophthalmoqa.com</a></p>
                    </div>
                </form>
            </div>
        `;
        
        // Create registration modal
        const registerModal = document.createElement('div');
        registerModal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        registerModal.id = 'register-modal';
        
        // Registration form HTML
        registerModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative max-h-[90vh] overflow-y-auto">
                <button id="close-register-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-5 flex items-center">
                    <i class="fas fa-user-plus mr-2"></i> Create Your Account
                </h2>
                <p class="text-sm text-gray-600 mb-5">Join OphthalmoQA to access specialized ophthalmology question banks</p>
                <form id="register-form">
                    <div class="mb-4">
                        <label for="register-name" class="block text-gray-700 font-medium mb-2">Full Name</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-user text-gray-400"></i>
                            </div>
                            <input type="text" id="register-name" name="name" required autocomplete="name"
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                                placeholder="Enter your full name">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="register-email" class="block text-gray-700 font-medium mb-2">Email Address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input type="email" id="register-email" name="email" required autocomplete="email"
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                                placeholder="your.email@example.com">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="register-password" class="block text-gray-700 font-medium mb-2">Create Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input type="password" id="register-password" name="password" required 
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                                placeholder="Minimum 6 characters">
                            <button type="button" id="toggle-reg-password-visibility" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="mb-5">
                        <label for="register-confirm-password" class="block text-gray-700 font-medium mb-2">Confirm Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input type="password" id="register-confirm-password" name="confirmPassword" required 
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                                placeholder="Re-enter your password">
                        </div>
                    </div>
                    
                    <div class="mb-5">
                        <label class="flex items-start">
                            <input type="checkbox" id="register-terms" name="terms" required 
                                class="h-4 w-4 mt-1 text-primary focus:ring-secondary border-gray-300 rounded">
                            <span class="ml-2 block text-sm text-gray-700">
                                I agree to the <a href="#" class="text-primary hover:underline">Terms of Service</a> and <a href="#" class="text-primary hover:underline">Privacy Policy</a>
                            </span>
                        </label>
                    </div>
                    
                    <div id="register-error" class="text-red-500 text-sm mb-4 hidden"></div>
                    
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="submit" class="w-full bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                            <i class="fas fa-user-plus mr-2"></i> Create Account
                        </button>
                        <button type="button" id="switch-to-login" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition">
                            Already Have Account
                        </button>
                    </div>
                    
                    <div class="mt-5 pt-5 border-t border-gray-200">
                        <div class="text-center">
                            <p class="text-xs text-gray-500 mb-3">By creating an account, you'll gain access to our standard features.</p>
                            <p class="text-xs text-gray-500">Want access to premium content? <a href="#" id="view-premium-features" class="text-primary font-medium hover:underline">View premium features</a></p>
                        </div>
                    </div>
                </form>
            </div>
        `;
        
        // Create account settings modal
        const accountSettingsModal = document.createElement('div');
        accountSettingsModal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        accountSettingsModal.id = 'account-settings-modal';
        
        // Account settings form HTML
        accountSettingsModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative">
                <button id="close-account-settings-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-6 flex items-center">
                    <i class="fas fa-user-cog mr-2"></i> Account Settings
                </h2>
                <form id="account-settings-form">
                    <div class="mb-4">
                        <label for="settings-name" class="block text-gray-700 font-medium mb-2">Full Name</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-user text-gray-400"></i>
                            </div>
                            <input type="text" id="settings-name" name="name" required
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="settings-email" class="block text-gray-700 font-medium mb-2">Email Address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input type="email" id="settings-email" name="email" required
                                class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition">
                        </div>
                    </div>
                    <div class="mb-6">
                        <button type="button" id="change-password-btn" 
                            class="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-md transition flex items-center justify-between">
                            <span class="flex items-center">
                                <i class="fas fa-key text-gray-400 mr-2"></i>
                                Change Password
                            </span>
                            <i class="fas fa-chevron-right text-gray-400"></i>
                        </button>
                    </div>
                    <div class="mb-6">
                        <h3 class="text-gray-700 font-medium mb-2">Account Status</h3>
                        <div class="bg-gray-50 p-4 rounded-md">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm text-gray-600">Premium Access</span>
                                <span id="premium-status-badge" class="px-3 py-1 rounded-full text-xs font-medium"></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Member Since</span>
                                <span id="member-since" class="text-sm text-gray-800"></span>
                            </div>
                        </div>
                    </div>
                    <div id="settings-error" class="text-red-500 text-sm mb-4 hidden"></div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="submit" class="w-full bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i> Save Changes
                        </button>
                        <button type="button" id="close-settings-btn" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        `;
        
        // Append modals to document
        document.body.appendChild(loginModal);
        document.body.appendChild(passwordResetModal);
        document.body.appendChild(registerModal);
        document.body.appendChild(accountSettingsModal);
        
        // Store references
        this.loginModal = loginModal;
        this.passwordResetModal = passwordResetModal;
        this.registerModal = registerModal;
        this.accountSettingsModal = accountSettingsModal;
        this.loginForm = document.getElementById('login-form');
        this.passwordResetForm = document.getElementById('password-reset-form');
        this.registerForm = document.getElementById('register-form');
        this.accountSettingsForm = document.getElementById('account-settings-form');
        
        // Password visibility toggles
        document.getElementById('toggle-password-visibility')?.addEventListener('click', (e) => {
            const passwordField = document.getElementById('login-password');
            const icon = e.currentTarget.querySelector('i');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        document.getElementById('toggle-reg-password-visibility')?.addEventListener('click', (e) => {
            const passwordField = document.getElementById('register-password');
            const icon = e.currentTarget.querySelector('i');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        // View premium features link
        document.getElementById('view-premium-features')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.hideRegisterModal();
            // Scroll to donation section
            const donationSection = document.querySelector('.donation-section');
            if (donationSection) {
                donationSection.scrollIntoView({ behavior: 'smooth' });
                // Highlight donation section briefly
                donationSection.classList.add('animate-pulse');
                setTimeout(() => {
                    donationSection.classList.remove('animate-pulse');
                }, 2000);
            }
        });
    }
    
    /**
     * Creates user display area in the header
     */
    createUserDisplay() {
        // Look for the user display container first
        const userDisplayContainer = document.querySelector('.user-display-container');
        const fallbackLocation = document.querySelector('header');
        
        if (!userDisplayContainer && !fallbackLocation) return;

        const userDisplay = document.createElement('div');
        userDisplay.className = 'relative flex items-center';
        userDisplay.innerHTML = `
            <div class="flex items-center">
                <button id="user-menu-button" class="hidden flex items-center text-xs bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-200 shadow-md" aria-expanded="false">
                    <span class="sr-only">Open user menu</span>
                    <div class="h-5 w-5 rounded-full bg-white text-green-600 flex items-center justify-center mr-2">
                        <i class="fas fa-user text-xs"></i>
                    </div>
                    <span class="font-medium user-name"></span>
                    <i class="fas fa-chevron-down ml-1 text-xs"></i>
                </button>
                <button id="login-button" class="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-2 rounded-full font-medium transition duration-200 shadow-md">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Log In
                </button>
            </div>

            <!-- Dropdown menu -->
            <div id="user-dropdown" class="hidden origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 py-1 z-50">
                <div class="px-4 py-2 text-xs text-gray-500 border-b border-gray-100">
                    Signed in as <span class="font-medium user-email"></span>
                </div>
                <a href="#" data-action="account-settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    <i class="fas fa-user-cog mr-2"></i> Account Settings
                </a>
                <a href="#" data-action="premium-status" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    <i class="fas fa-crown mr-2"></i> Premium Status
                </a>
                <div class="border-t border-gray-100"></div>
                <a href="#" data-action="logout" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    <i class="fas fa-sign-out-alt mr-2"></i> Sign Out
                </a>
            </div>
        `;

        // Append to user display container if it exists, otherwise fallback to header
        if (userDisplayContainer) {
            userDisplayContainer.appendChild(userDisplay);
        } else {
            fallbackLocation.appendChild(userDisplay);
        }
        this.userDisplay = userDisplay;
        this.userMenuButton = userDisplay.querySelector('#user-menu-button');
        this.loginButton = userDisplay.querySelector('#login-button');
        this.userDropdown = userDisplay.querySelector('#user-dropdown');

        // Add click event listener to close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (this.userDropdown && 
                this.userMenuButton && 
                !this.userMenuButton.contains(e.target) && 
                !this.userDropdown.contains(e.target)) {
                this.userDropdown.classList.add('hidden');
            }
        });

        // Add click event for user menu button
        this.userMenuButton.addEventListener('click', () => {
            this.toggleUserDropdown();
        });

        // Add click event for login button
        this.loginButton.addEventListener('click', () => {
            this.showLoginModal();
        });
    }
    
    /**
     * Bind all event handlers
     */
    bindEvents() {
        // Wait for DOM to be ready
        setTimeout(() => {
            // Login form events
            if (this.loginForm) {
                this.loginForm.addEventListener('submit', this.handleLogin.bind(this));
            }
            
            // Register form events
            if (this.registerForm) {
                this.registerForm.addEventListener('submit', this.handleRegistration.bind(this));
            }
            
            // Password reset form events
            if (this.passwordResetForm) {
                this.passwordResetForm.addEventListener('submit', this.handlePasswordReset.bind(this));
            }
            
            // Account settings form events
            if (this.accountSettingsForm) {
                this.accountSettingsForm.addEventListener('submit', this.handleAccountSettingsUpdate.bind(this));
            }
            
            // Modal close buttons
            const closeButtons = [
                { id: 'close-login-modal', action: () => this.hideLoginModal() },
                { id: 'close-register-modal', action: () => this.hideRegisterModal() },
                { id: 'close-password-reset-modal', action: () => this.hidePasswordResetModal() },
                { id: 'close-account-settings-modal', action: () => this.hideAccountSettings() },
                { id: 'close-settings-btn', action: () => this.hideAccountSettings() }
            ];
            
            closeButtons.forEach(({ id, action }) => {
                const element = document.getElementById(id);
                if (element) {
                    element.addEventListener('click', action);
                }
            });
            
            // Switch between modals
            const modalSwitches = [
                { id: 'switch-to-register', action: () => { this.hideLoginModal(); this.showRegisterModal(); } },
                { id: 'forgot-password-link', action: (e) => { e.preventDefault(); this.hideLoginModal(); this.showPasswordResetModal(); } },
                { id: 'back-to-login', action: () => { this.hidePasswordResetModal(); this.showLoginModal(); } }
            ];
            
            modalSwitches.forEach(({ id, action }) => {
                const element = document.getElementById(id);
                if (element) {
                    element.addEventListener('click', action);
                }
            });
            
            // Password visibility toggles
            const toggleLoginPassword = document.getElementById('toggle-password-visibility');
            const toggleRegPassword = document.getElementById('toggle-reg-password-visibility');
            
            if (toggleLoginPassword) {
                toggleLoginPassword.addEventListener('click', () => {
                    const passwordInput = document.getElementById('login-password');
                    if (passwordInput) {
                        const type = passwordInput.type === 'password' ? 'text' : 'password';
                        passwordInput.type = type;
                        toggleLoginPassword.innerHTML = `<i class="fas fa-${type === 'password' ? 'eye' : 'eye-slash'}"></i>`;
                    }
                });
            }
            
            if (toggleRegPassword) {
                toggleRegPassword.addEventListener('click', () => {
                    const passwordInput = document.getElementById('register-password');
                    if (passwordInput) {
                        const type = passwordInput.type === 'password' ? 'text' : 'password';
                        passwordInput.type = type;
                        toggleRegPassword.innerHTML = `<i class="fas fa-${type === 'password' ? 'eye' : 'eye-slash'}"></i>`;
                    }
                });
            }
            
            // Change password button in account settings
            const changePasswordBtn = document.getElementById('change-password-btn');
            if (changePasswordBtn) {
                changePasswordBtn.addEventListener('click', () => {
                    this.hideAccountSettings();
                    this.showPasswordResetModal();
                });
            }
            
            // Account settings button in user dropdown
            const accountSettingsBtn = document.querySelector('[data-action="account-settings"]');
            if (accountSettingsBtn) {
                accountSettingsBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.toggleUserDropdown(); // Hide the dropdown
                    this.showAccountSettings();
                });
            }
            
            // Logout button
            const logoutButton = document.querySelector('[data-action="logout"]');
            if (logoutButton) {
                logoutButton.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.toggleUserDropdown(); // Hide the dropdown
                    this.logout();
                });
            }
            
            // Fallback: Handle any remaining account settings placeholder alerts
            const accountSettingsLinks = document.querySelectorAll('a[href="#"], button');
            accountSettingsLinks.forEach(link => {
                const text = link.textContent.toLowerCase();
                if (text.includes('account settings') || link.id === 'account-settings') {
                    // Remove any existing click handlers that might show placeholder alerts
                    link.replaceWith(link.cloneNode(true));
                    
                    // Get the new element after replacement
                    const newLink = (link.id ? document.querySelector(`#${link.id}`) : null) || 
                                   Array.from(document.querySelectorAll('a, button'))
                                        .find(el => el.textContent.toLowerCase().includes('account settings'));
                    
                    if (newLink && !newLink.hasAttribute('data-auth-handled')) {
                        newLink.setAttribute('data-auth-handled', 'true');
                        newLink.addEventListener('click', (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (this.currentUser) {
                                this.showAccountSettings();
                            } else {
                                this.showLoginModal();
                            }
                        });
                    }
                }
            });
        }, 100); // Small delay to ensure DOM elements are ready
    }
    
    /**
     * Toggle the user dropdown menu
     */
    toggleUserDropdown() {
        if (!this.userDropdown) return;
        
        // Toggle visibility
        this.userDropdown.classList.toggle('hidden');
        
        // Update user email in dropdown if shown
        if (!this.userDropdown.classList.contains('hidden') && this.currentUser && this.dropdownUserEmail) {
            this.dropdownUserEmail.textContent = this.currentUser.email;
        }
    }
    
    /**
     * Show login modal
     */
    showLoginModal() {
        this.loginModal.classList.remove('hidden');
        document.getElementById('login-email').focus();
    }
    
    /**
     * Hide login modal
     */
    hideLoginModal() {
        this.loginModal.classList.add('hidden');
    }
    
    /**
     * Show registration modal
     */
    showRegisterModal() {
        this.registerModal.classList.remove('hidden');
        document.getElementById('register-name').focus();
    }
    
    /**
     * Hide registration modal
     */
    hideRegisterModal() {
        this.registerModal.classList.add('hidden');
    }
    
    /**
     * Show password reset modal
     */
    showPasswordResetModal() {
        this.hideLoginModal();
        this.passwordResetModal.classList.remove('hidden');
        document.getElementById('reset-email').focus();
    }
    
    /**
     * Hide password reset modal
     */
    hidePasswordResetModal() {
        this.passwordResetModal.classList.add('hidden');
    }
    
    /**
     * Handle login form submission
     */
    async handleLogin() {
        const emailField = document.getElementById('login-email');
        const passwordField = document.getElementById('login-password');
        const keepLoggedInField = document.getElementById('keep-logged-in');
        const errorElement = document.getElementById('login-error');
        
        errorElement.classList.add('hidden');
        
        const email = emailField.value.trim();
        const password = passwordField.value;
        const keepLoggedIn = keepLoggedInField.checked;
        
        if (!email || !password) {
            this.showLoginError('Please enter both email and password.');
            return;
        }
        
        try {
            const user = await this.authenticateUser(email, password);
            if (user) {
                try {
                    // Explicitly clear any error message
                    if (errorElement) errorElement.classList.add('hidden');
                    
                    this.completeLogin(user, keepLoggedIn);
                    this.hideLoginModal();
                    return; // Exit function after successful login
                } catch (loginError) {
                    console.error('Error completing login:', loginError);
                    this.showLoginError('Error completing login process. Please try again.');
                }
            } else {
                this.showLoginError('Authentication failed. Please check your credentials.');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showLoginError('An error occurred. Please try again.');
        }
    }
    
    /**
     * Handle registration form submission
     */
    async handleRegistration() {
        const nameField = document.getElementById('register-name');
        const emailField = document.getElementById('register-email');
        const passwordField = document.getElementById('register-password');
        const confirmPasswordField = document.getElementById('register-confirm-password');
        const termsCheckbox = document.getElementById('register-terms');
        const errorElement = document.getElementById('register-error');
        
        errorElement.classList.add('hidden');
        
        const name = nameField.value.trim();
        const email = emailField.value.trim();
        const password = passwordField.value;
        const confirmPassword = confirmPasswordField.value;
        
        // Client-side validation
        if (!name || !email || !password) {
            this.showRegisterError('Please fill out all required fields.');
            return;
        }
        
        if (name.length < 2) {
            this.showRegisterError('Name must be at least 2 characters.');
            return;
        }
        
        if (!email.includes('@') || !email.includes('.')) {
            this.showRegisterError('Please enter a valid email address.');
            return;
        }
        
        if (password.length < 6) {
            this.showRegisterError('Password must be at least 6 characters.');
            return;
        }
        
        if (password !== confirmPassword) {
            this.showRegisterError('Passwords do not match.');
            return;
        }
        
        if (termsCheckbox && !termsCheckbox.checked) {
            this.showRegisterError('You must agree to the Terms of Service and Privacy Policy.');
            return;
        }
        
        try {
            // Show loading state
            const submitButton = this.registerForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Creating Account...';
            submitButton.disabled = true;
            
            // Attempt to register
            const user = await this.registerUser(name, email, password);
            
            // Registration successful
            this.completeLogin(user);
            this.hideRegisterModal();
            
            // Show success message with premium upgrade prompt
            const statusEl = document.getElementById('status-message');
            if (statusEl) {
                statusEl.innerHTML = `
                    <div class="flex flex-col">
                        <p class="mb-2"><strong>Welcome, ${name}!</strong> Your account was created successfully.</p>
                        <p class="text-sm">Upgrade to premium to unlock advanced features and unlimited question generation.</p>
                    </div>
                `;
                statusEl.className = 'p-4 rounded-md font-medium my-4 bg-green-100 text-green-800 flex justify-between items-center';
                
                // Add upgrade button to the status message
                const upgradeButton = document.createElement('button');
                upgradeButton.className = 'ml-4 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded transition-colors whitespace-nowrap flex-shrink-0';
                upgradeButton.innerHTML = '<i class="fas fa-crown mr-2"></i> Upgrade Now';
                upgradeButton.addEventListener('click', () => {
                    // Scroll to donation section
                    const donationSection = document.querySelector('.donation-section');
                    if (donationSection) {
                        donationSection.scrollIntoView({ behavior: 'smooth' });
                        // Highlight donation section briefly
                        donationSection.classList.add('animate-pulse');
                        setTimeout(() => {
                            donationSection.classList.remove('animate-pulse');
                        }, 2000);
                    }
                    
                    // Hide the status message
                    statusEl.classList.add('hidden');
                });
                
                statusEl.appendChild(upgradeButton);
                statusEl.classList.remove('hidden');
                
                setTimeout(() => {
                    statusEl.classList.add('hidden');
                }, 8000);
            }
            
            // Scroll to donation section after a short delay
            setTimeout(() => {
                const donationSection = document.querySelector('.donation-section');
                if (donationSection) {
                    donationSection.scrollIntoView({ behavior: 'smooth' });
                    // Highlight donation section briefly
                    donationSection.classList.add('bg-blue-50');
                    setTimeout(() => {
                        donationSection.classList.remove('bg-blue-50');
                    }, 2000);
                }
            }, 1500);
        } catch (error) {
            console.error('Registration error:', error);
            this.showRegisterError(error.message || 'Failed to register. Please try again.');
        } finally {
            // Restore button state
            const submitButton = this.registerForm.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.innerHTML = '<i class="fas fa-user-plus mr-2"></i> Create Account';
                submitButton.disabled = false;
            }
        }
    }
    
    /**
     * Show registration error message
     */
    showRegisterError(message) {
        const errorElement = document.getElementById('register-error');
        if (!errorElement) return;
        
        errorElement.textContent = message;
        errorElement.classList.remove('hidden');
        errorElement.classList.add('bg-red-50', 'p-3', 'rounded-md', 'border-l-4', 'border-red-500');
        
        // Highlight fields with error
        this.highlightInvalidRegisterFields();
        
        // Scroll to error
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    /**
     * Highlight invalid fields in registration form
     */
    highlightInvalidRegisterFields() {
        const nameField = document.getElementById('register-name');
        const emailField = document.getElementById('register-email');
        const passwordField = document.getElementById('register-password');
        const confirmPasswordField = document.getElementById('register-confirm-password');
        
        // Reset previous error highlights
        [nameField, emailField, passwordField, confirmPasswordField].forEach(field => {
            if (field) {
                field.classList.remove('border-red-500', 'bg-red-50');
                field.classList.add('border-gray-300', 'bg-gray-50');
                
                // Remove any previous error message
                const errorMsg = field.parentNode.querySelector('.text-red-500');
                if (errorMsg) {
                    errorMsg.remove();
                }
            }
        });
        
        // Validate and highlight fields
        if (nameField && (!nameField.value.trim() || nameField.value.trim().length < 2)) {
            nameField.classList.remove('border-gray-300', 'bg-gray-50');
            nameField.classList.add('border-red-500', 'bg-red-50');
            this.addFieldErrorMessage(nameField, 'Name must be at least 2 characters.');
        }
        
        if (emailField && (!emailField.value.trim() || !emailField.value.includes('@') || !emailField.value.includes('.'))) {
            emailField.classList.remove('border-gray-300', 'bg-gray-50');
            emailField.classList.add('border-red-500', 'bg-red-50');
            this.addFieldErrorMessage(emailField, 'Please enter a valid email address.');
        }
        
        if (passwordField && (!passwordField.value || passwordField.value.length < 6)) {
            passwordField.classList.remove('border-gray-300', 'bg-gray-50');
            passwordField.classList.add('border-red-500', 'bg-red-50');
            this.addFieldErrorMessage(passwordField, 'Password must be at least 6 characters.');
        }
        
        if (confirmPasswordField && passwordField && confirmPasswordField.value !== passwordField.value) {
            confirmPasswordField.classList.remove('border-gray-300', 'bg-gray-50');
            confirmPasswordField.classList.add('border-red-500', 'bg-red-50');
            this.addFieldErrorMessage(confirmPasswordField, 'Passwords do not match.');
        }
    }
    
    /**
     * Add inline error message below a field
     */
    addFieldErrorMessage(field, message) {
        if (!field || !field.parentNode) return;
        
        // Don't add if already exists
        if (field.parentNode.querySelector('.text-red-500')) return;
        
        const errorMsg = document.createElement('p');
        errorMsg.className = 'text-red-500 text-xs mt-1';
        errorMsg.textContent = message;
        field.parentNode.appendChild(errorMsg);
    }
    
    /**
     * Show login error message
     */
    showLoginError(message) {
        const errorElement = document.getElementById('login-error');
        if (!errorElement) return;
        
        errorElement.textContent = message;
        errorElement.classList.remove('hidden');
        errorElement.classList.add('bg-red-50', 'p-3', 'rounded-md', 'border-l-4', 'border-red-500');
    }
    
    /**
     * Authenticate a user with email and password
     * This is a simulated method for demo purposes
     */
    async authenticateUser(email, password) {
        // In a real application, this would make an API call to a server
        // For demo purposes, we'll simulate authentication
        
        // First check if it's the creator/admin user
        if (email === this.creatorUser.email && password === this.creatorUser.password) {
            return {
                id: this.creatorUser.id,
                name: this.creatorUser.name,
                email: this.creatorUser.email,
                premium: true, // Creator is always premium
                isCreator: true,
                createdAt: this.creatorUser.createdAt
            };
        }

        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 800));

        // Check if there's a stored user with this email
        const users = this.getStoredUsers();
        const user = users.find(u => u.email === email);
        
        if (user && user.password === password) {
            // Return user data (omitting password)
            const { password, ...userData } = user;
            return userData;
        }
        
        // Check basic credentials - this is just a simple fallback for demo
        if (email.includes('@') && password.length >= 6) {
            // Create user object
            const newUser = {
                id: 'user_' + Math.random().toString(36).substr(2, 9),
                name: email.split('@')[0], // Simple name extraction from email
                email: email,
                premium: false, // Default to non-premium
                createdAt: new Date().toISOString()
            };
            
            return newUser;
        }
        
        // Authentication failed
        return null;
    }
    
    /**
     * Register a new user
     * In a real app, this would call an API endpoint
     */
    async registerUser(name, email, password) {
        // First check if it's trying to register with creator credentials
        if (email === this.creatorUser.email) {
            throw new Error('This email is already registered.');
        }
        
        // Validate input fields
        if (!name || name.trim().length < 2) {
            throw new Error('Please enter a valid name (minimum 2 characters).');
        }
        
        if (!email || !email.includes('@') || !email.includes('.')) {
            throw new Error('Please enter a valid email address.');
        }
        
        if (!password || password.length < 6) {
            throw new Error('Password must be at least 6 characters long.');
        }
        
        // Simulate API call
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    // Check if user already exists
                    const users = this.getStoredUsers();
                    if (users.some(u => u.email === email)) {
                        reject(new Error('This email is already registered.'));
                        return;
                    }
                    
                    // Create new user object
                    const newUser = {
                        id: 'user_' + Math.random().toString(36).substr(2, 9),
                        name: name,
                        email: email,
                        password: password, // In real app, this would be hashed
                        premium: false, // Default to non-premium
                        createdAt: new Date().toISOString()
                    };
                    
                    // Store user in local storage for demo purposes
                    this.storeNewUser(newUser);
                    
                    // Return user data (omitting password)
                    const { password: pwd, ...userData } = newUser;
                    resolve(userData);
                } catch (err) {
                    console.error('Registration error:', err);
                    reject(new Error('Registration failed. Please try again.'));
                }
            }, 800); // Simulate network delay
        });
    }
    
    /**
     * Get all stored users
     * @returns {Array} Array of user objects
     */
    getStoredUsers() {
        try {
            const encryptedData = localStorage.getItem('ophthalmoqa_users');
            if (!encryptedData) return [];
            
            const decryptedData = this.decryptData(encryptedData);
            if (!decryptedData) {
                console.warn('No valid decrypted data found, returning empty array');
                return [];
            }
            
            try {
                const parsedData = JSON.parse(decryptedData);
                
                // Ensure we have an array
                if (Array.isArray(parsedData)) {
                    return parsedData;
                } else {
                    console.error('Stored users data is not an array:', parsedData);
                    return [];
                }
            } catch (jsonError) {
                console.error('Error parsing JSON from decrypted data:', jsonError);
                // Clear corrupt data
                localStorage.removeItem('ophthalmoqa_users');
                return [];
            }
        } catch (e) {
            console.error('Error getting stored users:', e);
            // If there's an error, clear the corrupt data
            localStorage.removeItem('ophthalmoqa_users');
            return [];
        }
    }
    
    /**
     * Store a new user
     * @param {Object} user - User object to store
     */
    storeNewUser(user) {
        try {
            if (!user || !user.email) {
                throw new Error('Invalid user data provided');
            }
            
            // Get existing users data directly from localStorage to avoid recursion
            let users = [];
            try {
                const encryptedData = localStorage.getItem('ophthalmoqa_users');
                if (encryptedData) {
                    const decryptedData = this.decryptData(encryptedData);
                    if (decryptedData) {
                        const parsedData = JSON.parse(decryptedData);
                        if (Array.isArray(parsedData)) {
                            users = parsedData;
                        }
                    }
                }
            } catch (readError) {
                console.error('Error reading users data:', readError);
                // Continue with empty users array if reading fails
                users = [];
            }
            
            // Ensure we're not adding duplicate emails
            const userIndex = users.findIndex(u => u.email === user.email);
            if (userIndex >= 0) {
                users.splice(userIndex, 1); // Remove existing user
            }
            
            // Create a clean copy of the user object to avoid reference issues
            const userCopy = JSON.parse(JSON.stringify(user));
            
            // Add the new user
            users.push(userCopy);
            
            // Stringify and store
            const usersJson = JSON.stringify(users);
            const encryptedData = this.encryptData(usersJson);
            localStorage.setItem('ophthalmoqa_users', encryptedData);
            
            console.log(`User registered: ${user.email}`);
            return true;
        } catch (e) {
            console.error('Error storing new user:', e);
            throw new Error('Failed to store user data. Please try again.');
        }
    }
    
    /**
     * Debug method to clear all stored users (for development only)
     */
    clearAllStoredUsers() {
        localStorage.removeItem('ophthalmoqa_users');
        console.log('All stored users cleared');
    }
    
    /**
     * Complete the login process
     */
    completeLogin(user, keepLoggedIn = false) {
        try {
            // Prevent recursive calls
            if (this._isCompletingLogin) {
                console.warn('completeLogin already in progress, skipping to prevent recursion');
                return false;
            }
            this._isCompletingLogin = true;
            
            // Ensure we have a valid user object
            if (!user || !user.email) {
                console.error('Invalid user object provided to completeLogin');
                this._isCompletingLogin = false;
                return false;
            }
            
            // Store user info in memory
            // Add isCreator flag if it matches the creator email
            if (user.email === this.creatorUser.email) {
                user.isCreator = true;
                user.premium = true;
            }
            
            this.currentUser = { ...user }; // Create a copy to avoid reference issues
            this.isLoggedIn = true;
            
            // Generate authentication token
            const token = this.generateSecureToken();
            
            // Store authentication data
            if (keepLoggedIn) {
                // Store in localStorage for persistent login
                this.storeAuthToken(token);
                this.storeUserData(this.currentUser);
                // Also store the persistent preference
                localStorage.setItem('ophthalmoqa_persist_login', 'true');
            } else {
                try {
                    // Store in sessionStorage for temporary login (until page close/refresh)
                    const encryptedToken = this.encryptData(token);
                    const encryptedUser = this.encryptData(JSON.stringify(this.currentUser));
                    
                    sessionStorage.setItem('ophthalmoqa_session_token', encryptedToken);
                    sessionStorage.setItem('ophthalmoqa_session_user', encryptedUser);
                    // Make sure we don't have persistent login enabled
                    localStorage.removeItem('ophthalmoqa_persist_login');
                } catch (sessionError) {
                    console.error('Error storing session data:', sessionError);
                    // Fall back to localStorage if sessionStorage fails
                    this.storeAuthToken(token);
                    this.storeUserData(this.currentUser);
                }
            }
            
            // Update UI
            this.updateUIForLoggedInUser();
            
            // Check premium status
            this.checkPremiumStatus();
            
            // Notify other components about login (after UI update)
            this.notifyLoginStateChange();
            
            // Show welcome message based on user type
            this.showWelcomeMessage();
            
            this._isCompletingLogin = false;
            return true;
        } catch (error) {
            console.error('Error in completeLogin:', error);
            this._isCompletingLogin = false;
            return false;
        }
    }
    
    /**
     * Show welcome message for logged in user
     */
    showWelcomeMessage() {
        const statusEl = document.getElementById('status-message');
        if (!statusEl) return;
        
        let message = '';
        let messageClass = '';
        
        if (this.currentUser.isCreator) {
            message = `Welcome back, Creator! You have full premium access.`;
            messageClass = 'bg-purple-100 text-purple-800';
        } else if (this.currentUser.premium) {
            message = `Welcome back, ${this.currentUser.name}! Your premium features are active.`;
            messageClass = 'bg-green-100 text-green-800';
        } else {
            message = `Welcome back, ${this.currentUser.name}! Consider upgrading to premium for enhanced features.`;
            messageClass = 'bg-blue-100 text-blue-800';
        }
        
        statusEl.textContent = message;
        statusEl.className = 'p-3 rounded-md font-medium my-4'; // Reset classes
        statusEl.classList.add(messageClass);
        statusEl.classList.remove('hidden');
        
        // Hide message after a few seconds
        setTimeout(() => {
            statusEl.classList.add('hidden');
        }, 5000);
    }
    
    /**
     * Update UI elements for logged-in user
     */
    updateUIForLoggedInUser() {
        if (!this.currentUser) return;

        // Update user menu button
        if (this.userMenuButton) {
            this.userMenuButton.classList.remove('hidden');
            const userName = this.userMenuButton.querySelector('.user-name');
            if (userName) {
                userName.textContent = this.currentUser.name;
            }
        }

        // Update user email in dropdown
        if (this.userDropdown) {
            const userEmail = this.userDropdown.querySelector('.user-email');
            if (userEmail) {
                userEmail.textContent = this.currentUser.email;
            }
        }

        // Update dropdown user info
        const dropdownUserName = document.getElementById('dropdown-user-name');
        const dropdownUserStatus = document.getElementById('dropdown-user-status');
        const userAvatar = document.getElementById('user-avatar');
        
        if (dropdownUserName) {
            dropdownUserName.textContent = this.currentUser.name;
        }
        
        if (dropdownUserStatus && userAvatar) {
            if (this.currentUser.isCreator) {
                dropdownUserStatus.innerHTML = '👑 Creator & Premium';
                dropdownUserStatus.className = 'text-xs font-semibold text-amber-600';
                userAvatar.className = 'w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-600 rounded-full flex items-center justify-center';
                userAvatar.innerHTML = '<i class="fas fa-crown text-yellow-200 text-sm"></i>';
            } else if (this.currentUser.premium) {
                dropdownUserStatus.innerHTML = '⭐ Premium Member';
                dropdownUserStatus.className = 'text-xs font-semibold text-blue-600';
                userAvatar.className = 'w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center';
                userAvatar.innerHTML = '<i class="fas fa-star text-white text-sm"></i>';
            } else {
                dropdownUserStatus.innerHTML = 'Free Account';
                dropdownUserStatus.className = 'text-xs text-gray-500';
                userAvatar.className = 'w-10 h-10 bg-gray-500 rounded-full flex items-center justify-center';
                userAvatar.innerHTML = '<i class="fas fa-user text-white text-sm"></i>';
            }
        }

        // Hide login button
        if (this.loginButton) {
            this.loginButton.classList.add('hidden');
        }

        // Update premium status
        this.updatePremiumIndicator();

        // Do not call notifyLoginStateChange here to avoid recursion
        // It's already called from completeLogin
    }
    
    /**
     * Update UI elements for logged-out state
     */
    updateUIForLoggedOutUser() {
        // Show login button, hide user info
        if (this.loginButton) this.loginButton.classList.remove('hidden');
        if (this.userDisplay) this.userDisplay.classList.add('hidden');
        
        // Notify other components about logout
        this.notifyLoginStateChange();
    }
    
    /**
     * Update premium indicator based on user status
     */
    updatePremiumIndicator() {
        if (!this.currentUser || !this.premiumIndicator) return;
        
        if (this.currentUser.premium) {
            this.premiumIndicator.classList.remove('hidden');
            
            // Special gold styling for creator/admin
            if (this.currentUser.isCreator) {
                this.premiumIndicator.classList.remove('bg-yellow-400', 'text-gray-800');
                this.premiumIndicator.classList.add('bg-gradient-to-r', 'from-yellow-400', 'to-yellow-600', 'text-white');
                this.premiumIndicator.innerHTML = '<i class="fas fa-crown mr-1"></i> GOLD';
            } else {
                this.premiumIndicator.classList.remove('bg-gradient-to-r', 'from-yellow-400', 'to-yellow-600', 'text-white');
                this.premiumIndicator.classList.add('bg-yellow-400', 'text-gray-800');
                this.premiumIndicator.innerHTML = '<i class="fas fa-star mr-1"></i> PRO';
            }
            
            // Also hide the donation section if premium
            const donationSection = document.querySelector('.donation-section');
            if (donationSection) {
                donationSection.style.display = 'none';
            }
        } else {
            this.premiumIndicator.classList.add('hidden');
            
            // Make sure donation section is visible for non-premium users
            const donationSection = document.querySelector('.donation-section');
            if (donationSection) {
                donationSection.style.display = 'block';
            }
        }
    }
    
    /**
     * Logout the current user
     */
    logout() {
        // Clear user data
        this.currentUser = null;
        this.isLoggedIn = false;
        
        // Clear stored data from both storage types
        this.clearAuthToken();
        this.clearUserData();
        sessionStorage.removeItem('ophthalmoqa_session_token');
        sessionStorage.removeItem('ophthalmoqa_session_user');
        localStorage.removeItem('ophthalmoqa_persist_login');
        
        // Update UI
        this.updateUIForLoggedOutUser();
        
        // Notify other components about logout
        this.notifyLoginStateChange();
    }
    
    /**
     * Check if user is logged in on page load
     */
    checkLoginStatus() {
        // Check if we need to logout (page was refreshed without "keep me logged in")
        const shouldLogout = sessionStorage.getItem('ophthalmoqa_logout_on_refresh') === 'true';
        if (shouldLogout) {
            // Clear the flag and any session data
            sessionStorage.removeItem('ophthalmoqa_logout_on_refresh');
            sessionStorage.removeItem('ophthalmoqa_session_token');
            sessionStorage.removeItem('ophthalmoqa_session_user');
            // But don't clear localStorage data - that's for persistent logins
            
            // User will start as logged out
            this.currentUser = null;
            this.isLoggedIn = false;
            this.updateUIForLoggedOutUser();
            this.notifyLoginStateChange();
            return;
        }
        
        // First try localStorage (persistent login)
        const persistentToken = this.getStoredAuthToken();
        const persistentUserData = this.getUserData();
        const isPersistentLogin = localStorage.getItem('ophthalmoqa_persist_login') === 'true';
        
        // Then try sessionStorage (temporary login)
        let sessionToken = null;
        let sessionUserData = null;
        
        const encryptedSessionToken = sessionStorage.getItem('ophthalmoqa_session_token');
        if (encryptedSessionToken) {
            sessionToken = this.decryptData(encryptedSessionToken);
        }
        
        try {
            const encryptedUserData = sessionStorage.getItem('ophthalmoqa_session_user');
            if (encryptedUserData) {
                const decryptedUserData = this.decryptData(encryptedUserData);
                sessionUserData = JSON.parse(decryptedUserData);
            }
        } catch (e) {
            console.error('Error parsing session user data', e);
        }
        
        // Use persistent login if available and enabled
        if (persistentToken && persistentUserData && isPersistentLogin) {
            // User has persistent login
            // Check if it's the creator
            if (persistentUserData.email === this.creatorUser.email) {
                persistentUserData.isCreator = true;
                persistentUserData.premium = true;
            }
            
            this.currentUser = persistentUserData;
            this.isLoggedIn = true;
            this.updateUIForLoggedInUser();
            this.checkPremiumStatus();
        } 
        // Otherwise use session login if available
        else if (sessionToken && sessionUserData) {
            // User has session login only
            // Check if it's the creator
            if (sessionUserData.email === this.creatorUser.email) {
                sessionUserData.isCreator = true;
                sessionUserData.premium = true;
            }
            
            this.currentUser = sessionUserData;
            this.isLoggedIn = true;
            this.updateUIForLoggedInUser();
            this.checkPremiumStatus();
        }
    }
    
    /**
     * Check if current user has premium status
     * This would typically involve an API call in a real application
     */
    checkPremiumStatus() {
        if (!this.currentUser) return false;
        
        // Creator is always premium
        if (this.currentUser.email === this.creatorUser.email) {
            this.currentUser.premium = true;
            this.currentUser.isCreator = true;
            this.storeUserData(this.currentUser);
            this.updatePremiumIndicator();
            this.notifyPremiumStatusChange(true);
            return true;
        }
        
        // First check localStorage for premium status
        const isPremium = this.currentUser.premium || this.getPremiumStatus();
        
        // Update user object
        this.currentUser.premium = isPremium;
        this.storeUserData(this.currentUser);
        
        // Update UI
        this.updatePremiumIndicator();
        
        // Notify donation handler about premium status
        this.notifyPremiumStatusChange(isPremium);
        
        return isPremium;
    }
    
    /**
     * Set premium status for current user
     */
    setPremiumStatus(status) {
        if (!this.currentUser) return;
        
        // Update user object
        this.currentUser.premium = status;
        this.storeUserData(this.currentUser);
        
        // Store premium status
        localStorage.setItem('ophthalmoqa_premium', status.toString());
        
        // Update UI
        this.updatePremiumIndicator();
        
        // Notify other components
        this.notifyPremiumStatusChange(status);
    }
    
    /**
     * Notify other components about login state change
     */
    notifyLoginStateChange() {
        // Create a custom event
        const event = new CustomEvent('ophthalmoqa:loginChanged', {
            detail: {
                isLoggedIn: this.isLoggedIn,
                user: this.isLoggedIn ? this.currentUser : null
            }
        });
        
        // Dispatch the event
        document.dispatchEvent(event);
        
        // Also update donation handler directly if available
        if (window.donationHandler) {
            window.donationHandler.updateUIBasedOnStatus();
        }
    }
    
    /**
     * Notify other components about premium status change
     */
    notifyPremiumStatusChange(status) {
        // Dispatch custom event
        const event = new CustomEvent('ophthalmoqa:premiumChanged', {
            detail: {
                premium: status
            }
        });
        
        document.dispatchEvent(event);
        
        // Update donation handler directly if available
        if (window.donationHandler) {
            window.donationHandler.setPremiumStatus(status);
        }
    }
    
    /**
     * Generate a secure token (simulated)
     */
    generateSecureToken() {
        return 'token_' + 
            Math.random().toString(36).substr(2) + 
            Date.now().toString(36) + 
            Math.random().toString(36).substr(2);
    }
    
    /**
     * Securely encrypt sensitive data
     * @param {string} data - Data to encrypt
     * @returns {string} - Encrypted data
     */
    encryptData(data) {
        if (!data) return '';
        
        // Simple encryption for demo purposes
        // In production, use a proper encryption library
        try {
            // Convert to base64 and add salt
            const salted = this.securitySalt + data;
            return btoa(encodeURIComponent(salted));
        } catch (e) {
            console.error('Encryption error:', e);
            // Return a safe value in case of error instead of recursively calling
            return btoa('encryption_error');
        }
    }
    
    /**
     * Decrypt encrypted data
     * @param {string} encryptedData - Data to decrypt
     * @returns {string} - Decrypted data
     */
    decryptData(encryptedData) {
        if (!encryptedData) return '';
        
        try {
            // Decode and remove salt
            const decoded = decodeURIComponent(atob(encryptedData));
            // Check if the decoded string starts with our salt
            if (decoded.startsWith(this.securitySalt)) {
                return decoded.substring(this.securitySalt.length);
            } else {
                console.error('Invalid data format (missing security salt)');
                return '';
            }
        } catch (e) {
            console.error('Decryption error:', e);
            return '';
        }
    }
    
    /**
     * Securely store auth token
     */
    storeAuthToken(token) {
        // Encrypt token before storing
        const encryptedToken = this.encryptData(token);
        localStorage.setItem('ophthalmoqa_auth_token', encryptedToken);
    }
    
    /**
     * Get stored auth token
     */
    getStoredAuthToken() {
        const encryptedToken = localStorage.getItem('ophthalmoqa_auth_token');
        if (!encryptedToken) return null;
        return this.decryptData(encryptedToken);
    }
    
    /**
     * Store user data
     */
    storeUserData(userData) {
        // Encrypt user data for storage
        const encryptedData = this.encryptData(JSON.stringify(userData));
        localStorage.setItem('ophthalmoqa_user', encryptedData);
    }
    
    /**
     * Get stored user data
     */
    getUserData() {
        const encryptedData = localStorage.getItem('ophthalmoqa_user');
        if (!encryptedData) return null;
        
        try {
            const decryptedData = this.decryptData(encryptedData);
            return JSON.parse(decryptedData);
        } catch (e) {
            console.error('Error parsing user data', e);
            return null;
        }
    }
    
    /**
     * Clear stored auth token
     */
    clearAuthToken() {
        localStorage.removeItem('ophthalmoqa_auth_token');
    }
    
    /**
     * Clear stored user data
     */
    clearUserData() {
        localStorage.removeItem('ophthalmoqa_user');
    }
    
    /**
     * Get premium status from localStorage
     */
    getPremiumStatus() {
        return localStorage.getItem('ophthalmoqa_premium') === 'true';
    }

    /**
     * Handle page unload event - used for auto logout
     */
    handlePageUnload() {
        // If not using persistent login, clear session data
        const isPersistentLogin = localStorage.getItem('ophthalmoqa_persist_login') === 'true';
        
        if (!isPersistentLogin && this.isLoggedIn) {
            // Store a flag to indicate that we're refreshing/closing
            sessionStorage.setItem('ophthalmoqa_logout_on_refresh', 'true');
            
            // We don't clear session data here because beforeunload can be cancelled
            // The actual logout will happen on page load if the flag is set
        }
    }

    /**
     * Handle password reset form submission
     */
    async handlePasswordReset() {
        const emailField = document.getElementById('reset-email');
        const messageElement = document.getElementById('reset-message');
        const submitButton = document.getElementById('reset-submit-btn');
        
        messageElement.classList.remove('hidden', 'bg-green-100', 'text-green-700', 'bg-red-100', 'text-red-700', 'bg-blue-100', 'text-blue-700');
        
        const email = emailField.value.trim();
        
        if (!email) {
            this.showResetMessage('Please enter your email address.', 'error');
            emailField.focus();
            return;
        }
        
        if (!email.includes('@') || !email.includes('.')) {
            this.showResetMessage('Please enter a valid email address.', 'error');
            emailField.focus();
            return;
        }
        
        try {
            // Disable the submit button and show loading state
            submitButton.disabled = true;
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
            
            // Show loading indicator
            this.showResetMessage('Verifying your email address...', 'info');
            
            // In a real application, this would call an API to verify the email exists
            // For this demo, we'll simulate email verification
            const emailExists = await this.verifyEmailExists(email);
            
            if (!emailExists) {
                this.showResetMessage('Email not found in our system. Please check and try again.', 'error');
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                emailField.focus();
                return;
            }
            
            // Email exists, generate temporary credentials
            this.showResetMessage('Email verified. Generating and sending recovery instructions...', 'info');
            
            // Simulate sending email with credentials
            await this.sendLoginCredentials(email);
            
            // Show success message
            this.showResetMessage('Recovery instructions sent! Please check your email inbox and spam folder for further instructions.', 'success');
            
            // Clear the form
            emailField.value = '';
            
            // Update button state to "Done"
            submitButton.innerHTML = '<i class="fas fa-check mr-2"></i> Sent Successfully';
            
            // Return to login screen after a delay
            setTimeout(() => {
                this.hidePasswordResetModal();
                this.showLoginModal();
                
                // Show a notification on the login screen
                const loginError = document.getElementById('login-error');
                if (loginError) {
                    loginError.textContent = 'Check your email for password reset instructions.';
                    loginError.classList.remove('hidden', 'bg-red-50', 'border-red-500');
                    loginError.classList.add('bg-blue-50', 'text-blue-700', 'p-3', 'rounded-md', 'border-l-4', 'border-blue-500');
                }
                
                // Reset the button state for next time
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.innerHTML = originalButtonText;
                }, 1000);
            }, 3000);
            
        } catch (error) {
            console.error('Password reset error:', error);
            this.showResetMessage('An error occurred while processing your request. Please try again later.', 'error');
            
            // Reset button state
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonText;
        }
    }
    
    /**
     * Verify if email exists in the system
     * @param {string} email - Email to verify
     * @returns {Promise<boolean>} - Whether email exists
     */
    async verifyEmailExists(email) {
        // In a real application, this would call an API endpoint to check if the email exists
        // For this demo, we'll simulate a check with some common email patterns
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Simple validation - in a real app this would check against a database
        if (email.includes('@gmail.com') || 
            email.includes('@yahoo.com') || 
            email.includes('@hotmail.com') || 
            email.includes('@outlook.com') ||
            email.includes('@icloud.com') ||
            email.includes('@example.com')) {
            // Simulate 80% chance the email exists
            return Math.random() < 0.8;
        }
        
        // For demo purposes, we'll allow emails from medical domains to always work
        if (email.includes('hospital') || 
            email.includes('med.') || 
            email.includes('health') || 
            email.includes('clinic') ||
            email.includes('doctor') ||
            email.includes('ophth')) {
            return true;
        }
        
        // Other emails have a 50% chance of existing
        return Math.random() < 0.5;
    }
    
    /**
     * Send login credentials to user email
     * @param {string} email - Email to send credentials to
     * @returns {Promise<void>}
     */
    async sendLoginCredentials(email) {
        // Generate a secure reset token and temporary password
        const resetToken = this.generateSecureToken().substring(0, 16);
        const tempPassword = this.generateTemporaryPassword();
        
        // Store the reset token and expiration time (24 hours from now)
        const users = this.getStoredUsers();
        const userIndex = users.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
        
        if (userIndex !== -1) {
            // Update the user's reset token and expiration
            users[userIndex].resetToken = resetToken;
            users[userIndex].resetTokenExpires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
            users[userIndex].tempPassword = tempPassword; // This would not be done in a real system
            
            // Store the updated user data
            localStorage.setItem('ophthalmoqa_users', JSON.stringify(users));
        }
        
        // In a real application, this would send an actual email
        // We'll use EmailJS service to send a real email
        try {
            // Check if EmailJS is available
            if (typeof emailjs !== 'undefined') {
                // Get the admin email (which is the sender)
                const adminEmail = this.creatorUser.email;
                
                // Compose the email parameters
                const emailParams = {
                    to_email: email,
                    from_name: 'OphthalmoQA Admin',
                    from_email: adminEmail,
                    subject: 'Password Reset for OphthalmoQA',
                    reset_link: `https://ophthalmoqa.com/reset-password?token=${resetToken}&email=${encodeURIComponent(email)}`,
                    temp_password: tempPassword,
                    user_email: email,
                    reset_expiry: '24 hours'
                };
                
                // Send real email (this would require EmailJS to be properly set up)
                const emailJsServiceId = 'service_ophthalmoqa'; // Replace with actual service ID
                const emailJsTemplateId = 'template_password_reset'; // Replace with actual template ID
                const emailJsUserId = 'user_yourEmailJsUserId'; // Replace with actual user ID
                
                // Log the email parameters for demonstration
                console.log('Email would be sent with these parameters:', emailParams);
                
                // In a real implementation, uncomment this code and replace with actual credentials
                /*
                await emailjs.send(
                    emailJsServiceId,
                    emailJsTemplateId,
                    emailParams,
                    emailJsUserId
                );
                */
                
                // For now, we'll create a mailto link that opens the user's email client
                this.createPasswordResetEmail(email, resetToken, tempPassword);
            } else {
                // EmailJS not available, fallback to console log
                console.log(`Real email would be sent to: ${email}`);
                console.log(`From: ${this.creatorUser.email}`);
                console.log(`Reset token: ${resetToken}`);
                console.log(`Temporary password: ${tempPassword}`);
                
                // Create a mailto link as fallback
                this.createPasswordResetEmail(email, resetToken, tempPassword);
            }
            
            // Track password reset attempt for security
            this.logSecurityEvent({
                type: 'password_reset_requested',
                email: email,
                timestamp: new Date().toISOString(),
                success: true
            });
            
            return true;
        } catch (error) {
            console.error('Error sending password reset email:', error);
            
            // Log failure
            this.logSecurityEvent({
                type: 'password_reset_requested',
                email: email,
                timestamp: new Date().toISOString(),
                success: false,
                error: error.message
            });
            
            return false;
        }
    }
    
    /**
     * Create a password reset email and open the user's email client
     * @param {string} email - Recipient email
     * @param {string} resetToken - Password reset token
     * @param {string} tempPassword - Temporary password
     */
    createPasswordResetEmail(email, resetToken, tempPassword) {
        // Construct email body with HTML formatting
        const subject = 'Password Reset for OphthalmoQA';
        const body = `
        Hello,

        You recently requested to reset your password for OphthalmoQA. Use the following information to reset your password:

        Temporary Password: ${tempPassword}
        Reset Token: ${resetToken}

        For security reasons, this temporary password will expire in 24 hours.

        If you did not request this password reset, please ignore this email or contact support.

        Best regards,
        The OphthalmoQA Team
        `;
        
        // Create a mailto link
        const mailtoLink = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        
        // Open the user's default email client
        window.open(mailtoLink, '_blank');
    }
    
    /**
     * Generate a secure temporary password
     * @returns {string} Temporary password
     */
    generateTemporaryPassword() {
        // Define character sets for strong password
        const uppercaseChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // Omitting confusing characters like I, O
        const lowercaseChars = 'abcdefghijkmnpqrstuvwxyz'; // Omitting confusing characters like l, o
        const numberChars = '23456789'; // Omitting confusing characters like 0, 1
        const specialChars = '@#$%^&*!';
        
        // Ensure at least one character from each set
        let password = '';
        password += uppercaseChars.charAt(Math.floor(Math.random() * uppercaseChars.length));
        password += lowercaseChars.charAt(Math.floor(Math.random() * lowercaseChars.length));
        password += numberChars.charAt(Math.floor(Math.random() * numberChars.length));
        password += specialChars.charAt(Math.floor(Math.random() * specialChars.length));
        
        // Add 6 more random characters for a total length of 10
        const allChars = uppercaseChars + lowercaseChars + numberChars + specialChars;
        for (let i = 0; i < 6; i++) {
            password += allChars.charAt(Math.floor(Math.random() * allChars.length));
        }
        
        // Shuffle the password to avoid predictable patterns
        return this.shuffleString(password);
    }
    
    /**
     * Shuffle a string randomly
     * @param {string} str - String to shuffle
     * @returns {string} Shuffled string
     */
    shuffleString(str) {
        const arr = str.split('');
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]]; // Swap elements
        }
        return arr.join('');
    }
    
    /**
     * Log security-related events
     * @param {Object} eventData - Security event data
     */
    logSecurityEvent(eventData) {
        // In a real application, this would send the data to a logging service or security monitoring system
        // For this demo, we'll just log to console
        console.log('Security Event:', eventData);
        
        // Store recent security events in memory for potential security checks
        if (!this.securityEvents) {
            this.securityEvents = [];
        }
        
        // Keep only the last 10 events
        this.securityEvents.push(eventData);
        if (this.securityEvents.length > 10) {
            this.securityEvents.shift();
        }
    }
    
    /**
     * Show password reset message
     * @param {string} message - Message to display
     * @param {string} type - Message type (success, error, info)
     */
    showResetMessage(message, type = 'info') {
        const messageElement = document.getElementById('reset-message');
        if (!messageElement) return;
        
        messageElement.textContent = message;
        messageElement.classList.remove('hidden');
        
        // Apply appropriate styling based on message type
        messageElement.classList.remove(
            'bg-green-100', 'text-green-700', 'border-green-500',
            'bg-red-100', 'text-red-700', 'border-red-500',
            'bg-blue-100', 'text-blue-700', 'border-blue-500'
        );
        
        // Add common styling
        messageElement.classList.add('border-l-4', 'flex', 'items-center');
        
        // Add icon and specific styling based on type
        switch (type) {
            case 'success':
                messageElement.classList.add('bg-green-100', 'text-green-700', 'border-green-500');
                messageElement.innerHTML = `<i class="fas fa-check-circle mr-2 text-green-500"></i> ${message}`;
                break;
            case 'error':
                messageElement.classList.add('bg-red-100', 'text-red-700', 'border-red-500');
                messageElement.innerHTML = `<i class="fas fa-exclamation-circle mr-2 text-red-500"></i> ${message}`;
                break;
            case 'info':
            default:
                messageElement.classList.add('bg-blue-100', 'text-blue-700', 'border-blue-500');
                messageElement.innerHTML = `<i class="fas fa-info-circle mr-2 text-blue-500"></i> ${message}`;
                break;
        }
    }

    /**
     * Shows the account settings modal and populates it with current user data
     */
    showAccountSettings() {
        if (!this.currentUser) {
            return;
        }

        const nameInput = this.accountSettingsForm.querySelector('#settings-name');
        const emailInput = this.accountSettingsForm.querySelector('#settings-email');
        const premiumBadge = this.accountSettingsForm.querySelector('#premium-status-badge');
        const memberSince = this.accountSettingsForm.querySelector('#member-since');

        // Populate current user data
        nameInput.value = this.currentUser.name;
        emailInput.value = this.currentUser.email;

        // Update premium status badge
        if (this.currentUser.premium) {
            premiumBadge.textContent = 'Active';
            premiumBadge.className = 'px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800';
        } else {
            premiumBadge.textContent = 'Free';
            premiumBadge.className = 'px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800';
        }

        // Format and display member since date
        const memberSinceDate = new Date(this.currentUser.createdAt);
        memberSince.textContent = memberSinceDate.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        this.accountSettingsModal.classList.remove('hidden');
    }

    /**
     * Hides the account settings modal
     */
    hideAccountSettings() {
        this.accountSettingsModal.classList.add('hidden');
    }

    /**
     * Handles the account settings form submission
     * @param {Event} event - The form submission event
     */
    async handleAccountSettingsUpdate(event) {
        event.preventDefault();

        const nameInput = this.accountSettingsForm.querySelector('#settings-name');
        const emailInput = this.accountSettingsForm.querySelector('#settings-email');
        const errorDisplay = this.accountSettingsForm.querySelector('#settings-error');

        try {
            // Basic validation
            if (!nameInput.value.trim() || !emailInput.value.trim()) {
                throw new Error('All fields are required');
            }

            // Email format validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(emailInput.value)) {
                throw new Error('Please enter a valid email address');
            }

            // Check if email is changed and already exists
            if (emailInput.value !== this.currentUser.email) {
                const existingUser = await this.verifyEmailExists(emailInput.value);
                if (existingUser) {
                    throw new Error('This email is already registered');
                }
            }

            // Update user data
            const updatedUser = {
                ...this.currentUser,
                name: nameInput.value.trim(),
                email: emailInput.value.trim()
            };

            // Update stored user data
            const users = this.getStoredUsers();
            const userIndex = users.findIndex(u => u.id === this.currentUser.id);
            if (userIndex !== -1) {
                users[userIndex] = updatedUser;
                localStorage.setItem('users', JSON.stringify(users));
            }

            // Update current user and UI
            this.currentUser = updatedUser;
            this.storeUserData(updatedUser);
            this.updateUIForLoggedInUser();

            // Show success message and close modal
            this.showNotification('Account settings updated successfully', 'success');
            this.hideAccountSettings();

        } catch (error) {
            errorDisplay.textContent = error.message;
            errorDisplay.classList.remove('hidden');
        }
    }

    /**
     * Shows a notification message to the user
     * @param {string} message - The message to display
     * @param {string} type - The type of notification ('success' or 'error')
     */
    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-500' : 'bg-red-500'
        } text-white`;
        notification.textContent = message;

        document.body.appendChild(notification);

        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
} 
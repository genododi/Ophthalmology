/**
 * DonationHandler - Manages donation process and premium user status
 * for OphthalmoQA application
 */
class DonationHandler {
    constructor() {
        this.donationButton = document.querySelector('a[href*="paypal.com"]');
        this.premiumStatus = this.checkPremiumStatus();
        this.donationSection = document.querySelector('.donation-section') || document.querySelector('.mt-6.p-4.bg-blue-50');
        this.authManager = null;
        
        // Initialize event listeners
        this.initializeEvents();
        this.updateUIBasedOnStatus();
        
        // Listen for login status changes
        document.addEventListener('ophthalmoqa:loginChanged', (e) => this.handleLoginChange(e.detail));
    }
    
    /**
     * Set the auth manager reference
     */
    setAuthManager(authManager) {
        this.authManager = authManager;
    }
    
    /**
     * Handle login status changes
     */
    handleLoginChange(detail) {
        if (detail.isLoggedIn && detail.user) {
            // Update premium status based on user data
            this.premiumStatus = detail.user.premium;
            this.updateUIBasedOnStatus();
        } else {
            // Revert to non-premium when logged out
            this.premiumStatus = false;
            this.updateUIBasedOnStatus();
        }
    }
    
    /**
     * Initialize event listeners for donation process
     */
    initializeEvents() {
        // Track PayPal donation button clicks
        if (this.donationButton) {
            this.donationButton.addEventListener('click', (e) => {
                // Verify user is logged in first
                if (this.authManager && !this.authManager.isLoggedIn) {
                    e.preventDefault();
                    alert('Please log in before upgrading to Premium');
                    this.authManager.showLoginModal();
                    return;
                }
                
                // Record click attempt
                this.trackDonationAttempt('paypal');
                
                // Handle the return from PayPal (will be called when they return to the app)
                window.addEventListener('focus', () => {
                    setTimeout(() => {
                        this.showDonationFollowup();
                    }, 3000);
                }, { once: true });
            });
        }
        
        // Initialize other payment buttons
        this.initializeStripePayment();
        this.initializeApplePay();
        this.initializeGooglePay();
        this.initializeSamsungPay();
        
        // Set up test button for development
        if (CONFIG.DEBUG) {
            this.createTestPremiumButton();
        }
    }
    
    /**
     * Initialize Stripe payment
     */
    initializeStripePayment() {
        const stripeButton = document.getElementById('stripe-payment-btn');
        if (stripeButton) {
            stripeButton.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Verify user is logged in first
                if (this.authManager && !this.authManager.isLoggedIn) {
                    alert('Please log in before upgrading to Premium');
                    this.authManager.showLoginModal();
                    return;
                }
                
                // Track click attempt
                this.trackDonationAttempt('stripe');
                
                // In a real implementation, this would open a Stripe payment modal
                // For the demo, we'll simulate a successful payment
                this.simulatePaymentProcess('Stripe');
            });
        }
    }
    
    /**
     * Initialize Apple Pay
     */
    initializeApplePay() {
        const applePayButton = document.getElementById('apple-pay-btn');
        if (applePayButton) {
            applePayButton.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Verify user is logged in first
                if (this.authManager && !this.authManager.isLoggedIn) {
                    alert('Please log in before upgrading to Premium');
                    this.authManager.showLoginModal();
                    return;
                }
                
                // Track click attempt
                this.trackDonationAttempt('apple_pay');
                
                // Simulate Apple Pay process
                this.simulatePaymentProcess('Apple Pay');
            });
        }
    }
    
    /**
     * Initialize Google Pay
     */
    initializeGooglePay() {
        const googlePayButton = document.getElementById('google-pay-btn');
        if (googlePayButton) {
            googlePayButton.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Verify user is logged in first
                if (this.authManager && !this.authManager.isLoggedIn) {
                    alert('Please log in before upgrading to Premium');
                    this.authManager.showLoginModal();
                    return;
                }
                
                // Track click attempt
                this.trackDonationAttempt('google_pay');
                
                // Simulate Google Pay process
                this.simulatePaymentProcess('Google Pay');
            });
        }
    }
    
    /**
     * Initialize Samsung Pay
     */
    initializeSamsungPay() {
        const samsungPayButton = document.getElementById('samsung-pay-btn');
        if (samsungPayButton) {
            samsungPayButton.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Verify user is logged in first
                if (this.authManager && !this.authManager.isLoggedIn) {
                    alert('Please log in before upgrading to Premium');
                    this.authManager.showLoginModal();
                    return;
                }
                
                // Track click attempt
                this.trackDonationAttempt('samsung_pay');
                
                // Simulate Samsung Pay process
                this.simulatePaymentProcess('Samsung Pay');
            });
        }
    }
    
    /**
     * Simulate a payment process for demo purposes
     * @param {string} method - Payment method name
     */
    simulatePaymentProcess(method) {
        // Show processing message
        const statusEl = document.getElementById('status-message');
        if (statusEl) {
            statusEl.classList.remove('hidden', 'bg-green-100', 'text-green-800', 'bg-blue-100', 'text-blue-800');
            statusEl.classList.add('bg-blue-100', 'text-blue-800');
            statusEl.textContent = `Processing your ${method} payment...`;
            statusEl.classList.remove('hidden');
        }
        
        // Simulate network delay
        setTimeout(() => {
            if (statusEl) {
                statusEl.classList.remove('bg-blue-100', 'text-blue-800');
                statusEl.classList.add('bg-green-100', 'text-green-800');
                statusEl.textContent = `${method} payment successful! Upgrading your account...`;
            }
            
            // Simulate successful payment and activate premium
            setTimeout(() => {
                this.setPremiumStatus(true);
                this.showThankYouMessage();
                
                if (statusEl) {
                    statusEl.classList.add('hidden');
                }
            }, 2000);
        }, 3000);
    }
    
    /**
     * Track donation attempt in analytics (simplified version)
     * @param {string} method - Payment method used
     */
    trackDonationAttempt(method = 'paypal') {
        console.log(`Donation attempt tracked via ${method}`);
        // In a real implementation, this would send data to analytics
    }
    
    /**
     * Show a follow-up modal after returning from PayPal
     */
    showDonationFollowup() {
        // Only show if not already premium
        if (this.premiumStatus) {
            return;
        }
        
        const result = confirm('Thank you for supporting OphthalmoQA! Did you complete your donation?');
        if (result) {
            this.setPremiumStatus(true);
            this.showThankYouMessage();
            
            // Update user's premium status in auth manager
            if (this.authManager && this.authManager.isLoggedIn) {
                this.authManager.setPremiumStatus(true);
            }
        }
    }
    
    /**
     * Check if user has premium status
     */
    checkPremiumStatus() {
        // First check auth manager (if available)
        if (this.authManager && this.authManager.isLoggedIn) {
            return this.authManager.currentUser.premium;
        }
        
        // Fall back to localStorage
        return localStorage.getItem('ophthalmoqa_premium') === 'true';
    }
    
    /**
     * Checks if user has premium access and shows donation message if not
     * @param {boolean} showMessage - Whether to show the donation message
     * @returns {boolean} - Whether user has premium access
     */
    checkPremiumAccess(showMessage = true) {
        // Check if logged in first
        if (this.authManager && !this.authManager.isLoggedIn) {
            if (showMessage) {
                this.showLoginRequiredMessage();
            }
            return false;
        }
        
        // Then check premium status
        this.premiumStatus = this.checkPremiumStatus();
        if (!this.premiumStatus && showMessage) {
            this.showDonationMessage();
            return false;
        }
        
        return this.premiumStatus;
    }
    
    /**
     * Show login required message
     */
    showLoginRequiredMessage() {
        const statusEl = document.getElementById('status-message');
        if (statusEl) {
            statusEl.classList.remove('hidden', 'bg-green-100', 'text-green-800');
            statusEl.classList.add('bg-yellow-100', 'text-yellow-800');
            statusEl.textContent = 'Please log in to access premium features';
            
            setTimeout(() => {
                if (this.authManager) {
                    this.authManager.showLoginModal();
                }
                statusEl.classList.add('hidden');
            }, 3000);
        }
    }
    
    /**
     * Display donation message in the status area and ensure donation section is visible
     */
    showDonationMessage() {
        // Show status message
        const statusEl = document.getElementById('status-message');
        if (statusEl) {
            statusEl.classList.remove('hidden', 'bg-green-100', 'text-green-800');
            statusEl.classList.add('bg-blue-100', 'text-blue-800');
            statusEl.textContent = 'Upgrade to Premium for $20 to access enhanced question banks and advanced features!';
            
            // Keep message visible for a while
            setTimeout(() => {
                statusEl.classList.add('hidden');
            }, 10000);
        }
        
        // Ensure donation section is visible
        if (this.donationSection) {
            this.donationSection.classList.add('highlight-pulse');
            
            // Remove highlight after animation
            setTimeout(() => {
                this.donationSection.classList.remove('highlight-pulse');
            }, 3000);
        }
        
        // Scroll to donation section
        if (this.donationSection) {
            this.donationSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    /**
     * Set premium status and update UI
     */
    setPremiumStatus(status) {
        this.premiumStatus = status;
        localStorage.setItem('ophthalmoqa_premium', status.toString());
        
        // Update auth manager if available
        if (this.authManager && this.authManager.isLoggedIn) {
            this.authManager.setPremiumStatus(status);
        }
        
        // Update UI with new status
        this.updateUIBasedOnStatus();
        
        // If we have access to MedicalNLP, update its status too
        if (window.medicalNLP) {
            window.medicalNLP.isPremiumUser = status;
        }
    }
    
    /**
     * Update UI elements based on premium status
     */
    updateUIBasedOnStatus() {
        // Get current premium status (might have changed elsewhere)
        this.premiumStatus = this.checkPremiumStatus();
        
        // Check if user is the creator
        const isCreator = this.authManager && 
                         this.authManager.isLoggedIn && 
                         this.authManager.currentUser && 
                         this.authManager.currentUser.isCreator;
        
        // Update button text if premium
        if (this.premiumStatus && this.donationButton) {
            if (isCreator) {
                this.donationButton.innerHTML = '<i class="fas fa-crown mr-2"></i>Creator Access';
                this.donationButton.classList.remove('bg-blue-600', 'hover:bg-blue-700', 'bg-green-600', 'hover:bg-green-700');
                this.donationButton.classList.add('bg-purple-600', 'hover:bg-purple-700');
            } else {
                this.donationButton.innerHTML = '<i class="fas fa-crown mr-2"></i>Premium Activated';
                this.donationButton.classList.remove('bg-blue-600', 'hover:bg-blue-700', 'bg-purple-600', 'hover:bg-purple-700');
                this.donationButton.classList.add('bg-green-600', 'hover:bg-green-700');
            }
            
            this.donationButton.href = '#';
            this.donationButton.onclick = (e) => {
                e.preventDefault();
                if (isCreator) {
                    alert('You are the creator with full access to all premium features!');
                } else {
                    alert('Thank you for your support! You already have premium access.');
                }
            };
        } else if (this.donationButton) {
            // Reset button if not premium
            this.donationButton.innerHTML = '<i class="fab fa-paypal mr-2"></i>PayPal ($20)';
            this.donationButton.classList.remove('bg-green-600', 'hover:bg-green-700', 'bg-purple-600', 'hover:bg-purple-700');
            this.donationButton.classList.add('bg-blue-600', 'hover:bg-blue-700');
            this.donationButton.href = "https://www.paypal.com/paypalme/docms90/20";
            this.donationButton.onclick = null;
        }
        
        // Add premium indicator to header if premium
        if (this.premiumStatus) {
            const header = document.querySelector('header h1');
            if (header && !document.querySelector('.premium-badge')) {
                const premiumBadge = document.createElement('span');
                premiumBadge.className = 'premium-badge ml-2 px-2 py-1 bg-yellow-400 text-xs text-gray-800 rounded-full';
                
                if (isCreator) {
                    premiumBadge.classList.remove('bg-yellow-400', 'text-gray-800');
                    premiumBadge.classList.add('bg-gradient-to-r', 'from-yellow-400', 'to-yellow-600', 'text-white');
                    premiumBadge.innerHTML = 'CREATOR';
                } else {
                    premiumBadge.innerHTML = 'PREMIUM';
                }
                
                header.appendChild(premiumBadge);
            }
            
            // Hide donation section if premium
            if (this.donationSection) {
                // For creator, just update the message but keep visible
                if (isCreator) {
                    const upgradeHeading = this.donationSection.querySelector('h3');
                    if (upgradeHeading) {
                        upgradeHeading.innerHTML = '<i class="fas fa-crown text-purple-500 mr-2"></i> Creator Access Enabled';
                    }
                    
                    // Update description
                    const description = this.donationSection.querySelector('p.text-sm.text-gray-700');
                    if (description) {
                        description.textContent = 'As the creator, you have full access to all premium features and can manage the system.';
                    }
                    
                    // Hide payment buttons
                    const paymentButtons = this.donationSection.querySelectorAll('.flex.flex-wrap.justify-center');
                    paymentButtons.forEach(el => {
                        el.style.display = 'none';
                    });
                    
                    // Show creator info instead
                    const featuresDiv = this.donationSection.querySelector('.text-xs.text-gray-600.mb-3');
                    if (featuresDiv) {
                        // Keep the features list visible
                    }
                } else {
                    // For regular premium users, hide the section
                    this.donationSection.style.display = 'none';
                }
            }
        } else {
            // Remove premium badge if not premium
            const premiumBadge = document.querySelector('.premium-badge');
            if (premiumBadge) {
                premiumBadge.remove();
            }
            
            // Ensure donation section is visible if not premium
            if (this.donationSection) {
                this.donationSection.style.display = 'block';
            }
        }
    }
    
    /**
     * Show thank you message after successful donation
     */
    showThankYouMessage() {
        const statusEl = document.getElementById('status-message');
        if (statusEl) {
            statusEl.classList.remove('hidden');
            statusEl.classList.add('bg-green-100', 'text-green-800');
            statusEl.textContent = 'Thank you for upgrading to Premium! You now have access to enhanced question banks and features.';
            
            // Hide message after a few seconds
            setTimeout(() => {
                statusEl.classList.add('hidden');
            }, 8000);
        }
    }
    
    /**
     * Create a test button for toggling premium (debug only)
     */
    createTestPremiumButton() {
        const footer = document.querySelector('footer');
        if (footer) {
            const testButton = document.createElement('button');
            testButton.className = 'mt-2 px-3 py-1 bg-gray-200 text-xs rounded';
            testButton.textContent = 'Toggle Premium (Test)';
            testButton.onclick = () => {
                this.setPremiumStatus(!this.premiumStatus);
                alert(`Premium status: ${this.premiumStatus ? 'Activated' : 'Deactivated'}`);
            };
            footer.appendChild(testButton);
        }
    }
} 
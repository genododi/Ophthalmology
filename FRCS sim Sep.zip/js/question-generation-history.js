/**
 * Question Generation History System
 * Tracks all generated questions, feedback, and performance metrics for analysis
 */
class QuestionGenerationHistory {
    constructor() {
        this.history = [];
        this.feedbackData = new Map(); // questionId -> feedback details
        this.performanceMetrics = new Map(); // session -> metrics
        this.parameterOptimizations = new Map(); // parameter -> optimization data
        this.userPreferences = this.loadUserPreferences();
        this.maxHistorySize = 1000; // Limit to prevent memory issues
        
        this.initializeEventListeners();
        this.loadHistoryFromStorage();
    }

    initializeEventListeners() {
        // Listen for question generation events
        document.addEventListener('questionsGenerated', (event) => {
            this.recordGenerationSession(event.detail, false);
        });

        document.addEventListener('questionsRegenerated', (event) => {
            this.recordGenerationSession(event.detail, true);
        });

        // Listen for feedback events
        document.addEventListener('questionFeedback', (event) => {
            this.recordFeedback(event.detail);
        });

        // Save history periodically
        setInterval(() => this.saveHistoryToStorage(), 30000); // Every 30 seconds
    }

    recordGenerationSession(sessionData, isRegeneration = false) {
        const sessionId = `session-${Date.now()}-${Math.random().toString(36).substring(2)}`;
        
        const session = {
            id: sessionId,
            timestamp: new Date().toISOString(),
            isRegeneration,
            questions: sessionData.questions || [],
            metadata: sessionData.metadata || {},
            parameters: {
                difficulty: sessionData.metadata.difficulty,
                numQuestions: sessionData.metadata.numQuestions,
                knowledgeArea: sessionData.metadata.knowledgeArea,
                questionTypes: sessionData.metadata.questionTypes,
                focusArea: sessionData.metadata.focusArea,
                aiModel: sessionData.metadata.aiModel
            },
            performance: this.calculateSessionPerformance(sessionData)
        };

        this.history.push(session);
        this.performanceMetrics.set(sessionId, session.performance);

        // Maintain size limit
        if (this.history.length > this.maxHistorySize) {
            const removed = this.history.shift();
            this.performanceMetrics.delete(removed.id);
        }

        // Analyze for parameter optimization
        this.analyzeParameterPerformance(session);

        console.log(`Recorded generation session: ${sessionId} with ${session.questions.length} questions`);
        this.saveHistoryToStorage();
    }

    recordFeedback(feedbackData) {
        const questionId = feedbackData.questionId;
        const timestamp = new Date().toISOString();

        if (!this.feedbackData.has(questionId)) {
            this.feedbackData.set(questionId, {
                questionId,
                feedbackHistory: [],
                summary: {
                    likes: 0,
                    dislikes: 0,
                    improvements: 0,
                    lastFeedback: null
                }
            });
        }

        const feedback = this.feedbackData.get(questionId);
        feedback.feedbackHistory.push({
            timestamp,
            type: feedbackData.type,
            value: feedbackData.value,
            metadata: feedbackData.metadata || {}
        });

        // Update summary
        if (feedbackData.type === 'like') {
            feedback.summary.likes++;
        } else if (feedbackData.type === 'dislike') {
            feedback.summary.dislikes++;
        } else if (feedbackData.type === 'improvement') {
            feedback.summary.improvements++;
        }
        feedback.summary.lastFeedback = timestamp;

        // Analyze for parameter optimization
        this.analyzeFeedbackForOptimization(questionId, feedbackData);

        console.log(`Recorded feedback for question ${questionId}: ${feedbackData.type}`);
        this.saveHistoryToStorage();
    }

    calculateSessionPerformance(sessionData) {
        const questions = sessionData.questions || [];
        const metadata = sessionData.metadata || {};

        return {
            questionsGenerated: questions.length,
            requestedQuestions: metadata.numQuestions || questions.length,
            fulfillmentRate: questions.length / (metadata.numQuestions || questions.length),
            questionTypes: this.analyzeQuestionTypes(questions),
            averageConfidence: this.calculateAverageConfidence(questions),
            medicalRelevance: this.calculateMedicalRelevance(questions),
            generationTime: metadata.generationTime || null,
            errorRate: this.calculateErrorRate(questions, metadata)
        };
    }

    analyzeQuestionTypes(questions) {
        const types = {};
        questions.forEach(q => {
            const type = q.type || 'unknown';
            types[type] = (types[type] || 0) + 1;
        });
        return types;
    }

    calculateAverageConfidence(questions) {
        const confidences = questions
            .map(q => q.confidence || q.metadata?.confidence)
            .filter(c => c !== undefined && c !== null);
        
        return confidences.length > 0 
            ? confidences.reduce((sum, c) => sum + c, 0) / confidences.length 
            : 0;
    }

    calculateMedicalRelevance(questions) {
        const medicalTerms = [
            'patient', 'diagnosis', 'treatment', 'surgery', 'medication',
            'examination', 'symptoms', 'syndrome', 'disease', 'condition',
            'retina', 'cornea', 'glaucoma', 'cataract', 'IOP', 'OCT',
            'phacoemulsification', 'vitrectomy', 'trabeculectomy'
        ];

        let totalRelevance = 0;
        questions.forEach(q => {
            const text = ((q.question || '') + ' ' + (q.answer || '')).toLowerCase();
            const relevantTerms = medicalTerms.filter(term => text.includes(term));
            totalRelevance += relevantTerms.length / medicalTerms.length;
        });

        return questions.length > 0 ? totalRelevance / questions.length : 0;
    }

    calculateErrorRate(questions, metadata) {
        const issues = [];
        
        questions.forEach(q => {
            if (!q.question || q.question.length < 10) issues.push('short_question');
            if (!q.answer || q.answer.length < 5) issues.push('short_answer');
            if (q.type === 'multiple_choice' && (!q.options || q.options.length < 2)) {
                issues.push('insufficient_options');
            }
        });

        return questions.length > 0 ? issues.length / questions.length : 0;
    }

    analyzeParameterPerformance(session) {
        const params = session.parameters;
        const performance = session.performance;

        // Track performance by parameter combinations
        const paramKey = JSON.stringify({
            difficulty: params.difficulty,
            knowledgeArea: params.knowledgeArea,
            aiModel: params.aiModel
        });

        if (!this.parameterOptimizations.has(paramKey)) {
            this.parameterOptimizations.set(paramKey, {
                parameters: params,
                sessions: [],
                averagePerformance: {},
                trends: {}
            });
        }

        const optimization = this.parameterOptimizations.get(paramKey);
        optimization.sessions.push({
            sessionId: session.id,
            timestamp: session.timestamp,
            performance
        });

        // Calculate rolling averages
        this.updatePerformanceAverages(optimization);
    }

    analyzeFeedbackForOptimization(questionId, feedbackData) {
        // Find the session that generated this question
        const session = this.findSessionByQuestionId(questionId);
        if (!session) return;

        // Update parameter optimization based on feedback
        const paramKey = JSON.stringify({
            difficulty: session.parameters.difficulty,
            knowledgeArea: session.parameters.knowledgeArea,
            aiModel: session.parameters.aiModel
        });

        if (this.parameterOptimizations.has(paramKey)) {
            const optimization = this.parameterOptimizations.get(paramKey);
            
            if (!optimization.feedback) optimization.feedback = [];
            optimization.feedback.push({
                questionId,
                feedback: feedbackData,
                timestamp: new Date().toISOString()
            });

            // Update feedback-based metrics
            this.updateFeedbackMetrics(optimization);
        }
    }

    updatePerformanceAverages(optimization) {
        const sessions = optimization.sessions;
        if (sessions.length === 0) return;

        const recent = sessions.slice(-10); // Last 10 sessions
        
        optimization.averagePerformance = {
            fulfillmentRate: this.average(recent.map(s => s.performance.fulfillmentRate)),
            averageConfidence: this.average(recent.map(s => s.performance.averageConfidence)),
            medicalRelevance: this.average(recent.map(s => s.performance.medicalRelevance)),
            errorRate: this.average(recent.map(s => s.performance.errorRate))
        };
    }

    updateFeedbackMetrics(optimization) {
        if (!optimization.feedback || optimization.feedback.length === 0) return;

        const feedback = optimization.feedback;
        const likes = feedback.filter(f => f.feedback.type === 'like').length;
        const dislikes = feedback.filter(f => f.feedback.type === 'dislike').length;
        const total = likes + dislikes;

        optimization.feedbackMetrics = {
            totalFeedback: total,
            likeRate: total > 0 ? likes / total : 0,
            dislikeRate: total > 0 ? dislikes / total : 0,
            engagementRate: feedback.length / optimization.sessions.length
        };
    }

    getOptimalParameters(targetMetrics = {}) {
        const recommendations = {};
        
        // Analyze all parameter combinations
        for (const [paramKey, optimization] of this.parameterOptimizations) {
            const performance = optimization.averagePerformance;
            const feedback = optimization.feedbackMetrics || {};
            
            // Calculate composite score
            const score = this.calculateCompositeScore(performance, feedback, targetMetrics);
            
            if (!recommendations.best || score > recommendations.best.score) {
                recommendations.best = {
                    parameters: optimization.parameters,
                    performance,
                    feedback,
                    score,
                    sessions: optimization.sessions.length
                };
            }
        }

        // Get recommendations by category
        recommendations.byCategory = this.getRecommendationsByCategory();
        
        return recommendations;
    }

    calculateCompositeScore(performance, feedback, targetMetrics) {
        const weights = {
            fulfillmentRate: 0.25,
            averageConfidence: 0.20,
            medicalRelevance: 0.20,
            errorRate: -0.15, // Negative because lower is better
            likeRate: 0.15,
            engagementRate: 0.05
        };

        let score = 0;
        for (const [metric, weight] of Object.entries(weights)) {
            const value = performance[metric] !== undefined ? performance[metric] : 
                         feedback[metric] !== undefined ? feedback[metric] : 0;
            score += value * weight;
        }

        return Math.max(0, Math.min(1, score)); // Normalize to 0-1
    }

    getRecommendationsByCategory() {
        const categories = {
            difficulty: new Map(),
            knowledgeArea: new Map(),
            aiModel: new Map(),
            questionTypes: new Map()
        };

        // Aggregate performance by category
        for (const [paramKey, optimization] of this.parameterOptimizations) {
            const params = optimization.parameters;
            const performance = optimization.averagePerformance;
            const feedback = optimization.feedbackMetrics || {};
            
            const score = this.calculateCompositeScore(performance, feedback);

            // Update category scores
            this.updateCategoryScore(categories.difficulty, params.difficulty, score, optimization);
            this.updateCategoryScore(categories.knowledgeArea, params.knowledgeArea, score, optimization);
            this.updateCategoryScore(categories.aiModel, params.aiModel, score, optimization);
            
            // Question types
            if (params.questionTypes) {
                Object.keys(params.questionTypes).forEach(type => {
                    this.updateCategoryScore(categories.questionTypes, type, score, optimization);
                });
            }
        }

        // Get top recommendations for each category
        const recommendations = {};
        for (const [category, scores] of Object.entries(categories)) {
            recommendations[category] = this.getTopFromMap(scores, 3);
        }

        return recommendations;
    }

    updateCategoryScore(categoryMap, key, score, optimization) {
        if (!categoryMap.has(key)) {
            categoryMap.set(key, { scores: [], totalSessions: 0 });
        }
        
        const data = categoryMap.get(key);
        data.scores.push(score);
        data.totalSessions += optimization.sessions.length;
        data.averageScore = this.average(data.scores);
    }

    getTopFromMap(map, limit = 3) {
        return Array.from(map.entries())
            .map(([key, data]) => ({ key, ...data }))
            .sort((a, b) => b.averageScore - a.averageScore)
            .slice(0, limit);
    }

    findSessionByQuestionId(questionId) {
        for (const session of this.history) {
            if (session.questions.some(q => q.id === questionId)) {
                return session;
            }
        }
        return null;
    }

    getPerformanceTrends(timeframeDays = 30) {
        const cutoff = new Date(Date.now() - timeframeDays * 24 * 60 * 60 * 1000);
        const recentSessions = this.history.filter(s => new Date(s.timestamp) > cutoff);

        if (recentSessions.length === 0) return null;

        return {
            totalSessions: recentSessions.length,
            totalQuestions: recentSessions.reduce((sum, s) => sum + s.questions.length, 0),
            averagePerformance: {
                fulfillmentRate: this.average(recentSessions.map(s => s.performance.fulfillmentRate)),
                confidence: this.average(recentSessions.map(s => s.performance.averageConfidence)),
                medicalRelevance: this.average(recentSessions.map(s => s.performance.medicalRelevance)),
                errorRate: this.average(recentSessions.map(s => s.performance.errorRate))
            },
            feedbackSummary: this.getFeedbackSummary(recentSessions),
            topPerformingParameters: this.getTopPerformingParameters(recentSessions)
        };
    }

    getFeedbackSummary(sessions) {
        const questionIds = sessions.flatMap(s => s.questions.map(q => q.id));
        const relevantFeedback = questionIds
            .map(id => this.feedbackData.get(id))
            .filter(f => f !== undefined);

        const totalLikes = relevantFeedback.reduce((sum, f) => sum + f.summary.likes, 0);
        const totalDislikes = relevantFeedback.reduce((sum, f) => sum + f.summary.dislikes, 0);
        const totalFeedback = totalLikes + totalDislikes;

        return {
            totalFeedback,
            likeRate: totalFeedback > 0 ? totalLikes / totalFeedback : 0,
            engagementRate: relevantFeedback.length / questionIds.length
        };
    }

    getTopPerformingParameters(sessions) {
        const paramPerformance = new Map();

        sessions.forEach(session => {
            const key = JSON.stringify(session.parameters);
            if (!paramPerformance.has(key)) {
                paramPerformance.set(key, {
                    parameters: session.parameters,
                    performances: []
                });
            }
            
            const composite = this.calculateCompositeScore(
                session.performance, 
                {}, // No feedback data in this context
                {}
            );
            paramPerformance.get(key).performances.push(composite);
        });

        return Array.from(paramPerformance.entries())
            .map(([key, data]) => ({
                parameters: data.parameters,
                averageScore: this.average(data.performances),
                sessions: data.performances.length
            }))
            .sort((a, b) => b.averageScore - a.averageScore)
            .slice(0, 5);
    }

    average(arr) {
        return arr.length > 0 ? arr.reduce((sum, val) => sum + val, 0) / arr.length : 0;
    }

    loadUserPreferences() {
        try {
            const saved = localStorage.getItem('questionHistory_userPreferences');
            return saved ? JSON.parse(saved) : {
                preferredDifficulty: null,
                preferredKnowledgeAreas: [],
                preferredQuestionTypes: [],
                adaptiveParameters: true
            };
        } catch (error) {
            console.error('Error loading user preferences:', error);
            return {
                preferredDifficulty: null,
                preferredKnowledgeAreas: [],
                preferredQuestionTypes: [],
                adaptiveParameters: true
            };
        }
    }

    saveUserPreferences() {
        try {
            localStorage.setItem('questionHistory_userPreferences', JSON.stringify(this.userPreferences));
        } catch (error) {
            console.error('Error saving user preferences:', error);
        }
    }

    loadHistoryFromStorage() {
        try {
            const savedHistory = localStorage.getItem('questionGenerationHistory');
            if (savedHistory) {
                const data = JSON.parse(savedHistory);
                this.history = data.history || [];
                
                // Reconstruct Maps
                if (data.feedbackData) {
                    this.feedbackData = new Map(data.feedbackData);
                }
                if (data.performanceMetrics) {
                    this.performanceMetrics = new Map(data.performanceMetrics);
                }
                if (data.parameterOptimizations) {
                    this.parameterOptimizations = new Map(data.parameterOptimizations);
                }
                
                console.log(`Loaded ${this.history.length} historical sessions from storage`);
            }
        } catch (error) {
            console.error('Error loading history from storage:', error);
        }
    }

    saveHistoryToStorage() {
        try {
            const data = {
                history: this.history,
                feedbackData: Array.from(this.feedbackData.entries()),
                performanceMetrics: Array.from(this.performanceMetrics.entries()),
                parameterOptimizations: Array.from(this.parameterOptimizations.entries()),
                lastSaved: new Date().toISOString()
            };
            
            if (window.safeSetItem) {
                window.safeSetItem('questionGenerationHistory', data);
            } else {
                localStorage.setItem('questionGenerationHistory', JSON.stringify(data));
            }
        } catch (error) {
            console.error('Error saving history to storage:', error);
            if (error.name === 'QuotaExceededError' && window.storageManager) {
                console.log('🚨 Storage quota exceeded, attempting cleanup...');
                window.storageManager.emergencyCleanup();
                
                // Try again with reduced data
                try {
                    const reducedData = {
                        history: this.history.slice(-50), // Keep only last 50 sessions
                        feedbackData: Array.from(this.feedbackData.entries()).slice(-100),
                        performanceMetrics: Array.from(this.performanceMetrics.entries()).slice(-50),
                        parameterOptimizations: Array.from(this.parameterOptimizations.entries()).slice(-25),
                        lastSaved: new Date().toISOString()
                    };
                    localStorage.setItem('questionGenerationHistory', JSON.stringify(reducedData));
                    console.log('✅ Saved reduced history after cleanup');
                } catch (retryError) {
                    console.error('❌ Still failed to save after cleanup:', retryError);
                }
            }
        }
    }

    clearHistory() {
        this.history = [];
        this.feedbackData.clear();
        this.performanceMetrics.clear();
        this.parameterOptimizations.clear();
        localStorage.removeItem('questionGenerationHistory');
        console.log('Question generation history cleared');
    }

    exportHistory() {
        return {
            history: this.history,
            feedbackData: Array.from(this.feedbackData.entries()),
            performanceMetrics: Array.from(this.performanceMetrics.entries()),
            parameterOptimizations: Array.from(this.parameterOptimizations.entries()),
            userPreferences: this.userPreferences,
            exportedAt: new Date().toISOString()
        };
    }
}

// Initialize the system globally
if (typeof window !== 'undefined') {
    window.questionGenerationHistory = new QuestionGenerationHistory();
}
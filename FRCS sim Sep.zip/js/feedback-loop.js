/**
 * Enhanced Feedback Loop System
 * 
 * This module implements an advanced feedback collection, analysis, and 
 * parameter optimization system to improve question generation over time.
 */

// Initialize the feedback loop system
document.addEventListener('DOMContentLoaded', () => {
    initFeedbackLoopSystem();
});

// Global state for feedback analysis
const feedbackLoopState = {
    feedbackHistory: [], // Array of all feedback items
    questionGenerationHistory: [], // History of parameter sets used for generation
    parameterPerformance: {}, // Performance metrics for different parameter combinations
    recommendedParameters: null, // Current parameter recommendations
    repetitionMetrics: {
        byTopic: {},
        byQuestionType: {},
        byDifficulty: {}
    }
};

// Make it globally accessible
window.feedbackLoopState = feedbackLoopState;

/**
 * Initialize the feedback loop system
 */
function initFeedbackLoopSystem() {
    // Load feedback history from localStorage
    loadFeedbackData();
    
    // Setup event listeners
    setupFeedbackEventListeners();
    
    // Initialize parameter optimization
    initParameterOptimization();
    
    console.log('Feedback Loop System initialized');
}

/**
 * Setup event listeners for the feedback system
 */
function setupFeedbackEventListeners() {
    // Listen for question generation events
    document.getElementById('generate-btn')?.addEventListener('click', captureGenerationParameters);
    document.getElementById('regenerate-btn')?.addEventListener('click', captureGenerationParameters);
    
    // Listen for feedback submission events
    document.addEventListener('feedback:submitted', handleFeedbackSubmission);
    
    // Listen for parameter recommendation application
    document.getElementById('apply-recommendations-btn')?.addEventListener('click', applyRecommendedParameters);
    
    // Listen for repeated question detection
    document.addEventListener('question:repeated', handleRepeatedQuestionEvent);
    
    // Setup feedback analytics refresh
    document.getElementById('view-feedback-analytics')?.addEventListener('click', () => {
        refreshFeedbackAnalytics();
    });
}

/**
 * Capture parameters when generating questions
 */
function captureGenerationParameters() {
    // Comprehensive debugging and safety checks
    console.log('Starting captureGenerationParameters...');
    console.log('feedbackLoopState type:', typeof feedbackLoopState);
    console.log('feedbackLoopState exists:', !!feedbackLoopState);
    console.log('window.feedbackLoopState exists:', !!window.feedbackLoopState);
    
    // Use window.feedbackLoopState as primary reference to avoid scope issues
    let state = window.feedbackLoopState || feedbackLoopState;
    
    // Ensure feedbackLoopState is properly initialized
    if (!state || typeof state !== 'object') {
        console.error('feedbackLoopState not properly initialized, attempting to reinitialize...');
        // Try to reinitialize the global state
        state = {
            feedbackHistory: [],
            questionGenerationHistory: [],
            parameterPerformance: {},
            recommendedParameters: null,
            repetitionMetrics: {
                byTopic: {},
                byQuestionType: {},
                byDifficulty: {}
            }
        };
        window.feedbackLoopState = state;
        console.log('Reinitialized feedbackLoopState');
    }
    
    // Log current state of questionGenerationHistory
    console.log('questionGenerationHistory exists:', 'questionGenerationHistory' in state);
    console.log('questionGenerationHistory type:', typeof state.questionGenerationHistory);
    console.log('questionGenerationHistory isArray:', Array.isArray(state.questionGenerationHistory));
    console.log('questionGenerationHistory value:', state.questionGenerationHistory);
    
    // Ensure questionGenerationHistory exists and is properly initialized
    if (!state.hasOwnProperty('questionGenerationHistory')) {
        console.warn('questionGenerationHistory property missing, initializing...');
        state.questionGenerationHistory = [];
    }
    
    // Additional safety check: ensure it's actually an array
    if (!Array.isArray(state.questionGenerationHistory)) {
        console.warn('questionGenerationHistory was not an array, resetting to empty array');
        console.log('Current value was:', state.questionGenerationHistory);
        state.questionGenerationHistory = [];
    }
    
    // Final verification before proceeding
    if (typeof state.questionGenerationHistory.push !== 'function') {
        console.error('CRITICAL: questionGenerationHistory.push is not a function!');
        console.log('Attempting emergency reconstruction...');
        state.questionGenerationHistory = [];
        
        // Double check the reconstruction worked
        if (typeof state.questionGenerationHistory.push !== 'function') {
            console.error('EMERGENCY RECONSTRUCTION FAILED! Aborting captureGenerationParameters');
            return;
        }
    }
    
    // Get current generation parameters
    const parameters = {
        timestamp: Date.now(),
        inputType: document.getElementById('input-type')?.value,
        knowledgeArea: document.getElementById('knowledge-area')?.value,
        aiModel: document.getElementById('ai-model')?.value,
        difficulty: document.getElementById('difficulty')?.value,
        numQuestions: parseInt(document.getElementById('num-questions')?.value || '10'),
        questionTypes: getSelectedQuestionTypes(),
        focusKeywords: document.getElementById('focus-area')?.value,
        showAnswers: document.getElementById('show-answers-default')?.checked
    };
    
    // Store in history with additional error handling
    try {
        console.log('About to push parameters. Array length before:', state.questionGenerationHistory.length);
        state.questionGenerationHistory.push(parameters);
        console.log('Successfully pushed parameters. Array length after:', state.questionGenerationHistory.length);
        console.log('Question generation parameters captured:', parameters);
        
        // Ensure the global reference is updated
        window.feedbackLoopState = state;
    } catch (error) {
        console.error('Error pushing to questionGenerationHistory:', error);
        console.error('Stack trace:', error.stack);
        console.log('questionGenerationHistory at time of error:', state.questionGenerationHistory);
        
        // Reinitialize and try again
        state.questionGenerationHistory = [parameters];
        window.feedbackLoopState = state;
        console.log('Reinitialized questionGenerationHistory with current parameters');
    }
    
    // Save to localStorage with error handling
    try {
        saveGenerationParametersHistory();
    } catch (error) {
        console.error('Error saving generation parameters history:', error);
    }
    
    console.log('Completed captureGenerationParameters');
}

/**
 * Get the selected question types
 */
function getSelectedQuestionTypes() {
    const selectedTypes = [];
    const typeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ];
    
    typeCheckboxes.forEach(id => {
        const checkbox = document.getElementById(id);
        if (checkbox?.checked) {
            selectedTypes.push(id.replace('type-', ''));
        }
    });
    
    return selectedTypes;
}

/**
 * Handle feedback submission events
 * @param {CustomEvent} event - The feedback submission event
 */
function handleFeedbackSubmission(event) {
    // Get feedback data
    const feedbackData = event.detail;
    
    // Add timestamp and current parameters
    feedbackData.timestamp = Date.now();
    feedbackData.generationParameters = getCurrentParameters();
    
    // Ensure feedbackHistory is an array before pushing
    if (!feedbackLoopState.feedbackHistory) {
        feedbackLoopState.feedbackHistory = [];
    } else if (!Array.isArray(feedbackLoopState.feedbackHistory)) {
        console.warn('feedbackHistory was not an array, resetting to empty array');
        feedbackLoopState.feedbackHistory = [];
    }
    
    // Store in history
    feedbackLoopState.feedbackHistory.push(feedbackData);
    
    // Update parameter performance metrics
    updateParameterPerformance(feedbackData);
    
    // Generate new recommendations based on accumulated data
    generateParameterRecommendations();
    
    // Save to localStorage
    saveFeedbackHistory();
    
    // Log feedback
    console.log('Feedback recorded:', feedbackData);
}

/**
 * Handle repeated question detection events
 * @param {CustomEvent} event - The repeated question event
 */
function handleRepeatedQuestionEvent(event) {
    const { question, similarityScore, matchedQuestion } = event.detail;
    
    // Log the repetition
    console.log(`Repeated question detected with similarity score: ${similarityScore}`);
    
    // Extract metadata for analysis
    const questionType = question.type || 'unknown';
    const topic = question.topic || question.category || 'unknown';
    const difficulty = getCurrentParameters()?.difficulty || 'unknown';
    
    // Update repetition metrics
    updateRepetitionMetrics(questionType, topic, difficulty);
    
    // Analyze patterns in repetition
    analyzeRepetitionPatterns();
    
    // Update UI with repetition analysis
    updateRepetitionAnalysisUI();
}

/**
 * Update metrics tracking question repetition patterns
 */
function updateRepetitionMetrics(questionType, topic, difficulty) {
    // Update by topic
    if (!feedbackLoopState.repetitionMetrics.byTopic[topic]) {
        feedbackLoopState.repetitionMetrics.byTopic[topic] = 0;
    }
    feedbackLoopState.repetitionMetrics.byTopic[topic]++;
    
    // Update by question type
    if (!feedbackLoopState.repetitionMetrics.byQuestionType[questionType]) {
        feedbackLoopState.repetitionMetrics.byQuestionType[questionType] = 0;
    }
    feedbackLoopState.repetitionMetrics.byQuestionType[questionType]++;
    
    // Update by difficulty
    if (!feedbackLoopState.repetitionMetrics.byDifficulty[difficulty]) {
        feedbackLoopState.repetitionMetrics.byDifficulty[difficulty] = 0;
    }
    feedbackLoopState.repetitionMetrics.byDifficulty[difficulty]++;
    
    // Save updated metrics
    saveRepetitionMetrics();
}

/**
 * Analyze repetition patterns and provide insights
 */
function analyzeRepetitionPatterns() {
    // Get most frequent repetition categories
    const mostRepeatedTopic = findHighestProperty(feedbackLoopState.repetitionMetrics.byTopic);
    const mostRepeatedType = findHighestProperty(feedbackLoopState.repetitionMetrics.byQuestionType);
    const mostRepeatedDifficulty = findHighestProperty(feedbackLoopState.repetitionMetrics.byDifficulty);
    
    // Create analysis results
    const analysis = {
        highRepetitionAreas: {
            topic: mostRepeatedTopic,
            questionType: mostRepeatedType,
            difficulty: mostRepeatedDifficulty
        },
        recommendations: []
    };
    
    // Generate recommendations based on patterns
    if (mostRepeatedTopic.value > 3) {
        analysis.recommendations.push(`Try diversifying away from "${mostRepeatedTopic.key}" topics`);
    }
    
    if (mostRepeatedType.value > 3) {
        analysis.recommendations.push(`Reduce the number of "${mostRepeatedType.key}" question types`);
    }
    
    if (mostRepeatedDifficulty.value > 5) {
        analysis.recommendations.push(`Consider changing difficulty level from "${mostRepeatedDifficulty.key}"`);
    }
    
    // Store analysis
    feedbackLoopState.repetitionAnalysis = analysis;
    
    // Log analysis
    console.log('Repetition pattern analysis:', analysis);
    
    return analysis;
}

/**
 * Find the property with the highest value in an object
 */
function findHighestProperty(obj) {
    let highestKey = null;
    let highestValue = -1;
    
    for (const [key, value] of Object.entries(obj)) {
        if (value > highestValue) {
            highestKey = key;
            highestValue = value;
        }
    }
    
    return { key: highestKey, value: highestValue };
}

/**
 * Update UI with repetition analysis
 */
function updateRepetitionAnalysisUI() {
    // Only update if we have an analysis
    if (!feedbackLoopState.repetitionAnalysis) return;
    
    // Add info to feedback analytics modal
    const analyticsModal = document.getElementById('feedback-analytics-modal');
    if (!analyticsModal) return;
    
    // Check if repetition analysis section exists, create it if not
    let repetitionSection = document.getElementById('repetition-analysis-section');
    if (!repetitionSection) {
        // Create new section
        repetitionSection = document.createElement('div');
        repetitionSection.id = 'repetition-analysis-section';
        repetitionSection.className = 'mb-6';
        
        // Create header
        const header = document.createElement('h4');
        header.className = 'font-medium text-gray-800 mb-2 flex items-center';
        header.innerHTML = '<i class="fas fa-copy mr-1"></i> Repetition Analysis';
        
        // Create content container
        const content = document.createElement('div');
        content.id = 'repetition-analysis-content';
        content.className = 'bg-yellow-50 p-4 rounded-lg border border-yellow-100';
        
        // Assemble
        repetitionSection.appendChild(header);
        repetitionSection.appendChild(content);
        
        // Add to modal before the last section
        const feedbackHistorySection = analyticsModal.querySelector('h4:last-of-type').parentNode;
        feedbackHistorySection.parentNode.insertBefore(repetitionSection, feedbackHistorySection);
    }
    
    // Update content
    const content = document.getElementById('repetition-analysis-content');
    if (!content) return;
    
    const analysis = feedbackLoopState.repetitionAnalysis;
    
    // Update HTML with analysis
    content.innerHTML = `
        <div class="text-sm">
            <p class="mb-2 font-semibold">Most Repeated Categories:</p>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
                <div class="bg-white p-2 rounded border">
                    <span class="text-gray-600">Topic:</span>
                    <div class="font-medium">${analysis.highRepetitionAreas.topic.key || 'None'} 
                        <span class="text-yellow-600">(${analysis.highRepetitionAreas.topic.value || 0})</span>
                    </div>
                </div>
                <div class="bg-white p-2 rounded border">
                    <span class="text-gray-600">Question Type:</span>
                    <div class="font-medium">${analysis.highRepetitionAreas.questionType.key || 'None'}
                        <span class="text-yellow-600">(${analysis.highRepetitionAreas.questionType.value || 0})</span>
                    </div>
                </div>
                <div class="bg-white p-2 rounded border">
                    <span class="text-gray-600">Difficulty:</span>
                    <div class="font-medium">${analysis.highRepetitionAreas.difficulty.key || 'None'}
                        <span class="text-yellow-600">(${analysis.highRepetitionAreas.difficulty.value || 0})</span>
                    </div>
                </div>
            </div>
            
            <p class="mb-2 font-semibold">Recommendations to Reduce Repetition:</p>
            <ul class="list-disc pl-5 space-y-1">
                ${analysis.recommendations.map(rec => `<li>${rec}</li>`).join('') || '<li>No specific recommendations at this time</li>'}
            </ul>
        </div>
    `;
}

/**
 * Get current question generation parameters
 */
function getCurrentParameters() {
    // Get parameters from form inputs
    return {
        inputType: document.getElementById('input-type')?.value,
        knowledgeArea: document.getElementById('knowledge-area')?.value,
        aiModel: document.getElementById('ai-model')?.value,
        difficulty: document.getElementById('difficulty')?.value,
        numQuestions: parseInt(document.getElementById('num-questions')?.value || '10'),
        questionTypes: getSelectedQuestionTypes(),
        focusKeywords: document.getElementById('focus-area')?.value,
        showAnswers: document.getElementById('show-answers-default')?.checked
    };
}

/**
 * Update parameter performance metrics based on feedback
 */
function updateParameterPerformance(feedbackData) {
    const params = feedbackData.generationParameters;
    if (!params) return;
    
    // Create a key from the parameters
    const paramKey = createParameterKey(params);
    
    // Initialize if needed
    if (!feedbackLoopState.parameterPerformance[paramKey]) {
        feedbackLoopState.parameterPerformance[paramKey] = {
            parameters: params,
            useCount: 0,
            totalFeedback: 0,
            positiveFeedback: 0,
            negativeFeedback: 0,
            metrics: {
                relevance: 0,
                accuracy: 0,
                clarity: 0,
                difficulty: 0
            },
            repetitionRate: 0
        };
    }
    
    // Update stats
    const perfMetric = feedbackLoopState.parameterPerformance[paramKey];
    perfMetric.useCount++;
    perfMetric.totalFeedback++;
    
    // Update positive/negative count
    if (feedbackData.rating === 'positive') {
        perfMetric.positiveFeedback++;
    } else if (feedbackData.rating === 'negative') {
        perfMetric.negativeFeedback++;
    }
    
    // Update specific metrics if available
    if (feedbackData.metrics) {
        Object.keys(feedbackData.metrics).forEach(metric => {
            if (perfMetric.metrics[metric] !== undefined) {
                // Moving average
                perfMetric.metrics[metric] = 
                    (perfMetric.metrics[metric] * (perfMetric.totalFeedback - 1) + feedbackData.metrics[metric]) 
                    / perfMetric.totalFeedback;
            }
        });
    }
    
    // Save updated metrics
    saveParameterPerformance();
}

/**
 * Create a unique key for parameter combinations
 */
function createParameterKey(params) {
    // Create a consistent key from the main parameters
    return `${params.difficulty}_${params.aiModel}_${params.questionTypes.sort().join('_')}`;
}

/**
 * Generate parameter recommendations based on historical performance
 */
function generateParameterRecommendations() {
    // Skip if we don't have enough data
    if (Object.keys(feedbackLoopState.parameterPerformance).length < 2) {
        return null;
    }
    
    // Find the best performing parameter sets
    const performances = Object.values(feedbackLoopState.parameterPerformance)
        .filter(p => p.totalFeedback >= 3) // Only consider sets with enough feedback
        .map(p => ({
            parameters: p.parameters,
            score: calculateOverallScore(p),
            metrics: p.metrics,
            repetitionRate: p.repetitionRate
        }))
        .sort((a, b) => b.score - a.score);
    
    // If we have performance data, generate recommendations
    if (performances.length > 0) {
        const bestParams = performances[0];
        
        // Get current parameters
        const currentParams = getCurrentParameters();
        
        // Generate recommendations
        const recommendations = {
            difficulty: bestParams.parameters.difficulty,
            questionTypes: bestParams.parameters.questionTypes.slice(0, 4), // Top 4 types
            model: bestParams.parameters.aiModel,
            avoidRepetition: bestParams.repetitionRate > 0.2, // Suggest changes if repetition rate is high
            overallScore: bestParams.score.toFixed(2)
        };
        
        // Store recommendations
        feedbackLoopState.recommendedParameters = recommendations;
        
        // Save recommendations
        saveRecommendations();
        
        return recommendations;
    }
    
    return null;
}

/**
 * Calculate an overall score for a parameter set
 */
function calculateOverallScore(perfMetric) {
    // Calculate a weighted score from all available metrics
    const metrics = perfMetric.metrics;
    const weights = {
        relevance: 0.3,
        accuracy: 0.3,
        clarity: 0.2,
        difficulty: 0.2
    };
    
    // Base score from positive feedback percentage
    const positiveFeedbackRate = perfMetric.totalFeedback > 0 ? 
        perfMetric.positiveFeedback / perfMetric.totalFeedback : 0;
    
    // Weighted metric score
    let metricScore = 0;
    let totalWeight = 0;
    
    Object.keys(metrics).forEach(metric => {
        if (metrics[metric] > 0 && weights[metric]) {
            metricScore += metrics[metric] * weights[metric];
            totalWeight += weights[metric];
        }
    });
    
    // Normalize metric score
    const normalizedMetricScore = totalWeight > 0 ? metricScore / totalWeight : 0;
    
    // Penalize for high repetition rate
    const repetitionPenalty = perfMetric.repetitionRate * 0.5;
    
    // Combined score (0-10 scale)
    return (positiveFeedbackRate * 5 + normalizedMetricScore * 5) * (1 - repetitionPenalty);
}

/**
 * Apply the recommended parameters to the UI
 */
function applyRecommendedParameters() {
    const recommendations = feedbackLoopState.recommendedParameters;
    if (!recommendations) {
        console.log('No recommendations available to apply');
        return;
    }
    
    console.log('Applying recommended parameters:', recommendations);
    
    // Apply difficulty
    const difficultySelect = document.getElementById('difficulty');
    if (difficultySelect && recommendations.difficulty) {
        difficultySelect.value = recommendations.difficulty;
    }
    
    // Apply question types
    if (recommendations.questionTypes && recommendations.questionTypes.length) {
        // First uncheck all
        const typeCheckboxes = [
            'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
            'type-clinical-case', 'type-differential', 'type-management',
            'type-viva', 'type-osce'
        ];
        
        typeCheckboxes.forEach(id => {
            const checkbox = document.getElementById(id);
            if (checkbox) {
                checkbox.checked = false;
            }
        });
        
        // Then check recommended types
        recommendations.questionTypes.forEach(type => {
            const checkbox = document.getElementById(`type-${type}`);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
        
        // Update "Select All" checkbox state
        updateSelectAllCheckbox();
    }
    
    // Apply AI model if recommended
    if (recommendations.model) {
        const modelSelect = document.getElementById('ai-model');
        if (modelSelect) {
            modelSelect.value = recommendations.model;
        }
    }
    
    // Show success message
    const statusMessage = document.getElementById('status-message');
    if (statusMessage) {
        statusMessage.textContent = 'Optimized parameters applied based on your feedback history!';
        statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-green-100 text-green-800';
        statusMessage.style.display = 'block';
        
        // Hide after a few seconds
        setTimeout(() => {
            statusMessage.style.display = 'none';
        }, 4000);
    }
    
    // Close the analytics modal if it's open
    const analyticsModal = document.getElementById('feedback-analytics-modal');
    if (analyticsModal && !analyticsModal.classList.contains('hidden')) {
        document.getElementById('close-feedback-analytics-modal')?.click();
    }
}

/**
 * Initialize parameter optimization system
 */
function initParameterOptimization() {
    // Ensure the select all checkbox functionality works
    const typeAllCheckbox = document.getElementById('type-all');
    if (typeAllCheckbox) {
        typeAllCheckbox.addEventListener('change', updateAllCheckboxes);
    }
    
    // Add event listeners to individual checkboxes
    const questionTypeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ];
    
    questionTypeCheckboxes.forEach(id => {
        const checkbox = document.getElementById(id);
        if (checkbox) {
            checkbox.addEventListener('change', updateSelectAllCheckbox);
        }
    });
}

/**
 * Update all checkboxes based on the "Select All" checkbox
 */
function updateAllCheckboxes() {
    const typeAllCheckbox = document.getElementById('type-all');
    if (!typeAllCheckbox) return;
    
    const questionTypeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ].map(id => document.getElementById(id));
    
    // Update all checkboxes to match the "Select All" state
    questionTypeCheckboxes.forEach(cb => {
        if (cb) cb.checked = typeAllCheckbox.checked;
    });
}

/**
 * Update the "Select All" checkbox based on individual checkboxes
 */
function updateSelectAllCheckbox() {
    const typeAllCheckbox = document.getElementById('type-all');
    if (!typeAllCheckbox) return;
    
    const questionTypeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ].map(id => document.getElementById(id));
    
    const allChecked = questionTypeCheckboxes.every(cb => cb && cb.checked);
    const someChecked = questionTypeCheckboxes.some(cb => cb && cb.checked);
    
    typeAllCheckbox.checked = allChecked;
    typeAllCheckbox.indeterminate = someChecked && !allChecked;
}

/**
 * Refresh the feedback analytics display
 */
function refreshFeedbackAnalytics() {
    // Update general metrics
    updateFeedbackMetrics();
    
    // Update parameter recommendations UI
    updateRecommendationsUI();
    
    // Update repetition analysis
    updateRepetitionAnalysisUI();
    
    // Update history display
    updateFeedbackHistoryUI();
}

/**
 * Update the feedback metrics in the UI
 */
function updateFeedbackMetrics() {
    // Calculate general metrics
    const totalFeedback = feedbackLoopState.feedbackHistory.length;
    const positiveFeedback = feedbackLoopState.feedbackHistory.filter(f => f.rating === 'positive').length;
    const improvedQuestions = feedbackLoopState.feedbackHistory.filter(f => f.improved).length;
    
    // Update counters
    document.getElementById('feedback-total-count').textContent = totalFeedback;
    document.getElementById('feedback-improved-count').textContent = improvedQuestions;
    document.getElementById('feedback-positive-rate').textContent = 
        totalFeedback > 0 ? `${Math.round((positiveFeedback / totalFeedback) * 100)}%` : '0%';
    
    // Update metric bars
    updateMetricBar('relevance');
    updateMetricBar('accuracy');
    updateMetricBar('difficulty');
    updateMetricBar('clarity');
}

/**
 * Update a specific metric bar in the UI
 */
function updateMetricBar(metricName) {
    // Calculate average for this metric
    let sum = 0;
    let count = 0;
    
    feedbackLoopState.feedbackHistory.forEach(feedback => {
        if (feedback.metrics && feedback.metrics[metricName] !== undefined) {
            sum += feedback.metrics[metricName];
            count++;
        }
    });
    
    const average = count > 0 ? sum / count : 0;
    const percentage = Math.round(average * 100);
    
    // Update UI elements
    document.getElementById(`metric-${metricName}`).textContent = `${percentage}%`;
    document.getElementById(`metric-${metricName}-bar`).style.width = `${percentage}%`;
}

/**
 * Update the parameter recommendations UI
 */
function updateRecommendationsUI() {
    const recommendations = feedbackLoopState.recommendedParameters;
    
    // Skip if no recommendations
    if (!recommendations) {
        document.getElementById('recommended-difficulty').textContent = 'No change recommended';
        document.getElementById('recommended-types').innerHTML = 
            '<span class="bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs">Not enough data yet</span>';
        return;
    }
    
    // Update difficulty recommendation
    document.getElementById('recommended-difficulty').textContent = 
        recommendations.difficulty || 'No change recommended';
    
    // Update question types recommendations
    const typesContainer = document.getElementById('recommended-types');
    typesContainer.innerHTML = '';
    
    if (recommendations.questionTypes && recommendations.questionTypes.length) {
        recommendations.questionTypes.forEach(type => {
            const typeSpan = document.createElement('span');
            typeSpan.className = 'bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs';
            
            // Format type name for display
            let displayType = type;
            switch(type) {
                case 'mcq': displayType = 'Multiple Choice'; break;
                case 'tf': displayType = 'True/False'; break;
                case 'short-answer': displayType = 'Short Answer'; break;
                case 'clinical-case': displayType = 'Clinical Case'; break;
                case 'differential': displayType = 'Differential'; break;
                case 'management': displayType = 'Management'; break;
                case 'viva': displayType = 'VIVA'; break;
                case 'osce': displayType = 'OSCE'; break;
            }
            
            typeSpan.textContent = displayType;
            typesContainer.appendChild(typeSpan);
        });
    } else {
        typesContainer.innerHTML = 
            '<span class="bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs">No specific recommendations</span>';
    }
}

/**
 * Update the feedback history display in the UI
 */
function updateFeedbackHistoryUI() {
    const historyContainer = document.getElementById('feedback-history');
    if (!historyContainer) return;
    
    // Clear previous content
    historyContainer.innerHTML = '';
    
    if (feedbackLoopState.feedbackHistory.length === 0) {
        historyContainer.innerHTML = '<p class="text-center text-gray-500">No feedback activity yet</p>';
        return;
    }
    
    // Get the 5 most recent feedback entries
    const recentFeedback = [...feedbackLoopState.feedbackHistory]
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 5);
    
    // Add each entry to the UI
    recentFeedback.forEach(feedback => {
        const entryEl = document.createElement('div');
        entryEl.className = 'p-2 bg-white rounded border border-gray-200';
        
        // Format timestamp
        const date = new Date(feedback.timestamp);
        const formattedDate = date.toLocaleString();
        
        // Format feedback type
        let actionText = 'gave feedback';
        let actionClass = 'text-blue-600';
        
        if (feedback.rating === 'positive') {
            actionText = 'positive feedback';
            actionClass = 'text-green-600';
        } else if (feedback.rating === 'negative') {
            actionText = 'negative feedback';
            actionClass = 'text-red-600';
        }
        
        if (feedback.improved) {
            actionText = 'improved a question';
            actionClass = 'text-purple-600';
        }
        
        // Create entry content
        entryEl.innerHTML = `
            <div class="flex items-center justify-between">
                <span class="${actionClass} font-medium">You ${actionText}</span>
                <span class="text-gray-500 text-xs">${formattedDate}</span>
            </div>
            <p class="text-gray-700 text-xs mt-1 truncate">
                ${feedback.questionType || ''} 
                ${feedback.questionText ? `- "${feedback.questionText.substring(0, 40)}${feedback.questionText.length > 40 ? '...' : ''}"` : ''}
            </p>
        `;
        
        historyContainer.appendChild(entryEl);
    });
}

/**
 * Load feedback data from localStorage
 */
function loadFeedbackData() {
    try {
        // Use window reference as primary, with fallback
        let state = window.feedbackLoopState || feedbackLoopState;
        
        // Load feedback history
        const feedbackHistory = localStorage.getItem('feedbackHistory');
        if (feedbackHistory) {
            try {
                const parsed = JSON.parse(feedbackHistory);
                state.feedbackHistory = Array.isArray(parsed) ? parsed : [];
                if (!Array.isArray(parsed)) {
                    console.warn('feedbackHistory was not an array in localStorage, reset to empty array');
                }
            } catch (e) {
                console.error('Error parsing feedback history:', e);
                state.feedbackHistory = [];
                // Clear corrupted data
                localStorage.removeItem('feedbackHistory');
            }
        } else {
            state.feedbackHistory = [];
        }
        
        // Load parameter performance
        const parameterPerformance = localStorage.getItem('parameterPerformance');
        if (parameterPerformance) {
            try {
                state.parameterPerformance = JSON.parse(parameterPerformance);
            } catch (e) {
                console.error('Error parsing parameter performance:', e);
                state.parameterPerformance = {};
                localStorage.removeItem('parameterPerformance');
            }
        } else {
            state.parameterPerformance = {};
        }
        
        // Load recommendations
        const recommendations = localStorage.getItem('parameterRecommendations');
        if (recommendations) {
            try {
                state.recommendedParameters = JSON.parse(recommendations);
            } catch (e) {
                console.error('Error parsing recommendations:', e);
                state.recommendedParameters = null;
                localStorage.removeItem('parameterRecommendations');
            }
        } else {
            state.recommendedParameters = null;
        }
        
        // Load repetition metrics
        const repetitionMetrics = localStorage.getItem('repetitionMetrics');
        if (repetitionMetrics) {
            try {
                state.repetitionMetrics = JSON.parse(repetitionMetrics);
            } catch (e) {
                console.error('Error parsing repetition metrics:', e);
                state.repetitionMetrics = {
                    byTopic: {},
                    byQuestionType: {},
                    byDifficulty: {}
                };
                localStorage.removeItem('repetitionMetrics');
            }
        } else {
            state.repetitionMetrics = {
                byTopic: {},
                byQuestionType: {},
                byDifficulty: {}
            };
        }
        
        // Load question generation history with enhanced error handling
        const generationHistory = localStorage.getItem('questionGenerationHistory');
        if (generationHistory) {
            try {
                const parsed = JSON.parse(generationHistory);
                if (Array.isArray(parsed)) {
                    state.questionGenerationHistory = parsed;
                } else {
                    console.warn('questionGenerationHistory was not an array in localStorage, reset to empty array');
                    state.questionGenerationHistory = [];
                    localStorage.removeItem('questionGenerationHistory');
                }
            } catch (e) {
                console.error('Error parsing generation history:', e);
                state.questionGenerationHistory = [];
                // Clear corrupted data
                localStorage.removeItem('questionGenerationHistory');
            }
        } else {
            // Initialize with empty array if not present
            state.questionGenerationHistory = [];
        }
        
        // Verify all critical properties exist
        if (!state.hasOwnProperty('questionGenerationHistory')) {
            state.questionGenerationHistory = [];
        }
        if (!state.hasOwnProperty('feedbackHistory')) {
            state.feedbackHistory = [];
        }
        
        // Update the global reference
        window.feedbackLoopState = state;
        
        console.log('Feedback data loaded from localStorage');
        console.log('Loaded history lengths:', {
            feedbackHistory: state.feedbackHistory.length,
            questionGenerationHistory: state.questionGenerationHistory.length
        });
    } catch (error) {
        console.error('Error loading feedback data:', error);
        // Reset to safe defaults
        const state = {
            feedbackHistory: [],
            questionGenerationHistory: [],
            parameterPerformance: {},
            recommendedParameters: null,
            repetitionMetrics: {
                byTopic: {},
                byQuestionType: {},
                byDifficulty: {}
            }
        };
        window.feedbackLoopState = state;
    }
}

/**
 * Save feedback history to localStorage
 */
function saveFeedbackHistory() {
    try {
        localStorage.setItem('feedbackHistory', JSON.stringify(feedbackLoopState.feedbackHistory));
    } catch (error) {
        console.error('Error saving feedback history:', error);
    }
}

/**
 * Save parameter performance metrics to localStorage
 */
function saveParameterPerformance() {
    try {
        localStorage.setItem('parameterPerformance', JSON.stringify(feedbackLoopState.parameterPerformance));
    } catch (error) {
        console.error('Error saving parameter performance:', error);
    }
}

/**
 * Save parameter recommendations to localStorage
 */
function saveRecommendations() {
    try {
        localStorage.setItem('parameterRecommendations', JSON.stringify(feedbackLoopState.recommendedParameters));
    } catch (error) {
        console.error('Error saving recommendations:', error);
    }
}

/**
 * Save repetition metrics to localStorage
 */
function saveRepetitionMetrics() {
    try {
        localStorage.setItem('repetitionMetrics', JSON.stringify(feedbackLoopState.repetitionMetrics));
    } catch (error) {
        console.error('Error saving repetition metrics:', error);
    }
}

/**
 * Save generation parameters history to localStorage
 */
function saveGenerationParametersHistory() {
    try {
        // Use window reference for consistency
        const state = window.feedbackLoopState || feedbackLoopState;
        
        // Validate the data before saving
        if (!Array.isArray(state.questionGenerationHistory)) {
            console.warn('questionGenerationHistory is not an array, initializing as empty array before save');
            state.questionGenerationHistory = [];
            window.feedbackLoopState = state;
        }
        
        // Save to localStorage
        localStorage.setItem('questionGenerationHistory', JSON.stringify(state.questionGenerationHistory));
        
        // Log success for debugging
        console.log(`Saved ${state.questionGenerationHistory.length} generation history entries to localStorage`);
    } catch (error) {
        console.error('Error saving generation history:', error);
        
        // If localStorage quota exceeded, try to clean up old entries
        if (error.name === 'QuotaExceededError') {
            try {
                const state = window.feedbackLoopState || feedbackLoopState;
                // Keep only the last 50 entries
                state.questionGenerationHistory = state.questionGenerationHistory.slice(-50);
                window.feedbackLoopState = state;
                localStorage.setItem('questionGenerationHistory', JSON.stringify(state.questionGenerationHistory));
                console.log('Reduced generation history to 50 entries due to quota limit');
            } catch (retryError) {
                console.error('Failed to save even reduced generation history:', retryError);
            }
        }
    }
}

// Export necessary functions
window.FeedbackLoop = {
    recordFeedback: handleFeedbackSubmission,
    getRecommendedParameters: () => feedbackLoopState.recommendedParameters,
    applyRecommendedParameters,
    getRepetitionAnalysis: () => feedbackLoopState.repetitionAnalysis,
    refreshAnalytics: refreshFeedbackAnalytics
}; 
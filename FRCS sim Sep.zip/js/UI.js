class UI {
    constructor() {
        this.initializeElements();
        this.isProcessing = false;
        this.lastSettings = null;
    }

    initializeElements() {
        // Input elements
        this.inputTypeSelect = document.getElementById('input-type');
        this.uploadContainer = document.getElementById('upload-container');
        this.textContainer = document.getElementById('text-container');
        this.inputTextElement = document.getElementById('input-text');
        this.knowledgeAreaSelect = document.getElementById('knowledge-area');
        this.aiModelSelect = document.getElementById('ai-model');
        this.difficultySelect = document.getElementById('difficulty');
        this.numQuestionsInput = document.getElementById('num-questions');
        this.focusAreaInput = document.getElementById('focus-area');
        this.showAnswersDefaultCheckbox = document.getElementById('show-answers-default');
        this.exportFormatSelect = document.getElementById('export-format');

        // Journal search elements
        this.journalSearchContainer = document.getElementById('journal-search-container');

        // NotebookLM elements
        this.notebookContainer = document.getElementById('notebook-container');
        this.connectNotebookLmBtn = document.getElementById('connect-notebooklm');
        this.notebookStatus = document.getElementById('notebook-status');
        this.notebookStatusMessage = document.getElementById('notebook-status-message');
        this.notebookSelection = document.getElementById('notebook-selection');
        this.notebookSelect = document.getElementById('notebook-select');
        this.selectedNotebookInfo = document.getElementById('selected-notebook-info');
        this.selectedNotebookTitle = document.getElementById('selected-notebook-title');
        this.selectedNotebookDescription = document.getElementById('selected-notebook-description');

        // NotebookLM modal elements
        this.notebookLmModal = document.getElementById('notebooklm-modal');
        this.notebookLmModalBackdrop = document.getElementById('notebooklm-modal-backdrop');
        this.closeNotebookLmModalBtn = document.getElementById('close-notebooklm-modal');
        this.notebookLmCode = document.getElementById('notebooklm-code');
        this.notebookLmAuthStatus = document.getElementById('notebooklm-auth-status');
        this.authenticateNotebookLmBtn = document.getElementById('authenticate-notebooklm');

        // Buttons
        this.generateBtn = document.getElementById('generate-btn');
        this.clearBtn = document.getElementById('clear-btn');
        this.exportBtn = document.getElementById('export-btn');
        this.regenerateBtn = document.getElementById('regenerate-btn');

        // Containers
        this.qaContainer = document.getElementById('qa-container');
        this.questionContainer = this.qaContainer; // Alias for compatibility
        this.loadingIndicator = document.getElementById('loading-indicator');
        this.statusMessage = document.getElementById('status-message');

        // Question type checkboxes
        this.questionTypeCheckboxes = {
            mcq: document.getElementById('type-mcq'),
            tf: document.getElementById('type-tf'),
            matching: document.getElementById('type-matching'),
            shortAnswer: document.getElementById('type-short-answer'),
            clinicalCase: document.getElementById('type-clinical-case'),
            differential: document.getElementById('type-differential')
        };
    }

    initializeEventListeners() {
        // Main form controls
        this.inputTypeSelect.addEventListener('change', () => this.updateInputVisibility());
        this.knowledgeAreaSelect.addEventListener('change', () => this.updateKnowledgeAreaBehavior(this.knowledgeAreaSelect.value));
        this.clearBtn.addEventListener('click', () => this.clearAll());
        
        // Question container event delegation
        this.questionContainer.addEventListener('click', (event) => this.handleQuestionClick(event));
        
        // NotebookLM connect button
        this.connectNotebookLmBtn.addEventListener('click', () => this.showNotebookLmModal());
        
        // Add a direct FRCS notebook import button next to the connect button
        const directFrcsImportBtn = document.createElement('button');
        directFrcsImportBtn.className = 'bg-green-100 hover:bg-green-200 text-green-800 px-3 py-2 rounded-md text-sm transition flex items-center ml-2';
        directFrcsImportBtn.innerHTML = '<i class="fas fa-file-import mr-2"></i>Import FRCS Notebook';
        directFrcsImportBtn.title = 'Directly import your FRCS notebook';
        
        directFrcsImportBtn.addEventListener('click', async () => {
            try {
                this.showStatus('Importing your FRCS notebook...', 'info');
                
                if (!window.notebookLmHandler) {
                    throw new Error('NotebookLM handler not available');
                }
                
                // Make sure we're initialized
                if (!window.notebookLmHandler.isInitialized()) {
                    const defaultEmail = 'genododi@gmail.com';
                    const initialized = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                    
                    if (!initialized) {
                        throw new Error('Failed to initialize NotebookLM handler');
                    }
                }
                
                // Import the specific notebook
                const specificUrl = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
                const success = await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                
                if (success) {
                    this.showStatus('Successfully imported your FRCS notebook!', 'success');
                    
                    // Update UI and refresh notebooks
                    this.updateNotebookLmStatus();
                    this.loadNotebookOptions();
                } else {
                    throw new Error('Failed to import notebook');
                }
            } catch (error) {
                console.error('Error importing FRCS notebook:', error);
                this.showStatus('Error importing notebook: ' + error.message, 'error');
            }
        });
        
        // Add the button next to the connect button
        this.connectNotebookLmBtn.parentNode.insertBefore(directFrcsImportBtn, this.connectNotebookLmBtn.nextSibling);
        
        // NotebookLM notebook selection
        this.notebookSelect.addEventListener('change', () => this.handleNotebookSelection());

        // NotebookLM event listeners
        if (this.closeNotebookLmModalBtn) {
            this.closeNotebookLmModalBtn.addEventListener('click', () => this.hideNotebookLmModal());
        }

        if (this.notebookLmModalBackdrop) {
            this.notebookLmModalBackdrop.addEventListener('click', () => this.hideNotebookLmModal());
        }

        if (this.authenticateNotebookLmBtn) {
            this.authenticateNotebookLmBtn.addEventListener('click', () => this.handleNotebookLmAuthentication());
        }

        // Question type checkboxes
        Object.values(this.questionTypeCheckboxes).forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const anyChecked = Object.values(this.questionTypeCheckboxes).some(cb => cb.checked);
                if (!anyChecked) {
                    // Ensure at least one is checked
                    checkbox.checked = true;
                }
            });
        });
        
        // Show answers checkbox
        this.showAnswersDefaultCheckbox.addEventListener('change', () => {
            if (this.questionGenerator && this.questionGenerator.generatedQuestions.length > 0) {
                const questions = document.querySelectorAll('.question-item');
                questions.forEach(q => {
                    const answer = q.querySelector('.answer-container');
                    if (answer) {
                        answer.classList.toggle('hidden', !this.showAnswersDefaultCheckbox.checked);
                    }
                });
            }
        });
    }

    updateInputVisibility() {
        const selectedValue = this.inputTypeSelect.value;
        
        this.uploadContainer.classList.toggle('hidden', selectedValue !== 'upload');
        this.textContainer.classList.toggle('hidden', selectedValue !== 'text');
        this.notebookContainer.classList.toggle('hidden', selectedValue !== 'notebooklm');
        
        if (this.journalSearchContainer) {
            this.journalSearchContainer.classList.toggle('hidden', selectedValue !== 'journal-search');
        }
        
        // Update knowledge area behavior
        this.updateKnowledgeAreaBehavior(selectedValue);

        // If NotebookLM is selected, show connection status
        if (selectedValue === 'notebooklm') {
            this.updateNotebookLmStatus();
        }

        // Journal search is handled by standalone implementation
    }

    updateKnowledgeAreaBehavior(selectedValue) {
        const knowledgeAreaLabel = document.querySelector('label[for="knowledge-area"]');
        const knowledgeAreaHelpText = this.knowledgeAreaSelect.nextElementSibling;

        if (selectedValue === 'knowledge-base') {
            knowledgeAreaLabel.textContent = 'Select Knowledge Area';
            knowledgeAreaHelpText.textContent = 'Generates questions based on the selected built-in topic.';
            this.knowledgeAreaSelect.querySelector('option[value="general"]').disabled = true;
            if (this.knowledgeAreaSelect.value === 'general') this.knowledgeAreaSelect.value = 'all';
            // Enable 'all' option for knowledge-base
            this.knowledgeAreaSelect.querySelector('option[value="all"]').disabled = false;
        } else {
            knowledgeAreaLabel.textContent = 'Select Subspecialty Focus';
            knowledgeAreaHelpText.textContent = 'Guides question generation for all input types.';
            this.knowledgeAreaSelect.querySelector('option[value="general"]').disabled = false;
            // Disable 'all' option for other input types
            this.knowledgeAreaSelect.querySelector('option[value="all"]').disabled = true;
            if (this.knowledgeAreaSelect.value === 'all') this.knowledgeAreaSelect.value = 'general';
        }
    }

    clearAll() {
        // Call file handler's clearFileInput method if available
        if (this.fileHandler && typeof this.fileHandler.clearFileInput === 'function') {
            this.fileHandler.clearFileInput();
        }
        
        // Reset all form elements
        this.inputTextElement.value = '';
        this.knowledgeAreaSelect.value = 'general';
        // Set AI model to default from config
        if (this.aiModelSelect) {
            this.aiModelSelect.value = CONFIG.DEFAULT_MODEL || 'gemini';
        }
        this.difficultySelect.selectedIndex = 0;
        this.numQuestionsInput.value = 10;
        this.focusAreaInput.value = '';
        this.showAnswersDefaultCheckbox.checked = false;
        
        // Reset NotebookLM selection if available
        if (this.notebookSelect) {
            this.notebookSelect.selectedIndex = 0;
            if (this.selectedNotebookInfo) {
                this.selectedNotebookInfo.classList.add('hidden');
            }
        }
        
        Object.values(this.questionTypeCheckboxes).forEach(cb => cb.checked = (cb.id === 'type-mcq'));
        
        this.inputTypeSelect.value = 'upload';
        this.updateInputVisibility();
        this.qaContainer.innerHTML = '<p class="empty-state">Generated questions will appear here. Configure your settings and click "Generate Questions" to begin.</p>';
        
        // Reset question generator state if it exists
        if (this.questionGenerator) {
            this.questionGenerator.generatedQuestions = [];
            this.questionGenerator.lastSettings = null;
            // Update preferred model in question generator
            if (this.aiModelSelect) {
                this.questionGenerator.preferredModel = this.aiModelSelect.value;
                localStorage.setItem('ophthalmoqa_preferred_model', this.aiModelSelect.value);
            }
        }
        
        // Reset UI state
        this.lastSettings = null;
        
        this.updateButtonStates(false);
        this.showStatus('Form cleared.', 'info');
    }

    handleQuestionClick(event) {
        // Handle toggle answer button clicks
        if (event.target.closest('.toggle-answer') || event.target.closest('.toggle-answer-btn')) {
            const questionItem = event.target.closest('.question-item');
            if (questionItem) {
                const answerContainer = questionItem.querySelector('.answer-container') || 
                                       questionItem.querySelector('.answer-section');
                
                if (answerContainer) {
                    const isHidden = answerContainer.classList.contains('hidden');
                    answerContainer.classList.toggle('hidden');
                    
                    // Update the button text
                    const toggleButton = questionItem.querySelector('.toggle-answer') || 
                                        questionItem.querySelector('.toggle-answer-btn');
                    
                    if (toggleButton) {
                        const icon = toggleButton.querySelector('i');
                        if (icon) {
                            icon.className = isHidden ? 'fas fa-eye-slash mr-1' : 'fas fa-eye mr-1';
                        }
                        
                        // Try to update text content
                        const buttonText = toggleButton.childNodes[toggleButton.childNodes.length - 1];
                        if (buttonText && buttonText.nodeType === Node.TEXT_NODE) {
                            buttonText.nodeValue = isHidden ? ' Hide Answer' : ' Show Answer';
                        } else if (toggleButton.textContent) {
                            toggleButton.textContent = isHidden ? 'Hide Answer' : 'Show Answer';
                            // Re-add the icon if it was removed
                            if (icon) {
                                toggleButton.prepend(icon);
                            }
                        }
                    }
                }
            }
        }
        
        // Handle feedback button clicks
        if (event.target.closest('.feedback-btn')) {
            const button = event.target.closest('.feedback-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            const rating = button.getAttribute('data-feedback');
            
            // Find the question text and answer text from the DOM
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                 questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Process the feedback
            if (window.feedback) {
                window.feedback.processFeedback(questionId, rating, questionText, answerText);
            } else if (typeof this.processFeedback === 'function') {
                this.processFeedback(questionId, rating, questionText, answerText);
            }
            
            // Visual feedback
            const container = button.closest('.feedback-container');
            if (container) {
                const thankYouElement = container.querySelector('.feedback-thank-you');
                if (thankYouElement) {
                    // Show thank you message
                    thankYouElement.classList.remove('hidden');
                    // Hide after 3 seconds
                    setTimeout(() => {
                        thankYouElement.classList.add('hidden');
                    }, 3000);
                }
                
                // Highlight the selected button
                const buttons = container.querySelectorAll('.feedback-btn');
                buttons.forEach(btn => {
                    btn.classList.remove('active');
                    if (btn === button) {
                        btn.classList.add('active');
                        if (rating === 'like' || rating === 'positive') {
                            btn.classList.add('text-green-500');
                            btn.classList.remove('text-gray-400');
                        } else {
                            btn.classList.add('text-red-500');
                            btn.classList.remove('text-gray-400');
                        }
                    } else {
                        btn.classList.remove('text-green-500', 'text-red-500');
                        btn.classList.add('text-gray-400');
                    }
                });
            }
        }
        
        // Handle deep search button clicks
        if (event.target.closest('.deep-search-btn')) {
            const button = event.target.closest('.deep-search-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            
            // Find the question text and answer text
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Get the result container
            const resultContainer = questionItem.querySelector('.deep-search-result');
            
            // If already searching or has results, toggle visibility
            if (resultContainer.classList.contains('searching') || 
                (resultContainer.textContent.trim() !== '' && resultContainer.classList.contains('hidden'))) {
                resultContainer.classList.toggle('hidden');
                return;
            }
            
            // If we have results but it's visible, hide it
            if (resultContainer.textContent.trim() !== '' && !resultContainer.classList.contains('hidden')) {
                resultContainer.classList.add('hidden');
                return;
            }
            
            // Otherwise, perform deep search
            this.performDeepSearch(questionId, questionText, answerText, resultContainer);
        }

        // Handle show image button clicks
        if (event.target.closest('.show-image-btn')) {
            const button = event.target.closest('.show-image-btn');
            const questionItem = button.closest('.question-item');
            const questionId = button.getAttribute('data-id') || questionItem.getAttribute('data-id');
            
            // Find the question text and answer text
            const questionText = questionItem.querySelector('.question-text').textContent;
            const answerElement = questionItem.querySelector('.answer-text') || 
                                questionItem.querySelector('.answer');
            const answerText = answerElement ? answerElement.textContent : '';
            
            // Get the image container
            const imageContainer = questionItem.querySelector('.ophthalmic-image-container');
            
            // If already visible, just toggle visibility
            if (!imageContainer.classList.contains('hidden')) {
                imageContainer.classList.add('hidden');
                // Update the button text
                button.innerHTML = '<i class="fas fa-image mr-1"></i> Show Image';
                return;
            }
            
            // Update the button text before showing the image
            button.innerHTML = '<i class="fas fa-eye-slash mr-1"></i> Hide Image';
            
            // Load and display the image
            this.loadOphthalmicImage(questionId, questionText, answerText, imageContainer);
        }

        // Handle photo thumbnail clicks
        if (event.target.closest('.photo-thumbnail')) {
            const thumbnail = event.target.closest('.photo-thumbnail');
            const questionItem = thumbnail.closest('.question-item');
            const photoPreview = questionItem.querySelector('.photo-preview');
            const photoGrid = questionItem.querySelector('.photo-grid');
            
            // Get image data from data attributes
            const imageUrl = thumbnail.getAttribute('data-url');
            const imageTitle = thumbnail.getAttribute('data-title');
            const imageSource = thumbnail.getAttribute('data-source');
            
            if (imageUrl) {
                // Set the preview image
                const previewImage = photoPreview.querySelector('.photo-preview-image');
                previewImage.src = imageUrl;
                previewImage.alt = imageTitle || 'Ophthalmic Image';
                
                // Set the title and source
                photoPreview.querySelector('.photo-preview-title').textContent = imageTitle || 'Ophthalmic Image';
                const sourceLink = photoPreview.querySelector('.photo-preview-source');
                sourceLink.href = imageSource || '#';
                sourceLink.textContent = imageSource ? 'View Source' : 'No Source Available';
                
                // Hide the grid and show the preview
                photoGrid.classList.add('hidden');
                photoPreview.classList.remove('hidden');
            }
        }

        // Handle close photo preview button clicks
        if (event.target.closest('.close-photo-preview')) {
            const button = event.target.closest('.close-photo-preview');
            const photoPreview = button.closest('.photo-preview');
            const questionItem = button.closest('.question-item');
            const photoGrid = questionItem.querySelector('.photo-grid');
            
            // Hide the preview and show the grid
            photoPreview.classList.add('hidden');
            photoGrid.classList.remove('hidden');
        }
    }

    async performDeepSearch(questionId, questionText, answerText, resultContainer) {
        // Make sure the deep search handler is available
        if (!window.deepSearchHandler) {
            console.error('Deep search handler not available');
            this.showStatus('Deep search feature not available', 'error');
            resultContainer.innerHTML = `
                <div class="bg-red-50 p-4 rounded-md text-red-800">
                    <p>Deep search feature is not available. Please reload the page and try again.</p>
                </div>
            `;
            return;
        }
        
        try {
            // Show loading state
            resultContainer.innerHTML = `
                <div class="flex justify-center items-center py-4">
                    <div class="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
                    <span class="ml-3 text-indigo-800">Analyzing with scholarly resources...</span>
                </div>
            `;
            resultContainer.classList.add('searching');
            resultContainer.classList.remove('hidden');
            
            // Get the current AI model
            const aiModel = this.questionGenerator?.preferredModel || 'gemini';
            console.log(`Performing deep search using ${aiModel} model`);
            
            // Perform the deep search
            const result = await window.deepSearchHandler.performDeepSearch(questionText, answerText);

            // Helper: enhance and sanitize result HTML for professional display
            const enhanceDeepResult = (html) => {
                try {
                    let t = String(html || '');
                    // Replace JSON-like markers for question/answer with bold labels and spacing
                    t = t.replace(/\{?\s*"?question"?\s*:?\s*/gi, '<br><strong>Question:</strong> ');
                    t = t.replace(/\s*"?answer"?\s*:?\s*/gi, '<br><strong>Answer:</strong> ');
                    // Remove excessive braces that may remain from JSON wrappers (conservative)
                    t = t.replace(/^[\s\{\}\[\]"]+|[\s\{\}\[\]"]+$/g, '');
                    // Normalize multiple breaks
                    t = t.replace(/(<br>\s*){3,}/g, '<br><br>');
                    return t;
                } catch (_) {
                    return String(html || '');
                }
            };
            
            if (result) {
                console.log('Deep search completed successfully');
                // Build enhanced scholarly layout
                const plain = (html) => html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
                const wordCount = plain(result).split(/\s+/).filter(Boolean).length;
                const readingTimeMin = Math.max(1, Math.ceil(wordCount / 200));

                const displayResult = enhanceDeepResult(result);

                resultContainer.innerHTML = `
                    <div class="bg-white rounded-lg border border-indigo-100 shadow-sm">
                        <div class="flex flex-wrap items-center justify-between px-4 py-3 border-b border-indigo-100 bg-indigo-50 rounded-t-lg">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-microscope text-indigo-600"></i>
                                <h3 class="text-base md:text-lg font-semibold text-indigo-800 m-0">Scholarly Analysis</h3>
                                <span class="ml-2 text-xs md:text-sm text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">${readingTimeMin} min read · ${wordCount} words</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <button class="copy-deep-search text-xs md:text-sm text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded border border-indigo-200 hover:bg-indigo-50" title="Copy">
                                    <i class="fas fa-copy mr-1"></i>Copy
                                </button>
                                <button class="print-deep-search text-xs md:text-sm text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded border border-indigo-200 hover:bg-indigo-50" title="Print">
                                    <i class="fas fa-print mr-1"></i>Print
                                </button>
                                <button class="open-window-deep-search text-xs md:text-sm text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded border border-indigo-200 hover:bg-indigo-50" title="Open in window">
                                    <i class="fas fa-external-link-alt mr-1"></i>Open
                                </button>
                                <button class="close-deep-search text-xs md:text-sm text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded border border-indigo-200 hover:bg-indigo-50" title="Close">
                                    <i class="fas fa-times mr-1"></i>Close
                                </button>
                            </div>
                        </div>
                        <div class="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                            <aside class="order-2 md:order-1 md:col-span-1">
                                <div class="bg-indigo-50 border border-indigo-100 rounded-md p-3 mb-3">
                                    <div class="text-sm font-medium text-indigo-800 mb-2 flex items-center"><i class="fas fa-list-alt mr-2"></i>Overview</div>
                                    <div class="text-xs text-indigo-900 leading-relaxed deep-analysis-summary"></div>
                                </div>
                                <div class="bg-white border border-gray-200 rounded-md p-3 mb-3">
                                    <div class="text-sm font-medium text-gray-800 mb-2 flex items-center"><i class="fas fa-stream mr-2"></i>Table of Contents</div>
                                    <nav class="text-xs space-y-1 deep-analysis-toc"></nav>
                                </div>
                                <div class="bg-white border border-gray-200 rounded-md p-3 mb-3">
                                    <div class="text-sm font-medium text-gray-800 mb-2 flex items-center"><i class="fas fa-check-circle mr-2"></i>Evidence Summary</div>
                                    <div class="text-xs text-gray-700 leading-relaxed deep-analysis-evidence"></div>
                                </div>
                                <div class="bg-white border border-gray-200 rounded-md p-3">
                                    <div class="text-sm font-medium text-gray-800 mb-2 flex items-center"><i class="fas fa-tags mr-2"></i>Key Terms</div>
                                    <div class="deep-analysis-tags flex flex-wrap gap-1"></div>
                                    <div class="mt-3 text-sm font-medium text-gray-800 mb-1 flex items-center"><i class="fas fa-link mr-2"></i>References detected</div>
                                    <ul class="deep-analysis-refs list-disc list-inside text-xs text-gray-700"></ul>
                                    <div class="mt-3 text-sm font-medium text-gray-800 mb-1 flex items-center"><i class="fas fa-book mr-2"></i>Curated ophthalmology references</div>
                                    <ul class="deep-analysis-curated-refs list-decimal list-inside text-xs text-gray-800"></ul>
                                    <button class="copy-curated-refs mt-2 text-xs text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded border border-indigo-200 hover:bg-indigo-50" title="Copy curated references">
                                        <i class="fas fa-copy mr-1"></i>Copy curated references
                                    </button>
                                </div>
                            </aside>
                            <section class="order-1 md:order-2 md:col-span-2">
                                <div class="deep-analysis-content prose prose-sm max-w-none">
                                    ${displayResult}
                                </div>
                            </section>
                        </div>
                    </div>
                `;
                
                // Add event listener to close button
                const closeButton = resultContainer.querySelector('.close-deep-search');
                if (closeButton) {
                    closeButton.addEventListener('click', () => {
                        resultContainer.classList.add('hidden');
                    });
                }
                
                // Add event listener to print button
                const printButton = resultContainer.querySelector('.print-deep-search');
                if (printButton) {
                    printButton.addEventListener('click', () => {
                        this.printDeepSearchAnalysis(questionText, displayResult);
                    });
                }

                // Add event listener to copy button
                const copyButton = resultContainer.querySelector('.copy-deep-search');
                if (copyButton) {
                    copyButton.addEventListener('click', async () => {
                        try {
                            const text = plain(displayResult);
                            await navigator.clipboard.writeText(text);
                            copyButton.innerHTML = '<i class="fas fa-check mr-1"></i>Copied';
                            setTimeout(() => { copyButton.innerHTML = '<i class="fas fa-copy mr-1"></i>Copy'; }, 1500);
                        } catch (_) {}
                    });
                }

                // Open in new window
                const openButton = resultContainer.querySelector('.open-window-deep-search');
                if (openButton) {
                    openButton.addEventListener('click', () => {
                        this.printDeepSearchAnalysis(questionText, displayResult);
                    });
                }
                
                // Add event listeners to any images in the deep search result
                const images = resultContainer.querySelectorAll('.ophthalmic-image');
                if (images.length > 0 && window.ophthalmoImageGenerator) {
                    images.forEach(img => {
                        if (!img.hasAttribute('onclick')) {
                            img.addEventListener('click', () => {
                                const keyword = img.getAttribute('data-keyword') || '';
                                window.ophthalmoImageGenerator.showImagePreview(img.src, questionText, keyword);
                            });
                        }
                    });
                }

                // Build TOC and enhance headings with anchors
                const tocEl = resultContainer.querySelector('.deep-analysis-toc');
                const contentEl = resultContainer.querySelector('.deep-analysis-content');
                if (tocEl && contentEl) {
                    const headings = contentEl.querySelectorAll('h2, h3, h4');
                    const slug = (s) => s.toLowerCase().replace(/[^a-z0-9\s-]/g, '').trim().replace(/\s+/g, '-').slice(0, 60);
                    const items = [];
                    headings.forEach((h, idx) => {
                        const text = h.textContent || `section-${idx+1}`;
                        if (!h.id) h.id = slug(text) || `section-${idx+1}`;
                        const level = h.tagName === 'H2' ? 'pl-0' : h.tagName === 'H3' ? 'pl-3' : 'pl-6';
                        items.push(`<a href="#${h.id}" class="block ${level} text-gray-700 hover:text-indigo-700">${text}</a>`);
                    });
                    tocEl.innerHTML = items.length ? items.join('') : '<span class="text-gray-500">No sections detected</span>';
                }

                // Generate a highlighted overview strictly from key explanation points
                const summaryEl = resultContainer.querySelector('.deep-analysis-summary');
                if (summaryEl) {
                    const contentRoot = resultContainer.querySelector('.deep-analysis-content');
                    const bullets = [];
                    const seen = new Set();
                    const addBullet = (txt) => {
                        if (!txt) return;
                        const clean = txt.replace(/\s+/g, ' ').trim();
                        if (!clean || seen.has(clean.toLowerCase())) return;
                        seen.add(clean.toLowerCase());
                        const words = clean.split(/\s+/);
                        const short = words.length > 20 ? words.slice(0, 20).join(' ') + '…' : clean;
                        bullets.push(`<li class="leading-snug"><span class="bg-indigo-50 text-indigo-900 px-1.5 py-0.5 rounded">${short.replace(/\b(Diagnosis|Management|Treatment|Pathophysiology|Differential|Prognosis|Guidelines)\b:/i,'<strong class=\"text-indigo-900\">$1:</strong>')}</span></li>`);
                    };

                    if (contentRoot) {
                        // 1) Headings with their immediate paragraph summary
                        const heads = contentRoot.querySelectorAll('h2, h3, h4');
                        heads.forEach(h => {
                            if (bullets.length >= 5) return;
                            const title = (h.textContent || '').trim();
                            let sib = h.nextElementSibling;
                            while (sib && sib.tagName && sib.tagName.toLowerCase() === 'hr') sib = sib.nextElementSibling;
                            if (sib && sib.tagName && sib.tagName.toLowerCase() === 'p') {
                                const firstSentence = (sib.textContent || '').split(/(?<=[.!?])\s+/)[0] || sib.textContent || '';
                                if (firstSentence) addBullet(`${title}: ${firstSentence}`);
                            }
                        });

                        // 2) Paragraphs containing strong highlights or key callouts
                        if (bullets.length < 5) {
                            const ps = contentRoot.querySelectorAll('p');
                            ps.forEach(p => {
                                if (bullets.length >= 5) return;
                                const hasStrong = p.querySelector('strong, b');
                                const txt = (p.textContent || '').trim();
                                const isCallout = /^(Key\s*Point|Pearl|Remember|Pitfall|Note)\s*:/i.test(txt);
                                if (hasStrong || isCallout) {
                                    addBullet(txt);
                                }
                            });
                        }
                    }

                    // 3) Fallback to sentence extraction if not enough bullets
                    if (bullets.length < 3) {
                        const text = plain(displayResult);
                        const sentences = text
                            .split(/(?:(?:\.|\?|!)\s+|\n+)/)
                            .map(s => s.trim())
                            .filter(s => s.length > 0 && /[a-z]/i.test(s));
                        for (const s of sentences) {
                            if (bullets.length >= 3) break;
                            // Prefer sentences with medical keywords
                            if (/(diagnosis|management|treatment|pathophysiology|differential|guidelines|prognosis)/i.test(s)) {
                                addBullet(s);
                            }
                        }
                        // If still short, just add first sentences
                        for (const s of sentences) {
                            if (bullets.length >= 3) break;
                            addBullet(s);
                        }
                    }

                    const maxItems = Math.min(5, Math.max(3, bullets.length));
                    summaryEl.innerHTML = `<ul class="list-disc list-inside space-y-1">${bullets.slice(0, maxItems).join('')}</ul>`;

                    // Evidence summary: collect guideline/management headings
                    const evidenceEl = resultContainer.querySelector('.deep-analysis-evidence');
                    if (evidenceEl) {
                        const points = [];
                        const heads = contentRoot ? contentRoot.querySelectorAll('h2, h3') : [];
                        heads.forEach(h => {
                            const title = (h.textContent || '').trim();
                            if (/guideline|recommend|indication|contraindication|management|treatment|outcome|complication/i.test(title)) {
                                points.push(`• ${title}`);
                            }
                        });
                        evidenceEl.innerHTML = points.length ? points.map(this.sanitizeHTML).join('<br>') : '<span class="text-gray-500">No explicit evidence headings detected</span>';
                    }
                }

                // Extract key terms (expanded list and smart fallback)
                const tagsEl = resultContainer.querySelector('.deep-analysis-tags');
                if (tagsEl) {
                    const text = plain(displayResult).toLowerCase();
                    const candidates = [
                        // Retina & Macula
                        'retina','macula','cnv','amd','drusen','rhegmatogenous','retinal detachment','pvd','crvo','crao','brvo',
                        // Glaucoma
                        'glaucoma','iop','hvf','rnfl','optic nerve','cupping','oct',
                        // Cornea & Anterior
                        'cornea','keratitis','ulcer','hypopyon','pterygium','keratoconus','pkp',
                        // Cataract & Lens
                        'cataract','psc','iols','phacoemulsification',
                        // Uveitis & Inflammation
                        'uveitis','keratic precipitates','cells and flare','hla-b27',
                        // Neuro-ophthalmology
                        'papilledema','optic neuritis','visual field','afferent pupillary defect',
                        // Pediatric & Strabismus
                        'strabismus','esotropia','exotropia','amblyopia','nystagmus','pediatric ophthalmology',
                        // Oculoplastics
                        'chalazion','ptosis','entropion','ectropion'
                    ];
                    const found = candidates.filter(t => text.includes(t)).slice(0, 16);
                    if (found.length) {
                        tagsEl.innerHTML = found.map(t => `<span class="text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">${t}</span>`).join(' ');
                    } else {
                        // Fallback: naive extraction of frequent capitalized terms
                        const wordCounts = {};
                        (plain(displayResult).match(/\b[A-Z][a-z]{3,}\b/g) || []).forEach(w => {
                            const lw = w.toLowerCase();
                            wordCounts[lw] = (wordCounts[lw] || 0) + 1;
                        });
                        const top = Object.entries(wordCounts).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([w])=>w);
                        tagsEl.innerHTML = top.length ? top.map(t => `<span class="text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">${t}</span>`).join(' ') : '<span class="text-gray-500 text-xs">No key terms detected</span>';
                    }
                }

                // Detect references (DOI/PMID) and link out
                const refsEl = resultContainer.querySelector('.deep-analysis-refs');
                if (refsEl) {
                    const txt = plain(displayResult);
                    const dois = Array.from(new Set((txt.match(/10\.\d{4,9}\/[\-._;()\/:A-Z0-9]+/gi) || []).slice(0, 5)));
                    const pmids = Array.from(new Set((txt.match(/PMID\s*:?\s*(\d{7,8})/gi) || []).map(m => (m.match(/\d{7,8}/) || [null])[0]).filter(Boolean))).slice(0, 5);
                    const items = [];
                    for (const d of dois) items.push(`<li><a href="https://doi.org/${d}" target="_blank" class="text-indigo-700 hover:underline">DOI: ${d}</a></li>`);
                    for (const p of pmids) items.push(`<li><a href="https://pubmed.ncbi.nlm.nih.gov/${p}/" target="_blank" class="text-indigo-700 hover:underline">PMID: ${p}</a></li>`);
                    refsEl.innerHTML = items.length ? items.join('') : '<li class="text-gray-500">None detected</li>';
                }

                // Curated ophthalmology references (best-effort via CrossRef helper if available)
                (async () => {
                    try {
                        const curatedEl = resultContainer.querySelector('.deep-analysis-curated-refs');
                        if (!curatedEl) return;
                        const q = (questionText + ' ' + (answerText || '')).slice(0, 300);
                        let papers = [];
                        if (typeof this.searchCrossRef === 'function') {
                            try {
                                papers = await this.searchCrossRef(q, 'keywords', { yearFrom: new Date().getFullYear() - 10, yearTo: new Date().getFullYear(), limit: 12, sortBy: 'relevance' });
                            } catch (_) { papers = []; }
                        }
                        const highImpact = ['ophthalmology','jama ophthalmology','british journal of ophthalmology','american journal of ophthalmology','retina','cornea','investigative ophthalmology & visual science','iovs','eye','acta ophthalmologica','graefe\'s archive','ophthalmic surgery','lancet'];
                        const norm = s => (s || '').toLowerCase();
                        const sel = [], other = [];
                        (papers || []).forEach(p => (highImpact.some(j => norm(p.journal).includes(j)) ? sel : other).push(p));
                        const top = sel.slice(0,6).concat(other.slice(0,4)).slice(0,8);
                        const citations = top.map(p => (this.formatCitation ? this.formatCitation(p) : `${p.authors || ''}. ${p.title}. ${p.journal} ${p.year}. ${p.doi ? 'doi:' + p.doi : ''}`));
                        curatedEl.innerHTML = citations.length ? citations.map(c => `<li>${this.sanitizeHTML(c)}</li>`).join('') : '<li class="text-gray-500">No curated references available</li>';
                        const copyBtn = resultContainer.querySelector('.copy-curated-refs');
                        if (copyBtn && citations.length) {
                            copyBtn.addEventListener('click', async () => {
                                try {
                                    await navigator.clipboard.writeText(citations.join('\n'));
                                    copyBtn.innerHTML = '<i class="fas fa-check mr-1"></i>Copied';
                                    setTimeout(() => { copyBtn.innerHTML = '<i class="fas fa-copy mr-1"></i>Copy curated references'; }, 1500);
                                } catch (_) {}
                            });
                        } else if (copyBtn) {
                            copyBtn.disabled = true;
                        }
                    } catch (e) {
                        console.warn('Curated refs failed:', e.message);
                    }
                })();
            } else {
                console.warn('Deep search returned empty result');
                resultContainer.innerHTML = `
                    <div class="bg-red-50 p-4 rounded-md text-red-800">
                        <p>Sorry, we couldn't generate a detailed analysis for this question. Please try again later.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error during deep search:', error);
            resultContainer.innerHTML = `
                <div class="bg-red-50 p-4 rounded-md text-red-800">
                    <p>Error performing deep search: ${error.message}</p>
                    <p class="text-xs mt-2">Try selecting a different AI model in the settings and try again.</p>
                </div>
            `;
            this.showStatus(`Deep search error: ${error.message}. Try a different AI model.`, 'error');
        } finally {
            resultContainer.classList.remove('searching');
        }
    }
    
    /**
     * Print the deep search analysis in a new window
     */
    printDeepSearchAnalysis(questionText, analysisHtml) {
        // Create a new window for printing
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        // Create the content for the print window
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>OphthalmoQA - Deep Analysis</title>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 20px;
                        padding-bottom: 20px;
                        border-bottom: 1px solid #eee;
                    }
                    .logo {
                        font-size: 24px;
                        font-weight: bold;
                        color: #2c6fa5;
                    }
                    .subtitle {
                        font-size: 14px;
                        color: #666;
                    }
                    .question-box {
                        background-color: #f8f9fa;
                        padding: 15px;
                        border-radius: 8px;
                        margin-bottom: 20px;
                        border-left: 4px solid #2c6fa5;
                    }
                    .analysis-title {
                        font-size: 18px;
                        color: #2c6fa5;
                        margin-bottom: 15px;
                    }
                    h3 {
                        color: #2c6fa5;
                        margin-top: 25px;
                        margin-bottom: 10px;
                    }
                    h4 {
                        color: #4a5568;
                        margin-top: 15px;
                        margin-bottom: 8px;
                    }
                    ul, ol {
                        margin-bottom: 15px;
                    }
                    li {
                        margin-bottom: 5px;
                    }
                    .footer {
                        margin-top: 30px;
                        text-align: center;
                        font-size: 12px;
                        color: #666;
                        padding-top: 20px;
                        border-top: 1px solid #eee;
                    }
                    img {
                        max-width: 100%;
                        height: auto;
                        display: block;
                        margin: 15px auto;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                        padding: 5px;
                    }
                    @media print {
                        body {
                            font-size: 12pt;
                        }
                        .no-print {
                            display: none;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="logo">OphthalmoQA</div>
                    <div class="subtitle">Advanced Ophthalmology Question Analysis</div>
                </div>
                
                <div class="question-box">
                    <strong>Question:</strong>
                    <p>${questionText}</p>
                </div>
                
                <div class="analysis-title">Scholarly Deep Analysis</div>
                
                <div class="analysis-content">
                    ${analysisHtml}
                </div>
                
                <div class="footer">
                    Generated by OphthalmoQA - FRCS Exam Preparation Tool<br>
                    ${new Date().toLocaleDateString()}
                </div>
                
                <div class="no-print" style="text-align: center; margin-top: 30px;">
                    <button onclick="window.print()" style="padding: 8px 16px; background-color: #2c6fa5; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-print" style="margin-right: 5px;"></i> Print Analysis
                    </button>
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
    }

    formatDeepSearchResult(result) {
        // Ensure result is a string
        if (result === null || result === undefined) {
            return 'No results available';
        }
        
        // Convert to string if it's not already
        const resultStr = typeof result === 'string' ? result : String(result);
        
        // If the result already contains HTML, sanitize it and return
        if (resultStr.includes('<') && resultStr.includes('>')) {
            return this.sanitizeHTML(resultStr);
        }
        
        // Process markdown-style formatting
        let formattedResult = resultStr
            // Headers
            .replace(/^# (.*$)/gm, '<h2 class="text-xl font-bold text-indigo-900 mt-4 mb-2">$1</h2>')
            .replace(/^## (.*$)/gm, '<h3 class="text-lg font-semibold text-indigo-800 mt-3 mb-2">$1</h3>')
            .replace(/^### (.*$)/gm, '<h4 class="text-base font-medium text-indigo-700 mt-2 mb-1">$1</h4>')
            // Bold
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            // Italic
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            // Lists
            .replace(/^\d+\. (.*$)/gm, '<li class="ml-5 list-decimal">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-5 list-disc">$1</li>')
            // Paragraphs
            .replace(/\n\n/g, '</p><p class="my-2">')
            // Line breaks
            .replace(/\n/g, '<br>');
        
        // Wrap in paragraph tags if not already
        if (!formattedResult.startsWith('<')) {
            formattedResult = `<p class="my-2">${formattedResult}</p>`;
        }
        
        return formattedResult;
    }
    
    processFeedback(questionId, rating, questionText, answerText) {
        // Log feedback to console
        console.log(`Feedback received for question #${questionId}: ${rating}`);
        
        // If feedback handler exists, use it
        if (window.feedbackHandler && typeof window.feedbackHandler.recordFeedback === 'function') {
            window.feedbackHandler.recordFeedback(questionId, rating, questionText, answerText);
        }
        
        // Store feedback in localStorage as a fallback
        try {
            const feedbackKey = `feedback_${questionId}`;
            localStorage.setItem(feedbackKey, JSON.stringify({
                rating,
                timestamp: new Date().toISOString()
            }));
        } catch (error) {
            console.error('Error storing feedback:', error);
        }
    }

    showNotebookLmModal() {
        // Create modal if it doesn't exist
        if (!this.notebookLmModal) {
            this.notebookLmModal = document.createElement('div');
            this.notebookLmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
            document.body.appendChild(this.notebookLmModal);
            
            // Modal content
            const modalContent = document.createElement('div');
            modalContent.className = 'bg-white rounded-lg shadow-xl p-6 w-full max-w-md';
            this.notebookLmModal.appendChild(modalContent);
            
            // Header
            const header = document.createElement('h3');
            header.className = 'text-lg font-semibold mb-4';
            header.textContent = 'Connect to NotebookLM';
            modalContent.appendChild(header);
            
            // Status message
            this.notebookLmAuthStatus = document.createElement('div');
            this.notebookLmAuthStatus.className = 'mb-4 hidden';
            modalContent.appendChild(this.notebookLmAuthStatus);
            
            // Instructions
            const instructions = document.createElement('p');
            instructions.className = 'mb-4 text-gray-600';
            instructions.innerHTML = 'To connect to NotebookLM, you can either:<br>1. Paste HTML code from NotebookLM<br>2. Use quick login with email<br>3. Import from a notebook URL<br>4. Try demo mode';
            modalContent.appendChild(instructions);
            
            // Option 1: HTML Code input
            const codeLabel = document.createElement('label');
            codeLabel.className = 'block font-medium mb-1';
            codeLabel.textContent = '1. Paste HTML Code:';
            modalContent.appendChild(codeLabel);
            
            this.notebookLmCode = document.createElement('textarea');
            this.notebookLmCode.className = 'w-full border border-gray-300 rounded-md p-2 mb-4';
            this.notebookLmCode.rows = 4;
            this.notebookLmCode.placeholder = 'Paste the HTML code from NotebookLM here...';
            modalContent.appendChild(this.notebookLmCode);
            
            const authenticateBtn = document.createElement('button');
            authenticateBtn.className = 'bg-primary text-white px-4 py-2 rounded-md mb-4 hover:bg-primary-dark transition';
            authenticateBtn.textContent = 'Connect with HTML';
            authenticateBtn.addEventListener('click', () => this.handleNotebookLmAuthentication());
            modalContent.appendChild(authenticateBtn);
            
            const orDivider1 = document.createElement('div');
            orDivider1.className = 'flex items-center my-4';
            orDivider1.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider1);
            
            // Option 2: Email input
            const emailLabel = document.createElement('label');
            emailLabel.className = 'block font-medium mb-1';
            emailLabel.textContent = '2. Quick Login with Email:';
            modalContent.appendChild(emailLabel);
            
            this.notebookLmEmail = document.createElement('input');
            this.notebookLmEmail.type = 'email';
            this.notebookLmEmail.className = 'w-full border border-gray-300 rounded-md p-2 mb-2';
            this.notebookLmEmail.placeholder = 'Enter your email';
            this.notebookLmEmail.value = 'genododi@gmail.com';  // Default email
            modalContent.appendChild(this.notebookLmEmail);
            
            const emailAuthBtn = document.createElement('button');
            emailAuthBtn.className = 'bg-blue-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-blue-600 transition';
            emailAuthBtn.textContent = 'Connect with Email';
            emailAuthBtn.addEventListener('click', () => {
                const email = this.notebookLmEmail.value.trim();
                if (email && window.notebookLmHandler) {
                    const success = window.notebookLmHandler.authenticateWithEmail(email);
                    if (success) {
                        this.showNotebookAuthStatus(`Successfully connected as ${email}!`, 'success');
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                        }, 1500);
                    } else {
                        this.showNotebookAuthStatus('Failed to authenticate with the provided email.', 'error');
                    }
                } else {
                    this.showNotebookAuthStatus('Please enter a valid email.', 'error');
                }
            });
            modalContent.appendChild(emailAuthBtn);
            
            const orDivider2 = document.createElement('div');
            orDivider2.className = 'flex items-center my-4';
            orDivider2.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider2);
            
            // Option 3: Import from URL
            const urlLabel = document.createElement('label');
            urlLabel.className = 'block font-medium mb-1';
            urlLabel.textContent = '3. Import from Notebook URL:';
            modalContent.appendChild(urlLabel);
            
            this.notebookLmUrl = document.createElement('input');
            this.notebookLmUrl.type = 'text';
            this.notebookLmUrl.className = 'w-full border border-gray-300 rounded-md p-2 mb-2';
            this.notebookLmUrl.placeholder = 'https://notebooklm.google.com/notebook/your-notebook-id';
            this.notebookLmUrl.value = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
            modalContent.appendChild(this.notebookLmUrl);
            
            const urlImportBtn = document.createElement('button');
            urlImportBtn.className = 'bg-purple-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-purple-600 transition';
            urlImportBtn.textContent = 'Import from URL';
            urlImportBtn.addEventListener('click', async () => {
                const url = this.notebookLmUrl.value.trim();
                if (!url) {
                    this.showNotebookAuthStatus('Please enter a valid NotebookLM URL.', 'error');
                    return;
                }
                
                if (!window.notebookLmHandler) {
                    this.showNotebookAuthStatus('NotebookLM handler not available.', 'error');
                    return;
                }
                
                this.showNotebookAuthStatus('Importing notebook...', 'info');
                
                try {
                    const success = await window.notebookLmHandler.importNotebookByUrl(url);
                    
                    if (success) {
                        this.showNotebookAuthStatus('Successfully imported notebook!', 'success');
                        
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                            // Force refresh notebooks immediately
                            this.loadNotebookOptions();
                        }, 1000);
                    } else {
                        this.showNotebookAuthStatus('Failed to import notebook. Please check the URL.', 'error');
                    }
                } catch (error) {
                    console.error('Error importing notebook:', error);
                    this.showNotebookAuthStatus('Error importing notebook: ' + error.message, 'error');
                }
            });
            modalContent.appendChild(urlImportBtn);
            
            const orDivider3 = document.createElement('div');
            orDivider3.className = 'flex items-center my-4';
            orDivider3.innerHTML = '<div class="flex-grow border-t border-gray-300"></div><div class="px-3 text-gray-500">OR</div><div class="flex-grow border-t border-gray-300"></div>';
            modalContent.appendChild(orDivider3);
            
            // Option 4: Demo Mode
            const demoLabel = document.createElement('label');
            demoLabel.className = 'block font-medium mb-1';
            demoLabel.textContent = '4. Demo Mode:';
            modalContent.appendChild(demoLabel);
            
            const demoBtn = document.createElement('button');
            demoBtn.className = 'bg-green-500 text-white px-4 py-2 rounded-md mb-4 hover:bg-green-600 transition';
            demoBtn.textContent = 'Use Demo Mode';
            demoBtn.addEventListener('click', () => {
                if (window.notebookLmHandler) {
                    const success = window.notebookLmHandler.initializeDemo();
                    if (success) {
                        this.showNotebookAuthStatus('Successfully connected in demo mode!', 'success');
                        setTimeout(() => {
                            this.hideNotebookLmModal();
                            this.updateNotebookLmStatus();
                            // Force refresh notebooks immediately
                            this.loadNotebookOptions();
                        }, 1000);
                    } else {
                        this.showNotebookAuthStatus('Failed to initialize demo mode.', 'error');
                    }
                } else {
                    this.showNotebookAuthStatus('NotebookLM handler not available.', 'error');
                }
            });
            modalContent.appendChild(demoBtn);
            
            const closeBtn = document.createElement('button');
            closeBtn.className = 'absolute top-4 right-4 text-gray-500 hover:text-gray-700';
            closeBtn.innerHTML = '<i class="fas fa-times"></i>';
            closeBtn.addEventListener('click', () => this.hideNotebookLmModal());
            modalContent.appendChild(closeBtn);
        }
        
        // Show the modal
        this.notebookLmModal.classList.remove('hidden');
    }

    hideNotebookLmModal() {
        if (this.notebookLmModal) {
            this.notebookLmModal.classList.add('hidden');
        }
    }

    updateNotebookLmStatus() {
        // Check if NotebookLM handler is initialized
        if (window.notebookLmHandler && window.notebookLmHandler.isInitialized()) {
            // Get user email if available
            const email = window.notebookLmHandler.credentials?.oPEP7c || '';
            
            if (!this.notebookLogoutBtn) {
                // Create logout button if it doesn't exist
                this.notebookLogoutBtn = document.createElement('button');
                this.notebookLogoutBtn.className = 'text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 ml-2 px-2 py-1 rounded-md transition';
                this.notebookLogoutBtn.innerHTML = '<i class="fas fa-sign-out-alt mr-1"></i>Logout';
                
                // Add event listener for logout
                this.notebookLogoutBtn.addEventListener('click', () => {
                    if (window.notebookLmHandler) {
                        window.notebookLmHandler.logout();
                        this.updateNotebookLmStatus();
                        this.showStatus('Disconnected from NotebookLM', 'info');
                    }
                });
                
                // Add logout button to status container
                const statusContainer = this.notebookStatus.querySelector('p');
                if (statusContainer) {
                    statusContainer.appendChild(document.createTextNode(' '));
                    statusContainer.appendChild(this.notebookLogoutBtn);
                }
            } else {
                // Ensure the logout button is visible
                this.notebookLogoutBtn.classList.remove('hidden');
            }

            // Update status message with email if available
            const statusText = email ? 
                `Connected as ${email}. Select a notebook to continue.` : 
                'Connected to NotebookLM. Select a notebook to continue.';
            
            this.notebookStatusMessage.textContent = statusText;
            this.notebookStatus.classList.remove('hidden');
            this.notebookSelection.classList.remove('hidden');
            
            // Make notebook section more noticeable with a distinct border
            this.notebookSelection.style.border = '1px solid #e5e7eb';
            this.notebookSelection.style.borderRadius = '8px';
            this.notebookSelection.style.padding = '12px';
            this.notebookSelection.style.marginTop = '12px';
            this.notebookSelection.style.backgroundColor = '#f9fafb';
            
            // Add a manual connect button for easy reconnection
            if (!this.manualConnectBtn) {
                this.manualConnectBtn = document.createElement('button');
                this.manualConnectBtn.className = 'text-sm bg-blue-100 hover:bg-blue-200 text-primary ml-2 px-2 py-1 rounded-md transition';
                this.manualConnectBtn.innerHTML = '<i class="fas fa-link mr-1"></i>Connect Again';
                
                // Add event listener
                this.manualConnectBtn.addEventListener('click', () => {
                    // Try to reconnect with the default email
                    if (window.notebookLmHandler) {
                        const defaultEmail = 'genododi@gmail.com';
                        const success = window.notebookLmHandler.authenticateWithEmail(defaultEmail);
                        
                        if (success) {
                            this.updateNotebookLmStatus();
                            this.showStatus(`Reconnected as ${defaultEmail}`, 'success');
                            // Force refresh notebooks
                            setTimeout(() => {
                                this.loadNotebookOptions();
                            }, 100);
                        } else {
                            this.showStatus('Failed to reconnect', 'error');
                        }
                    }
                });
                
                // Add to status container
                const statusContainer = this.notebookStatus.querySelector('p');
                if (statusContainer) {
                    statusContainer.appendChild(document.createTextNode(' '));
                    statusContainer.appendChild(this.manualConnectBtn);
                }
            } else {
                // Ensure the manual connect button is visible
                this.manualConnectBtn.classList.remove('hidden');
            }
            
            // Add Import Specific Notebook button
            if (!this.importSpecificNotebookBtn) {
                // Create a container for the notebook actions
                if (!this.notebookActionsContainer) {
                    this.notebookActionsContainer = document.createElement('div');
                    this.notebookActionsContainer.className = 'mt-3 flex flex-wrap gap-2';
                    this.notebookSelection.appendChild(this.notebookActionsContainer);
                }
                
                this.importSpecificNotebookBtn = document.createElement('button');
                this.importSpecificNotebookBtn.className = 'text-sm bg-green-100 hover:bg-green-200 text-green-800 px-3 py-2 rounded-md transition flex items-center';
                this.importSpecificNotebookBtn.innerHTML = '<i class="fas fa-file-import mr-2"></i>Import My FRCS Notebook';
                
                // Add event listener
                this.importSpecificNotebookBtn.addEventListener('click', async () => {
                    try {
                        this.showStatus('Importing your specific FRCS notebook...', 'info');
                        
                        if (window.notebookLmHandler) {
                            const success = await window.notebookLmHandler.loadUserSpecificNotebook();
                            
                            if (success) {
                                this.showStatus('Successfully imported your FRCS notebook!', 'success');
                                // Force refresh notebooks
                                this.loadNotebookOptions();
                            } else {
                                this.showStatus('Failed to import your notebook. Please try again.', 'error');
                            }
                        }
                    } catch (error) {
                        console.error('Error importing specific notebook:', error);
                        this.showStatus('Error importing your notebook: ' + error.message, 'error');
                    }
                });
                
                // Add to the actions container
                this.notebookActionsContainer.appendChild(this.importSpecificNotebookBtn);
            } else {
                // Ensure the button is visible
                this.importSpecificNotebookBtn.classList.remove('hidden');
            }
            
            // Update notebooks dropdown immediately
            console.log('Triggering notebook options load from updateNotebookLmStatus');
            this.loadNotebookOptions();
        } else {
            // Hide logout button if it exists
            if (this.notebookLogoutBtn) {
                this.notebookLogoutBtn.classList.add('hidden');
            }
            
            // Hide manual connect button if it exists
            if (this.manualConnectBtn) {
                this.manualConnectBtn.classList.add('hidden');
            }
            
            // Hide specific notebook import button if it exists
            if (this.importSpecificNotebookBtn) {
                this.importSpecificNotebookBtn.classList.add('hidden');
            }
            
            this.notebookStatusMessage.textContent = 'Please connect to NotebookLM to access your saved notes.';
            this.notebookStatus.classList.remove('hidden');
            this.notebookSelection.classList.add('hidden');
        }
    }

    async loadNotebookOptions() {
        if (!window.notebookLmHandler || !window.notebookLmHandler.isInitialized()) {
            this.showStatus('NotebookLM not initialized. Please connect first.', 'warning');
            return;
        }

        try {
            this.showStatus('Loading notebooks...', 'info');
            
            // Clear existing options except the first one
            while (this.notebookSelect.options.length > 1) {
                this.notebookSelect.remove(1);
            }
            
            // Add refresh button if not already added
            if (!this.notebookRefreshBtn) {
                const notebookSelectParent = this.notebookSelect.parentElement;
                
                // Create container for select and button
                const selectContainer = document.createElement('div');
                selectContainer.className = 'flex items-center gap-2';
                
                // Move select into container
                this.notebookSelect.parentNode.insertBefore(selectContainer, this.notebookSelect);
                selectContainer.appendChild(this.notebookSelect);
                this.notebookSelect.className += ' flex-grow';
                
                // Create refresh button
                this.notebookRefreshBtn = document.createElement('button');
                this.notebookRefreshBtn.className = 'bg-blue-100 hover:bg-blue-200 text-primary p-2 rounded-md transition';
                this.notebookRefreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                this.notebookRefreshBtn.title = 'Refresh notebooks list';
                
                // Add click event
                this.notebookRefreshBtn.addEventListener('click', () => {
                    this.loadNotebookOptions();
                });
                
                // Add to container
                selectContainer.appendChild(this.notebookRefreshBtn);
            }

            // Fetch notebooks and add them to dropdown
            try {
                const notebooks = await window.notebookLmHandler.fetchUserNotebooks();
                console.log('Fetched notebooks:', notebooks);
                
                if (notebooks && Array.isArray(notebooks) && notebooks.length > 0) {
                    // First check if we have the user's specific notebook
                    const userSpecificNotebookId = '07d17136-d624-417d-8b82-6977f9674f71';
                    const hasUserNotebook = notebooks.some(nb => nb.id === userSpecificNotebookId);
                    
                    // If the specific notebook isn't there, try to add it
                    if (!hasUserNotebook) {
                        console.log('User\'s specific notebook not found, attempting to import it...');
                        try {
                            const specificUrl = `https://notebooklm.google.com/notebook/${userSpecificNotebookId}`;
                            await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                            // Refresh notebooks list after import
                            const updatedNotebooks = await window.notebookLmHandler.fetchUserNotebooks();
                            if (updatedNotebooks && Array.isArray(updatedNotebooks)) {
                                notebooks.splice(0, notebooks.length, ...updatedNotebooks);
                            }
                        } catch (importErr) {
                            console.error('Failed to auto-import user\'s notebook:', importErr);
                        }
                    }
                    
                    // Add each notebook to the dropdown
                    notebooks.forEach(notebook => {
                        const option = document.createElement('option');
                        option.value = notebook.id;
                        option.textContent = notebook.title || `Notebook ${notebook.id}`;
                        // Highlight the user's specific notebook
                        if (notebook.id === userSpecificNotebookId) {
                            option.className = 'font-bold text-green-800';
                            option.style.backgroundColor = '#f0fff4';
                            option.textContent += ' (My FRCS Notes)';
                        }
                        this.notebookSelect.add(option);
                    });
                    
                    this.showStatus(`Successfully loaded ${notebooks.length} notebooks.`, 'success');
                    
                    // Select the user's specific notebook if available, otherwise select the first notebook
                    const userNotebookIndex = Array.from(this.notebookSelect.options).findIndex(
                        opt => opt.value === userSpecificNotebookId
                    );
                    
                    if (userNotebookIndex > 0) {
                        this.notebookSelect.selectedIndex = userNotebookIndex;
                    } else if (this.notebookSelect.options.length > 1) {
                        this.notebookSelect.selectedIndex = 1;
                    }
                    
                    this.handleNotebookSelection();
                } else {
                    // Add a placeholder if no notebooks found
                    const option = document.createElement('option');
                    option.value = "";
                    option.textContent = "No notebooks found";
                    option.disabled = true;
                    this.notebookSelect.add(option);
                    
                    this.showStatus('No notebooks found in your account.', 'warning');
                }
            } catch (fetchError) {
                console.error('Error fetching notebooks:', fetchError);
                
                // Try to import the user's specific notebook directly as a fallback
                try {
                    this.showStatus('Trying to import your FRCS notebook directly...', 'info');
                    const specificUrl = 'https://notebooklm.google.com/notebook/07d17136-d624-417d-8b82-6977f9674f71';
                    const imported = await window.notebookLmHandler.importNotebookByUrl(specificUrl);
                    
                    if (imported) {
                        // If import succeeds, refresh the notebook list
                        const notebooks = await window.notebookLmHandler.fetchUserNotebooks();
                        
                        if (notebooks && Array.isArray(notebooks) && notebooks.length > 0) {
                            notebooks.forEach(notebook => {
                                const option = document.createElement('option');
                                option.value = notebook.id;
                                option.textContent = notebook.title || `Notebook ${notebook.id}`;
                                this.notebookSelect.add(option);
                            });
                            
                            this.showStatus('Successfully imported your FRCS notebook.', 'success');
                            
                            // Select the first notebook
                            if (this.notebookSelect.options.length > 1) {
                                this.notebookSelect.selectedIndex = 1;
                                this.handleNotebookSelection();
                            }
                        }
                    } else {
                        throw new Error('Failed to import notebook directly');
                    }
                } catch (importError) {
                    console.error('Error in direct notebook import:', importError);
                    this.showNotebookAuthStatus('Failed to load notebooks: ' + fetchError.message, 'error');
                    this.showStatus('Error loading notebooks. Please try reconnecting.', 'error');
                    
                    // Add error option
                    const option = document.createElement('option');
                    option.value = "";
                    option.textContent = "Error loading notebooks";
                    option.disabled = true;
                    this.notebookSelect.add(option);
                }
            }
        } catch (error) {
            console.error('Error loading notebooks:', error);
            this.showNotebookAuthStatus('Failed to load notebooks: ' + error.message, 'error');
            this.showStatus('Error loading notebooks. Please try reconnecting.', 'error');
            
            // Add error option
            const option = document.createElement('option');
            option.value = "";
            option.textContent = "Error loading notebooks";
            option.disabled = true;
            this.notebookSelect.add(option);
        }
    }

    /**
     * Handle authentication with NotebookLM
     */
    async handleNotebookLmAuthentication() {
        try {
            // Get the NotebookLM HTML code
            const htmlCode = document.getElementById('notebooklm-code').value.trim();
            
            // Check if the code is empty
            if (!htmlCode) {
                this.showNotebookAuthStatus('Please paste the NotebookLM HTML code first.', 'warning');
                this.addFallbackAuthOption(); // Show fallback option immediately
                return;
            }
            
            // Show loading state
            this.showNotebookAuthStatus('Processing authentication data...', 'info');
            const authenticateBtn = document.getElementById('authenticate-notebooklm');
            authenticateBtn.disabled = true;
            authenticateBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Authenticating...';
            
            // Process the HTML code
            const result = window.notebookLmHandler.processNotebookLmHtml(htmlCode);
            
            // Reset button state
            authenticateBtn.disabled = false;
            authenticateBtn.innerHTML = '<i class="fas fa-key mr-2"></i> Import Notes';
            
            if (!result.success) {
                // Authentication failed
                this.showNotebookAuthStatus(result.message || 'Authentication failed.', 'error');
                
                // Always show fallback option when authentication fails
                this.addFallbackAuthOption();
                
                // Also add direct import option for FRCS notebook
                setTimeout(() => {
                    this.addDirectImportOption();
                }, 500);
                
                return;
            }
            
            // Authentication succeeded
            const statusMessage = result.isFallback ?
                `Connected with limited access as ${result.userEmail || 'user'}. Some features may be restricted.` :
                `Successfully connected as ${result.userEmail || 'user'}.`;
            
            this.showNotebookAuthStatus(statusMessage, 'success');
            
            // Load notebooks
            await this.loadNotebookOptions();
            
            // Update UI to show notebook selection
            this.updateNotebookLmStatus();
            
        } catch (error) {
            console.error('Error during NotebookLM authentication:', error);
            this.showNotebookAuthStatus(`Authentication error: ${error.message}`, 'error');
            
            // Show fallback options
            this.addFallbackAuthOption();
            this.addDirectImportOption();
            
            // Reset authenticate button
            const authenticateBtn = document.getElementById('authenticate-notebooklm');
            if (authenticateBtn) {
                authenticateBtn.disabled = false;
                authenticateBtn.innerHTML = '<i class="fas fa-key mr-2"></i> Import Notes';
            }
        }
    }
    
    /**
     * Add fallback authentication option to the modal
     */
    addFallbackAuthOption() {
        const authStatus = document.getElementById('notebooklm-auth-status');
        
        // Check if the fallback option already exists
        if (document.getElementById('demo-notebook-btn')) {
            return;
        }
        
        // Create fallback option UI
        const fallbackDiv = document.createElement('div');
        fallbackDiv.className = 'mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg';
        fallbackDiv.innerHTML = `
            <h4 class="font-medium text-gray-800 mb-2">Having trouble?</h4>
            <p class="text-sm text-gray-600 mb-3">
                You can use our demo notebook with pre-loaded FRCS study material instead.
            </p>
            <button id="demo-notebook-btn" class="w-full bg-secondary hover:bg-primary text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center">
                <i class="fas fa-magic mr-2"></i>
                Use Demo Notebook Instead
            </button>
        `;
        
        // Insert fallback option after the auth status
        authStatus.parentNode.insertBefore(fallbackDiv, authStatus.nextSibling);
        authStatus.classList.remove('hidden');
        
        // Add event listener to the demo button
        document.getElementById('demo-notebook-btn').addEventListener('click', async () => {
            try {
                // Show loading state
                document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Loading Demo...';
                document.getElementById('demo-notebook-btn').disabled = true;
                
                // Initialize demo mode
                const success = window.notebookLmHandler.initializeDemo();
                
                if (success) {
                    this.showNotebookAuthStatus('Demo notebook access granted successfully.', 'success');
                    
                    // Load demo notebooks
                    await this.loadNotebookOptions();
                    
                    // Update UI
                    this.updateNotebookLmStatus();
                    
                    // Close modal after a short delay
                    setTimeout(() => {
                        this.hideNotebookLmModal();
                        this.showStatus('Connected to NotebookLM demo mode. You can now select notebooks.', 'success');
                    }, 1500);
                } else {
                    this.showNotebookAuthStatus('Failed to initialize demo mode. Please try again.', 'error');
                    document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-magic mr-2"></i> Use Demo Notebook Instead';
                    document.getElementById('demo-notebook-btn').disabled = false;
                }
            } catch (error) {
                console.error('Error initializing demo mode:', error);
                this.showNotebookAuthStatus(`Error initializing demo mode: ${error.message}`, 'error');
                document.getElementById('demo-notebook-btn').innerHTML = '<i class="fas fa-magic mr-2"></i> Use Demo Notebook Instead';
                document.getElementById('demo-notebook-btn').disabled = false;
            }
        });
    }
    
    /**
     * Add direct import option for the FRCS notebook
     */
    addDirectImportOption() {
        const authStatus = document.getElementById('notebooklm-auth-status');
        
        // Check if the direct import option already exists
        if (document.getElementById('direct-import-btn')) {
            return;
        }
        
        // Create direct import option UI
        const directImportDiv = document.createElement('div');
        directImportDiv.className = 'mt-3 p-4 bg-green-50 border border-green-200 rounded-lg';
        directImportDiv.innerHTML = `
            <h4 class="font-medium text-green-800 mb-2">Quick Access Option</h4>
            <p class="text-sm text-green-700 mb-3">
                Import our specialized FRCS notebook with comprehensive ophthalmology content directly.
            </p>
            <button id="direct-import-btn" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center">
                <i class="fas fa-file-medical mr-2"></i>
                Import FRCS Notebook Directly
            </button>
        `;
        
        // Find where to insert the direct import option
        const fallbackOption = document.getElementById('demo-notebook-btn')?.closest('div');
        if (fallbackOption) {
            fallbackOption.parentNode.insertBefore(directImportDiv, fallbackOption.nextSibling);
        } else {
            authStatus.parentNode.insertBefore(directImportDiv, authStatus.nextSibling);
        }
        
        // Add event listener to the direct import button
        document.getElementById('direct-import-btn').addEventListener('click', async () => {
            try {
                // Show loading state
                document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Importing...';
                document.getElementById('direct-import-btn').disabled = true;
                
                // Either use existing handler or initialize a new demo one
                if (!window.notebookLmHandler.isInitialized()) {
                    const success = window.notebookLmHandler.initializeDemo();
                    if (!success) {
                        throw new Error('Failed to initialize notebook handler');
                    }
                }
                
                // Import the specific FRCS notebook
                const success = await window.notebookLmHandler.loadUserSpecificNotebook();
                
                if (success) {
                    this.showNotebookAuthStatus('FRCS notebook imported successfully.', 'success');
                    
                    // Load notebook options
                    await this.loadNotebookOptions();
                    
                    // Update UI
                    this.updateNotebookLmStatus();
                    
                    // Close modal after a short delay
                    setTimeout(() => {
                        this.hideNotebookLmModal();
                        this.showStatus('FRCS notebook imported. You can now generate questions from it.', 'success');
                    }, 1500);
                } else {
                    this.showNotebookAuthStatus('Failed to import FRCS notebook. Please try again.', 'error');
                    document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-file-medical mr-2"></i> Import FRCS Notebook Directly';
                    document.getElementById('direct-import-btn').disabled = false;
                }
            } catch (error) {
                console.error('Error importing FRCS notebook:', error);
                this.showNotebookAuthStatus(`Error importing FRCS notebook: ${error.message}`, 'error');
                document.getElementById('direct-import-btn').innerHTML = '<i class="fas fa-file-medical mr-2"></i> Import FRCS Notebook Directly';
                document.getElementById('direct-import-btn').disabled = false;
            }
        });
    }

    showNotebookAuthStatus(message, type = 'info') {
        this.notebookLmAuthStatus.textContent = message;
        this.notebookLmAuthStatus.className = 'mb-4 p-3 rounded-md';
        
        // Add appropriate styling based on message type
        if (type === 'error') {
            this.notebookLmAuthStatus.classList.add('bg-red-100', 'text-red-700');
        } else if (type === 'success') {
            this.notebookLmAuthStatus.classList.add('bg-green-100', 'text-green-700');
        } else {
            this.notebookLmAuthStatus.classList.add('bg-blue-100', 'text-blue-700');
        }
        
        this.notebookLmAuthStatus.classList.remove('hidden');
    }

    handleNotebookSelection() {
        const selectedId = this.notebookSelect.value;
        if (!selectedId) {
            this.selectedNotebookInfo.classList.add('hidden');
            return;
        }

        // Display notebook info
        const selectedOption = this.notebookSelect.options[this.notebookSelect.selectedIndex];
        this.selectedNotebookTitle.textContent = selectedOption.textContent;
        this.selectedNotebookDescription.textContent = `Notebook ID: ${selectedId}`;
        this.selectedNotebookInfo.classList.remove('hidden');
    }

    showStatus(message, type = 'info') {
        this.statusMessage.textContent = message;
        const typeClasses = {
            info: 'bg-blue-100 text-blue-700',
            success: 'bg-green-100 text-green-700',
            warning: 'bg-yellow-100 text-yellow-700',
            error: 'bg-red-100 text-red-700'
        };
        
        this.statusMessage.className = `status-message p-3 rounded-md font-medium text-center my-4 ${typeClasses[type] || typeClasses.info}`;
        this.statusMessage.classList.remove('hidden');

        if (type !== 'error') {
            setTimeout(() => {
                if (this.statusMessage.textContent === message) {
                    this.statusMessage.classList.add('hidden');
                }
            }, 6000);
        }
    }

    setProcessingState(processing) {
        this.isProcessing = processing;
        this.loadingIndicator.classList.toggle('hidden', !processing);
        this.loadingIndicator.classList.toggle('flex', processing);
        
        // Disable/enable form elements
        const elements = [
            this.generateBtn, this.clearBtn, this.inputTypeSelect,
            this.inputTextElement, this.knowledgeAreaSelect, this.aiModelSelect,
            this.difficultySelect, this.numQuestionsInput,
            this.focusAreaInput, this.showAnswersDefaultCheckbox,
            this.exportFormatSelect, this.connectNotebookLmBtn, 
            this.notebookSelect
        ];
        
        elements.forEach(element => {
            if (element) element.disabled = processing;
        });
        
        Object.values(this.questionTypeCheckboxes).forEach(cb => cb.disabled = processing);
        
        if (processing) {
            if (this.exportBtn) this.exportBtn.disabled = true;
            if (this.regenerateBtn) this.regenerateBtn.disabled = true;
        } else {
            // Re-enable based on state only after processing finishes
            if (this.questionGenerator) {
                this.updateButtonStates(this.questionGenerator.generatedQuestions.length > 0);
            } else {
                this.updateButtonStates(false);
            }
        }
    }

    updateButtonStates(questionsExist) {
        if (this.exportBtn) this.exportBtn.disabled = !questionsExist || this.isProcessing;
        if (this.regenerateBtn) this.regenerateBtn.disabled = !(this.lastSettings || (this.questionGenerator && this.questionGenerator.lastSettings)) || this.isProcessing;
    }

    sanitizeHTML(str) {
        return str ? String(str).replace(/</g, "&lt;").replace(/>/g, "&gt;") : '';
    }
    
    setFileHandler(fileHandler) {
        this.fileHandler = fileHandler;
    }
    
    setQuestionGenerator(questionGenerator) {
        this.questionGenerator = questionGenerator;
    }

    async loadOphthalmicImage(questionId, questionText, answerText, imageContainer) {
        // Make sure the image generator is available
        if (!window.ophthalmoImageGenerator) {
            console.error('Ophthalmic image generator not available');
            this.showStatus('Image feature not available', 'error');
            imageContainer.innerHTML = `
                <div class="text-center py-4 text-red-600">
                    <i class="fas fa-exclamation-circle text-xl mb-2"></i>
                    <p>Image generation feature is not available.</p>
                </div>
            `;
            imageContainer.classList.remove('hidden');
            return;
        }
        
        try {
            // Show loading state
            imageContainer.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    <p class="mt-2 text-gray-600">Loading relevant ophthalmic image...</p>
                </div>
            `;
            imageContainer.classList.remove('hidden');
            
            // Generate image based on question content
            const imageInfo = await window.ophthalmoImageGenerator.generateImage(questionText, questionId);
            
            if (imageInfo && imageInfo.url) {
                // Determine a caption based on the identified keyword
                const captionText = imageInfo.keyword ? 
                    `Clinical image of ${imageInfo.keyword}` : 
                    'Relevant ophthalmic image';
                
                // Update the image container with the generated image
                const imgElement = imageContainer.querySelector('img.ophthalmic-image');
                const captionElement = imageContainer.querySelector('.image-caption');
                
                if (imgElement && captionElement) {
                    // Update existing elements
                    imgElement.src = imageInfo.url;
                    imgElement.alt = captionText;
                    imgElement.setAttribute('data-keyword', imageInfo.keyword || '');
                    captionElement.textContent = captionText;
                    
                    // Add click handler to open modal
                    imgElement.onclick = function() {
                        window.ophthalmoImageGenerator.showImagePreview(
                            imageInfo.url, 
                            questionText, 
                            imageInfo.keyword
                        );
                    };
                } else {
                    // Create new elements
                    imageContainer.innerHTML = `
                        <div class="text-center">
                            <img src="${imageInfo.url}" alt="${captionText}" 
                                class="ophthalmic-image max-w-full max-h-[300px] mx-auto object-contain rounded-lg border border-gray-200 shadow-sm cursor-pointer"
                                data-keyword="${imageInfo.keyword || ''}" 
                                onclick="window.ophthalmoImageGenerator.showImagePreview('${imageInfo.url}', '${this.sanitizeHTML(questionText)}', '${imageInfo.keyword || ''}')">
                            <p class="text-sm text-gray-600 mt-2 image-caption">${captionText}</p>
                            <div class="text-xs text-primary mt-2">Click image to view details</div>
                        </div>
                    `;
                }
            } else {
                // No image found
                imageContainer.innerHTML = `
                    <div class="text-center py-4 text-gray-500">
                        <i class="fas fa-image text-2xl mb-2 opacity-50"></i>
                        <p>No relevant images found for this question.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading ophthalmic image:', error);
            
            // Show error in the image container
            imageContainer.innerHTML = `
                <div class="text-center py-4 text-red-600">
                    <i class="fas fa-exclamation-circle text-xl mb-2"></i>
                    <p>Error loading image: ${error.message}</p>
                </div>
            `;
        }
    }

    initializeJournalSearch() {
        console.log('🔍 Initializing journal search functionality...');
        
        // Check if elements exist
        const searchBtn = document.getElementById('search-journals-btn');
        if (!searchBtn) {
            console.error('🔍 Search button not found during initialization!');
            return;
        }
        
        console.log('🔍 Search button found, initializing event listeners...');
        
        // Remove any existing event listeners and add new ones
        this.initializeJournalSearchEventListeners();
        
        console.log('🔍 Journal search initialization complete!');
    }

    initializeJournalSearchEventListeners() {
        // Search method radio buttons
        const searchKeywordsRadio = document.getElementById('search-keywords');
        const searchTitleRadio = document.getElementById('search-title');
        const keywordsSection = document.getElementById('keywords-search-section');
        const titleSection = document.getElementById('title-search-section');

        if (searchKeywordsRadio && searchTitleRadio) {
            searchKeywordsRadio.addEventListener('change', () => {
                if (searchKeywordsRadio.checked) {
                    keywordsSection.classList.remove('hidden');
                    titleSection.classList.add('hidden');
                }
            });

            searchTitleRadio.addEventListener('change', () => {
                if (searchTitleRadio.checked) {
                    keywordsSection.classList.add('hidden');
                    titleSection.classList.remove('hidden');
                }
            });
        }

        // Search button
        const searchBtn = document.getElementById('search-journals-btn');
        if (searchBtn) {
            console.log('🔍 Attaching event listener to search button');
            
            // Remove any existing listeners
            searchBtn.replaceWith(searchBtn.cloneNode(true));
            const newSearchBtn = document.getElementById('search-journals-btn');
            
            // Add event listener
            newSearchBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('🔍 Search button clicked, calling performJournalSearch');
                this.performJournalSearch();
            });
            
            // Also add a direct onclick handler as fallback
            newSearchBtn.onclick = (e) => {
                e.preventDefault();
                console.log('🔍 Fallback onclick called');
                this.performJournalSearch();
            };
            
            console.log('🔍 Event listeners attached successfully');
        } else {
            console.error('🔍 Search button not found!');
        }

        // Generate from selected papers button
        const generateFromSelectedBtn = document.getElementById('generate-from-selected');
        if (generateFromSelectedBtn) {
            generateFromSelectedBtn.addEventListener('click', () => this.generateQuestionsFromSelectedPapers());
        }
    }

    async performJournalSearch() {
        console.log('🔍 Journal search button clicked!');
        
        const searchBtn = document.getElementById('search-journals-btn');
        const resultsContainer = document.getElementById('journal-search-results');
        const resultsList = document.getElementById('search-results-list');
        const resultsCount = document.getElementById('results-count');

        try {
            console.log('🔍 Starting journal search...');
            
            // Show loading state
            searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Searching...';
            searchBtn.disabled = true;
            
            this.showStatus('Starting journal search...', 'info');

            // Get search parameters
            const searchMethodElement = document.querySelector('input[name="search-method"]:checked');
            if (!searchMethodElement) {
                throw new Error('Please select a search method');
            }
            
            const searchMethod = searchMethodElement.value;
            console.log('🔍 Search method:', searchMethod);
            
            const searchQuery = searchMethod === 'keywords' 
                ? document.getElementById('search-keywords-input').value.trim()
                : document.getElementById('search-title-input').value.trim();

            console.log('🔍 Search query:', searchQuery);

            if (!searchQuery) {
                throw new Error('Please enter search terms');
            }

            // Get selected sources
            const selectedSources = [];
            const sourceCheckboxes = [
                { id: 'source-pubmed', source: 'pubmed' },
                { id: 'source-europmc', source: 'europmc' },
                { id: 'source-crossref', source: 'crossref' },
                { id: 'source-doaj', source: 'doaj' },
                { id: 'source-arxiv', source: 'arxiv' },
                { id: 'source-semantic', source: 'semantic' }
            ];

            sourceCheckboxes.forEach(({ id, source }) => {
                const checkbox = document.getElementById(id);
                if (checkbox && checkbox.checked) {
                    selectedSources.push(source);
                }
            });

            if (selectedSources.length === 0) {
                throw new Error('Please select at least one journal source');
            }

            // Get advanced options
            const yearFrom = document.getElementById('search-year-from').value;
            const yearTo = document.getElementById('search-year-to').value;
            const limit = document.getElementById('search-limit').value;
            const sortBy = document.getElementById('search-sort').value;

            console.log('🔍 Search parameters:', {
                query: searchQuery,
                method: searchMethod,
                sources: selectedSources,
                yearFrom,
                yearTo,
                limit: parseInt(limit),
                sortBy
            });

            // First try actual API search, with fallback to mock data
            let searchResults;
            try {
                this.showStatus('Searching academic databases...', 'info');
                searchResults = await this.searchJournalAPIs({
                    query: searchQuery,
                    method: searchMethod,
                    sources: selectedSources,
                    yearFrom,
                    yearTo,
                    limit: parseInt(limit),
                    sortBy
                });
                console.log('🔍 API search completed, results:', searchResults.length);
            } catch (apiError) {
                console.warn('🔍 API search failed, using mock data:', apiError.message);
                this.showStatus('API access limited, showing sample results...', 'warning');
                
                // Generate mock results for demonstration
                searchResults = this.generateMockSearchResults(searchQuery, parseInt(limit));
            }

            // Display results
            this.displayJournalSearchResults(searchResults, resultsList, resultsCount);
            resultsContainer.classList.remove('hidden');

            if (searchResults.length > 0) {
                this.showStatus(`Found ${searchResults.length} papers matching your search`, 'success');
            } else {
                this.showStatus('No papers found. Try different keywords or sources.', 'warning');
            }

        } catch (error) {
            console.error('🔍 Journal search error:', error);
            this.showStatus(`Search error: ${error.message}`, 'error');
        } finally {
            // Reset button state
            searchBtn.innerHTML = '<i class="fas fa-search mr-2"></i>Search Journals';
            searchBtn.disabled = false;
        }
    }

    generateMockSearchResults(query, limit) {
        console.log('🔍 Generating mock search results for:', query);
        
        const mockPapers = [
            {
                id: 'mock_1',
                title: `Advanced Techniques in ${query} Management: A Comprehensive Review`,
                authors: 'Smith, J.D., Johnson, M.K., Williams, R.T.',
                journal: 'Journal of Ophthalmology',
                year: '2024',
                doi: '10.1016/j.joph.2024.001',
                abstract: `This comprehensive review examines current approaches to ${query} management in clinical practice. The study analyzes recent developments in diagnostic techniques, treatment protocols, and patient outcomes. Our findings suggest significant improvements in success rates when implementing evidence-based protocols for ${query} cases.`,
                url: 'https://example.com/paper1',
                source: 'PubMed (Mock)'
            },
            {
                id: 'mock_2',
                title: `Clinical Outcomes in ${query}: A Multi-Center Study`,
                authors: 'Anderson, P.L., Brown, S.M., Davis, K.R.',
                journal: 'British Journal of Ophthalmology',
                year: '2023',
                doi: '10.1136/bjophthalmol-2023-002',
                abstract: `A multi-center retrospective study examining ${query} outcomes across 15 clinical centers. The research included 1,247 patients and followed outcomes for 24 months. Results demonstrate improved visual acuity and reduced complications with updated treatment protocols.`,
                url: 'https://example.com/paper2',
                source: 'Europe PMC (Mock)'
            },
            {
                id: 'mock_3',
                title: `Novel Biomarkers in ${query} Diagnosis and Prognosis`,
                authors: 'Chen, L., Martinez, A.C., Thompson, B.K.',
                journal: 'Ophthalmology Research International',
                year: '2024',
                doi: '10.1155/2024/345678',
                abstract: `Investigation of novel biomarkers for early detection and prognosis of ${query}. The study identified three promising biomarkers with high sensitivity and specificity. These findings may lead to earlier intervention and improved patient outcomes in ${query} management.`,
                url: 'https://example.com/paper3',
                source: 'CrossRef (Mock)'
            },
            {
                id: 'mock_4',
                title: `Machine Learning Applications in ${query} Screening`,
                authors: 'Kumar, V.S., Lee, H.J., Patel, N.M.',
                journal: 'Digital Ophthalmology',
                year: '2023',
                doi: '10.1038/s41598-023-12345',
                abstract: `Development and validation of machine learning algorithms for automated ${query} screening. The deep learning model achieved 94.2% accuracy in detecting ${query} cases from fundus photographs, potentially revolutionizing screening programs in resource-limited settings.`,
                url: 'https://example.com/paper4',
                source: 'Semantic Scholar (Mock)'
            },
            {
                id: 'mock_5',
                title: `Surgical Innovations in ${query} Treatment: 5-Year Follow-up`,
                authors: 'Rodriguez, M.A., Singh, R.K., White, D.L.',
                journal: 'Retinal Surgery Today',
                year: '2024',
                doi: '10.1097/IAE.0000000000004567',
                abstract: `Long-term follow-up study of innovative surgical techniques for ${query} treatment. The 5-year data shows sustained improvement in visual outcomes with minimal complications. New microsurgical approaches demonstrate superior results compared to traditional methods.`,
                url: 'https://example.com/paper5',
                source: 'PubMed (Mock)'
            }
        ];

        // Return limited number of results
        const results = mockPapers.slice(0, Math.min(limit, mockPapers.length));
        console.log(`🔍 Generated ${results.length} mock results`);
        return results;
    }

    async searchJournalAPIs(params) {
        const { query, method, sources, yearFrom, yearTo, limit, sortBy } = params;
        let allResults = [];

        console.log('🔍 Attempting to search APIs with CORS handling...');

        // Due to CORS limitations, most APIs won't work directly from browser
        // For now, we'll attempt CrossRef which sometimes works, but fall back to mock data
        
        try {
            // Try CrossRef API (most likely to work due to permissive CORS)
            if (sources.includes('crossref')) {
                console.log('🔍 Trying CrossRef API...');
                const crossrefResults = await this.searchCrossRef(query, method, { yearFrom, yearTo, limit: Math.min(10, limit), sortBy });
                allResults = allResults.concat(crossrefResults);
            }
            
            // If we got some results, return them
            if (allResults.length > 0) {
                console.log('🔍 Successfully retrieved', allResults.length, 'results from APIs');
                return this.removeDuplicatePapers(allResults);
            }
        } catch (error) {
            console.warn('🔍 API search failed:', error.message);
        }

        // If no results from APIs, throw error to trigger mock data fallback
        throw new Error('CORS restrictions prevent direct API access from browser');
    }

    async searchSpecificAPI(source, params) {
        const { query, method, yearFrom, yearTo, limit, sortBy } = params;

        switch (source) {
            case 'pubmed':
                return await this.searchPubMed(query, method, { yearFrom, yearTo, limit, sortBy });
            case 'europmc':
                return await this.searchEuropePMC(query, method, { yearFrom, yearTo, limit, sortBy });
            case 'crossref':
                return await this.searchCrossRef(query, method, { yearFrom, yearTo, limit, sortBy });
            case 'doaj':
                return await this.searchDOAJ(query, method, { yearFrom, yearTo, limit, sortBy });
            case 'arxiv':
                return await this.searchArXiv(query, method, { yearFrom, yearTo, limit, sortBy });
            case 'semantic':
                return await this.searchSemanticScholar(query, method, { yearFrom, yearTo, limit, sortBy });
            default:
                throw new Error(`Unknown source: ${source}`);
        }
    }

    async searchPubMed(query, method, options) {
        // PubMed E-utilities API
        const baseUrl = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
        
        // Build search term for ophthalmology
        let searchTerm = method === 'keywords' 
            ? `(${query}) AND (ophthalmology OR ophthalmic OR retina OR cornea OR glaucoma OR cataract)`
            : query;

        // Add year filter
        if (options.yearFrom || options.yearTo) {
            const fromYear = options.yearFrom || '1900';
            const toYear = options.yearTo || new Date().getFullYear();
            searchTerm += ` AND ("${fromYear}"[Date - Publication] : "${toYear}"[Date - Publication])`;
        }

        try {
            // Search for IDs
            const searchUrl = `${baseUrl}esearch.fcgi?db=pubmed&term=${encodeURIComponent(searchTerm)}&retmax=${options.limit}&retmode=json&sort=${options.sortBy === 'date' ? 'date' : 'relevance'}`;
            
            const searchResponse = await fetch(searchUrl);
            const searchData = await searchResponse.json();
            
            if (!searchData.esearchresult?.idlist?.length) {
                return [];
            }

            // Get details for the papers
            const ids = searchData.esearchresult.idlist.slice(0, options.limit);
            const summaryUrl = `${baseUrl}esummary.fcgi?db=pubmed&id=${ids.join(',')}&retmode=json`;
            
            const summaryResponse = await fetch(summaryUrl);
            const summaryData = await summaryResponse.json();

            const results = [];
            for (const id of ids) {
                const paper = summaryData.result[id];
                if (paper) {
                    results.push({
                        id: `pubmed_${id}`,
                        title: paper.title,
                        authors: paper.authors?.map(a => a.name).join(', ') || 'Unknown',
                        journal: paper.fulljournalname || paper.source || 'Unknown Journal',
                        year: paper.pubdate?.split(' ')[0] || 'Unknown',
                        pmid: id,
                        doi: paper.doi || null,
                        abstract: paper.abstract || 'Abstract not available',
                        url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
                        source: 'PubMed'
                    });
                }
            }

            return results;
        } catch (error) {
            console.error('PubMed search error:', error);
            return [];
        }
    }

    async searchEuropePMC(query, method, options) {
        // Europe PMC REST API
        const baseUrl = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search';
        
        let searchQuery = method === 'keywords' 
            ? `(${query}) AND (ophthalmology OR ophthalmic OR retina OR cornea OR glaucoma OR cataract)`
            : query;

        // Add year filter
        if (options.yearFrom || options.yearTo) {
            const fromYear = options.yearFrom || '1900';
            const toYear = options.yearTo || new Date().getFullYear();
            searchQuery += ` AND (PUB_YEAR:[${fromYear} TO ${toYear}])`;
        }

        try {
            const url = `${baseUrl}?query=${encodeURIComponent(searchQuery)}&resultType=core&format=json&pageSize=${options.limit}&sort=${options.sortBy === 'date' ? 'date' : 'relevance'}`;
            
            const response = await fetch(url);
            const data = await response.json();

            if (!data.resultList?.result?.length) {
                return [];
            }

            return data.resultList.result.map(paper => ({
                id: `europmc_${paper.id}`,
                title: paper.title,
                authors: paper.authorString || 'Unknown',
                journal: paper.journalTitle || 'Unknown Journal',
                year: paper.pubYear || 'Unknown',
                pmid: paper.pmid || null,
                doi: paper.doi || null,
                abstract: paper.abstractText || 'Abstract not available',
                url: `https://europepmc.org/article/${paper.source}/${paper.id}`,
                source: 'Europe PMC'
            }));
        } catch (error) {
            console.error('Europe PMC search error:', error);
            return [];
        }
    }

    async searchCrossRef(query, method, options) {
        // CrossRef API
        const baseUrl = 'https://api.crossref.org/works';
        
        try {
            const params = new URLSearchParams();
            params.set('query', query);
            params.set('rows', String(options.limit));
            params.set('sort', options.sortBy === 'date' ? 'published' : 'relevance');
            // Recommended polite usage
            params.set('mailto', 'ophthalmoqa@example.com');
            
            // Combine filters into a single filter param to avoid 400s
            const filters = [];
            if (options.yearFrom) filters.push(`from-pub-date:${options.yearFrom}`);
            if (options.yearTo) filters.push(`until-pub-date:${options.yearTo}`);
            if (filters.length) params.set('filter', filters.join(','));

            const url = `${baseUrl}?${params.toString()}`;
            const response = await fetch(url);
            const data = await response.json();

            if (!data.message?.items?.length) {
                return [];
            }

            return data.message.items
                .filter(paper => {
                    // Filter for ophthalmology-related papers
                    const text = `${paper.title?.join(' ') || ''} ${paper.abstract || ''}`.toLowerCase();
                    return text.includes('ophthalmology') || text.includes('ophthalmic') || 
                           text.includes('retina') || text.includes('cornea') || 
                           text.includes('glaucoma') || text.includes('cataract');
                })
                .map(paper => ({
                    id: `crossref_${paper.DOI?.replace('/', '_')}`,
                    title: paper.title?.join(' ') || 'Untitled',
                    authors: paper.author?.map(a => `${a.given || ''} ${a.family || ''}`).join(', ') || 'Unknown',
                    journal: paper['container-title']?.join(', ') || 'Unknown Journal',
                    year: paper.published?.['date-parts']?.[0]?.[0] || 'Unknown',
                    doi: paper.DOI || null,
                    abstract: paper.abstract || 'Abstract not available',
                    url: paper.URL || `https://doi.org/${paper.DOI}`,
                    source: 'CrossRef'
                }));
        } catch (error) {
            console.error('CrossRef search error:', error);
            return [];
        }
    }

    async searchDOAJ(query, method, options) {
        // DOAJ API (simplified - DOAJ API has limited search capabilities)
        try {
            // DOAJ search is limited, so we'll return a placeholder
            // In a real implementation, you'd need to use DOAJ's specific API endpoints
            return [];
        } catch (error) {
            console.error('DOAJ search error:', error);
            return [];
        }
    }

    async searchArXiv(query, method, options) {
        // arXiv API
        const baseUrl = 'http://export.arxiv.org/api/query';
        
        try {
            let searchQuery = method === 'keywords' 
                ? `all:"${query}" AND (all:"ophthalmology" OR all:"ophthalmic" OR all:"retina" OR all:"cornea" OR all:"glaucoma" OR all:"cataract")`
                : `all:"${query}"`;

            const url = `${baseUrl}?search_query=${encodeURIComponent(searchQuery)}&start=0&max_results=${options.limit}&sortBy=${options.sortBy === 'date' ? 'submittedDate' : 'relevance'}`;
            
            const response = await fetch(url);
            const xmlText = await response.text();
            
            // Parse XML response (simplified)
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
            const entries = xmlDoc.querySelectorAll('entry');

            const results = [];
            entries.forEach((entry, index) => {
                const title = entry.querySelector('title')?.textContent?.trim();
                const summary = entry.querySelector('summary')?.textContent?.trim();
                const authors = Array.from(entry.querySelectorAll('author name')).map(name => name.textContent).join(', ');
                const published = entry.querySelector('published')?.textContent;
                const id = entry.querySelector('id')?.textContent;

                if (title && id) {
                    results.push({
                        id: `arxiv_${index}`,
                        title,
                        authors: authors || 'Unknown',
                        journal: 'arXiv Preprint',
                        year: published ? new Date(published).getFullYear() : 'Unknown',
                        doi: null,
                        abstract: summary || 'Abstract not available',
                        url: id,
                        source: 'arXiv'
                    });
                }
            });

            return results;
        } catch (error) {
            console.error('arXiv search error:', error);
            return [];
        }
    }

    async searchSemanticScholar(query, method, options) {
        // Semantic Scholar API
        const baseUrl = 'https://api.semanticscholar.org/graph/v1/paper/search';
        
        try {
            let searchQuery = method === 'keywords' 
                ? `${query} ophthalmology OR ophthalmic OR retina OR cornea OR glaucoma OR cataract`
                : query;

            let url = `${baseUrl}?query=${encodeURIComponent(searchQuery)}&limit=${options.limit}&fields=title,authors,venue,year,abstract,externalIds,url`;
            
            // Add year filter
            if (options.yearFrom) {
                url += `&year=${options.yearFrom}-`;
            }
            if (options.yearTo) {
                url += (options.yearFrom ? options.yearTo : `&year=-${options.yearTo}`);
            }

            const response = await fetch(url);
            const data = await response.json();

            if (!data.data?.length) {
                return [];
            }

            return data.data.map((paper, index) => ({
                id: `semantic_${paper.paperId || index}`,
                title: paper.title || 'Untitled',
                authors: paper.authors?.map(a => a.name).join(', ') || 'Unknown',
                journal: paper.venue || 'Unknown Journal',
                year: paper.year || 'Unknown',
                doi: paper.externalIds?.DOI || null,
                abstract: paper.abstract || 'Abstract not available',
                url: paper.url || `https://www.semanticscholar.org/paper/${paper.paperId}`,
                source: 'Semantic Scholar'
            }));
        } catch (error) {
            console.error('Semantic Scholar search error:', error);
            return [];
        }
    }

    removeDuplicatePapers(papers) {
        const seen = new Set();
        return papers.filter(paper => {
            // Use DOI if available, otherwise use title
            const identifier = paper.doi || paper.title.toLowerCase().trim();
            if (seen.has(identifier)) {
                return false;
            }
            seen.add(identifier);
            return true;
        });
    }

    sortSearchResults(results, sortBy) {
        switch (sortBy) {
            case 'date':
                return results.sort((a, b) => (b.year || 0) - (a.year || 0));
            case 'cited':
                // Note: Citation count would need to be fetched separately for most APIs
                return results.sort((a, b) => (b.citationCount || 0) - (a.citationCount || 0));
            default: // relevance
                return results; // Already sorted by relevance from APIs
        }
    }

    displayJournalSearchResults(results, container, countElement) {
        // Update count
        countElement.textContent = results.length;

        // Clear container
        container.innerHTML = '';

        if (results.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-search text-3xl mb-3"></i>
                    <p>No papers found matching your search criteria.</p>
                    <p class="text-sm mt-2">Try different keywords or broaden your search.</p>
                </div>
            `;
            return;
        }

        // Add demo notice if showing mock data
        const hasMockData = results.some(paper => paper.source.includes('Mock'));
        if (hasMockData) {
            const demoNotice = document.createElement('div');
            demoNotice.className = 'bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4';
            demoNotice.innerHTML = `
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-info-circle text-yellow-400"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-yellow-700">
                            <strong>Demo Mode:</strong> Due to browser security restrictions (CORS), showing sample results. 
                            The interface demonstrates how journal search would work with real API access.
                        </p>
                    </div>
                </div>
            `;
            container.appendChild(demoNotice);
        }

        // Display results
        results.forEach(paper => {
            const resultElement = document.createElement('div');
            resultElement.className = 'border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition cursor-pointer';
            resultElement.dataset.paperId = paper.id;

            resultElement.innerHTML = `
                <div class="flex items-start space-x-3">
                    <input type="checkbox" class="paper-checkbox mt-1 h-4 w-4 text-primary focus:ring-secondary border-gray-300 rounded" 
                           value="${paper.id}" onchange="if(window.ui) window.ui.updateSelectedPapersCount()">
                    <div class="flex-1 min-w-0">
                        <h5 class="font-medium text-gray-900 mb-1 line-clamp-2">${this.sanitizeHTML(paper.title)}</h5>
                        <p class="text-sm text-gray-600 mb-2">
                            <strong>Authors:</strong> ${this.sanitizeHTML(paper.authors)}
                        </p>
                        <p class="text-sm text-gray-600 mb-2">
                            <strong>Journal:</strong> ${this.sanitizeHTML(paper.journal)} (${paper.year})
                        </p>
                        <p class="text-xs text-gray-500 mb-2 line-clamp-3">${this.sanitizeHTML(paper.abstract)}</p>
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-3 text-xs">
                                <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">${paper.source}</span>
                                ${paper.doi ? `<span class="text-gray-500">DOI: ${paper.doi}</span>` : ''}
                            </div>
                            <a href="${paper.url}" target="_blank" class="text-primary hover:text-accent text-sm flex items-center">
                                <i class="fas fa-external-link-alt mr-1"></i>View Paper
                            </a>
                        </div>
                    </div>
                </div>
            `;

            container.appendChild(resultElement);
        });

        // Update generate button state
        this.updateSelectedPapersCount();
    }

    updateSelectedPapersCount() {
        const checkboxes = document.querySelectorAll('.paper-checkbox:checked');
        const count = checkboxes.length;
        
        const countElement = document.getElementById('selected-papers-count');
        const generateBtn = document.getElementById('generate-from-selected');
        
        if (countElement) {
            countElement.textContent = count;
        }
        
        if (generateBtn) {
            generateBtn.disabled = count === 0;
        }
    }

    async generateQuestionsFromSelectedPapers() {
        const checkboxes = document.querySelectorAll('.paper-checkbox:checked');
        
        if (checkboxes.length === 0) {
            this.showStatus('Please select at least one paper to generate questions from', 'warning');
            return;
        }

        const selectedPaperIds = Array.from(checkboxes).map(cb => cb.value);
        
        try {
            this.setProcessingState(true);
            this.showStatus(`Generating questions from ${selectedPaperIds.length} selected papers...`, 'info');

            // Get paper details for selected papers
            const selectedPapers = [];
            selectedPaperIds.forEach(paperId => {
                const paperElement = document.querySelector(`[data-paper-id="${paperId}"]`);
                if (paperElement) {
                    const title = paperElement.querySelector('h5').textContent;
                    const abstract = paperElement.querySelector('.line-clamp-3').textContent;
                    selectedPapers.push({
                        id: paperId,
                        title,
                        abstract,
                        content: `${title}\n\n${abstract}`
                    });
                }
            });

            // Combine all paper content
            const combinedContent = selectedPapers.map(paper => 
                `Paper: ${paper.title}\n\nAbstract: ${paper.abstract}`
            ).join('\n\n---\n\n');

            // Use the question generator to create questions
            if (this.questionGenerator) {
                // Set the content source to journal search
                this.questionGenerator.currentContent = combinedContent;
                this.questionGenerator.currentContentSource = 'journal-search';
                
                // Generate questions
                await this.questionGenerator.generateQuestions();
                
                this.showStatus(`Successfully generated questions from ${selectedPaperIds.length} research papers!`, 'success');
            } else {
                throw new Error('Question generator not available');
            }

        } catch (error) {
            console.error('Error generating questions from papers:', error);
            this.showStatus(`Error generating questions: ${error.message}`, 'error');
        } finally {
            this.setProcessingState(false);
        }
    }
} 
const fs = require('fs');
const path = require('path');

// Path to the file
const filePath = path.join(__dirname, 'js', 'QuestionGenerator.js');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Check for the specific error where there are unexpected lines after the closing brace
const pattern = `            }                
                console.log`;
const replacementPattern = `            }
            
            // Call the Gemini API with enhanced prompt`;

// Replace the problematic section
if (content.includes(pattern)) {
  content = content.replace(pattern, replacementPattern);
  
  // Write the corrected file
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('Successfully fixed syntax errors in the file.');
} else {
  console.log('Could not find the syntax error pattern to fix.');
} 
const fs = require('fs');
const path = require('path');

// Path to the file
const filePath = path.join(__dirname, 'js', 'QuestionGenerator.js');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Also update the post-processing section for focus keywords
const processingStartPattern = '// For uploaded documents, strictly filter based on focus keywords if provided';
const processingStartIndex = content.indexOf(processingStartPattern);

if (processingStartIndex !== -1) {
  console.log('Found post-processing section, enhancing it...');
  
  // We already have filtering in place, but let's enhance the log message
  const logMessagePattern = 'console.log(`Found ${keywordRelevantQuestions.length} questions specifically about:';
  const logMessageIndex = content.indexOf(logMessagePattern, processingStartIndex);
  
  if (logMessageIndex !== -1) {
    const enhancedLogMessage = 'console.log(`Found ${keywordRelevantQuestions.length} questions specifically about the focus keywords: ';
    content = content.substring(0, logMessageIndex) + enhancedLogMessage + content.substring(logMessageIndex + logMessagePattern.length);
    
    // Write the updated file
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('Successfully enhanced post-processing section.');
  } else {
    console.log('Could not find log message pattern to enhance.');
  }
} else {
  console.log('Could not find post-processing section to enhance.');
}

console.log('All updates completed!'); 
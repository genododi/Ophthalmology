/**
 * FeedbackHandler.js
 * Handles question feedback (thumbs up/down) and tracks repeated questions
 */

class FeedbackHandler {
    constructor() {
        this.feedbackData = {};
        this.seenQuestions = new Set();
        this.loadFeedbackData();
    }

    /**
     * Load previously saved feedback data from local storage
     */
    loadFeedbackData() {
        const storedFeedback = localStorage.getItem('ophthalmoQA_feedbackData');
        if (storedFeedback) {
            try {
                this.feedbackData = JSON.parse(storedFeedback);
            } catch (e) {
                console.error('Error loading feedback data:', e);
                this.feedbackData = {};
            }
        }

        const storedSeenQuestions = localStorage.getItem('ophthalmoQA_seenQuestions');
        if (storedSeenQuestions) {
            try {
                this.seenQuestions = new Set(JSON.parse(storedSeenQuestions));
            } catch (e) {
                console.error('Error loading seen questions data:', e);
                this.seenQuestions = new Set();
            }
        }
    }

    /**
     * Save feedback data to local storage
     */
    saveFeedbackData() {
        localStorage.setItem('ophthalmoQA_feedbackData', JSON.stringify(this.feedbackData));
        localStorage.setItem('ophthalmoQA_seenQuestions', JSON.stringify([...this.seenQuestions]));
    }

    /**
     * Record feedback for a specific question
     * @param {string} questionId - Unique identifier for the question
     * @param {boolean} isPositive - Whether feedback is positive (true) or negative (false)
     */
    recordFeedback(questionId, isPositive) {
        this.feedbackData[questionId] = isPositive;
        this.saveFeedbackData();
    }

    /**
     * Check if a question has been seen before
     * @param {string} questionText - The text of the question to check
     * @returns {boolean} - True if the question has been seen before
     */
    isRepeatedQuestion(questionText) {
        // Create a simplified version of the question for comparison
        const simplifiedQuestion = this.simplifyQuestionText(questionText);
        
        // Check if we've seen this question before
        if (this.seenQuestions.has(simplifiedQuestion)) {
            return true;
        }
        
        // If not, add it to our set of seen questions
        this.seenQuestions.add(simplifiedQuestion);
        this.saveFeedbackData();
        return false;
    }

    /**
     * Simplify question text for more accurate repetition detection
     * @param {string} questionText - The full question text
     * @returns {string} - A simplified version for comparison
     */
    simplifyQuestionText(questionText) {
        // Convert to lowercase and remove punctuation, extra spaces, etc.
        return questionText
            .toLowerCase()
            .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Add feedback buttons to a question element
     * @param {HTMLElement} questionElement - The element containing the question
     * @param {string} questionId - Unique ID for the question
     * @param {string} questionText - The text content of the question
     */
    addFeedbackButtonsToQuestion(questionElement, questionId, questionText) {
        // Create feedback buttons container
        const feedbackContainer = document.createElement('div');
        feedbackContainer.className = 'question-feedback-buttons';
        
        // Create thumbs up button
        const thumbsUpBtn = document.createElement('button');
        thumbsUpBtn.className = 'feedback-btn thumbs-up-btn';
        thumbsUpBtn.innerHTML = '<i class="fas fa-thumbs-up mr-1"></i> Helpful';
        thumbsUpBtn.title = 'Mark this question as helpful';
        
        // Create thumbs down button
        const thumbsDownBtn = document.createElement('button');
        thumbsDownBtn.className = 'feedback-btn thumbs-down-btn';
        thumbsDownBtn.innerHTML = '<i class="fas fa-thumbs-down mr-1"></i> Not Helpful';
        thumbsDownBtn.title = 'Mark this question as not helpful';
        
        // Add event listeners
        thumbsUpBtn.addEventListener('click', () => {
            this.recordFeedback(questionId, true);
            thumbsUpBtn.classList.add('active');
            thumbsDownBtn.classList.remove('active');
        });
        
        thumbsDownBtn.addEventListener('click', () => {
            this.recordFeedback(questionId, false);
            thumbsDownBtn.classList.add('active');
            thumbsUpBtn.classList.remove('active');
        });
        
        // Restore previous feedback state if exists
        if (questionId in this.feedbackData) {
            if (this.feedbackData[questionId]) {
                thumbsUpBtn.classList.add('active');
            } else {
                thumbsDownBtn.classList.add('active');
            }
        }
        
        // Add buttons to container
        feedbackContainer.appendChild(thumbsUpBtn);
        feedbackContainer.appendChild(thumbsDownBtn);
        
        // Add container to question element
        questionElement.appendChild(feedbackContainer);
        
        // Check if this is a repeated question and add indicator if so
        if (this.isRepeatedQuestion(questionText)) {
            const repeatedIndicator = document.createElement('div');
            repeatedIndicator.className = 'repeated-question-indicator';
            repeatedIndicator.innerHTML = '<i class="fas fa-exclamation"></i>';
            repeatedIndicator.title = 'This question appears to be a repeat';
            questionElement.classList.add('question-card');
            questionElement.appendChild(repeatedIndicator);
        }
    }

    /**
     * Clear all seen questions data
     */
    clearSeenQuestions() {
        this.seenQuestions = new Set();
        this.saveFeedbackData();
    }
}

// Create global instance
const feedbackHandler = new FeedbackHandler();

// Export for ES modules
if (typeof exports !== 'undefined') {
    exports.feedbackHandler = feedbackHandler;
} 
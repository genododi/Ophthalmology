/*
 Lightweight APKG media loader
 - Uses JSZip to read the .apkg (zip) file
 - Parses the media mapping ("media" or "media.json")
 - Extracts image blobs and exposes them as object URLs on window.kanskiImages
*/

(function(){
  function isImageFilename(filename) {
    if (!filename) return false;
    const lower = String(filename).toLowerCase();
    return (
      lower.endsWith('.jpg') || lower.endsWith('.jpeg') ||
      lower.endsWith('.png') || lower.endsWith('.gif') ||
      lower.endsWith('.webp') || lower.endsWith('.bmp') ||
      lower.endsWith('.tiff') || lower.endsWith('.tif')
    );
  }

  function decodeText(bytes) {
    if (typeof bytes === 'string') return bytes;
    const buf = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const decUtf8 = new TextDecoder('utf-8', { fatal: false });
    let text = decUtf8.decode(buf);
    // If looks like UTF-16 (many nulls), try LE
    const nullRatio = [...buf].filter(b => b === 0).length / Math.max(1, buf.length);
    if (nullRatio > 0.2) {
      try {
        const dec16 = new TextDecoder('utf-16le', { fatal: false });
        text = dec16.decode(buf);
      } catch (_) {}
    }
    return text;
  }

  function parseMediaMap(textOrBytes) {
    let raw = decodeText(textOrBytes);
    if (!raw) throw new Error('Empty media mapping');
    raw = String(raw).trim();
    // Remove UTF-8 BOM if present
    if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
    // Try plain JSON first
    try { return JSON.parse(raw); } catch (_) {}
    // Try quoting numeric keys: 0: "a.jpg" -> "0": "a.jpg"
    try {
      const quotedKeys = raw.replace(/(^|[,{\n\r\t ])(\d+)\s*:/g, '$1"$2":');
      return JSON.parse(quotedKeys);
    } catch (_) {}
    // Try converting single quotes to double quotes
    try {
      const dbl = raw.replace(/'/g, '"');
      return JSON.parse(dbl);
    } catch (_) {}
    // Remove trailing commas in objects/arrays
    try {
      const noTrailing = raw.replace(/,\s*([}\]])/g, '$1');
      return JSON.parse(noTrailing);
    } catch (_) {}
    // Last resort: extract pairs like 0: "file.jpg" or '0': 'file.jpg'
    const map = {};
    const pairRegex = /(\d+)\s*:\s*(?:"([^"]+)"|'([^']+)')/g;
    let m;
    while ((m = pairRegex.exec(raw)) !== null) {
      const id = m[1];
      const filename = m[2] || m[3];
      if (id && filename) map[id] = filename;
    }
    if (Object.keys(map).length > 0) return map;
    throw new Error('Invalid APKG media mapping');
  }

  function sniffIsImage(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const sig = u8.slice(0, 16);
    const asStr4 = String.fromCharCode(sig[0]||0, sig[1]||0, sig[2]||0, sig[3]||0);
    // JPEG
    if (sig[0] === 0xFF && sig[1] === 0xD8 && sig[2] === 0xFF) return true;
    // PNG
    if (sig[0] === 0x89 && asStr4 === '\u0089PNG') return true; // defensive
    if (sig[0] === 0x89 && sig[1] === 0x50 && sig[2] === 0x4E && sig[3] === 0x47) return true;
    // GIF
    if (asStr4 === 'GIF8') return true;
    // WEBP (RIFF....WEBP)
    if (asStr4 === 'RIFF' && String.fromCharCode(sig[8]||0, sig[9]||0, sig[10]||0, sig[11]||0) === 'WEBP') return true;
    // BMP
    if (asStr4[0] === 'B' && asStr4[1] === 'M') return true;
    // TIFF
    if ((sig[0] === 0x49 && sig[1] === 0x49 && sig[2] === 0x2A) || (sig[0] === 0x4D && sig[1] === 0x4D && sig[2] === 0x2A)) return true;
    return false;
  }

  async function loadApkgWithJSZip(file) {
    if (typeof JSZip === 'undefined') {
      throw new Error('JSZip is not loaded');
    }
    const zip = await JSZip.loadAsync(file);

    // Helper to find first file anywhere in zip matching regex
    const findFirstFile = (regex) => {
      const arr = zip.file(regex);
      if (arr && arr.length > 0) return arr[0];
      return null;
    };

    // Build a lightweight manifest of entries for debugging
    const allEntries = zip.file(/.*/).map(e => e.name);

    // Locate media mapping file (Anki uses a JSON named 'media' or 'media.json')
    let mediaEntry = findFirstFile(/(^|\/)media(\.json)?$/i);
    if (!mediaEntry) {
      // Some decks might not include a mapping; scan entries and sniff image signatures
      console.warn('APKG media map not found; scanning files for images');
      const kanskiImages = new Map();
      const tasks = [];
      zip.forEach((relPath, entry) => {
        if (entry.dir) return;
        if (relPath === 'collection.anki2' || relPath === 'collection.anki21' || /(^|\/)media(\.json)?$/.test(relPath)) return;
        tasks.push(entry.async('uint8array').then(bytes => {
          if (sniffIsImage(bytes)) {
            const url = URL.createObjectURL(new Blob([bytes]));
            kanskiImages.set(relPath, url);
          }
        }));
      });
      await Promise.all(tasks);
      // Also add numeric-named files as images (common in Anki media-only zips)
      const numericTasks = [];
      const all = zip.file(/.*/);
      all.forEach(entry => {
        if (entry.dir) return;
        const parts = entry.name.split('/');
        const base = parts[parts.length - 1];
        if (/^\d+(\.[A-Za-z0-9]+)?$/.test(base)) {
          numericTasks.push(entry.async('uint8array').then(bytes => {
            const blob = new Blob([bytes]);
            const url = URL.createObjectURL(blob);
            kanskiImages.set(entry.name, url);
          }));
        }
      });
      await Promise.all(numericTasks);
      return { images: kanskiImages, mapped: false, debug: { fileCount: allEntries.length, sample: allEntries.slice(0, 20) } };
    }

    // Parse mapping
    let mediaBytes = await mediaEntry.async('uint8array');
    // Robustly parse media mapping from various formats; if it still fails, fall back to scanning
    let mediaMap;
    try {
      mediaMap = parseMediaMap(mediaBytes);
    } catch (e) {
      console.warn('Failed to parse APKG media map, falling back to scanning entries:', e.message);
      const kanskiImages = new Map();
      const tasks = [];
      zip.forEach((relPath, entry) => {
        if (entry.dir) return;
        if (relPath === 'collection.anki2' || relPath === 'collection.media' || relPath === 'media' || relPath === 'media.json') return;
        tasks.push(entry.async('uint8array').then(bytes => {
          if (sniffIsImage(bytes)) {
            const blob = new Blob([bytes]);
            const url = URL.createObjectURL(blob);
            // use relPath and also a generic key
            kanskiImages.set(relPath, url);
          }
        }));
      });
      await Promise.all(tasks);
      return { images: kanskiImages, mapped: false, debug: { fileCount: allEntries.length, sample: allEntries.slice(0, 20) } };
    }

    const kanskiImages = new Map();
    const tasks = [];

    function getEntryByIdOrName(id, filename) {
      // Try exact numeric id at root
      let entry = zip.file(id);
      if (entry) return entry;
      // Try under media/
      entry = zip.file(`media/${id}`);
      if (entry) return entry;
      // Try under collection.media/
      entry = zip.file(`collection.media/${id}`);
      if (entry) return entry;
      // Try id with common image extensions
      const exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tif', '.tiff'];
      for (const ext of exts) {
        entry = zip.file(id + ext) || zip.file(`media/${id}${ext}`) || zip.file(`collection.media/${id}${ext}`);
        if (entry) return entry;
      }
      // Try regex anywhere (id or id.ext)
      let matches = zip.file(new RegExp(`(^|/)${id}(\\.[^/]+)?$`));
      if (matches && matches.length) return matches[0];
      // Try by filename at end of path
      if (filename) {
        entry = zip.file(new RegExp(`(^|/)${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`));
        if (entry && entry.length) return entry[0];
        entry = zip.file(new RegExp(`(^|/)(media|collection\.media)/${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`));
        if (entry && entry.length) return entry[0];
      }
      return null;
    }

    // Determine mapping direction
    const keys = Object.keys(mediaMap);
    const keysAreNumeric = keys.every(k => /^\d+$/.test(k));
    if (keysAreNumeric) {
      for (const id of keys) {
        const filename = mediaMap[id];
        // If filename known but not an image, still try id path as some exports omit extension in mapping
        if (filename && !isImageFilename(filename)) {
          // continue but still attempt id sniff
        }
        const entry = getEntryByIdOrName(id, filename);
        if (!entry) continue;
        tasks.push(
          entry.async('uint8array').then(bytes => {
            if (!sniffIsImage(bytes)) return;
            const blob = new Blob([bytes]);
            const url = URL.createObjectURL(blob);
            if (filename) kanskiImages.set(filename, url);
            kanskiImages.set(id, url);
          })
        );
      }
    } else {
      // Assume filename -> id mapping
      for (const filename of keys) {
        const id = String(mediaMap[filename]);
        if (!isImageFilename(filename) && !/^\d+$/.test(id)) continue;
        const entry = getEntryByIdOrName(id, filename) || zip.file(new RegExp(`(^|/)${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`));
        const resolved = Array.isArray(entry) ? entry[0] : entry;
        if (!resolved) continue;
        tasks.push(
          resolved.async('blob').then(blob => {
            const url = URL.createObjectURL(blob);
            if (filename) kanskiImages.set(filename, url);
            if (id) kanskiImages.set(id, url);
          })
        );
      }
    }

    await Promise.all(tasks);

    // If nothing loaded via mapping, fallback to scan all files (including /media and /collection.media folders)
    if (kanskiImages.size === 0) {
      const scanTasks = [];
      zip.forEach((relPath, entry) => {
        if (entry.dir) return;
        if (relPath === 'collection.anki2' || relPath === 'collection.anki21' || /(^|\/)media(\.json)?$/.test(relPath) || relPath === 'collection.media') return;
        scanTasks.push(entry.async('uint8array').then(bytes => {
          if (sniffIsImage(bytes)) {
            const blob = new Blob([bytes]);
            const url = URL.createObjectURL(blob);
            kanskiImages.set(relPath, url);
          }
        }));
      });
      await Promise.all(scanTasks);

      // Additionally, pick up numeric-named files (id or id.ext) as media
      if (kanskiImages.size === 0) {
        const numericTasks = [];
        const all = zip.file(/.*/);
        all.forEach(entry => {
          if (entry.dir) return;
          const parts = entry.name.split('/');
          const base = parts[parts.length - 1];
          if (/^\d+(\.[A-Za-z0-9]+)?$/.test(base) || /^(media|collection\.media)\//.test(entry.name)) {
            numericTasks.push(entry.async('uint8array').then(bytes => {
              const blob = new Blob([bytes]);
              const url = URL.createObjectURL(blob);
              kanskiImages.set(entry.name, url);
            }));
          }
        });
        await Promise.all(numericTasks);
      }
      return { images: kanskiImages, mapped: false };
    }

    return { images: kanskiImages, mapped: true, debug: { fileCount: allEntries.length, sample: allEntries.slice(0, 20) } };
  }

  // Public API used by OfflineStorageManager
  window.processUploadedApkgFile = async function(file){
    if (!file) throw new Error('No file provided');
    const result = await loadApkgWithJSZip(file);

    // Expose images for OphthalmoImageGenerator
    window.kanskiImages = result.images;

    // Try to parse notes from collection.anki2 using sql.js
    let notesLoaded = 0;
    let cardsCount = 0;
    try {
      const zip = await JSZip.loadAsync(file);
      let collectionEntry = findFirstFile(/(^|\/)collection\.(anki2|anki21|sqlite|db)$/i);
      if (collectionEntry) {
        const dbBytes = await collectionEntry.async('uint8array');
        const SQL = await ensureSqlJs();
        const db = new SQL.Database(dbBytes);

        // Check available tables (helps with robustness across versions)
        let tableNames = [];
        try {
          const t = db.exec("SELECT name FROM sqlite_master WHERE type='table'");
          if (t && t[0] && t[0].values) tableNames = t[0].values.map(v => String(v[0]));
        } catch(_) {}

        // Newer Anki may store fields with unit separator (\u001F)
        let res = null;
        try {
          res = db.exec('SELECT id, flds, sfld, guid, mid, tags FROM notes');
        } catch (_) {
          // Some variants may use a different casing or schema—fallbacks
          try { res = db.exec('SELECT id, flds, sfld, guid, mid, tags FROM Notes'); } catch(_) {}
        }
        const notes = new Map();
        if (res && res[0]) {
          const cols = res[0].columns;
          const rows = res[0].values;
          const idx = (n) => cols.indexOf(n);
          const iId = idx('id');
          const iFlds = idx('flds');
          const iSfld = idx('sfld');
          const iGuid = idx('guid');
          const iMid = idx('mid');
          const iTags = idx('tags');
          for (const row of rows) {
            const id = String(row[iId]);
            const fldsRaw = row[iFlds] != null ? String(row[iFlds]) : '';
            // Try both separators just in case
            let fields = fldsRaw.split('\u001f');
            if (fields.length === 1) fields = fldsRaw.split('\x1f');
            if (fields.length === 1) fields = fldsRaw.split('\u001F');
            const primary = String(row[iSfld] || '');
            const guid = String(row[iGuid] || '');
            const mid = String(row[iMid] || '');
            const tags = String(row[iTags] || '').trim();
            const text = fields.join(' ');
            const images = [];
            // Extract image references from any HTML in fields
            const imgRegex = /<img[^>]+src=["']([^"']+)["']/gi;
            let m;
            while ((m = imgRegex.exec(text)) !== null) {
              images.push(m[1]);
            }
            notes.set(id, { id, fields, primary, guid, mid, tags, images });
          }
        }
        notesLoaded = notes.size;
        // Cards count (more robust by counting rows)
        try {
          const c = db.exec('SELECT id FROM cards');
          if (c && c[0] && Array.isArray(c[0].values)) {
            cardsCount = c[0].values.length;
          }
        } catch(_) {}
        window.kanskiCards = notes;
        // Attach debug info for caller
        result.debug = result.debug || {};
        result.debug.tables = tableNames;
      } else {
        window.kanskiCards = window.kanskiCards || new Map();
      }
    } catch (e) {
      console.warn('APKG note parsing skipped:', e.message);
      window.kanskiCards = window.kanskiCards || new Map();
    }

    // If no structured notes were found, heuristically tag media-only zips (e.g., Kanski media.zip)
    if (!notesLoaded || (window.kanskiCards instanceof Map && window.kanskiCards.size === 0)) {
      try {
        const heuristic = buildHeuristicImageCards(window.kanskiImages);
        if (heuristic && heuristic.size) {
          window.kanskiCards = heuristic;
          notesLoaded = heuristic.size;
        }
      } catch (e) {
        console.warn('Heuristic media tagging failed:', e.message);
      }
    }

    return {
      imagesLoaded: result.images ? result.images.size : 0,
      usedMapping: result.mapped === true,
      notesLoaded,
      cardsCount,
      debug: result.debug || null
    };
  };

  async function ensureSqlJs() {
    if (typeof initSqlJs === 'function') {
      return await initSqlJs({ locateFile: (f) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/${f}` });
    }
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/sql-wasm.min.js';
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
    if (typeof initSqlJs !== 'function') throw new Error('sql.js failed to load');
    return await initSqlJs({ locateFile: (f) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/${f}` });
  }

  // Build pseudo-notes with tags/topics from media filenames for plain media zips
  function buildHeuristicImageCards(imagesMap) {
    try {
      if (!imagesMap || (imagesMap instanceof Map && imagesMap.size === 0)) return new Map();
      const out = new Map();

      const priorityConditions = [
        'diabetic retinopathy','amd','retinal detachment','glaucoma','keratoconus',
        'corneal ulcer','uveitis','pterygium','chalazion','ptosis','papilledema'
      ];
      const conditionRegex = {
        'diabetic retinopathy': /(diabetic|\bdr\b|npdr|pdr|microaneurysm|cotton\s*wool|macular\s*edema|\bdme\b)/i,
        'amd': /(\bamd\b|macular\s*degeneration|drusen|cnv|neovascular|geographic\s*atrophy|\bga\b|ped\b)/i,
        'retinal detachment': /(retinal\s*detachment|\brd\b|retinal\s*(tear|break|hole))/i,
        'glaucoma': /(glaucoma|rnfl|optic\s*(disc|nerve)|\bcdr\b|cup(ing)?|notch|hvf|\bvf\b|24-2|30-2|gonio)/i,
        'keratoconus': /(keratoconus|fleischer|vogt)/i,
        'corneal ulcer': /((cornea|corneal).*(ulcer|infiltrate))/i,
        'uveitis': /(uveitis|iritis|cells\s*and\s*flare|keratic\s*precipitates)/i,
        'pterygium': /pterygium/i,
        'chalazion': /(chalazion|meibom)/i,
        'ptosis': /(ptosis|levator)/i,
        'papilledema': /(papilledema|frisen)/i
      };
      const modalityRegex = {
        oct: /(\boct\b|b-?scan|cube|thickness|segmentation|rnfl)/i,
        fundus: /(fundus|retina|macula|drusen|amd|cnv|disc|optic|vessel|fovea|choroid|\bdr\b)/i,
        slit: /(slit\s*lamp|cornea|kerato|iris|conj|fluorescein|stain|anterior\s*segment)/i,
        vf: /(\bhvf\b|humphrey|visual\s*field|perimetry|\bvf\b|24-2|30-2|10-2|\bmd\b|\bpsd\b)/i,
        external: /(external|eyelid|lid|orbit|dermoid|ptosis|lacrimal|thyroid)/i
      };

      const imagesIter = imagesMap instanceof Map ? imagesMap.keys() : Object.keys(imagesMap);
      let counter = 0;
      for (const key of imagesIter) {
        const name = String(key);
        const lower = name.toLowerCase();
        const base = name.split('/').pop();
        const baseNoExt = base ? base.replace(/\.[a-z0-9]+$/i, '') : name;
        const tags = new Set();

        // Conditions
        let primary = null;
        for (const cond of priorityConditions) {
          const re = conditionRegex[cond];
          if (re && re.test(lower)) {
            tags.add(cond);
            if (!primary) primary = cond;
          }
        }

        // Generic subspecialty based on folders/names
        if (/retina|fundus|macula|drusen|amd|cnv|rnfl|disc|optic|choroid|retinal/i.test(lower)) tags.add('retina');
        if (/cornea|kerato|conj|pterygium|ulcer|fluorescein|anterior/i.test(lower)) tags.add('cornea');
        if (/glaucoma|rnfl|hvf|\bvf\b|gonio|angle/i.test(lower)) tags.add('glaucoma');
        if (/orbit|eyelid|lid|ptosis|chalazion|dermoid|lacrimal|thyroid/i.test(lower)) tags.add('oculoplastics');
        if (/neuro|papilledema|optic\s*neuritis|field/i.test(lower)) tags.add('neuro-ophthalmology');

        // Modalities
        for (const m in modalityRegex) {
          if (modalityRegex[m].test(lower)) tags.add(m);
        }

        if (!primary) {
          // Pick a primary from coarse tags if none matched
          if (tags.has('retina')) primary = 'retina';
          else if (tags.has('cornea')) primary = 'cornea';
          else if (tags.has('glaucoma')) primary = 'glaucoma';
          else if (tags.has('oculoplastics')) primary = 'oculoplastics';
          else if (tags.has('neuro-ophthalmology')) primary = 'neuro-ophthalmology';
          else primary = 'ophthalmology';
        }

        const id = `media:${baseNoExt}:${counter++}`;
        const note = {
          id,
          fields: [primary, base, Array.from(tags).join(' ')],
          primary,
          guid: id,
          mid: 'media-only',
          tags: Array.from(tags).join(' '),
          images: [base]
        };
        out.set(id, note);
      }

      // Also expose image -> topics for convenience
      const topics = new Map();
      for (const [, note] of out) {
        const img = note.images[0];
        topics.set(img, (note.tags || '').split(/\s+/g).filter(Boolean));
      }
      window.kanskiImageTopics = topics;
      return out;
    } catch (_) {
      return new Map();
    }
  }
})();



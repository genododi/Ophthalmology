/**
 * HuggingFaceUI.js
 * UI components for Hugging Face API integration
 */

class HuggingFaceUI {
    constructor() {
        this.modalElement = null;
        this.huggingFaceAPI = window.huggingFaceAPI;
        this.selectedModel = "google/flan-t5-xxl"; // Default model
        
        // Create UI elements
        this.createModal();
        
        // Add model selection to the existing modal
        this.addModelSelection();
    }
    
    /**
     * Create the Hugging Face API key modal
     */
    createModal() {
        // Create modal element
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        modal.id = 'huggingface-api-modal';
        
        // Modal HTML content
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative max-h-[90vh] overflow-y-auto">
                <button id="close-huggingface-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-4 flex items-center">
                    <i class="fas fa-robot mr-2"></i> Hugging Face Settings
                </h2>
                
                <div class="bg-blue-50 p-4 rounded-md border-l-4 border-blue-500 text-sm text-gray-700 mb-4">
                    <p class="mb-2">Configure your Hugging Face Inference API settings:</p>
                    <ul class="list-disc pl-5 space-y-1">
                        <li>Enter your API token for access to all Hugging Face models</li>
                        <li>Select a specific model for ophthalmology question generation</li>
                        <li>Customize parameters for optimal results</li>
                    </ul>
                    <p class="mt-2">Get a Hugging Face API token from <a href="https://huggingface.co/settings/tokens" target="_blank" class="text-blue-600 hover:underline">Hugging Face</a></p>
                </div>
                
                <div class="mb-5">
                    <label for="huggingface-api-key" class="block text-gray-700 font-medium mb-2">Your Hugging Face API Token</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-key text-gray-400"></i>
                        </div>
                        <input type="password" id="huggingface-api-key" 
                            class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                            placeholder="Enter your Hugging Face API token here">
                        <button type="button" id="toggle-huggingface-key-visibility" class="absolute inset-y-0 right-12 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" id="paste-huggingface-key" class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-primary">
                            <i class="fas fa-paste"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mb-5">
                    <label for="huggingface-model" class="block text-gray-700 font-medium mb-2">Select Model</label>
                    <select id="huggingface-model" class="w-full p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition">
                        <option value="flan-t5">Google Flan-T5-XXL (General)</option>
                        <option value="mistral">Mistral 7B (General)</option>
                        <option value="llama2">LLaMA-2 70B (General)</option>
                        <option value="gemma">Google Gemma 7B (General)</option>
                        <option value="falcon">Falcon 40B (General)</option>
                        <option value="meditron">Meditron 70B (Biomedical)</option>
                        <option value="biomed">BioMedLM (Biomedical)</option>
                        <option value="biomistral">BioMistral 7B (Biomedical)</option>
                        <option value="custom">Custom Model Path</option>
                    </select>
                </div>
                
                <div id="custom-model-container" class="mb-5 hidden">
                    <label for="custom-model-path" class="block text-gray-700 font-medium mb-2">Custom Model Path</label>
                    <input type="text" id="custom-model-path" 
                        class="w-full p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                        placeholder="e.g., facebook/bart-large">
                    <p class="text-xs text-gray-500 mt-1">Enter the full model path in format: organization/model-name</p>
                </div>
                
                <div class="mb-5">
                    <label for="huggingface-temperature" class="block text-gray-700 font-medium mb-2">Temperature: <span id="temperature-value">0.7</span></label>
                    <input type="range" id="huggingface-temperature" 
                        class="w-full" min="0.1" max="1.0" step="0.1" value="0.7">
                    <div class="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Precise (0.1)</span>
                        <span>Balanced (0.7)</span>
                        <span>Creative (1.0)</span>
                    </div>
                </div>
                
                <div id="huggingface-test-result" class="mb-4 p-3 rounded-md text-sm hidden"></div>
                
                <div class="flex flex-col sm:flex-row gap-3">
                    <button type="button" id="save-huggingface-settings" class="flex-1 bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                        <i class="fas fa-save mr-2"></i> Save Settings
                    </button>
                    <button type="button" id="test-huggingface-api" class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                        <i class="fas fa-vial mr-2"></i> Test API
                    </button>
                </div>
                
                <div class="mt-4 pt-4 border-t border-gray-200 text-xs text-gray-500">
                    <p class="flex items-center mb-1"><i class="fas fa-shield-alt mr-2"></i> Your API token is stored locally on your device and never sent to our servers.</p>
                    <p>Note: Large models may require a paid Hugging Face Pro subscription for optimal performance.</p>
                </div>
            </div>
        `;
        
        // Add modal to document
        document.body.appendChild(modal);
        this.modalElement = modal;
        
        // Initialize event listeners
        this.initializeEventListeners();
    }
    
    /**
     * Initialize event listeners for the modal
     */
    initializeEventListeners() {
        if (!this.modalElement) return;
        
        // Close modal
        const closeBtn = document.getElementById('close-huggingface-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.hideModal());
        }
        
        // Toggle API key visibility
        const toggleVisibilityBtn = document.getElementById('toggle-huggingface-key-visibility');
        if (toggleVisibilityBtn) {
            toggleVisibilityBtn.addEventListener('click', () => {
                const apiKeyInput = document.getElementById('huggingface-api-key');
                const icon = toggleVisibilityBtn.querySelector('i');
                
                if (apiKeyInput.type === 'password') {
                    apiKeyInput.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    apiKeyInput.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        }
        
        // Paste API key
        const pasteBtn = document.getElementById('paste-huggingface-key');
        if (pasteBtn) {
            pasteBtn.addEventListener('click', async () => {
                try {
                    const text = await navigator.clipboard.readText();
                    const apiKeyInput = document.getElementById('huggingface-api-key');
                    apiKeyInput.value = text.trim();
                } catch (err) {
                    console.error('Failed to paste API key:', err);
                    // Show a message to the user about clipboard permissions
                    this.showApiTestResult('Unable to paste from clipboard. Please paste manually.', 'error');
                }
            });
        }
        
        // Model selection change
        const modelSelect = document.getElementById('huggingface-model');
        if (modelSelect) {
            modelSelect.addEventListener('change', () => {
                const customModelContainer = document.getElementById('custom-model-container');
                if (modelSelect.value === 'custom') {
                    customModelContainer.classList.remove('hidden');
                } else {
                    customModelContainer.classList.add('hidden');
                }
            });
        }
        
        // Temperature slider
        const temperatureSlider = document.getElementById('huggingface-temperature');
        if (temperatureSlider) {
            temperatureSlider.addEventListener('input', () => {
                const temperatureValue = document.getElementById('temperature-value');
                temperatureValue.textContent = temperatureSlider.value;
            });
        }
        
        // Test API key
        const testBtn = document.getElementById('test-huggingface-api');
        if (testBtn) {
            testBtn.addEventListener('click', () => this.testApiKey());
        }
        
        // Save settings
        const saveBtn = document.getElementById('save-huggingface-settings');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveSettings());
        }
        
        // Pre-fill the API key input if we have a stored key
        const apiKeyInput = document.getElementById('huggingface-api-key');
        if (apiKeyInput && this.huggingFaceAPI && this.huggingFaceAPI.apiKey) {
            apiKeyInput.value = this.huggingFaceAPI.apiKey;
        }
    }
    
    /**
     * Add model selection to the advanced settings panel
     */
    addModelSelection() {
        // Add additional settings to the AI model dropdown
        const aiModelSelect = document.getElementById('ai-model');
        if (aiModelSelect) {
            aiModelSelect.addEventListener('change', (event) => {
                if (event.target.value === 'huggingface') {
                    this.showModal();
                }
            });
        }
    }
    
    /**
     * Show the modal
     */
    showModal() {
        if (this.modalElement) {
            this.modalElement.classList.remove('hidden');
        }
    }
    
    /**
     * Hide the modal
     */
    hideModal() {
        if (this.modalElement) {
            this.modalElement.classList.add('hidden');
        }
    }
    
    /**
     * Test the API key
     */
    async testApiKey() {
        const apiKeyInput = document.getElementById('huggingface-api-key');
        const apiKey = apiKeyInput.value.trim();
        
        if (!apiKey) {
            this.showApiTestResult('Please enter an API token', 'error');
            return;
        }
        
        // Show loading state
        this.showApiTestResult('Testing API token...', 'loading');
        
        // Get the selected model
        const modelSelect = document.getElementById('huggingface-model');
        let modelPath = this.huggingFaceAPI.modelOptions[modelSelect.value] || '';
        
        if (modelSelect.value === 'custom') {
            const customModelPath = document.getElementById('custom-model-path').value.trim();
            if (customModelPath) {
                modelPath = customModelPath;
            } else {
                this.showApiTestResult('Please enter a custom model path', 'error');
                return;
            }
        }
        
        try {
            const isValid = await this.huggingFaceAPI.testApiKey(apiKey);
            
            if (isValid) {
                this.showApiTestResult('API token is valid! You can now use Hugging Face models.', 'success');
            } else {
                this.showApiTestResult('API token validation failed. Please check your token and try again.', 'error');
            }
        } catch (error) {
            console.error('Error testing API token:', error);
            this.showApiTestResult(`Error: ${error.message}`, 'error');
        }
    }
    
    /**
     * Save the settings
     */
    async saveSettings() {
        const apiKeyInput = document.getElementById('huggingface-api-key');
        const apiKey = apiKeyInput.value.trim();
        
        if (!apiKey) {
            this.showApiTestResult('Please enter an API token', 'error');
            return;
        }
        
        // Get the selected model
        const modelSelect = document.getElementById('huggingface-model');
        let modelValue = modelSelect.value;
        
        if (modelValue === 'custom') {
            const customModelPath = document.getElementById('custom-model-path').value.trim();
            if (customModelPath) {
                modelValue = customModelPath;
            } else {
                this.showApiTestResult('Please enter a custom model path', 'error');
                return;
            }
        }
        
        // Get the temperature
        const temperatureSlider = document.getElementById('huggingface-temperature');
        const temperature = parseFloat(temperatureSlider.value);
        
        // Save the API key
        const saveResult = this.huggingFaceAPI.saveApiKey(apiKey);
        
        if (saveResult) {
            // Set the model
            this.huggingFaceAPI.setModel(modelValue);
            
            // Set the temperature
            this.huggingFaceAPI.temperature = temperature;
            
            this.showApiTestResult('Settings saved successfully!', 'success');
            
            // Initialize the API with the new key
            await this.huggingFaceAPI.initialize(apiKey);
            
            // Close the modal after a short delay
            setTimeout(() => this.hideModal(), 1500);
        } else {
            this.showApiTestResult('Failed to save settings', 'error');
        }
    }
    
    /**
     * Show API test result
     * @param {string} message - Message to show
     * @param {string} type - Type of message (success, error, loading)
     */
    showApiTestResult(message, type) {
        const resultElement = document.getElementById('huggingface-test-result');
        if (!resultElement) return;
        
        resultElement.classList.remove('hidden', 'bg-green-50', 'bg-red-50', 'bg-blue-50', 'text-green-700', 'text-red-700', 'text-blue-700');
        
        let icon = '';
        switch (type) {
            case 'success':
                resultElement.classList.add('bg-green-50', 'text-green-700', 'border-l-4', 'border-green-500');
                icon = '<i class="fas fa-check-circle mr-2"></i>';
                break;
            case 'error':
                resultElement.classList.add('bg-red-50', 'text-red-700', 'border-l-4', 'border-red-500');
                icon = '<i class="fas fa-exclamation-circle mr-2"></i>';
                break;
            case 'loading':
                resultElement.classList.add('bg-blue-50', 'text-blue-700', 'border-l-4', 'border-blue-500');
                icon = '<i class="fas fa-spinner fa-spin mr-2"></i>';
                break;
        }
        
        resultElement.innerHTML = `<p class="flex items-center">${icon}${message}</p>`;
        resultElement.classList.remove('hidden');
    }
}

// Initialize when document is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for HuggingFaceAPI to initialize
    setTimeout(() => {
        if (window.huggingFaceAPI) {
            window.huggingFaceUI = new HuggingFaceUI();
        } else {
            console.error('HuggingFaceAPI not available, UI initialization delayed');
            // Try again in 1 second
            setTimeout(() => {
                if (window.huggingFaceAPI) {
                    window.huggingFaceUI = new HuggingFaceUI();
                } else {
                    console.error('HuggingFaceAPI still not available, UI initialization failed');
                }
            }, 1000);
        }
    }, 500);
});

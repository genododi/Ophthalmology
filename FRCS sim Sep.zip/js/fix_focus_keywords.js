const fs = require('fs');
const path = require('path');

// Path to the file
const filePath = path.join(__dirname, 'js', 'QuestionGenerator.js');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Find the section we want to replace
const startPattern = '// For uploaded documents, strictly focus on the provided additional focus keywords if available';
const startIndex = content.indexOf(startPattern);

if (startIndex === -1) {
  console.error('Could not find the section to replace');
  process.exit(1);
}

// Find the end of the section (the next line that's not indented or is a closing brace)
let endIndex = content.indexOf('            }', startIndex);
endIndex = content.indexOf('\n', endIndex) + 1;

// Replace the section with our new code
const replacement = `// For uploaded documents, strictly focus on the provided additional focus keywords if available
            if (this.lastSettings.inputType === 'upload' && this.lastSettings.focusArea && this.lastSettings.focusArea.trim()) {
                const focusKeywords = this.lastSettings.focusArea.trim();
                enhancedPrompt += \`\\n\\nCRITICAL INSTRUCTION: You MUST ONLY generate questions specifically about: \${focusKeywords}. 
                Every single question MUST directly involve \${focusKeywords}.
                Do NOT generate questions about other topics in the document, even if they seem relevant.
                Ignore all content not related to \${focusKeywords}.
                If there's limited content about \${focusKeywords}, use your expert knowledge to create appropriate questions on this specific topic.\`;
                
                console.log(\`Added strict focus on keywords: "\${focusKeywords}" for uploaded document\`);
            }`;

// Replace the section
content = content.substring(0, startIndex) + replacement + content.substring(endIndex);

// Write the file
fs.writeFileSync(filePath, content, 'utf8');

console.log('Successfully updated the file.');

// Also update the post-processing section for focus keywords
const processingStartPattern = '// For uploaded documents, strictly filter based on focus keywords if provided';
const processingStartIndex = content.indexOf(processingStartPattern);

if (processingStartIndex !== -1) {
  console.log('Found post-processing section, enhancing it...');
  
  // We already have filtering in place, but let's enhance the log message
  const logMessagePattern = 'console.log(`Found ${keywordRelevantQuestions.length} questions specifically about:';
  const logMessageIndex = content.indexOf(logMessagePattern, processingStartIndex);
  
  if (logMessageIndex !== -1) {
    const enhancedLogMessage = 'console.log(`Found ${keywordRelevantQuestions.length} questions specifically about the focus keywords: ';
    content = content.substring(0, logMessageIndex) + enhancedLogMessage + content.substring(logMessageIndex + logMessagePattern.length);
    
    // Write the updated file
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('Successfully enhanced post-processing section.');
  }
}

console.log('All updates completed!'); 
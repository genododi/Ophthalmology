// Improvement recommendations function
window.getImprovementRecommendations = function() {
    const recommendations = [];
    
    try {
        // Try to get recommendations from the feedback loop system
        if (window.feedbackLoop && window.feedbackLoop.getRecommendedParameters) {
            const params = window.feedbackLoop.getRecommendedParameters();
            
            if (params && params.confidence > 0.3) {
                // Convert FeedbackLoop recommendations to improvement recommendations format
                if (params.difficulty) {
                    recommendations.push({
                        type: 'difficulty',
                        action: 'adjust_difficulty',
                        target: params.difficulty,
                        message: 'Try ' + params.difficulty + ' difficulty level',
                        confidence: params.confidence
                    });
                }
                
                if (params.questionTypes && params.questionTypes.length > 0) {
                    params.questionTypes.forEach(type => {
                        recommendations.push({
                            type: 'question_type',
                            action: 'enable_type',
                            target: type,
                            message: type.charAt(0).toUpperCase() + type.slice(1) + ' questions performing well',
                            confidence: params.confidence
                        });
                    });
                }
                
                if (params.focusKeywords && params.focusKeywords.length > 0) {
                    recommendations.push({
                        type: 'focus',
                        action: 'add_keywords',
                        target: params.focusKeywords.join(', '),
                        message: 'Consider focusing on: ' + params.focusKeywords.slice(0, 3).join(', '),
                        confidence: params.confidence
                    });
                }
            }
        }
        
        // Try to get recommendations from the feedback loop state
        if (recommendations.length === 0 && window.FeedbackLoop && window.FeedbackLoop.getRecommendedParameters) {
            const params = window.FeedbackLoop.getRecommendedParameters();
            if (params && Object.keys(params).length > 0) {
                recommendations.push({
                    type: 'general',
                    message: 'Apply optimized parameters based on feedback',
                    confidence: 0.7
                });
            }
        }
        
        // Fallback recommendations if no specific system is available
        if (recommendations.length === 0) {
            recommendations.push({
                type: 'feedback',
                message: 'Provide more feedback to enable smart recommendations',
                confidence: 0.5
            });
        }
        
    } catch (error) {
        console.warn('Error generating improvement recommendations:', error);
        // Return a safe fallback
        return [{
            type: 'system',
            message: 'Recommendation system temporarily unavailable',
            confidence: 0.1
        }];
    }
    
    return recommendations;
}; 
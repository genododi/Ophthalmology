/**
 * MedicalMLProcessor.js
 * Implements machine learning techniques to enhance ophthalmology question generation
 */
class MedicalMLProcessor {
    constructor() {
        this.initialized = false;
        this.modelLoaded = false;
        this.preprocessor = null;
        this.prevGeneratedQuestions = new Set(); // For tracking previously generated questions
        this.modelHandlers = {}; // For storing registered model handlers
    }

    /**
     * Initialize the ML processor
     */
    async initialize() {
        if (this.initialized) return;
        
        try {
            // Load dependencies if using TensorFlow.js
            await this.loadDependencies();
            
            // Initialize NLP preprocessor
            this.preprocessor = new MedicalTextPreprocessor();
            
            this.initialized = true;
            console.log('Medical ML Processor initialized');
            
            // Dispatch event to notify other modules that processor is ready
            document.dispatchEvent(new CustomEvent('MedicalMLProcessorReady'));
        } catch (error) {
            console.error('Error initializing Medical ML Processor:', error);
            // Fallback to basic processing if ML initialization fails
            this.initialized = true;
            
            // Still dispatch event even if initialization had errors
            document.dispatchEvent(new CustomEvent('MedicalMLProcessorReady'));
        }
    }

    /**
     * Load necessary dependencies
     */
    async loadDependencies() {
        // Check if TensorFlow.js is already loaded
        if (window.tf) return;
        
        return new Promise((resolve, reject) => {
            try {
                // Load TensorFlow.js dynamically if needed
                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.18.0/dist/tf.min.js';
                script.async = true;
                script.onload = () => {
                    console.log('TensorFlow.js loaded');
                    resolve();
                };
                script.onerror = (err) => {
                    console.error('Failed to load TensorFlow.js:', err);
                    reject(err);
                };
                document.head.appendChild(script);
            } catch (error) {
                reject(error);
            }
        });
    }

    /**
     * Process text content to extract key medical concepts
     * @param {string} text - Medical text to process
     * @returns {Object} - Extracted concepts and terms
     */
    processContent(text) {
        if (!this.initialized) {
            console.warn('Medical ML Processor not initialized');
            return { concepts: [], keywords: [] };
        }
        
        // Basic processing if ML model isn't available
        const concepts = this.extractConcepts(text);
        const keywords = this.extractKeywords(text);
        
        return {
            concepts,
            keywords,
            entities: this.extractMedicalEntities(text)
        };
    }

    /**
     * Extract medical concepts from text
     * @param {string} text - Text to process
     * @returns {Array} - Extracted concepts
     */
    extractConcepts(text) {
        // Basic implementation - look for common patterns in ophthalmology text
        const concepts = [];
        
        // Common ophthalmology patterns
        const patterns = [
            { regex: /\b(diagnosis|assessment)\s+of\s+([^.]+)/gi, type: 'diagnosis' },
            { regex: /\b(treatment|therapy|management)\s+of\s+([^.]+)/gi, type: 'treatment' },
            { regex: /\b(sign|symptom)s?\s+of\s+([^.]+)/gi, type: 'clinical' },
            { regex: /\b(visual acuity|va)\s+(\d+\/\d+|cf|hm|lp|nlp)/gi, type: 'measurement' }
        ];
        
        patterns.forEach(pattern => {
            let match;
            while ((match = pattern.regex.exec(text)) !== null) {
                concepts.push({
                    type: pattern.type,
                    context: match[0],
                    value: match[2].trim()
                });
            }
        });
        
        return concepts;
    }

    /**
     * Extract important medical keywords
     * @param {string} text - Text to process
     * @returns {Array} - Extracted keywords
     */
    extractKeywords(text) {
        // Simple TF-IDF like approach for keyword extraction
        const words = text.toLowerCase()
            .replace(/[^\w\s]/g, ' ')
            .split(/\s+/)
            .filter(w => w.length > 3);
        
        // Count word frequencies
        const wordFreq = {};
        words.forEach(word => {
            wordFreq[word] = (wordFreq[word] || 0) + 1;
        });
        
        // Filter out common words and sort by frequency
        const commonWords = new Set(['with', 'that', 'this', 'have', 'from', 'they', 'will', 'would', 'there', 'their', 'what', 'about', 'which']);
        const keywords = Object.entries(wordFreq)
            .filter(([word]) => !commonWords.has(word))
            .sort((a, b) => b[1] - a[1])
            .slice(0, 20)
            .map(([word]) => word);
        
        return keywords;
    }

    /**
     * Extract medical entities like drugs, procedures, conditions
     * @param {string} text - Text to process
     * @returns {Object} - Extracted entities by category
     */
    extractMedicalEntities(text) {
        // Dictionary-based approach for medical entity extraction
        const entities = {
            drugs: [],
            conditions: [],
            procedures: [],
            anatomical: []
        };
        
        // Common ophthalmology medications
        const drugs = [
            'timolol', 'latanoprost', 'brimonidine', 'dorzolamide', 'prednisolone', 
            'cyclopentolate', 'tropicamide', 'phenylephrine', 'atropine', 'pilocarpine',
            'ketorolac', 'nepafenac', 'olopatadine', 'loteprednol', 'tobramycin'
        ];
        
        // Common ophthalmology conditions
        const conditions = [
            'glaucoma', 'cataract', 'retinopathy', 'macular degeneration', 'uveitis',
            'keratitis', 'conjunctivitis', 'strabismus', 'amblyopia', 'presbyopia',
            'myopia', 'hyperopia', 'astigmatism', 'retinal detachment', 'dry eye'
        ];
        
        // Common ophthalmology procedures
        const procedures = [
            'phacoemulsification', 'trabeculectomy', 'vitrectomy', 'iridotomy', 'iridectomy',
            'photocoagulation', 'keratoplasty', 'slt', 'lasik', 'prk'
        ];
        
        // Common anatomical structures
        const anatomical = [
            'cornea', 'retina', 'iris', 'lens', 'sclera', 'conjunctiva', 'vitreous',
            'macula', 'optic nerve', 'ciliary body', 'trabecular meshwork', 'fovea'
        ];
        
        // Simple pattern matching for each category
        const lowerText = text.toLowerCase();
        
        drugs.forEach(drug => {
            if (lowerText.includes(drug)) entities.drugs.push(drug);
        });
        
        conditions.forEach(condition => {
            if (lowerText.includes(condition)) entities.conditions.push(condition);
        });
        
        procedures.forEach(procedure => {
            if (lowerText.includes(procedure)) entities.procedures.push(procedure);
        });
        
        anatomical.forEach(structure => {
            if (lowerText.includes(structure)) entities.anatomical.push(structure);
        });
        
        return entities;
    }

    /**
     * Check for question redundancy against previously generated questions
     * @param {Array} newQuestions - Newly generated questions
     * @param {Array} existingQuestions - Previously generated/stored questions
     * @returns {Array} - Filtered non-redundant questions
     */
    filterRedundantQuestions(newQuestions, existingQuestions = []) {
        // Get complete list of existing questions to check against
        const allExistingQuestions = [...existingQuestions];
        
        // Add any questions from our tracking set that weren't included
        for (const questionText of this.prevGeneratedQuestions) {
            if (!allExistingQuestions.some(q => q.question === questionText)) {
                allExistingQuestions.push({ question: questionText });
            }
        }
        
        // Filter out redundant questions
        const filteredQuestions = newQuestions.filter(newQ => {
            // Skip if missing question text
            if (!newQ.question) return false;
            
            // Check against previous questions
            const isDuplicate = allExistingQuestions.some(existingQ => {
                const existingText = existingQ.question || '';
                return this.calculateQuestionSimilarity(newQ.question, existingText) > 0.7;
            });
            
            // If not a duplicate, add to our tracking set
            if (!isDuplicate) {
                this.prevGeneratedQuestions.add(newQ.question);
            }
            
            return !isDuplicate;
        });
        
        return filteredQuestions;
    }
    
    /**
     * Calculate similarity between two questions
     * @param {string} q1 - First question
     * @param {string} q2 - Second question
     * @returns {number} - Similarity score (0-1)
     */
    calculateQuestionSimilarity(q1, q2) {
        // Normalize strings
        const s1 = String(q1).toLowerCase().trim();
        const s2 = String(q2).toLowerCase().trim();
        
        // If strings are identical
        if (s1 === s2) return 1.0;
        
        // Basic Jaccard similarity method
        const getTokens = (str) => {
            // Simple tokenization (words longer than 3 chars)
            return new Set(str.split(/\s+/).filter(w => w.length > 3));
        };
        
        const tokens1 = getTokens(s1);
        const tokens2 = getTokens(s2);
        
        if (tokens1.size === 0 || tokens2.size === 0) return 0;
        
        // Count intersection
        let intersection = 0;
        for (const token of tokens1) {
            if (tokens2.has(token)) intersection++;
        }
        
        // Calculate Jaccard index
        const union = tokens1.size + tokens2.size - intersection;
        return intersection / union;
    }

    /**
     * Enhance prompt with ML-derived context
     * @param {string} basePrompt - Original prompt
     * @param {Object} processedContent - NLP processed content
     * @returns {string} - Enhanced prompt
     */
    enhancePromptWithML(basePrompt, processedContent) {
        if (!processedContent) return basePrompt;
        
        let enhancedPrompt = basePrompt;
        
        // Add key concepts for prompt enhancement
        if (processedContent.concepts && processedContent.concepts.length > 0) {
            const conceptInfo = processedContent.concepts
                .slice(0, 5)
                .map(c => `${c.type}: ${c.value}`)
                .join(', ');
                
            enhancedPrompt += `\n\nPay special attention to these key medical concepts: ${conceptInfo}.`;
        }
        
        // Add medical entities for more detailed questions
        if (processedContent.entities) {
            // Add medications
            if (processedContent.entities.drugs && processedContent.entities.drugs.length > 0) {
                enhancedPrompt += `\n\nInclude questions about these medications where relevant: ${processedContent.entities.drugs.join(', ')}.`;
            }
            
            // Add conditions
            if (processedContent.entities.conditions && processedContent.entities.conditions.length > 0) {
                enhancedPrompt += `\n\nEnsure coverage of these conditions: ${processedContent.entities.conditions.join(', ')}.`;
            }
            
            // Add procedures
            if (processedContent.entities.procedures && processedContent.entities.procedures.length > 0) {
                enhancedPrompt += `\n\nIncorporate questions about these procedures: ${processedContent.entities.procedures.join(', ')}.`;
            }
        }
        
        // Add instruction to ensure novelty
        enhancedPrompt += `\n\nIMPORTANT: Generate novel, unique questions that don't repeat common patterns. Ensure variety in question structure and content.`;
        
        return enhancedPrompt;
    }

    /**
     * Register a model handler function to be used by the generator
     * @param {string} modelName - Name of the model to register
     * @param {Function} handlerFunction - Function to call for this model
     */
    registerModel(modelName, handlerFunction) {
        if (typeof handlerFunction !== 'function') {
            console.error(`Invalid handler for model ${modelName}. Must be a function.`);
            return false;
        }
        
        this.modelHandlers[modelName] = handlerFunction;
        console.log(`Model handler registered for: ${modelName}`);
        return true;
    }
    
    /**
     * Get a registered model handler by name
     * @param {string} modelName - Name of the model
     * @returns {Function|null} - Handler function or null if not found
     */
    getModelHandler(modelName) {
        return this.modelHandlers[modelName] || null;
    }
}

/**
 * Helper class for medical text preprocessing
 */
class MedicalTextPreprocessor {
    constructor() {
        this.medicalStopWords = new Set([
            'the', 'and', 'was', 'with', 'patient', 'patients', 'had', 'were', 'that', 'this',
            'have', 'has', 'for', 'eye', 'eyes', 'left', 'right', 'bilateral'
        ]);
    }
    
    /**
     * Preprocess text for ML analysis
     * @param {string} text - Text to preprocess
     * @returns {string} - Preprocessed text
     */
    preprocess(text) {
        return text
            .toLowerCase()
            .replace(/[^\w\s]/g, ' ')
            .split(/\s+/)
            .filter(word => word.length > 2 && !this.medicalStopWords.has(word))
            .join(' ');
    }
    
    /**
     * Segment text into meaningful chunks
     * @param {string} text - Text to segment
     * @returns {Array} - Text segments
     */
    segmentText(text) {
        // Split by common section headers in medical text
        const segments = [];
        
        // Common section patterns in ophthalmology documents
        const sectionPatterns = [
            /history\s+of\s+present\s+illness/i,
            /past\s+medical\s+history/i,
            /past\s+ocular\s+history/i,
            /family\s+history/i,
            /medications/i,
            /allergies/i,
            /review\s+of\s+systems/i,
            /ocular\s+examination/i,
            /slit\s+lamp\s+examination/i,
            /visual\s+acuity/i,
            /intraocular\s+pressure/i,
            /fundus\s+examination/i,
            /impression/i,
            /assessment/i,
            /diagnosis/i,
            /plan/i,
            /discussion/i
        ];
        
        // Simple section detection
        const lines = text.split(/\n/);
        let currentSection = 'introduction';
        let currentContent = [];
        
        lines.forEach(line => {
            let foundNewSection = false;
            
            // Check if line starts a new section
            for (const pattern of sectionPatterns) {
                if (pattern.test(line)) {
                    // Save previous section
                    if (currentContent.length > 0) {
                        segments.push({
                            section: currentSection,
                            content: currentContent.join(' ')
                        });
                    }
                    
                    // Start new section
                    currentSection = line.trim();
                    currentContent = [];
                    foundNewSection = true;
                    break;
                }
            }
            
            if (!foundNewSection && line.trim()) {
                currentContent.push(line.trim());
            }
        });
        
        // Add final section
        if (currentContent.length > 0) {
            segments.push({
                section: currentSection,
                content: currentContent.join(' ')
            });
        }
        
        return segments;
    }
}

// Export as global
window.medicalMLProcessor = new MedicalMLProcessor();

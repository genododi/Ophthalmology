/**
 * BioMistralAPI.js
 * This module handles the integration with the local BioMistral-7B model for generating 
 * ophthalmology questions and adding them to the question bank database through a feedback loop.
 */

class BioMistralAPI {
    constructor() {
        this.apiEndpoint = "http://localhost:8000/completion";
        this.healthEndpoint = "http://localhost:8000/health";
        this.isInitialized = false;
        this.isModelLoaded = false;
        this.temperature = 0.7;
        this.maxTokens = 1024;
        this.feedbackCache = [];
        this.feedbackEnabled = true;
        this.maxFeedbackExamples = 3;
        this.feedbackScoreThreshold = 0.7; // Only use highly-rated questions for feedback
    }

    /**
     * Initialize the BioMistral API integration
     */
    async initialize() {
        console.log("BioMistral API module initializing...");
        
        try {
            // Check if the local server is running
            const healthStatus = await this.checkServerHealth();
            this.isModelLoaded = healthStatus.status === "ok";
            console.log(`BioMistral model status: ${this.isModelLoaded ? 'loaded' : 'not loaded'}`);
            
            if (!this.isModelLoaded) {
                console.warn("BioMistral model is not loaded or server is not running. Please start the server using run_biomistral_server.sh");
            }
        } catch (error) {
            // Avoid noisy console errors when server is not running (common in file://)
            console.warn("BioMistral server not reachable (this is expected if it's not running):", error?.message || error);
            console.warn("Please start the BioMistral server using run_biomistral_server.sh");
            this.isModelLoaded = false;
        }
        
        this.isInitialized = true;
        
        // Register BioMistral with the MedicalMLProcessor system
        if (typeof window.medicalMLProcessor !== 'undefined') {
            window.medicalMLProcessor.registerModel('biomistral', this.generateQuestions.bind(this));
        } else {
            console.warn("MedicalMLProcessor not available, BioMistral registration delayed");
            // Setup a listener for when MedicalMLProcessor becomes available
            document.addEventListener('MedicalMLProcessorReady', () => {
                window.medicalMLProcessor.registerModel('biomistral', this.generateQuestions.bind(this));
            });
        }
        
        // Load feedback examples from the question database if available
        this.loadFeedbackExamples();
        
        // Set up an interval to refresh feedback examples every 5 minutes
        setInterval(() => this.loadFeedbackExamples(), 5 * 60 * 1000);
        
        return this.isModelLoaded;
    }

    /**
     * Check if the BioMistral server is running and healthy
     */
    async checkServerHealth() {
        try {
            // Do not attempt network calls when opened as a local file
            if (typeof location !== 'undefined' && location.protocol !== 'http:' && location.protocol !== 'https:') {
                return { status: "disabled", message: "Running under file://, skipping server health check" };
            }
            // Use a short timeout and avoid throwing fatal errors on failure
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 2000);
            const response = await fetch(this.healthEndpoint, { signal: controller.signal }).catch(() => null);
            clearTimeout(timeout);
            if (!response.ok) {
                throw new Error(`Health check failed with status ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            // Log as warning to prevent console error noise when server is absent
            console.warn("BioMistral health check unavailable:", error?.message || error);
            return { status: "error", message: error.message };
        }
    }

    /**
     * Load high-quality questions from the database to use as feedback examples
     */
    loadFeedbackExamples() {
        if (!this.feedbackEnabled || !window.questionDatabase) {
            return;
        }
        
        try {
            // Get all questions from the database
            const allQuestions = window.questionDatabase.storedQuestions || [];
            
            // Filter for questions with high ratings or frequent usage
            const highQualityQuestions = allQuestions.filter(q => {
                // If the question has a rating, check if it's above the threshold
                if (q.metadata && q.metadata.rating) {
                    return q.metadata.rating >= this.feedbackScoreThreshold;
                }
                
                // Otherwise, include questions that have been used in multiple sessions
                if (q.metadata && q.metadata.usageCount) {
                    return q.metadata.usageCount > 2;
                }
                
                return false;
            });
            
            // Sort by rating or usage count (descending)
            highQualityQuestions.sort((a, b) => {
                const ratingA = a.metadata?.rating || 0;
                const ratingB = b.metadata?.rating || 0;
                const usageA = a.metadata?.usageCount || 0;
                const usageB = b.metadata?.usageCount || 0;
                
                return (ratingB - ratingA) || (usageB - usageA);
            });
            
            // Store the top examples in the feedback cache
            this.feedbackCache = highQualityQuestions.slice(0, 10).map(q => ({
                question: q.question || q.text,
                type: q.type,
                subspecialty: q.metadata?.subspecialty || "general"
            }));
            
            console.log(`Loaded ${this.feedbackCache.length} high-quality questions for feedback loop`);
        } catch (error) {
            console.error("Error loading feedback examples:", error);
        }
    }

    /**
     * Generate questions using BioMistral
     * @param {Object} config - Configuration parameters
     * @returns {Promise<Array>} - Generated questions
     */
    async generateQuestions(config) {
        try {
            const { content, questionTypes, difficulty, subspecialty, focusKeywords, numQuestions } = config;
            
            // Ensure the API is initialized
            if (!this.isInitialized) {
                await this.initialize();
            }
            
            // Check if the model is loaded
            if (!this.isModelLoaded) {
                const serverStatus = await this.checkServerHealth();
                this.isModelLoaded = serverStatus.status === "ok";
                
                if (!this.isModelLoaded) {
                    throw new Error("BioMistral server is not running. Please start the server using run_biomistral_server.sh");
                }
            }
            
            // Construct a prompt for BioMistral that explains what we need
            const prompt = this.constructPrompt(content, questionTypes, difficulty, subspecialty, focusKeywords, numQuestions);
            
            // Select feedback examples relevant to the current request
            const relevantFeedback = this.selectRelevantFeedbackExamples(subspecialty, questionTypes);
            
            // Make the API call to BioMistral
            const response = await this.callBioMistralAPI(prompt, relevantFeedback);
            
            // Parse the response into structured questions
            const questions = this.parseQuestionsFromResponse(response);
            
            // Add the generated questions to the database for feedback loop
            await this.addQuestionsToDatabase(questions, subspecialty, difficulty);
            
            return questions;
        } catch (error) {
            console.error("Error generating questions with BioMistral:", error);
            throw error;
        }
    }

    /**
     * Select relevant feedback examples based on the current request
     */
    selectRelevantFeedbackExamples(subspecialty, questionTypes) {
        if (!this.feedbackEnabled || this.feedbackCache.length === 0) {
            return [];
        }
        
        // First filter by subspecialty
        let relevantExamples = this.feedbackCache.filter(ex => {
            return ex.subspecialty === subspecialty || 
                   ex.subspecialty === "general" || 
                   subspecialty === "general";
        });
        
        // Then filter by question types if specified
        if (questionTypes && Object.keys(questionTypes).length > 0) {
            const selectedTypes = Object.keys(questionTypes).filter(t => questionTypes[t]);
            
            if (selectedTypes.length > 0) {
                // If we have enough examples, filter by type
                if (relevantExamples.length > this.maxFeedbackExamples * 2) {
                    relevantExamples = relevantExamples.filter(ex => {
                        return selectedTypes.includes(ex.type);
                    });
                }
            }
        }
        
        // Return at most maxFeedbackExamples examples
        return relevantExamples.slice(0, this.maxFeedbackExamples);
    }

    /**
     * Construct a detailed prompt for BioMistral
     */
    constructPrompt(content, questionTypes, difficulty, subspecialty, focusKeywords, numQuestions) {
        let typesList = Object.keys(questionTypes).filter(type => questionTypes[type]).join(", ");
        if (!typesList) typesList = "Multiple Choice"; // Default if none selected
        
        return `As an ophthalmology specialist creating FRCS exam questions, generate ${numQuestions} high-quality ${difficulty} level questions about ${subspecialty} ophthalmology.

CONTENT TO BASE QUESTIONS ON:
${content}

QUESTION TYPES: ${typesList}
DIFFICULTY: ${difficulty}
SUBSPECIALTY FOCUS: ${subspecialty}
${focusKeywords ? `ADDITIONAL FOCUS KEYWORDS: ${focusKeywords}` : ''}

FORMAT REQUIREMENTS:
1. For multiple choice questions, include 4-5 options with one correct answer clearly marked.
2. For clinical cases, provide a detailed patient scenario, findings, and diagnostic questions.
3. For each question, include a detailed explanation with the correct answer.
4. Format each question as JSON with the following structure:
{
  "questions": [
    {
      "id": "1",
      "type": "mcq", // or "tf", "matching", "short-answer", "clinical-case", "differential"
      "text": "Question text here",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "answer": "Correct option or answer here",
      "explanation": "Detailed explanation with references if possible"
    },
    // more questions...
  ]
}

Generate highly-specific, clinically-relevant questions that test important concepts for FRCS ophthalmology examination. Each question should focus on clinical reasoning and practical knowledge.`;
    }

    /**
     * Call the BioMistral API with the constructed prompt
     */
    async callBioMistralAPI(prompt, feedbackExamples = []) {
        try {
            // Prepare request body
            const requestBody = {
                prompt: prompt,
                n_predict: this.maxTokens,
                temperature: this.temperature,
                top_p: 0.9
            };
            
            // Add feedback examples if available
            if (feedbackExamples && feedbackExamples.length > 0) {
                requestBody.feedback = feedbackExamples;
            }
            
            // Make the API request
            const response = await fetch(this.apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestBody)
            });
            
            if (!response.ok) {
                throw new Error(`API request failed with status ${response.status}`);
            }
            
            const data = await response.json();
            return data.content;
        } catch (error) {
            console.error("Error calling BioMistral API:", error);
            throw error;
        }
    }

    /**
     * Parse the text response from BioMistral into structured question objects
     */
    parseQuestionsFromResponse(responseText) {
        try {
            // Try to extract JSON from the response text
            const jsonMatch = responseText.match(/\{[\s\S]*\}/);
            
            if (jsonMatch) {
                // If JSON is found, parse it
                const questionsData = JSON.parse(jsonMatch[0]);
                return questionsData.questions || [];
            } else {
                // If no JSON structure is found, parse text manually
                console.warn("No JSON structure found in BioMistral response, attempting manual parsing");
                return this.parseUnstructuredText(responseText);
            }
        } catch (error) {
            console.error("Error parsing BioMistral response:", error);
            // Fallback to manual parsing if JSON parsing fails
            return this.parseUnstructuredText(responseText);
        }
    }

    /**
     * Fallback parser for unstructured text responses
     */
    parseUnstructuredText(text) {
        const questions = [];
        const questionBlocks = text.split(/Question \d+:|Q\d+:/);
        
        questionBlocks.forEach((block, index) => {
            if (index === 0 && !block.trim()) return; // Skip empty first block
            
            const questionObj = {
                id: String(index),
                type: "unknown",
                text: "",
                options: [],
                answer: "",
                explanation: ""
            };
            
            // Extract the question text
            const lines = block.trim().split('\n');
            questionObj.text = lines[0].trim();
            
            // Identify question type
            if (block.includes("True or False") || block.includes("True/False")) {
                questionObj.type = "tf";
            } else if (block.match(/[A-E]\)|\([A-E]\)/)) {
                questionObj.type = "mcq";
                
                // Extract options
                const optionMatches = block.match(/[A-E]\).*|[A-E]\..*|\([A-E]\).*/g);
                if (optionMatches) {
                    questionObj.options = optionMatches.map(opt => opt.trim());
                }
            } else if (block.includes("Case:") || block.includes("clinical scenario")) {
                questionObj.type = "clinical-case";
            }
            
            // Extract answer and explanation
            if (block.includes("Answer:")) {
                const answerMatch = block.match(/Answer:([^\n]*)/);
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                }
                
                const explanationMatch = block.match(/Explanation:([\s\S]*)/);
                if (explanationMatch) {
                    questionObj.explanation = explanationMatch[1].trim();
                }
            }
            
            questions.push(questionObj);
        });
        
        return questions;
    }

    /**
     * Add the generated questions to the question database for the feedback loop
     */
    async addQuestionsToDatabase(questions, subspecialty, difficulty) {
        // Check if QuestionDatabase is available
        if (typeof window.questionDatabase !== 'undefined') {
            const timestamp = new Date().toISOString();
            
            // Add each question to the database
            questions.forEach(question => {
                // Prepare the question for the database
                const questionForDB = {
                    ...question,
                    source: "biomistral",
                    createdAt: timestamp,
                    metadata: {
                        subspecialty: subspecialty || "general",
                        difficulty: difficulty || "board",
                        rating: 0.5, // Initial neutral rating
                        usageCount: 1,  // First usage
                        dateAdded: timestamp
                    }
                };
                
                // Add to database
                window.questionDatabase.addQuestion(questionForDB);
            });
            
            console.log(`Added ${questions.length} BioMistral-generated questions to database for feedback loop`);
            
            // After adding new questions, update the feedback cache
            setTimeout(() => this.loadFeedbackExamples(), 1000);
        } else {
            console.warn("QuestionDatabase not available, unable to add questions to database");
        }
    }
    
    /**
     * Rate a question for the feedback loop
     * @param {string} questionId - ID of the question to rate
     * @param {number} rating - Rating value (0-1)
     */
    rateQuestion(questionId, rating) {
        if (!window.questionDatabase) {
            console.warn("QuestionDatabase not available, unable to rate question");
            return false;
        }
        
        try {
            // Find the question in the database
            const allQuestions = window.questionDatabase.storedQuestions;
            const questionIndex = allQuestions.findIndex(q => 
                q.metadata && q.metadata.id === questionId
            );
            
            if (questionIndex >= 0) {
                // Update the question's rating
                allQuestions[questionIndex].metadata.rating = rating;
                
                // Increment usage count
                if (!allQuestions[questionIndex].metadata.usageCount) {
                    allQuestions[questionIndex].metadata.usageCount = 1;
                } else {
                    allQuestions[questionIndex].metadata.usageCount++;
                }
                
                // Save to local storage
                window.questionDatabase.saveToLocalStorage();
                
                // If it's a high rating, refresh our feedback cache
                if (rating >= this.feedbackScoreThreshold) {
                    this.loadFeedbackExamples();
                }
                
                return true;
            }
            
            return false;
        } catch (error) {
            console.error("Error rating question:", error);
            return false;
        }
    }
}

// Create the BioMistral API module (lazy initialization; no network calls until used)
window.bioMistralAPI = new BioMistralAPI();
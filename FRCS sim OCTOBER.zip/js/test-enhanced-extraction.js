/**
 * Test Suite for Enhanced Q&A Extraction System
 * Tests file processing, question extraction, and feedback integration
 */

class EnhancedExtractionTest {
    constructor() {
        this.testResults = [];
        this.startTime = Date.now();
    }

    // Test advanced file processor
    async testAdvancedFileProcessor() {
        console.log('🧪 Testing Advanced File Processor...');
        
        const testContent = 'Question 1: What is the normal I0P range?\nA) 10-21 mmHg\nB) 5-15 mmHg\nAnswer: A';
        
        try {
            if (window.advancedFileProcessor) {
                const processed = window.advancedFileProcessor.enhanceStructure(testContent);
                const fixed = window.advancedFileProcessor.fixCommonIssues(processed);
                
                this.logTestResult('Advanced File Processing', 'PASS', `Processed ${testContent.length} → ${fixed.length} chars`);
            } else {
                this.logTestResult('Advanced File Processing', 'SKIP', 'Not available');
            }
        } catch (error) {
            this.logTestResult('Advanced File Processing', 'FAIL', error.message);
        }
    }

    // Test enhanced question block identification
    async testEnhancedQuestionBlocks() {
        console.log('🧪 Testing Enhanced Question Blocks...');
        
        const testContent = `1. What is the primary cause of glaucoma?
                         A) High blood pressure
                         B) Increased intraocular pressure
                         C) Diabetes
                         Answer: B
                         
                         2. Which imaging technique is used for retinal evaluation?
                         A) CT scan
                         B) MRI
                         C) OCT
                         Answer: C`;
        
        try {
            if (window.enhancedQAExtractor && window.enhancedQAExtractor.identifyQuestionBlocksEnhanced) {
                const blocks = window.enhancedQAExtractor.identifyQuestionBlocksEnhanced(testContent, {
                    confidenceThreshold: 0.3
                });
                
                const status = blocks.length >= 2 ? 'PASS' : 'PARTIAL';
                this.logTestResult('Enhanced Question Blocks', status, `Found ${blocks.length}/2 questions`);
            } else {
                this.logTestResult('Enhanced Question Blocks', 'SKIP', 'Not available');
            }
        } catch (error) {
            this.logTestResult('Enhanced Question Blocks', 'FAIL', error.message);
        }
    }

    // Test content analysis
    async testContentAnalysis() {
        console.log('🧪 Testing Content Analysis...');
        
        const testContents = [
            {
                name: 'Multiple Choice Quiz',
                content: `1. What is AMD?
                         A) Age-related macular degeneration
                         B) Acute myocardial dysfunction
                         C) Anterior membrane dystrophy
                         Answer: A
                         
                         2. Normal IOP is:
                         A) 5-10 mmHg
                         B) 10-21 mmHg
                         C) 25-30 mmHg
                         Answer: B`,
                expectedType: 'multiple_choice_quiz'
            },
            {
                name: 'Questions Only',
                content: `What causes diabetic retinopathy?
                         How is glaucoma diagnosed?
                         What are the symptoms of cataract?`,
                expectedType: 'questions_only'
            },
            {
                name: 'General Text',
                content: `The retina is a light-sensitive layer of tissue at the back of the eye.
                         It contains photoreceptors that convert light into electrical signals.
                         These signals are transmitted to the brain via the optic nerve.`,
                expectedType: 'general_text'
            }
        ];

        for (const test of testContents) {
            try {
                if (window.analyzeFileContent) {
                    const analysis = await window.analyzeFileContent(test.content);
                    
                    const typeMatch = analysis.contentType === test.expectedType;
                    const status = typeMatch ? 'PASS' : 'PARTIAL';
                    const detail = `Type: ${analysis.contentType}, Questions: ${analysis.questionCount}, Confidence: ${Math.round(analysis.confidence * 100)}%`;
                    
                    this.logTestResult(test.name, status, detail);
                } else {
                    this.logTestResult(test.name, 'SKIP', 'Content analysis not available');
                }
            } catch (error) {
                this.logTestResult(test.name, 'FAIL', error.message);
            }
        }
    }

    // Test answer extraction improvements
    async testAnswerExtraction() {
        console.log('🧪 Testing Answer Extraction...');
        
        const testContent = `Question: What is the normal IOP?
                         A) 10-21 mmHg
                         B) 5-15 mmHg
                         C) 20-30 mmHg
                         Answer: A`;
        
        try {
            if (window.enhancedQAExtractor) {
                const result = await window.enhancedQAExtractor.extractFromText(testContent, {
                    confidenceThreshold: 0.3
                });
                
                const hasAnswers = result.questions.some(q => q.answer && q.answer.trim());
                const status = hasAnswers ? 'PASS' : 'PARTIAL';
                this.logTestResult('Answer Extraction', status, `${result.questions.length} questions processed`);
            } else {
                this.logTestResult('Answer Extraction', 'SKIP', 'Not available');
            }
        } catch (error) {
            this.logTestResult('Answer Extraction', 'FAIL', error.message);
        }
    }

    // Test feedback integration
    async testFeedbackIntegration() {
        console.log('🧪 Testing Feedback Integration...');
        
        const testCases = [
            {
                name: 'Improvement Detection',
                setupFeedback: true,
                content: `Question: What is glaucoma?
                         Answer: A disease that damages the optic nerve`,
                expectedImprovement: true
            },
            {
                name: 'Quality Enhancement',
                content: `1. AMD causes?
                         2. IOP normal range?`,
                expectedEnhancement: true
            }
        ];

        for (const testCase of testCases) {
            try {
                if (testCase.setupFeedback && window.enhancedFeedbackSystem) {
                    // Simulate previous feedback for improvement
                    const questionHash = 'test_question_' + Date.now();
                    window.enhancedFeedbackSystem.recordImprovement(questionHash, {
                        type: 'test_improvement',
                        details: 'Test improvement for enhanced extraction',
                        timestamp: Date.now()
                    });
                }
                
                if (window.enhancedQAExtractor && window.enhancedQAExtractor.extractFromTextWithFeedback) {
                    const result = await window.enhancedQAExtractor.extractFromTextWithFeedback(testCase.content);
                    
                    const hasImprovements = result.metadata?.improvementStats?.totalImproved > 0;
                    const status = hasImprovements ? 'PASS' : 'PARTIAL';
                    const detail = `${result.questions.length} questions, ${result.metadata?.improvementStats?.totalImproved || 0} improved`;
                    
                    this.logTestResult(testCase.name, status, detail);
                } else {
                    this.logTestResult(testCase.name, 'SKIP', 'Feedback integration not available');
                }
            } catch (error) {
                this.logTestResult(testCase.name, 'FAIL', error.message);
            }
        }
    }

    // Performance test
    async testPerformance() {
        console.log('🧪 Testing Performance...');
        
        const largeContent = this.generateLargeTestContent();
        const startTime = Date.now();
        
        try {
            if (window.enhancedQAExtractor) {
                const result = await window.enhancedQAExtractor.extractFromText(largeContent, {
                    confidenceThreshold: 0.4
                });
                
                const processingTime = Date.now() - startTime;
                const questionsPerSecond = Math.round(result.questions.length / (processingTime / 1000));
                
                const status = processingTime < 10000 ? 'PASS' : 'SLOW';
                const detail = `${result.questions.length} questions in ${processingTime}ms (${questionsPerSecond} Q/s)`;
                
                this.logTestResult('Large Content Processing', status, detail);
            } else {
                this.logTestResult('Large Content Processing', 'SKIP', 'Enhanced extractor not available');
            }
        } catch (error) {
            this.logTestResult('Large Content Processing', 'FAIL', error.message);
        }
    }

    // Generate large test content
    generateLargeTestContent() {
        const questionTemplates = [
            'What is the treatment for {condition}?\nA) {treatment1}\nB) {treatment2}\nC) {treatment3}\nAnswer: A',
            'Case: Patient with {symptom}. Most likely diagnosis?\nA) {diagnosis1}\nB) {diagnosis2}\nC) {diagnosis3}\nAnswer: B',
            'True or False: {statement}\nAnswer: True',
            'The normal range for {parameter} is ___.\nAnswer: {range}'
        ];

        const variables = {
            condition: ['glaucoma', 'AMD', 'diabetic retinopathy', 'cataract', 'retinal detachment'],
            treatment1: ['surgery', 'medication', 'laser therapy', 'observation', 'injection'],
            treatment2: ['drops', 'oral medication', 'lifestyle changes', 'glasses', 'patch'],
            treatment3: ['implant', 'transplant', 'radiation', 'cryotherapy', 'phototherapy'],
            symptom: ['vision loss', 'eye pain', 'flashing lights', 'floaters', 'double vision'],
            diagnosis1: ['glaucoma', 'cataract', 'AMD', 'diabetic retinopathy', 'uveitis'],
            diagnosis2: ['retinal detachment', 'vitreous hemorrhage', 'optic neuritis', 'keratitis', 'conjunctivitis'],
            diagnosis3: ['dry eye', 'allergic reaction', 'migraine', 'stroke', 'tumor'],
            statement: ['OCT is useful for retinal imaging', 'IOP above 21 always indicates glaucoma', 'Cataracts are reversible'],
            parameter: ['IOP', 'visual acuity', 'cup-to-disc ratio', 'corneal thickness', 'axial length'],
            range: ['10-21 mmHg', '20/20', '0.3-0.5', '500-600 microns', '22-25 mm']
        };

        let content = '';
        for (let i = 0; i < 100; i++) {
            const template = questionTemplates[i % questionTemplates.length];
            let question = template.replace(/\{(\w+)\}/g, (match, key) => {
                const options = variables[key];
                return options ? options[Math.floor(Math.random() * options.length)] : match;
            });
            
            content += `\n\n${i + 1}. ${question}`;
        }
        
        return content;
    }

    // Log test result
    logTestResult(testName, status, details) {
        const result = {
            name: testName,
            status: status,
            details: details,
            timestamp: new Date().toISOString()
        };
        
        this.testResults.push(result);
        
        const icon = status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : status === 'SKIP' ? '⏭️' : '⚠️';
        console.log(`${icon} ${testName}: ${status} - ${details}`);
    }

    // Run all tests
    async runAllTests() {
        console.log('🚀 Testing Enhanced Extraction System...');
        this.startTime = Date.now();
        
        await this.testAdvancedFileProcessor();
        await this.testEnhancedQuestionBlocks();
        await this.testContentAnalysis();
        await this.testAnswerExtraction();
        await this.testFeedbackIntegration();
        await this.testPerformance();
        
        this.generateReport();
    }

    // Generate comprehensive test report
    generateReport() {
        const totalTime = Date.now() - this.startTime;
        const passed = this.testResults.filter(r => r.status === 'PASS').length;
        const failed = this.testResults.filter(r => r.status === 'FAIL').length;
        const skipped = this.testResults.filter(r => r.status === 'SKIP').length;
        const partial = this.testResults.filter(r => r.status === 'PARTIAL').length;
        
        console.log('\n📊 Enhanced Extraction Test Report');
        console.log('='.repeat(50));
        console.log(`Total Tests: ${this.testResults.length}`);
        console.log(`✅ Passed: ${passed}`);
        console.log(`❌ Failed: ${failed}`);
        console.log(`⚠️ Partial: ${partial}`);
        console.log(`⏭️ Skipped: ${skipped}`);
        console.log(`⏱️ Total Time: ${totalTime}ms`);
        console.log(`📈 Success Rate: ${Math.round((passed / (passed + failed + partial)) * 100)}%`);
        
        // Store results for analytics
        if (window.testResults) {
            window.testResults.enhancedExtraction = this.testResults;
        }
        
        return {
            summary: {
                total: this.testResults.length,
                passed,
                failed,
                partial,
                skipped,
                totalTime,
                successRate: Math.round((passed / (passed + failed + partial)) * 100)
            },
            results: this.testResults
        };
    }
}

// Initialize and expose test functions
window.enhancedExtractionTest = new EnhancedExtractionTest();

// Convenience functions
window.testEnhancedExtraction = () => window.enhancedExtractionTest.runAllTests();
window.testFileProcessor = () => window.enhancedExtractionTest.testAdvancedFileProcessor();
window.testQuestionBlocks = () => window.enhancedExtractionTest.testEnhancedQuestionBlocks();
window.testExtractionPerformance = () => window.enhancedExtractionTest.testPerformance();

// Auto-run test when page loads (for development)
document.addEventListener('DOMContentLoaded', function() {
    // Delay to ensure all components are loaded
    setTimeout(() => {
        if (window.location.search.includes('test=extraction')) {
            console.log('🧪 Auto-running enhanced extraction tests...');
            window.testEnhancedExtraction();
        }
    }, 2000);
});

console.log('🧪 Enhanced Extraction Test Suite loaded! Run testEnhancedExtraction() to start testing.'); 
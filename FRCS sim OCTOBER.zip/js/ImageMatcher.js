// Lightweight image-text matching using CLIP via transformers.js (if available)
// Falls back gracefully when the model is unavailable

(function(){
  class ImageMatcher {
    constructor() {
      this.isReady = false;
      this.maxIndexImages = 1500; // broader coverage
      this.imageEmbeddings = new Map(); // key -> Float32Array
      this.keyToUrl = new Map();
      this.imageTokens = new Map(); // key -> Set<string>
      this.model = null;
      this.tokenizer = null;
      this._indexing = false;
      this._indexedOnce = false;
      this.recentKeys = [];
      this.recentLimit = 12;
      this.stopwords = new Set(['the','a','an','of','to','and','or','with','in','on','for','by','as','at','is','are','be','this','that','these','those','patient','case']);

      // Domain knowledge: ophthalmology synonyms and aliases commonly found in Kanski media
      this.ophthalmologySynonyms = new Map([
        ['amd', ['age related macular degeneration','macular degeneration','drusen','cnv','geographic atrophy','neovascular']],
        ['drusen', ['amd','macular degeneration']],
        ['cnv', ['choroidal neovascularization','neovascular amd','wet amd','subretinal membrane']],
        ['ga', ['geographic atrophy','dry amd']],
        ['rnfl', ['retinal nerve fiber layer','nerve fibre layer']],
        ['vf', ['visual field','perimetry','humphrey','hvf','30-2','24-2','10-2','md','psd']],
        ['hvf', ['visual field','vf','humphrey']],
        ['oct', ['optical coherence tomography','b-scan','bscan','macular thickness','retinal layers']],
        ['disc', ['optic disc','optic nerve head','optic nerve']],
        ['glaucoma', ['cupping','increased cup','cdr','rnfl defect','vf defect','hvf']],
        ['pdr', ['proliferative diabetic retinopathy','neovascularization']],
        ['npdr', ['non proliferative diabetic retinopathy']],
        ['diabetic retinopathy', ['npdr','pdr','microaneurysm','dot blot hemorrhage','cotton wool','macular edema']],
        ['keratoconus', ['cone','fleischer ring','vogt striae']],
        ['fluorescein', ['stain','staining','fluorescein stain']],
        ['ptosis', ['levator dehiscence','lid droop']],
        ['chalazion', ['meibomian cyst','hordeolum','stye']],
        ['papilledema', ['disc swelling','frisen']],
        ['rd', ['retinal detachment']],
        ['slitlamp', ['slit lamp','anterior segment','cornea','conjunctiva','iris','ac']],
        ['fundus', ['retina','posterior pole','optic disc','macula','vessels']],
      ]);

      // Modality hint regexes
      this.modalityHints = {
        fundus: /(fundus|retina|macula|drusen|amd|cnv|disc|optic|rnfl|vessel|fovea|choroid)/i,
        slit: /(slit\s*lamp|cornea|kerato|ulcer|conjunctiva|pterygium|iris|anterior|fluorescein|stain)/i,
        oct: /(\boct\b|optical coherence|b-?scan|cube|thickness|segmentation|retinal layers)/i,
        vf: /(\bvf\b|hvf|humphrey|visual field|perimetry|24-2|30-2|10-2|md\b|psd\b)/i,
        external: /(external|eyelid|ptosis|chalazion|orbit|dermoid|oculoplastic|lid)/i
      };

      // Index of media filename -> tokens aggregated from Kanski notes/tags
      this.mediaNameToTokens = new Map();
      this.cardIndexBuilt = false;
      this.siblingNameCache = new Map(); // key -> descriptive sibling key (if any)
    }

    async initialize() {
      // No ESM-friendly environment under file://; disable CLIP and use lexical-only ranking
      this.isReady = true;
      this.model = null;
      return true;
    }

    async indexImages(imagesMap) {
      if (!imagesMap) return 0;
      // Build card-derived token index once if APKG notes are available
      this.buildCardIndexIfNeeded();
      const keys = imagesMap instanceof Map ? Array.from(imagesMap.keys()) : Object.keys(imagesMap);
      // Shuffle to avoid always indexing the same early subset
      const shuffled = keys.slice();
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      const limit = Math.min(this.maxIndexImages, shuffled.length);
      const slice = shuffled.slice(0, limit);
      let count = 0;
      for (const key of slice) {
        try {
          const url = imagesMap instanceof Map ? imagesMap.get(key) : imagesMap[key];
          if (!url) continue;
          this.keyToUrl.set(key, url);
          // Build enriched tokens using filename, sibling descriptive names, and APKG card text
          this.imageTokens.set(key, this.buildTokensForKey(key));
          if (!this.isReady) continue;
          const embedding = await this.embedImage(url);
          if (embedding) {
            this.imageEmbeddings.set(key, embedding);
            count++;
          }
        } catch (_) {}
      }
      return count;
    }

    ensureBackgroundIndex(imagesMap) {
      if (this._indexing) return;
      this._indexing = true;
      const work = async () => {
        try {
          if (!this.isReady) {
            const ok = await this.initialize();
            if (!ok) { this._indexing = false; return; }
          }
          await this.indexImages(imagesMap);
        } finally {
          this._indexedOnce = true;
          this._indexing = false;
        }
      };
      if ('requestIdleCallback' in window) {
        window.requestIdleCallback(() => { work(); });
      } else {
        setTimeout(work, 0);
      }
    }

    async embedImage(url) {
      // Disabled in non-module environment
      return null;
    }

    async embedText(text) {
      // Disabled in non-module environment
      return null;
    }

    tokenize(text) {
      const tokens = new Set();
      if (!text) return tokens;
      const parts = String(text).toLowerCase().split(/[^a-z0-9]+/g);
      for (const p of parts) {
        if (!p || p.length < 2) continue;
        if (this.stopwords.has(p)) continue;
        tokens.add(p);
      }
      return tokens;
    }

    tokenizeWithSynonyms(text) {
      const base = this.tokenize(text);
      return this.expandSynonyms(base);
    }

    expandSynonyms(tokenSet) {
      if (!tokenSet || tokenSet.size === 0) return tokenSet || new Set();
      const out = new Set(tokenSet);
      const add = (t) => { if (t && !this.stopwords.has(t)) out.add(t); };
      // Simple stemming for plurals/verb endings
      const stem = (w) => {
        if (w.endsWith('ies') && w.length > 4) return w.slice(0, -3) + 'y';
        if (w.endsWith('ses') && w.length > 4) return w.slice(0, -2);
        if (w.endsWith('s') && !w.endsWith('us') && w.length > 3) return w.slice(0, -1);
        if (w.endsWith('ing') && w.length > 5) return w.slice(0, -3);
        if (w.endsWith('ed') && w.length > 4) return w.slice(0, -2);
        return w;
      };
      const seen = Array.from(tokenSet);
      for (const t of seen) {
        const s = stem(t);
        add(s);
        // Map through domain synonyms
        if (this.ophthalmologySynonyms.has(t)) {
          for (const alias of this.ophthalmologySynonyms.get(t)) add(alias.replace(/\s+/g, ' '));
        }
        if (this.ophthalmologySynonyms.has(s)) {
          for (const alias of this.ophthalmologySynonyms.get(s)) add(alias.replace(/\s+/g, ' '));
        }
      }
      // Also add back compacted aliases as single tokens (e.g., optic nerve -> optic, nerve)
      const more = new Set(out);
      for (const term of more) {
        if (term.includes(' ')) {
          const parts = term.split(/\s+/g);
          for (const p of parts) add(p);
        }
      }
      return out;
    }

    extractBasename(name) {
      if (!name) return '';
      const str = String(name);
      const parts = str.split('/');
      const base = parts[parts.length - 1];
      return base;
    }

    buildCardIndexIfNeeded() {
      if (this.cardIndexBuilt) return;
      try {
        const cards = window.kanskiCards;
        if (!cards) { this.cardIndexBuilt = true; return; }
        const iter = cards instanceof Map ? cards.values() : Object.values(cards);
        for (const note of iter) {
          if (!note) continue;
          const text = [note.primary, ...(note.fields || []), note.tags].filter(Boolean).join(' ').toLowerCase();
          const tok = this.tokenizeWithSynonyms(text);
          const imgs = Array.isArray(note.images) ? note.images : [];
          for (const src of imgs) {
            const base = this.extractBasename(src).toLowerCase();
            if (!base) continue;
            const existing = this.mediaNameToTokens.get(base) || new Set();
            tok.forEach(t => existing.add(t));
            this.mediaNameToTokens.set(base, existing);
          }
        }
      } catch (_) {}
      this.cardIndexBuilt = true;
    }

    findSiblingDescriptiveKey(key) {
      if (this.siblingNameCache.has(key)) return this.siblingNameCache.get(key);
      const url = this.keyToUrl.get(key);
      if (!url) { this.siblingNameCache.set(key, null); return null; }
      let found = null;
      for (const [k, u] of this.keyToUrl.entries()) {
        if (u !== url) continue;
        if (k === key) continue;
        const base = this.extractBasename(k);
        if (/[a-zA-Z]/.test(base)) { found = k; break; }
      }
      this.siblingNameCache.set(key, found);
      return found;
    }

    buildTokensForKey(key) {
      const tokens = new Set();
      const addSet = (s) => { if (s) for (const t of s) tokens.add(t); };
      // From the key itself
      addSet(this.tokenize(String(key)));
      // From a sibling descriptive filename pointing to same blob (handles numeric-only ids)
      const sibling = this.findSiblingDescriptiveKey(key);
      if (sibling) addSet(this.tokenize(String(sibling)));
      // From APKG card index using basename
      const base = this.extractBasename(key).toLowerCase();
      if (this.mediaNameToTokens.has(base)) addSet(this.mediaNameToTokens.get(base));
      // Try also without extension
      const baseNoExt = base.replace(/\.[a-z0-9]+$/i, '');
      if (this.mediaNameToTokens.has(baseNoExt)) addSet(this.mediaNameToTokens.get(baseNoExt));
      // Expand with synonyms for richer matching
      return this.expandSynonyms(tokens);
    }

    computeLexicalScore(questionText, key) {
      const qTokens = this.tokenizeWithSynonyms(questionText);
      const kTokens = this.imageTokens.get(key) || this.buildTokensForKey(key);
      if (!qTokens.size || !kTokens.size) return 0;
      let overlap = 0;
      qTokens.forEach(t => { if (kTokens.has(t)) overlap++; });
      // Jaccard-like
      const denom = qTokens.size + kTokens.size - overlap;
      return denom > 0 ? overlap / denom : 0;
    }

    modalityBoost(questionText, key) {
      try {
        const q = String(questionText || '');
        const wantFundus = this.modalityHints.fundus.test(q);
        const wantSlit = this.modalityHints.slit.test(q);
        const wantOCT = this.modalityHints.oct.test(q);
        const wantVF = this.modalityHints.vf.test(q);
        const wantExternal = this.modalityHints.external.test(q);
        const keyStr = `${key} ${this.extractBasename(key)}`.toLowerCase();
        const toks = this.imageTokens.get(key) || this.buildTokensForKey(key);
        const has = (re) => re.test(keyStr) || Array.from(toks).some(t => re.test(t));
        let boost = 0;
        if (wantFundus && has(this.modalityHints.fundus)) boost += 0.15;
        if (wantSlit && has(this.modalityHints.slit)) boost += 0.15;
        if (wantOCT && has(this.modalityHints.oct)) boost += 0.2;
        if (wantVF && has(this.modalityHints.vf)) boost += 0.2;
        if (wantExternal && has(this.modalityHints.external)) boost += 0.1;
        return boost; // [0, ~0.8]
      } catch (_) { return 0; }
    }

    static cosineSimilarity(a, b) {
      if (!a || !b || a.length !== b.length) return -1;
      let dot = 0, na = 0, nb = 0;
      for (let i = 0; i < a.length; i++) {
        const va = a[i];
        const vb = b[i];
        dot += va * vb;
        na += va * va;
        nb += vb * vb;
      }
      if (na === 0 || nb === 0) return -1;
      return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }

    async findBestMatch(questionText) {
      if (!this.keyToUrl.size) return null;
      if (!this.isReady) return null;
      const textVec = await this.embedText(questionText);
      if (!textVec) return null;
      // Rank and avoid recently used keys to reduce repetition; blend CLIP similarity with lexical overlap
      const candidates = [];
      const alpha = 0.8; // weight for CLIP
      const beta = 0.2;  // weight for lexical
      for (const [key, imgVec] of this.imageEmbeddings.entries()) {
        const clip = ImageMatcher.cosineSimilarity(textVec, imgVec); // [-1,1]
        const clipNorm = (clip + 1) / 2; // [0,1]
        const lex = this.computeLexicalScore(questionText, key); // [0,1]
        const score = alpha * clipNorm + beta * lex;
        candidates.push([key, score]);
      }
      candidates.sort((a, b) => b[1] - a[1]);
      for (const [key, score] of candidates) {
        if (this.recentKeys.includes(key)) continue;
        const url = this.keyToUrl.get(key);
        if (!url) continue;
        return { key, url, score };
      }
      // Fallback to top if all were recently used
      if (candidates.length) {
        const [key, score] = candidates[0];
        const url = this.keyToUrl.get(key);
        if (url) return { key, url, score };
      }
      return null;
    }

    markUsed(key) {
      if (!key) return;
      this.recentKeys.push(key);
      if (this.recentKeys.length > this.recentLimit) this.recentKeys.shift();
    }

    // Return top ranked candidate keys with scores for downstream reranking
    async rankCandidates(questionText, limit = 20) {
      if (!this.keyToUrl.size) return [];
      // Lexical ranking with ophthalmology-aware boosts
      const candidates = [];
      for (const key of this.keyToUrl.keys()) {
        const baseScore = this.computeLexicalScore(questionText, key);
        const modeBoost = this.modalityBoost(questionText, key);
        const score = baseScore + modeBoost;
        candidates.push([key, score]);
      }
      candidates.sort((a, b) => b[1] - a[1]);
      const out = [];
      for (const [key, score] of candidates) {
        if (this.recentKeys.includes(key)) continue;
        out.push([key, score]);
        if (out.length >= limit) break;
      }
      return out;
    }
  }

  window.imageMatcher = new ImageMatcher();
})();



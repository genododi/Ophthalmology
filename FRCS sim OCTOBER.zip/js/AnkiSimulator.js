(function(){
  const STORAGE_KEY = 'ankiSimulatorState_v1';

  function saveState(state){
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch(_) {}
  }
  function loadState(){
    try { const raw = localStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : null; } catch(_) { return null; }
  }
  function clearState(){ try { localStorage.removeItem(STORAGE_KEY); } catch(_) {}

  }

  function sanitizeHtml(html){
    const div = document.createElement('div');
    div.innerHTML = html || '';
    // Remove script tags and on* handlers
    div.querySelectorAll('script').forEach(s => s.remove());
    div.querySelectorAll('*').forEach(el => {
      [...el.attributes].forEach(attr => {
        const name = attr.name.toLowerCase();
        if (name.startsWith('on')) el.removeAttribute(attr.name);
      });
    });
    return div.innerHTML;
  }

  function isImageFilename(name){
    if (!name) return false;
    const n = String(name).trim();
    return /\.(jpg|jpeg|png|gif|webp|bmp|tif|tiff)$/i.test(n);
  }

  function buildImageIndex(){
    try {
      if (window.__kanskiImageIndex && window.__kanskiImageIndexVersion === 1) return;
      const index = new Map();
      const add = (key, url) => {
        try {
          const base = String(key).split('/').pop();
          const lowFull = String(key).toLowerCase();
          const lowBase = String(base || key).toLowerCase();
          if (lowFull && !index.has(lowFull)) index.set(lowFull, url);
          if (lowBase && !index.has(lowBase)) index.set(lowBase, url);
        } catch(_) {}
      };
      if (window.kanskiImages instanceof Map) {
        for (const [k, v] of window.kanskiImages.entries()) add(k, v);
      } else if (window.kanskiImages && typeof window.kanskiImages === 'object') {
        for (const k in window.kanskiImages) add(k, window.kanskiImages[k]);
      }
      window.__kanskiImageIndex = index;
      window.__kanskiImageIndexVersion = 1;
    } catch(_) {}
  }

  function getMediaUrl(name){
    if (!name) return null;
    buildImageIndex();
    const candidates = [];
    const raw = String(name).trim();
    const base = raw.split('/').pop();
    candidates.push(raw);
    if (base && base !== raw) candidates.push(base);
    const lower = raw.toLowerCase();
    const lowerBase = base ? base.toLowerCase() : lower;
    candidates.push(lower);
    if (lowerBase !== lower) candidates.push(lowerBase);
    // Try exact/index lookups first
    for (const c of candidates) {
      if (window.kanskiImages instanceof Map && window.kanskiImages.has(c)) return window.kanskiImages.get(c);
      if (window.__kanskiImageIndex instanceof Map && window.__kanskiImageIndex.has(c)) return window.__kanskiImageIndex.get(c);
      if (window.kanskiImages && typeof window.kanskiImages === 'object' && c in window.kanskiImages) return window.kanskiImages[c];
    }
    // Last resort: scan Map keys to find case-insensitive base-name match
    try {
      const target = lowerBase;
      if (window.kanskiImages instanceof Map) {
        for (const [k, v] of window.kanskiImages.entries()) {
          const b = String(k).split('/').pop().toLowerCase();
          if (b === target) return v;
        }
      } else if (window.kanskiImages && typeof window.kanskiImages === 'object') {
        for (const k in window.kanskiImages) {
          const b = String(k).split('/').pop().toLowerCase();
          if (b === target) return window.kanskiImages[k];
        }
      }
    } catch(_) {}
    return null;
  }

  function renderMediaAware(html){
    const container = document.createElement('div');
    const original = String(html || '').trim();
    // If field is just an image filename, wrap as <img>
    if (isImageFilename(original) && !/[<>]/.test(original)) {
      const url = getMediaUrl(original) || original;
      container.innerHTML = `<img src="${url}">`;
    } else {
      container.innerHTML = sanitizeHtml(original);
    }
    // Resolve <img src> through kanskiImages if present
    container.querySelectorAll('img').forEach(img => {
      const src = img.getAttribute('src');
      if (!src) return;
      const resolved = getMediaUrl(src);
      if (resolved) img.src = resolved;
      img.loading = 'lazy';
      img.decoding = 'async';
      img.style.maxWidth = '100%';
      img.style.height = 'auto';
    });
    return container.innerHTML;
  }

  function computeNow(){ return Date.now(); }

  function createScheduler(initialCards){
    const now = computeNow();
    const queue = [];
    const stateById = new Map();

    (initialCards || []).forEach(card => {
      const s = {
        id: card.id,
        intervalMs: 0,
        ease: 2500,
        due: now,
        reps: 0,
        lapses: 0
      };
      stateById.set(card.id, s);
      queue.push(card.id);
    });

    function pickNext(){
      // Simple: pick the first due card; if none due, next in queue
      const nowTs = computeNow();
      let idx = queue.findIndex(id => (stateById.get(id) || {}).due <= nowTs);
      if (idx === -1) idx = 0;
      return queue[idx] || null;
    }

    function reschedule(id, rating){
      const s = stateById.get(id);
      if (!s) return;
      const nowTs = computeNow();
      // Minimal SM-2 inspired
      if (rating === 'again') {
        s.intervalMs = 10 * 1000; // 10s
        s.ease = Math.max(1300, s.ease - 200);
        s.lapses += 1;
      } else if (rating === 'good') {
        s.reps += 1;
        if (s.intervalMs === 0) s.intervalMs = 60 * 1000; // 1m
        else s.intervalMs = Math.min(30 * 24 * 3600 * 1000, Math.round(s.intervalMs * (s.ease / 1000)));
      } else if (rating === 'easy') {
        s.reps += 1;
        s.ease = Math.min(3500, s.ease + 100);
        if (s.intervalMs === 0) s.intervalMs = 5 * 60 * 1000; // 5m
        else s.intervalMs = Math.min(60 * 24 * 3600 * 1000, Math.round(s.intervalMs * (s.ease / 900)));
      }
      s.due = nowTs + s.intervalMs;
      // Move card to back
      const i = queue.indexOf(id);
      if (i >= 0) { queue.splice(i, 1); queue.push(id); }
    }

    function snapshot(){
      return { queue: [...queue], states: [...stateById.entries()], version: 1 };
    }

    function restore(snap){
      try {
        if (!snap) return;
        queue.length = 0; queue.push(...snap.queue);
        stateById.clear();
        snap.states.forEach(([id, s]) => stateById.set(id, s));
      } catch(_) {}
    }

    return { pickNext, reschedule, snapshot, restore };
  }

  function extractCardsFromKanski(){
    // Prefer fully rendered cards if available
    if (Array.isArray(window.kanskiRenderedCards) && window.kanskiRenderedCards.length > 0) {
      return window.kanskiRenderedCards.map(c => ({
        id: String(c.id),
        frontHtml: c.frontHtml || '',
        backHtml: c.backHtml || ''
      }));
    }
    const notes = window.kanskiCards;
    const out = [];
    if (notes && notes instanceof Map) {
      for (const [, note] of notes) {
        const front = (note.fields && note.fields[0]) || note.primary || '';
        const back = (note.fields && note.fields[1]) || '';
        const imagesHtml = (note.images || []).map(src => `<div><img src="${src}" /></div>`).join('');
        out.push({ id: String(note.id || note.guid || Math.random()), frontHtml: front, backHtml: back || imagesHtml });
      }
    }
    return out;
  }

  function buildCardsFromSqlRows(db){
    try {
      let res = null;
      try {
        res = db.exec('SELECT id, flds FROM notes');
      } catch (_) {
        try { res = db.exec('SELECT id, flds FROM Notes'); } catch(_) {}
      }
      if (!res || !res[0]) return [];
      const cols = res[0].columns; const rows = res[0].values;
      const iId = cols.indexOf('id'); const iFlds = cols.indexOf('flds');
      const out = [];
      for (const row of rows) {
        const id = String(row[iId]);
        const fldsRaw = String(row[iFlds] || '');
        let fields = fldsRaw.split('\u001f'); if (fields.length === 1) fields = fldsRaw.split('\x1f'); if (fields.length === 1) fields = fldsRaw.split('\u001F');
        out.push({ id, frontHtml: fields[0] || '', backHtml: fields[1] || '' });
      }
      return out;
    } catch(_) { return []; }
  }

  async function handleFile(file){
    const status = document.getElementById('anki-status');
    if (status) { status.textContent = 'Parsing deck...'; }
    try {
      const summary = await window.processUploadedApkgFile(file);
      const cardsA = extractCardsFromKanski();
      let cards = cardsA;
      if (!cards || cards.length === 0) {
        // Fallback: try to parse raw with JSZip + sql.js quickly
        try {
          const zip = await JSZip.loadAsync(file);
          const coll = zip.file(/(^|\/)collection\.(anki2|anki21|sqlite|db)$/i)[0];
          if (coll) {
            const dbBytes = await coll.async('uint8array');
            const SQL = await (typeof initSqlJs === 'function' ? initSqlJs({ locateFile: f => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/${f}` }) : null);
            if (SQL) {
              const db = new SQL.Database(dbBytes);
              cards = buildCardsFromSqlRows(db);
            }
          }
        } catch(_) {}
      }
      startSession(cards || [], summary);
    } catch (e) {
      if (status) { status.textContent = 'Failed to parse deck: ' + e.message; }
    }
  }

  function startSession(cards, summary){
    const status = document.getElementById('anki-status');
    const counters = document.getElementById('anki-counters');
    const front = document.getElementById('anki-front');
    const back = document.getElementById('anki-back');
    const flipBtn = document.getElementById('anki-flip');
    const againBtn = document.getElementById('anki-again');
    const goodBtn = document.getElementById('anki-good');
    const easyBtn = document.getElementById('anki-easy');

    if (!cards || cards.length === 0) {
      if (status) status.textContent = 'No cards detected in the .apkg';
      if (front) front.innerHTML = '';
      if (back) back.innerHTML = '';
      return;
    }

    const scheduler = createScheduler(cards);

    function updateCounters(){
      const total = cards.length;
      if (counters) counters.textContent = `${total} cards loaded`;
    }

    function showCardSide(which){
      if (which === 'front') {
        front.classList.remove('hidden');
        back.classList.add('hidden');
        flipBtn.textContent = 'Show Answer';
        againBtn.classList.add('hidden');
        goodBtn.classList.add('hidden');
        easyBtn.classList.add('hidden');
      } else {
        front.classList.add('hidden');
        back.classList.remove('hidden');
        flipBtn.textContent = 'Show Question';
        againBtn.classList.remove('hidden');
        goodBtn.classList.remove('hidden');
        easyBtn.classList.remove('hidden');
      }
    }

    function renderCurrent(){
      const id = scheduler.pickNext();
      if (!id) { if (status) status.textContent = 'All done for now!'; return; }
      const card = cards.find(c => c.id === id) || cards[0];
      if (front) front.innerHTML = renderMediaAware(card.frontHtml || '');
      if (back) back.innerHTML = renderMediaAware(card.backHtml || '');
      showCardSide('front');
      saveState({ currentId: card.id, cards, sched: scheduler.snapshot() });
    }

    // Restore state if exists
    const saved = loadState();
    if (saved && saved.cards && saved.sched) {
      try {
        cards = saved.cards;
        scheduler.restore(saved.sched);
      } catch(_) {}
    }

    updateCounters();
    renderCurrent();

    flipBtn.onclick = function(){
      if (back.classList.contains('hidden')) showCardSide('back'); else showCardSide('front');
    };
    againBtn.onclick = function(){ const id = scheduler.pickNext(); scheduler.reschedule(id, 'again'); renderCurrent(); };
    goodBtn.onclick = function(){ const id = scheduler.pickNext(); scheduler.reschedule(id, 'good'); renderCurrent(); };
    easyBtn.onclick = function(){ const id = scheduler.pickNext(); scheduler.reschedule(id, 'easy'); renderCurrent(); };

    if (status) {
      const imgs = (window.kanskiImages && (window.kanskiImages.size || Object.keys(window.kanskiImages).length)) || 0;
      const count = typeof imgs === 'number' ? imgs : 0;
      status.textContent = `Loaded ${cards.length} cards · Media: ${count}`;
    }
  }

  function wireUI(){
    const upload = document.getElementById('anki-upload');
    const reset = document.getElementById('anki-reset');
    if (upload) {
      upload.addEventListener('change', function(e){
        const f = e.target.files && e.target.files[0];
        if (f) handleFile(f);
      });
    }
    if (reset) {
      reset.addEventListener('click', function(){
        clearState();
        const status = document.getElementById('anki-status');
        if (status) status.textContent = 'Session reset. Load a .apkg to start';
        const front = document.getElementById('anki-front'); if (front) front.innerHTML = '';
        const back = document.getElementById('anki-back'); if (back) back.innerHTML = '';
      });
    }
  }

  function onReady(fn){
    if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(fn, 0);
    else document.addEventListener('DOMContentLoaded', fn);
  }

  onReady(wireUI);
})();

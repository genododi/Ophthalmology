class OfflineStorageManager {
    
    constructor() {
        this.storage = window.localStorage;
        this.questionSetsKey = 'ophthalmoqa_offline_sets';
        this.questionSetsVisibilityKey = 'ophthalmoqa_offline_sets_visible';
        
        // Enhanced persistent storage initialization
        this.initializePersistentStorage();
        this.questionSets = this.loadQuestionSets();
        
        // Initialize UI elements
        this.offlineQuestionsSection = document.getElementById('offline-questions-section');
        this.offlineSetsList = document.getElementById('offline-sets-list');
        this.noOfflineSets = document.getElementById('no-offline-sets');
        this.clearAllOfflineBtn = document.getElementById('clear-all-offline-btn');
        this.saveOfflineBtn = document.getElementById('save-offline-btn');
        this.offlineModeIndicator = document.getElementById('offline-mode-indicator');
        this.offlineSetsCount = document.getElementById('offline-sets-count');
        
        // Save Question Set modal elements
        this.saveQuestionSetModal = document.getElementById('save-question-set-modal');
        this.saveQuestionSetModalBackdrop = document.getElementById('save-question-set-modal-backdrop');
        this.closeQuestionSetModalBtn = document.getElementById('close-save-question-modal');
        this.questionSetTitleInput = document.getElementById('question-set-title');
        this.questionSetDescriptionInput = document.getElementById('question-set-description');
        this.questionSetFavoriteCheckbox = document.getElementById('question-set-favorite');
        this.saveQuestionSetStatus = document.getElementById('save-question-set-status');
        this.confirmSaveQuestionSetBtn = document.getElementById('confirm-save-question-set');
        
        // View Question Set modal elements
        this.viewQuestionSetModal = document.getElementById('view-question-set-modal');
        this.viewQuestionSetModalBackdrop = document.getElementById('view-question-set-modal-backdrop');
        this.closeViewQuestionModalBtn = document.getElementById('close-view-question-modal');
        this.viewQuestionSetTitle = document.getElementById('view-question-set-title');
        this.viewQuestionSetDescription = document.getElementById('view-question-set-description');
        this.viewQuestionSetDate = document.getElementById('view-question-set-date').querySelector('span');
        this.viewQuestionSetCount = document.getElementById('view-question-set-count').querySelector('span');
        this.viewQuestionSetSource = document.getElementById('view-question-set-source').querySelector('span');
        this.viewQuestionSetContent = document.getElementById('view-question-set-content');
        this.deleteQuestionSetBtn = document.getElementById('delete-question-set');
        this.loadQuestionSetBtn = document.getElementById('load-question-set');
        
        this.currentQuestionSet = null;
        this.questionGenerator = null;
        this.selectedQuestions = new Set(); // Track selected questions for saving
        
        this.initializeEventListeners();
        this.updateUI();
        this.initializeStorageNotification();
    }
    
    initializeStorageNotification() {
        // Show persistent storage notification
        setTimeout(() => {
            const notification = document.getElementById('storage-status-notification');
            const dismissBtn = document.getElementById('dismiss-storage-notification');
            
            if (notification) {
                // Check if user has dismissed this notification before
                const dismissed = localStorage.getItem('storage-notification-dismissed');
                if (!dismissed) {
                    notification.classList.remove('hidden');
                }
                
                // Handle dismiss button
                if (dismissBtn) {
                    dismissBtn.addEventListener('click', () => {
                        notification.classList.add('hidden');
                        localStorage.setItem('storage-notification-dismissed', 'true');
                    });
                }
            }
        }, 2000); // Show after 2 seconds to let other systems initialize
    }
    
    setQuestionGenerator(questionGenerator) {
        this.questionGenerator = questionGenerator;
    }
    
    // Enhanced persistent storage system
    async initializePersistentStorage() {
        try {
            // Request persistent storage permission for maximum durability
            if ('storage' in navigator && 'persist' in navigator.storage) {
                const isPersistent = await navigator.storage.persist();
                if (isPersistent) {
                    console.log('✅ Persistent storage granted - questions will be saved forever');
                } else {
                    console.warn('⚠️ Persistent storage not granted - using standard storage');
                }
            }
            
            // Initialize IndexedDB as backup storage
            this.initializeIndexedDB();
            
            // Set up storage quota monitoring
            this.monitorStorageQuota();
            
            // Enable service worker for offline support
            this.registerServiceWorker();
            
        } catch (error) {
            console.error('Error initializing persistent storage:', error);
        }
    }
    
    async initializeIndexedDB() {
        try {
            this.dbName = 'OphthalmoQA_OfflineStorage';
            this.dbVersion = 1;
            
            // Open IndexedDB for backup storage
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            request.onerror = () => {
                console.warn('IndexedDB backup storage unavailable');
            };
            
            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log('✅ IndexedDB backup storage initialized');
                
                // Sync any data from IndexedDB to localStorage if needed
                this.syncFromIndexedDB();
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create object store for question sets
                if (!db.objectStoreNames.contains('questionSets')) {
                    const store = db.createObjectStore('questionSets', { keyPath: 'id' });
                    store.createIndex('title', 'title', { unique: false });
                    store.createIndex('date', 'date', { unique: false });
                }
            };
            
        } catch (error) {
            console.error('Error initializing IndexedDB:', error);
        }
    }
    
    async monitorStorageQuota() {
        try {
            if ('storage' in navigator && 'estimate' in navigator.storage) {
                const estimate = await navigator.storage.estimate();
                const usedMB = (estimate.usage / (1024 * 1024)).toFixed(2);
                const quotaMB = (estimate.quota / (1024 * 1024)).toFixed(2);
                
                console.log(`📊 Storage usage: ${usedMB}MB / ${quotaMB}MB`);
                
                // Warning if storage is getting full
                if (estimate.usage / estimate.quota > 0.8) {
                    console.warn('⚠️ Storage quota nearly full - consider cleaning old data');
                }
            }
        } catch (error) {
            console.error('Error monitoring storage quota:', error);
        }
    }
    
    async registerServiceWorker() {
        try {
            if (!('serviceWorker' in navigator)) {
                console.log('Service Worker not supported');
                return;
            }

            // Check if we're running on HTTP/HTTPS
            if (location.protocol !== 'http:' && location.protocol !== 'https:') {
                console.log('Service Worker requires HTTP or HTTPS protocol, current protocol:', location.protocol);
                return;
            }

            // Create a simple service worker for offline support
            const swCode = `
                const CACHE_NAME = 'ophthalmoqa-cache-v1';
                const urlsToCache = [
                    '/',
                    '/css/styles.css',
                    '/FRCS simulator.html'
                ];

                self.addEventListener('install', event => {
                    event.waitUntil(
                        caches.open(CACHE_NAME)
                            .then(cache => cache.addAll(urlsToCache))
                    );
                });

                self.addEventListener('fetch', event => {
                    event.respondWith(
                        caches.match(event.request)
                            .then(response => response || fetch(event.request))
                    );
                });
            `;
            
            // Only register if we have a proper HTTP/HTTPS protocol
            if (location.protocol === 'http:' || location.protocol === 'https:') {
                const blob = new Blob([swCode], { type: 'application/javascript' });
                const swUrl = URL.createObjectURL(blob);
                
                await navigator.serviceWorker.register(swUrl);
                console.log('✅ Service worker registered for offline support');
                
                // Clean up the blob URL after registration
                URL.revokeObjectURL(swUrl);
            } else {
                console.log(`Service Worker registration skipped - unsupported protocol: ${location.protocol}. Requires HTTP or HTTPS.`);
            }
        } catch (error) {
            console.warn('Service Worker registration failed (this is normal for file:// protocol):', error.message);
        }
    }
    
    async syncFromIndexedDB() {
        try {
            if (!this.db) return;
            
            const transaction = this.db.transaction(['questionSets'], 'readonly');
            const store = transaction.objectStore('questionSets');
            const request = store.getAll();
            
            request.onsuccess = () => {
                const indexedDBSets = request.result;
                const localStorageSets = this.loadQuestionSets();
                
                // Merge any sets that exist in IndexedDB but not in localStorage
                let hasNewSets = false;
                indexedDBSets.forEach(dbSet => {
                    const existsInLocalStorage = localStorageSets.some(localSet => localSet.id === dbSet.id);
                    if (!existsInLocalStorage) {
                        localStorageSets.push(dbSet);
                        hasNewSets = true;
                    }
                });
                
                if (hasNewSets) {
                    this.questionSets = localStorageSets;
                    this.saveQuestionSets();
                    console.log('✅ Restored question sets from IndexedDB backup');
                }
            };
        } catch (error) {
            console.error('Error syncing from IndexedDB:', error);
        }
    }
    
    loadQuestionSets() {
        try {
            const setsJSON = this.storage.getItem(this.questionSetsKey);
            return setsJSON ? JSON.parse(setsJSON) : [];
        } catch (error) {
            console.error('Error loading offline question sets:', error);
            return [];
        }
    }
    
    saveQuestionSets() {
        try {
            // Save to localStorage (primary storage)
            this.storage.setItem(this.questionSetsKey, JSON.stringify(this.questionSets));
            
            // Also save to IndexedDB as backup (enhanced persistence)
            this.saveToIndexedDB();
            
            console.log('✅ Question sets saved to both localStorage and IndexedDB');
        } catch (error) {
            console.error('Error saving offline question sets:', error);
            
            // Try to save to IndexedDB only if localStorage fails
            this.saveToIndexedDB();
        }
    }
    
    async saveToIndexedDB() {
        try {
            if (!this.db) return;
            
            const transaction = this.db.transaction(['questionSets'], 'readwrite');
            const store = transaction.objectStore('questionSets');
            
            // Clear existing data and save current sets
            await store.clear();
            
            for (const questionSet of this.questionSets) {
                store.add(questionSet);
            }
            
            console.log('✅ Backup saved to IndexedDB');
        } catch (error) {
            console.error('Error saving to IndexedDB:', error);
        }
    }
    
    initializeEventListeners() {
        // Set Save Offline button handler
        if (this.saveOfflineBtn) {
            this.saveOfflineBtn.addEventListener('click', () => this.showSaveQuestionSetModal());
        }
        
        // Clear All button handler
        if (this.clearAllOfflineBtn) {
            this.clearAllOfflineBtn.addEventListener('click', () => this.clearAllQuestionSets());
        }
        // Clear Selected Sets handler
        const clearSelectedBtn = document.getElementById('clear-selected-sets-btn');
        if (clearSelectedBtn) {
            clearSelectedBtn.addEventListener('click', () => {
                // Find any set-selection checkboxes in offline sets list
                const selectedSetCheckboxes = document.querySelectorAll('#offline-sets-list .set-selection-checkbox input:checked');
                if (selectedSetCheckboxes.length === 0) {
                    alert('No selected sets to clear. Use "Select Sets to Merge" to select sets first.');
                    return;
                }
                if (!confirm(`Delete ${selectedSetCheckboxes.length} selected set(s)? This cannot be undone.`)) return;
                const idsToDelete = Array.from(selectedSetCheckboxes).map(cb => cb.getAttribute('data-set-id'));
                this.questionSets = this.questionSets.filter(set => !idsToDelete.includes(set.id));
                this.saveQuestionSets();
                this.updateUI();
            });
        }
        
        // Save Question Set modal handlers
        if (this.closeQuestionSetModalBtn) {
            this.closeQuestionSetModalBtn.addEventListener('click', () => this.hideSaveQuestionSetModal());
        }
        
        if (this.saveQuestionSetModalBackdrop) {
            this.saveQuestionSetModalBackdrop.addEventListener('click', () => this.hideSaveQuestionSetModal());
        }
        
        if (this.confirmSaveQuestionSetBtn) {
            this.confirmSaveQuestionSetBtn.addEventListener('click', () => this.saveCurrentQuestionSet());
        }
        
        // View Question Set modal handlers
        if (this.closeViewQuestionModalBtn) {
            this.closeViewQuestionModalBtn.addEventListener('click', () => this.hideViewQuestionSetModal());
        }
        
        if (this.viewQuestionSetModalBackdrop) {
            this.viewQuestionSetModalBackdrop.addEventListener('click', () => this.hideViewQuestionSetModal());
        }
        
        if (this.deleteQuestionSetBtn) {
            this.deleteQuestionSetBtn.addEventListener('click', () => {
                if (this.currentQuestionSet) {
                    this.deleteQuestionSet(this.currentQuestionSet.id);
                    this.hideViewQuestionSetModal();
                }
            });
        }
        
        if (this.loadQuestionSetBtn) {
            this.loadQuestionSetBtn.addEventListener('click', () => {
                if (this.currentQuestionSet && this.questionGenerator) {
                    // Clear the form and existing questions before loading new ones
                    this.clearForm();
                    
                    // Load the question set
                    this.questionGenerator.loadQuestionSet(this.currentQuestionSet);
                    
                    // Hide the modal
                    this.hideViewQuestionSetModal();
                }
            });
        }
        
        // Always show the offline section by default (requirement #1)
        this.setSectionVisibility(true);
        
        // Show the offline section on page load
        window.addEventListener('DOMContentLoaded', () => {
            this.updateUI();
        });
        
        // Add event delegation for question selection
        const qaContainer = document.getElementById('qa-container');
        if (qaContainer) {
            qaContainer.addEventListener('click', (e) => {
                if (e.target && e.target.classList.contains('question-select-checkbox')) {
                    const questionId = e.target.getAttribute('data-question-id');
                    
                    if (e.target.checked) {
                        this.selectedQuestions.add(questionId);
                    } else {
                        this.selectedQuestions.delete(questionId);
                    }
                    
                    // Update the selection UI
                    this.updateSelectionUI();
                }
            });
        }
        
        // Add select all checkbox functionality to header
        const selectAllCheckbox = document.getElementById('select-all-questions');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                const checkboxes = document.querySelectorAll('.question-select-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = e.target.checked;
                    
                    const questionId = checkbox.getAttribute('data-question-id');
                    if (e.target.checked) {
                        this.selectedQuestions.add(questionId);
                    } else {
                        this.selectedQuestions.delete(questionId);
                    }
                });
                
                // Update the selection UI
                this.updateSelectionUI();
            });
        }
        
        // Question selection mode toggle
        this.setupSelectionModeToggle();
    }
    
    setupSelectionModeToggle() {
        // Find the existing selection mode button in the HTML
        const selectionModeBtn = document.getElementById('selection-mode-btn');
        if (selectionModeBtn) {
            // Handle button click
            selectionModeBtn.addEventListener('click', () => this.toggleSelectionMode());
        }
    }
    
    toggleSelectionMode() {
        const qaContainer = document.getElementById('qa-container');
        if (!qaContainer) return;
        
        // Toggle selection mode class
        qaContainer.classList.toggle('selection-mode');
        const isSelectionMode = qaContainer.classList.contains('selection-mode');
        
        // Toggle button text
        const selectionModeBtn = document.getElementById('selection-mode-btn');
        if (selectionModeBtn) {
            if (isSelectionMode) {
                selectionModeBtn.innerHTML = '<i class="fas fa-times mr-2"></i>Cancel Selection';
                selectionModeBtn.classList.remove('bg-indigo-600', 'hover:bg-indigo-700');
                selectionModeBtn.classList.add('bg-gray-600', 'hover:bg-gray-700');
            } else {
                selectionModeBtn.innerHTML = '<i class="fas fa-check-square mr-2"></i>Select Questions';
                selectionModeBtn.classList.add('bg-indigo-600', 'hover:bg-indigo-700');
                selectionModeBtn.classList.remove('bg-gray-600', 'hover:bg-gray-700');
            }
        }
        
        // If entering selection mode, add UI elements
        if (isSelectionMode) {
            this.addSelectionUI();
        } else {
            this.removeSelectionUI();
            this.selectedQuestions.clear();
        }
        
        // Update save button behavior - only visible during selection mode
        const saveOfflineBtn = document.getElementById('save-offline-btn');
        if (saveOfflineBtn) {
            if (isSelectionMode) {
                saveOfflineBtn.innerHTML = '<i class="fas fa-save mr-2"></i>Save Selected';
                saveOfflineBtn.classList.remove('bg-purple-600', 'hover:bg-purple-700');
                saveOfflineBtn.classList.add('bg-green-600', 'hover:bg-green-700');
            } else {
                saveOfflineBtn.innerHTML = '<i class="fas fa-save mr-2"></i>Save Offline';
                saveOfflineBtn.classList.add('bg-purple-600', 'hover:bg-purple-700');
                saveOfflineBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
            }
        }
    }
    
    addSelectionUI() {
        // Create selection header
        const qaContainer = document.getElementById('qa-container');
        if (!qaContainer) return;
        
        // Add header for selection
        const header = document.createElement('div');
        header.id = 'question-selection-header';
        header.className = 'bg-gray-100 p-3 rounded-md mb-4 flex justify-between items-center sticky top-0 z-10';
        header.innerHTML = `
            <div class="flex items-center">
                <label class="flex items-center select-none cursor-pointer">
                    <input type="checkbox" id="select-all-questions" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 rounded mr-2">
                    <span>Select All Questions</span>
                </label>
            </div>
            <div id="selected-questions-counter" class="text-sm font-medium text-gray-700">
                0 questions selected
            </div>
        `;
        
        qaContainer.prepend(header);

        // Wire up "Select All Questions" now that the checkbox exists
        const selectAllQuestions = document.getElementById('select-all-questions');
        if (selectAllQuestions) {
            selectAllQuestions.addEventListener('change', (e) => {
                const check = e.target.checked;
                // Toggle all question checkboxes
                const questionCheckboxes = qaContainer.querySelectorAll('.question-select-checkbox');
                questionCheckboxes.forEach(cb => {
                    const wasChecked = cb.checked;
                    cb.checked = check;
                    const questionId = cb.getAttribute('data-question-id');
                    if (check) {
                        this.selectedQuestions.add(questionId);
                    } else {
                        this.selectedQuestions.delete(questionId);
                    }
                });
                // Update selected counter UI
                this.updateSelectionUI();
            });
        }
        
        // Add checkboxes to each question
        const questions = qaContainer.querySelectorAll('.question-item');
        questions.forEach((question, idx) => {
            const questionId = `q-${idx}`;
            
            // Add ID to question element if not already present
            if (!question.id) {
                question.id = questionId;
            }
            
            // Add selection checkbox
            const checkbox = document.createElement('div');
            checkbox.className = 'absolute right-3 top-3 question-select-checkbox-container';
            checkbox.innerHTML = `
                <input type="checkbox" data-question-id="${questionId}" 
                       class="question-select-checkbox h-5 w-5 text-indigo-600 focus:ring-indigo-500 rounded cursor-pointer">
            `;
            
            // Add the checkbox as first child to position it properly
            question.classList.add('selected');
            question.classList.add('relative');
            question.prepend(checkbox);
        });
    }
    
    removeSelectionUI() {
        // Remove the selection header
        const header = document.getElementById('question-selection-header');
        if (header) {
            header.remove();
        }
        
        // Remove checkboxes from questions
        const checkboxContainers = document.querySelectorAll('.question-select-checkbox-container');
        checkboxContainers.forEach(container => {
            container.remove();
        });
        
        // Remove selected class from questions
        const questions = document.querySelectorAll('.question-item');
        questions.forEach(question => {
            question.classList.remove('selected');
        });
    }
    
    updateSelectionUI() {
        const counter = document.getElementById('selected-questions-counter');
        if (counter) {
            const count = this.selectedQuestions.size;
            counter.textContent = `${count} question${count !== 1 ? 's' : ''} selected`;
        }
    }
    
    clearForm() {
        // Clear all form inputs and UI elements
        
        // Reset the subject fields
        const difficultySelect = document.getElementById('difficulty');
        if (difficultySelect) difficultySelect.selectedIndex = 0;
        
        const knowledgeAreaSelect = document.getElementById('knowledge-area');
        if (knowledgeAreaSelect) knowledgeAreaSelect.selectedIndex = 0;
        
        const aiModelSelect = document.getElementById('ai-model');
        if (aiModelSelect) aiModelSelect.selectedIndex = 0;
        
        const numQuestionsInput = document.getElementById('num-questions');
        if (numQuestionsInput) numQuestionsInput.value = 10;
        
        const focusAreaInput = document.getElementById('focus-area');
        if (focusAreaInput) focusAreaInput.value = '';
        
        const inputTypeSelect = document.getElementById('input-type');
        if (inputTypeSelect) {
            inputTypeSelect.selectedIndex = 0;
            
            // Trigger the change event to update UI visibility
            const changeEvent = new Event('change');
            inputTypeSelect.dispatchEvent(changeEvent);
        }
        
        // Reset file upload if applicable
        const fileUpload = document.getElementById('pdf-upload');
        if (fileUpload) fileUpload.value = '';
        
        const fileInfo = document.getElementById('file-info');
        if (fileInfo) fileInfo.classList.add('hidden');
        
        // Clear text input
        const inputTextElement = document.getElementById('input-text');
        if (inputTextElement) inputTextElement.value = '';
    }
    
    setSectionVisibility(visible) {
        // Always keep the section visible (as per requirement)
        if (this.offlineQuestionsSection) {
            this.offlineQuestionsSection.classList.remove('hidden');
        }
        
        // Save the visibility preference
        this.storage.setItem(this.questionSetsVisibilityKey, 'visible');
        
        this.updateUI();
    }
    
    updateUI() {
        if (this.questionSets.length === 0) {
            if (this.noOfflineSets) this.noOfflineSets.classList.remove('hidden');
            if (this.offlineSetsList) this.offlineSetsList.classList.add('hidden');
            if (this.offlineModeIndicator) this.offlineModeIndicator.classList.add('hidden');
        } else {
            if (this.noOfflineSets) this.noOfflineSets.classList.add('hidden');
            if (this.offlineSetsList) {
                this.offlineSetsList.classList.remove('hidden');
                this.renderQuestionSets();
            }
            if (this.offlineModeIndicator) {
                this.offlineModeIndicator.classList.remove('hidden');
                if (this.offlineSetsCount) {
                    this.offlineSetsCount.textContent = this.questionSets.length;
                }
            }
        }
    }
    
    showSaveQuestionSetModal() {
        if (!this.questionGenerator || !this.questionGenerator.generatedQuestions || this.questionGenerator.generatedQuestions.length === 0) {
            alert('No questions to save. Please generate questions first.');
            return;
        }
        
        // Check if we're in selection mode and have questions selected
        const qaContainer = document.getElementById('qa-container');
        const isSelectionMode = qaContainer && qaContainer.classList.contains('selection-mode');
        
        if (isSelectionMode && this.selectedQuestions.size === 0) {
            alert('No questions selected. Please select at least one question to save.');
            return;
        }
        
        if (this.saveQuestionSetModal) {
            // Get the current subspecialty as a suggestion for the title
            const subspecialtySelect = document.getElementById('knowledge-area');
            let subspecialtyText = 'General Ophthalmology';
            
            if (subspecialtySelect) {
                const selectedOption = subspecialtySelect.options[subspecialtySelect.selectedIndex];
                if (selectedOption) {
                    subspecialtyText = selectedOption.text;
                }
            }
            
            // Pre-populate title with subspecialty
            this.questionSetTitleInput.value = subspecialtyText;
            this.questionSetDescriptionInput.value = '';
            this.questionSetFavoriteCheckbox.checked = false;
            
            // Update the modal title based on selection mode
            const modalTitle = document.querySelector('#save-question-set-modal .text-lg');
            if (modalTitle) {
                if (isSelectionMode) {
                    modalTitle.innerHTML = `<i class="fas fa-save text-green-600 mr-2"></i>Save ${this.selectedQuestions.size} Selected Question${this.selectedQuestions.size !== 1 ? 's' : ''}`;
                } else {
                    modalTitle.innerHTML = '<i class="fas fa-save text-purple-600 mr-2"></i>Save Question Set Offline';
                }
            }
            
            // Show the modal
            this.saveQuestionSetModal.classList.remove('hidden');
        }
    }
    
    hideSaveQuestionSetModal() {
        if (this.saveQuestionSetModal) {
            this.saveQuestionSetModal.classList.add('hidden');
        }
    }
    
    saveCurrentQuestionSet() {
        // Check if we're in selection mode
        const qaContainer = document.getElementById('qa-container');
        const isSelectionMode = qaContainer && qaContainer.classList.contains('selection-mode');
        
        // If we're in selection mode and no questions are selected, show error
        if (isSelectionMode && this.selectedQuestions.size === 0) {
            this.showSaveQuestionSetStatus('No questions selected', 'error');
            return;
        }
        
        // Otherwise check if there are any generated questions at all
        if (!this.questionGenerator || !this.questionGenerator.generatedQuestions || this.questionGenerator.generatedQuestions.length === 0) {
            this.showSaveQuestionSetStatus('No questions to save', 'error');
            return;
        }
        
        const title = this.questionSetTitleInput.value.trim();
        if (!title) {
            this.showSaveQuestionSetStatus('Please enter a title for the question set', 'error');
            return;
        }
        
        try {
            const subspecialty = document.getElementById('knowledge-area').value;
            const description = this.questionSetDescriptionInput.value.trim();
            const isFavorite = this.questionSetFavoriteCheckbox.checked;
            
            // Determine which questions to save (all or selected)
            let questionsToSave = [];
            
            if (isSelectionMode && this.selectedQuestions.size > 0) {
                // Get only selected questions
                questionsToSave = this.questionGenerator.generatedQuestions.filter((_, idx) => {
                    const questionId = `q-${idx}`;
                    return this.selectedQuestions.has(questionId);
                });
            } else {
                // Get all questions
                questionsToSave = [...this.questionGenerator.generatedQuestions];
            }
            
            // Create a new question set
            const newSet = {
                id: Date.now().toString(),
                title: title,
                description: description,
                subspecialty: subspecialty,
                favorite: isFavorite,
                date: new Date().toISOString(),
                questions: questionsToSave,
                source: this.getSourceInfo()
            };
            
            // Add the new set
            this.questionSets.push(newSet);
            
            // Save to localStorage
            this.saveQuestionSets();
            
            // Update the UI
            this.updateUI();
            
            // Show success message
            this.showSaveQuestionSetStatus('Question set saved successfully!', 'success');
            
            // Hide the modal after a short delay
            setTimeout(() => {
                this.hideSaveQuestionSetModal();
                
                // If in selection mode, exit it
                if (isSelectionMode) {
                    this.toggleSelectionMode();
                }
            }, 1500);
            
            // Update the saved questions counter
            this.updateQuestionCounter(questionsToSave.length);
        } catch (error) {
            console.error('Error saving question set:', error);
            this.showSaveQuestionSetStatus('Error saving question set', 'error');
        }
    }
    
    getSourceInfo() {
        let source = 'Custom Input';
        
        const inputType = document.getElementById('input-type').value;
        switch (inputType) {
            case 'upload':
                const fileInput = document.getElementById('pdf-upload');
                if (fileInput && fileInput.files && fileInput.files[0]) {
                    source = `Upload: ${fileInput.files[0].name}`;
                } else {
                    source = 'Uploaded Document';
                }
                break;
            case 'text':
                source = 'Manual Text Input';
                break;
            case 'knowledge-base':
                const knowledgeArea = document.getElementById('knowledge-area');
                if (knowledgeArea) {
                    const selectedOption = knowledgeArea.options[knowledgeArea.selectedIndex];
                    if (selectedOption) {
                        source = `Knowledge Base: ${selectedOption.text}`;
                    } else {
                        source = 'Knowledge Base';
                    }
                }
                break;
            case 'notebooklm':
                const notebookSelect = document.getElementById('notebook-select');
                if (notebookSelect) {
                    const selectedOption = notebookSelect.options[notebookSelect.selectedIndex];
                    if (selectedOption && selectedOption.text) {
                        source = `NotebookLM: ${selectedOption.text}`;
                    } else {
                        source = 'NotebookLM';
                    }
                }
                break;
        }
        
        return source;
    }
    
    showSaveQuestionSetStatus(message, type = 'info') {
        if (this.saveQuestionSetStatus) {
            this.saveQuestionSetStatus.textContent = message;
            this.saveQuestionSetStatus.className = `mb-4 p-3 rounded-md text-sm ${this.getStatusClass(type)}`;
            this.saveQuestionSetStatus.classList.remove('hidden');
        }
    }
    
    getStatusClass(type) {
        switch (type) {
            case 'success': return 'bg-green-100 text-green-800';
            case 'error': return 'bg-red-100 text-red-800';
            case 'warning': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-blue-100 text-blue-800';
        }
    }
    
    renderQuestionSets() {
        if (!this.offlineSetsList) return;
        
        // Clear the current list
        this.offlineSetsList.innerHTML = '';
        
        // Group question sets by subspecialty
        const setsBySubspecialty = this.groupSetsBySubspecialty();
        
        // Create and append elements for each group
        for (const [subspecialty, sets] of Object.entries(setsBySubspecialty)) {
            // Get a readable name for the subspecialty
            const subspecialtyName = this.getSubspecialtyName(subspecialty);
            
            // Create a section for this subspecialty
            const subspecialtySection = document.createElement('div');
            subspecialtySection.className = 'col-span-full mb-4';
            subspecialtySection.innerHTML = `
                <h3 class="text-md font-semibold text-gray-700 mb-2 pb-1 border-b border-gray-200">
                    ${subspecialtyName} <span class="text-sm font-normal text-gray-500">(${sets.length} sets)</span>
                </h3>
            `;
            
            this.offlineSetsList.appendChild(subspecialtySection);
            
            // Add sets for this subspecialty
            sets.forEach(set => {
                const setElement = this.createQuestionSetElement(set);
                this.offlineSetsList.appendChild(setElement);
            });
        }
    }
    
    groupSetsBySubspecialty() {
        const groups = {};
        
        this.questionSets.forEach(set => {
            const subspecialty = set.subspecialty || 'general';
            if (!groups[subspecialty]) {
                groups[subspecialty] = [];
            }
            groups[subspecialty].push(set);
        });
        
        // Sort sets within each group by date (newest first)
        for (const group in groups) {
            groups[group].sort((a, b) => new Date(b.date) - new Date(a.date));
        }
        
        return groups;
    }
    
    getSubspecialtyName(subspecialtyKey) {
        const subspecialtyMap = {
            'general': 'General Ophthalmology',
            'all': 'All Subspecialties',
            'retinal-disorders': 'Retinal Disorders',
            'corneal-diseases': 'Corneal Diseases',
            'glaucoma': 'Glaucoma',
            'cataract': 'Cataract & Lens Disorders',
            'refractive-errors': 'Refractive Errors',
            'neuro-ophthalmology': 'Neuro-ophthalmology',
            'ocular-inflammation': 'Ocular Inflammation & Uveitis',
            'pediatric': 'Pediatric Ophthalmology',
            'oculoplastics-oncology': 'Oculoplastics & Oncology'
        };
        
        return subspecialtyMap[subspecialtyKey] || subspecialtyKey;
    }
    
    createQuestionSetElement(set) {
        const element = document.createElement('div');
        element.className = 'bg-white border border-gray-200 rounded-lg p-4 transition-all hover:shadow-md offline-set-card';
        // Provide stable identifiers for selection/merge features
        if (set && set.id) {
            element.setAttribute('data-set-id', set.id);
            if (!element.id) {
                element.id = `offline-set-${set.id}`;
            }
        }
        
        // Format date
        const date = new Date(set.date);
        const formattedDate = date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
        
        // Set a maximum length for the description
        const shortDesc = set.description && set.description.length > 100 
            ? set.description.substring(0, 97) + '...' 
            : set.description || 'No description';
            
        element.innerHTML = `
            <div class="flex justify-between items-start mb-2">
                <h4 class="font-medium text-gray-800 line-clamp-1">${set.title}</h4>
                ${set.favorite ? '<span class="text-yellow-500"><i class="fas fa-star"></i></span>' : ''}
            </div>
            <p class="text-sm text-gray-600 line-clamp-2 mb-3">${shortDesc}</p>
            <div class="flex justify-between items-center text-xs">
                <div class="flex items-center gap-2">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded flex items-center">
                        <i class="fas fa-question-circle mr-1"></i> ${set.questions.length}
                    </span>
                    <span class="text-gray-500">
                        <i class="far fa-calendar-alt mr-1"></i> ${formattedDate}
                    </span>
                </div>
                <button class="text-primary hover:text-accent transition-colors">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
        `;
        
        // Add event listener to view the question set
        element.addEventListener('click', () => {
            this.viewQuestionSet(set);
        });
        
        return element;
    }
    
    viewQuestionSet(set) {
        this.currentQuestionSet = set;
        
        if (this.viewQuestionSetModal) {
            // Set the modal title and metadata
            this.viewQuestionSetTitle.innerHTML = `
                <i class="fas fa-list-alt text-primary mr-2"></i>
                ${set.title} ${set.favorite ? '<i class="fas fa-star text-yellow-500 ml-2"></i>' : ''}
            `;
            
            if (this.viewQuestionSetDescription) {
                this.viewQuestionSetDescription.textContent = set.description || 'No description provided.';
            }
            
            // Format date
            const date = new Date(set.date);
            const formattedDate = date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
            
            this.viewQuestionSetDate.textContent = formattedDate;
            this.viewQuestionSetCount.textContent = `${set.questions.length} Questions`;
            this.viewQuestionSetSource.textContent = set.source || 'Unknown Source';
            
            // Render the questions
            this.renderQuestionSetContent(set);
            
            // Show the modal
            this.viewQuestionSetModal.classList.remove('hidden');
        }
    }
    
    renderQuestionSetContent(set) {
        if (!this.viewQuestionSetContent) return;
        
        // Clear the current content
        this.viewQuestionSetContent.innerHTML = '';
        
        // Render each question
        set.questions.forEach((question, index) => {
            const questionElement = document.createElement('div');
            questionElement.className = 'question-item';
            
            // Normalize question object to detect MCQ options embedded in text
            const originalText = (question.question || question.text || '').toString();
            let stemText = originalText;
            let parsedOptions = [];
            try {
                // Extract A./B./C./D./E. choices across lines
                const choiceRegex = /(^|\n)\s*([A-Ea-e])\.?\s+(.+?)(?=(\n\s*[A-Ea-e]\.\s+)|$)/gs;
                let match;
                const options = [];
                let consumed = originalText;
                while ((match = choiceRegex.exec(originalText)) !== null) {
                    const label = match[2].toUpperCase();
                    const text = match[3].trim();
                    if (text) {
                        options.push({ label, text });
                    }
                }
                if (options.length >= 3) {
                    parsedOptions = options.map(o => `${o.label}. ${o.text}`);
                    // Remove the options block from the stem
                    stemText = originalText.replace(choiceRegex, '\n').trim();
                }
            } catch (_) {}
            const isMcq = (question.type === 'mcq') || (parsedOptions.length >= 3);
            const displayType = isMcq ? 'MCQ' : (question.type || 'Question');

            let questionContent = `
                <div class="question-header mb-2">
                    <span class="inline-block bg-primary text-white text-sm px-2 py-1 rounded mr-2">Q${index + 1}</span>
                    <span class="text-sm text-gray-500">${displayType}</span>
                </div>
                <div class="question-text mb-3 text-gray-800">${stemText}</div>
            `;
            
            // Add appropriate content based on question type (parsed or explicit)
            const optionsToRender = isMcq ? (question.options && question.options.length ? question.options : parsedOptions) : null;
            if (optionsToRender) {
                questionContent += '<div class="options-list mb-3">';
                optionsToRender.forEach((option, optIndex) => {
                    const isCorrect = question.answer && (option === question.answer || option.startsWith((question.answer || '').trim()[0] + '.'));
                    questionContent += `
                        <div class="option-item mb-1 flex items-start">
                            <span class="option-letter mr-2 ${isCorrect ? 'text-green-600 font-bold' : ''}">${String.fromCharCode(65 + optIndex)}.</span>
                            <span class="option-text ${isCorrect ? 'text-green-600 font-bold' : ''}">${option.replace(/^([A-Ea-e])\.?\s+/, '')}</span>
                        </div>
                    `;
                });
                questionContent += '</div>';
            }
            
            // Add answer explanation if available
            if (question.answer && !['mcq'].includes(question.type)) {
                questionContent += `
                    <div class="answer-container mt-2">
                        <div class="font-medium text-green-700 mb-1">Answer:</div>
                        <div class="bg-green-50 p-3 rounded-md text-green-800">${question.answer}</div>
                    </div>
                `;
            }
            
            if (question.explanation) {
                questionContent += `
                    <div class="explanation-container mt-3">
                        <div class="font-medium text-blue-700 mb-1">Explanation:</div>
                        <div class="bg-blue-50 p-3 rounded-md text-blue-800">${question.explanation}</div>
                    </div>
                `;
            }
            
            questionElement.innerHTML = questionContent;
            this.viewQuestionSetContent.appendChild(questionElement);
        });
    }
    
    hideViewQuestionSetModal() {
        if (this.viewQuestionSetModal) {
            this.viewQuestionSetModal.classList.add('hidden');
            this.currentQuestionSet = null;
        }
    }
    
    clearAllQuestionSets() {
        if (confirm('Are you sure you want to delete all saved question sets? This cannot be undone.')) {
            this.questionSets = [];
            this.saveQuestionSets();
            this.updateUI();
        }
    }
    
    deleteQuestionSet(id) {
        this.questionSets = this.questionSets.filter(set => set.id !== id);
        this.saveQuestionSets();
        this.updateUI();
    }
    
    updateQuestionCounter(newCount) {
        // Get the counter element
        const questionCountElement = document.getElementById('question-count');
        if (!questionCountElement) return;
        
        // Get the current count
        let currentCount = parseInt(questionCountElement.textContent) || 0;
        
        // Add the new questions to the count
        currentCount += newCount;
        
        // Update the displayed count
        questionCountElement.textContent = currentCount;
        
        // Show the counter if it's hidden
        const usageCounter = document.querySelector('.usage-counter');
        if (usageCounter) {
            usageCounter.classList.remove('hidden');
        }
        
        // Save the updated count to localStorage
        this.storage.setItem('question_count', currentCount);
    }
    
    // Reset the question counter to zero (requirement #3)
    resetQuestionCounter() {
        const questionCountElement = document.getElementById('question-count');
        if (questionCountElement) {
            questionCountElement.textContent = '0';
        }
        
        // Save the reset count to localStorage
        this.storage.setItem('question_count', 0);
    }
}

// Initialize the OfflineStorageManager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.offlineStorageManager = new OfflineStorageManager();
    
    // Reset the question counter to zero (requirement #3)
    window.offlineStorageManager.resetQuestionCounter();
    
    // Connect to question generator if available
    if (window.questionGenerator) {
        window.offlineStorageManager.setQuestionGenerator(window.questionGenerator);
    }
    // Simple APKG import handler (optional parser elsewhere)
    const apkgInput = document.getElementById('apkg-file-input');
    const apkgStatus = document.getElementById('apkg-import-status');
    if (apkgInput) {
        apkgInput.addEventListener('change', async (e) => {
            try {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                apkgStatus.textContent = `Loading APKG: ${file.name}...`;
                if (typeof window.processUploadedApkgFile === 'function') {
                    const result = await window.processUploadedApkgFile(file);
                    const notes = typeof result?.notesLoaded === 'number' ? result.notesLoaded : (window.kanskiCards?.size || 0);
                    const cards = typeof result?.cardsCount === 'number' ? result.cardsCount : notes;
                    const images = typeof result?.imagesLoaded === 'number' ? result.imagesLoaded : (window.kanskiImages?.size || 0);
                    let status = `APKG loaded: ${file.name}. ${notes} notes, ${cards} cards, ${images} images.`;
                    if (notes === 0 && cards === 0 && images === 0 && result?.debug) {
                        const sample = Array.isArray(result.debug.sample) ? result.debug.sample.join(', ') : '';
                        const tables = Array.isArray(result.debug.tables) ? result.debug.tables.join(', ') : '';
                        const fileCount = typeof result.debug.fileCount === 'number' ? result.debug.fileCount : undefined;
                        status += `\nHint: zip files detected = ${fileCount ?? 'n/a'}`;
                        if (sample) status += `\nEntries sample: ${sample}`;
                        if (tables) status += `\nDB tables: ${tables}`;
                    }
                    apkgStatus.textContent = status;
                } else {
                    apkgStatus.textContent = 'APKG loader is not available in this build.';
                }
            } catch (err) {
                console.error('APKG import error:', err);
                apkgStatus.textContent = `APKG import error: ${err.message}`;
            }
        });
    }
});

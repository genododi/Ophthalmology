/**
 * Enhanced Continuous Improvement System
 * Provides optimization capabilities and feedback-driven improvements
 */

class ContinuousImprovementSystem {
    constructor() {
        this.storageKey = 'ophthalmoqa_improvement_system';
        this.feedbackStorageKey = 'ophthalmoqa_feedback_data';
        this.improvementQueue = [];
        this.optimizationHistory = [];
        this.systemMetrics = {
            totalOptimizations: 0,
            improvementCycles: 0,
            feedbackProcessed: 0,
            lastOptimization: null
        };
        
        this.isOptimizing = false;
        this.loadSystemState();
        this.initializeSystem();
    }
    
    initializeSystem() {
        // Register global feedback loop system
        window.feedbackLoopSystem = this;
        
        // Listen for feedback events
        document.addEventListener('questionFeedback', (event) => {
            this.processFeedback(event.detail);
        });
        
        // Auto-optimization timer (every 5 minutes if there's new feedback)
        setInterval(() => {
            this.autoOptimizationCheck();
        }, 300000); // 5 minutes
        
        console.log('✅ Continuous Improvement System initialized');
    }
    
    loadSystemState() {
        try {
            const saved = localStorage.getItem(this.storageKey);
            if (saved) {
                const data = JSON.parse(saved);
                this.systemMetrics = { ...this.systemMetrics, ...data.systemMetrics };
                this.optimizationHistory = data.optimizationHistory || [];
            }
        } catch (error) {
            console.error('Error loading improvement system state:', error);
        }
    }
    
    saveSystemState() {
        try {
            const data = {
                systemMetrics: this.systemMetrics,
                optimizationHistory: this.optimizationHistory.slice(-50), // Keep last 50 entries
                lastSaved: new Date().toISOString()
            };
            localStorage.setItem(this.storageKey, JSON.stringify(data));
        } catch (error) {
            console.error('Error saving improvement system state:', error);
        }
    }
    
    processFeedback(feedbackData) {
        try {
            // Store feedback for optimization analysis
            const feedbackLog = this.getFeedbackLog();
            feedbackLog.push({
                ...feedbackData,
                timestamp: new Date().toISOString()
            });
            
            // Keep only last 1000 feedback entries
            if (feedbackLog.length > 1000) {
                feedbackLog.splice(0, feedbackLog.length - 1000);
            }
            
            localStorage.setItem(this.feedbackStorageKey, JSON.stringify(feedbackLog));
            this.systemMetrics.feedbackProcessed++;
            this.saveSystemState();
            
            // Queue for improvement if negative feedback
            if (this.isNegativeFeedback(feedbackData)) {
                this.queueForImprovement(feedbackData);
            }
            
        } catch (error) {
            console.error('Error processing feedback:', error);
        }
    }
    
    getFeedbackLog() {
        try {
            const stored = localStorage.getItem(this.feedbackStorageKey);
            return stored ? JSON.parse(stored) : [];
        } catch (error) {
            console.error('Error loading feedback log:', error);
            return [];
        }
    }
    
    isNegativeFeedback(feedbackData) {
        const negativeValues = ['poor', 'no', 'too_hard', 'too_easy', 'irrelevant'];
        return negativeValues.includes(feedbackData.value);
    }
    
    queueForImprovement(feedbackData) {
        // Add to improvement queue if not already there
        const exists = this.improvementQueue.some(item => 
            item.questionId === feedbackData.questionId && 
            item.type === feedbackData.type
        );
        
        if (!exists) {
            this.improvementQueue.push({
                questionId: feedbackData.questionId,
                type: feedbackData.type,
                value: feedbackData.value,
                metadata: feedbackData.metadata,
                priority: this.calculatePriority(feedbackData),
                queuedAt: new Date().toISOString()
            });
            
            // Sort by priority
            this.improvementQueue.sort((a, b) => b.priority - a.priority);
        }
    }
    
    calculatePriority(feedbackData) {
        let priority = 1;
        
        // Higher priority for quality issues
        if (feedbackData.type === 'quality' && feedbackData.value === 'poor') {
            priority += 3;
        }
        
        // Higher priority for relevance issues
        if (feedbackData.type === 'relevance' && feedbackData.value === 'no') {
            priority += 2;
        }
        
        // Higher priority for difficulty issues
        if (feedbackData.type === 'difficulty') {
            priority += 1;
        }
        
        return priority;
    }
    
    async runImprovementCycle() {
        if (this.isOptimizing) {
            console.log('⚠️ Optimization already in progress');
            return;
        }
        
        this.isOptimizing = true;
        this.systemMetrics.improvementCycles++;
        
        try {
            console.log('🔄 Starting improvement cycle...');
            
            // Analyze current feedback data
            const analysis = this.analyzeFeedbackData();
            
            // Generate optimization recommendations
            const recommendations = this.generateOptimizationRecommendations(analysis);
            
            // Apply optimizations
            await this.applyOptimizations(recommendations);
            
            // Update system metrics
            this.systemMetrics.totalOptimizations++;
            this.systemMetrics.lastOptimization = new Date().toISOString();
            
            // Record optimization in history
            this.optimizationHistory.push({
                timestamp: new Date().toISOString(),
                analysis: analysis,
                recommendations: recommendations.length,
                feedbackProcessed: analysis.totalFeedback
            });
            
            this.saveSystemState();
            console.log('✅ Improvement cycle completed');
            
            // Notify user of optimization completion
            this.showOptimizationResults(recommendations);
            
        } catch (error) {
            console.error('Error during improvement cycle:', error);
        } finally {
            this.isOptimizing = false;
        }
    }
    
    analyzeFeedbackData() {
        const feedbackLog = this.getFeedbackLog();
        const analysis = {
            totalFeedback: feedbackLog.length,
            qualityFeedback: { good: 0, poor: 0 },
            relevanceFeedback: { yes: 0, no: 0 },
            difficultyFeedback: { appropriate: 0, too_hard: 0, too_easy: 0 },
            byQuestionType: {},
            trends: {},
            lastWeekFeedback: 0
        };
        
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        
        feedbackLog.forEach(feedback => {
            // Count by feedback type and value
            if (feedback.type === 'quality') {
                analysis.qualityFeedback[feedback.value] = (analysis.qualityFeedback[feedback.value] || 0) + 1;
            } else if (feedback.type === 'relevance') {
                analysis.relevanceFeedback[feedback.value] = (analysis.relevanceFeedback[feedback.value] || 0) + 1;
            } else if (feedback.type === 'difficulty') {
                analysis.difficultyFeedback[feedback.value] = (analysis.difficultyFeedback[feedback.value] || 0) + 1;
            }
            
            // Count by question type
            if (feedback.metadata && feedback.metadata.questionType) {
                const qType = feedback.metadata.questionType;
                if (!analysis.byQuestionType[qType]) {
                    analysis.byQuestionType[qType] = { total: 0, negative: 0 };
                }
                analysis.byQuestionType[qType].total++;
                
                if (this.isNegativeFeedback(feedback)) {
                    analysis.byQuestionType[qType].negative++;
                }
            }
            
            // Count recent feedback
            if (new Date(feedback.timestamp) > oneWeekAgo) {
                analysis.lastWeekFeedback++;
            }
        });
        
        return analysis;
    }
    
    generateOptimizationRecommendations(analysis) {
        const recommendations = [];
        
        // Quality improvement recommendations
        if (analysis.qualityFeedback.poor > analysis.qualityFeedback.good * 0.3) {
            recommendations.push({
                type: 'quality_improvement',
                priority: 'high',
                description: 'High rate of poor quality feedback detected',
                action: 'enhance_question_generation_parameters',
                targetMetric: 'quality_feedback_ratio'
            });
        }
        
        // Relevance improvement recommendations
        if (analysis.relevanceFeedback.no > analysis.relevanceFeedback.yes * 0.2) {
            recommendations.push({
                type: 'relevance_improvement',
                priority: 'medium',
                description: 'Questions may not be relevant to user needs',
                action: 'adjust_topic_focus',
                targetMetric: 'relevance_feedback_ratio'
            });
        }
        
        // Difficulty adjustment recommendations
        const totalDifficulty = Object.values(analysis.difficultyFeedback).reduce((a, b) => a + b, 0);
        if (totalDifficulty > 0) {
            const hardRatio = analysis.difficultyFeedback.too_hard / totalDifficulty;
            const easyRatio = analysis.difficultyFeedback.too_easy / totalDifficulty;
            
            if (hardRatio > 0.4) {
                recommendations.push({
                    type: 'difficulty_adjustment',
                    priority: 'medium',
                    description: 'Questions are too difficult',
                    action: 'reduce_complexity',
                    targetMetric: 'difficulty_balance'
                });
            } else if (easyRatio > 0.4) {
                recommendations.push({
                    type: 'difficulty_adjustment',
                    priority: 'medium',
                    description: 'Questions are too easy',
                    action: 'increase_complexity',
                    targetMetric: 'difficulty_balance'
                });
            }
        }
        
        // Question type specific recommendations
        Object.entries(analysis.byQuestionType).forEach(([type, stats]) => {
            const negativeRatio = stats.negative / stats.total;
            if (negativeRatio > 0.4 && stats.total > 5) {
                recommendations.push({
                    type: 'question_type_improvement',
                    priority: 'medium',
                    description: `High negative feedback for ${type} questions`,
                    action: 'optimize_question_type',
                    targetMetric: 'type_specific_feedback',
                    questionType: type
                });
            }
        });
        
        return recommendations;
    }
    
    async applyOptimizations(recommendations) {
        for (const rec of recommendations) {
            await this.applyRecommendation(rec);
        }
    }
    
    async applyRecommendation(recommendation) {
        try {
            switch (recommendation.action) {
                case 'enhance_question_generation_parameters':
                    this.optimizeQualityParameters();
                    break;
                    
                case 'adjust_topic_focus':
                    this.optimizeRelevanceParameters();
                    break;
                    
                case 'reduce_complexity':
                    this.optimizeDifficultyParameters('easier');
                    break;
                    
                case 'increase_complexity':
                    this.optimizeDifficultyParameters('harder');
                    break;
                    
                case 'optimize_question_type':
                    this.optimizeQuestionTypeParameters(recommendation.questionType);
                    break;
            }
            
            // Small delay to prevent overwhelming the system
            await new Promise(resolve => setTimeout(resolve, 100));
            
        } catch (error) {
            console.error('Error applying recommendation:', error);
        }
    }
    
    optimizeQualityParameters() {
        // Update quality-related parameters if question generator is available
        if (window.questionGenerator && window.questionGenerator.updateParameters) {
            const qualityParams = {
                qualityWeight: 0.9,
                clarityBoost: 0.2,
                coherenceThreshold: 0.8
            };
            window.questionGenerator.updateParameters(qualityParams);
        }
        console.log('📈 Quality parameters optimized');
    }
    
    optimizeRelevanceParameters() {
        // Update relevance-related parameters
        if (window.questionGenerator && window.questionGenerator.updateParameters) {
            const relevanceParams = {
                topicRelevance: 0.85,
                contextWeight: 0.8,
                focusBoost: 0.3
            };
            window.questionGenerator.updateParameters(relevanceParams);
        }
        console.log('🎯 Relevance parameters optimized');
    }
    
    optimizeDifficultyParameters(direction) {
        // Adjust difficulty parameters
        if (window.questionGenerator && window.questionGenerator.updateParameters) {
            const difficultyAdjustment = direction === 'easier' ? -0.2 : 0.2;
            const difficultyParams = {
                complexityLevel: Math.max(0.1, Math.min(1.0, 0.6 + difficultyAdjustment)),
                vocabularyLevel: Math.max(0.1, Math.min(1.0, 0.7 + difficultyAdjustment))
            };
            window.questionGenerator.updateParameters(difficultyParams);
        }
        console.log(`⚖️ Difficulty parameters optimized (${direction})`);
    }
    
    optimizeQuestionTypeParameters(questionType) {
        // Type-specific optimizations
        if (window.questionGenerator && window.questionGenerator.updateTypeParameters) {
            window.questionGenerator.updateTypeParameters(questionType, {
                weight: 0.8,
                qualityBoost: 0.3
            });
        }
        console.log(`🔧 ${questionType} question type parameters optimized`);
    }
    
    showOptimizationResults(recommendations) {
        const resultsDiv = document.createElement('div');
        resultsDiv.className = 'fixed top-20 right-4 bg-white border-l-4 border-purple-500 p-4 rounded-lg shadow-lg z-50 max-w-md';
        resultsDiv.innerHTML = `
            <div class="flex items-start">
                <i class="fas fa-magic text-purple-500 mr-3 mt-1"></i>
                <div class="flex-1">
                    <h4 class="font-medium text-purple-800 mb-2">Optimization Complete!</h4>
                    <div class="text-sm text-purple-700">
                        <p class="mb-2">Applied ${recommendations.length} improvements:</p>
                        <ul class="list-disc list-inside space-y-1">
                            ${recommendations.map(rec => `<li>${rec.description}</li>`).join('')}
                        </ul>
                        <p class="mt-2 text-xs text-purple-600">
                            Total optimizations: ${this.systemMetrics.totalOptimizations}
                        </p>
                    </div>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" class="text-purple-600 hover:text-purple-800 ml-2">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(resultsDiv);
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (resultsDiv.parentElement) {
                resultsDiv.remove();
            }
        }, 10000);
    }
    
    autoOptimizationCheck() {
        const feedbackLog = this.getFeedbackLog();
        const recentFeedback = feedbackLog.filter(f => {
            const feedbackTime = new Date(f.timestamp);
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
            return feedbackTime > fiveMinutesAgo;
        });
        
        // Auto-optimize if there's significant new negative feedback
        const negativeCount = recentFeedback.filter(f => this.isNegativeFeedback(f)).length;
        if (negativeCount >= 3 && !this.isOptimizing) {
            console.log('🤖 Auto-optimization triggered by negative feedback');
            this.runImprovementCycle();
        }
    }
    
    // Public API methods
    getSystemStats() {
        return {
            ...this.systemMetrics,
            improvementQueue: this.improvementQueue,
            currentlyImproving: this.isOptimizing ? ['system'] : [],
            feedbackCount: this.getFeedbackLog().length
        };
    }
    
    isQuestionTypeInQueue(questionType) {
        return this.improvementQueue.some(item => 
            item.metadata && item.metadata.questionType === questionType
        );
    }
    
    hasQuestionBeenImproved(questionId) {
        return this.optimizationHistory.some(opt => 
            opt.targetQuestions && opt.targetQuestions.includes(questionId)
        );
    }
    
    clearSystem() {
        this.improvementQueue = [];
        this.optimizationHistory = [];
        this.systemMetrics = {
            totalOptimizations: 0,
            improvementCycles: 0,
            feedbackProcessed: 0,
            lastOptimization: null
        };
        
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem(this.feedbackStorageKey);
        console.log('🗑️ Improvement system cleared');
    }
}

// Initialize the system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Small delay to ensure other systems are loaded
    setTimeout(() => {
        if (!window.feedbackLoopSystem) {
            window.continuousImprovementSystem = new ContinuousImprovementSystem();
        }
    }, 1000);
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ContinuousImprovementSystem;
} 
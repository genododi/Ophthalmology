/**
 * OphthalmoQA Utility Functions
 */

const Utils = (() => {
    /**
     * Simple HTML sanitizer to prevent XSS
     * @param {string} str String to sanitize
     * @returns {string} Sanitized string
     */
    const sanitizeHTML = (str) => {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };
    
    /**
     * Prevent default for event (used for drag and drop)
     * @param {Event} e Event object
     */
    const preventDefaults = (e) => {
        e.preventDefault();
        e.stopPropagation();
    };
    
    /**
     * Format date in a user-friendly way
     * @returns {string} Formatted current date
     */
    const getCurrentFormattedDate = () => {
        return new Date().toLocaleString();
    };
    
    /**
     * Generates a filename for exports
     * @param {string} sourceName Source name (will be sanitized)
     * @param {string} extension File extension without dot
     * @returns {string} Generated filename
     */
    const generateExportFilename = (sourceName, extension) => {
        const sanitizedSource = sourceName
            ? sourceName.replace(/[^a-z0-9]/gi, '_').substring(0, 20)
            : 'General';
        
        return `OphthalmoQA_${sanitizedSource}_${Date.now()}.${extension}`;
    };
    
    /**
     * Logger utility with different log levels
     */
    const logger = {
        debug: (message, ...args) => {
            if (localStorage.getItem('debug') === 'true') {
                console.log(`[DEBUG] ${message}`, ...args);
            }
        },
        info: (message, ...args) => console.info(`[INFO] ${message}`, ...args),
        warn: (message, ...args) => console.warn(`[WARN] ${message}`, ...args),
        error: (message, ...args) => console.error(`[ERROR] ${message}`, ...args)
    };
    
    /**
     * Validate the number input is within acceptable range
     * @param {number} value Value to validate
     * @param {number} min Minimum allowed value
     * @param {number} max Maximum allowed value
     * @returns {boolean} True if valid
     */
    const validateNumberInput = (value, min, max) => {
        const numValue = parseInt(value, 10);
        return !isNaN(numValue) && numValue >= min && numValue <= max;
    };
    
    /**
     * Safely parse JSON with error handling
     * @param {string} jsonString JSON string to parse
     * @returns {Object|null} Parsed object or null on error
     */
    const safeJsonParse = (jsonString) => {
        try {
            return JSON.parse(jsonString);
        } catch (e) {
            logger.error("JSON Parse Error:", e);
            return null;
        }
    };
    
    /**
     * Helper to create DOM elements with attributes and content
     * @param {string} tag HTML tag name
     * @param {Object} attributes Element attributes
     * @param {string|Node|Array} content Element content
     * @returns {HTMLElement} Created element
     */
    const createElement = (tag, attributes = {}, content = null) => {
        const element = document.createElement(tag);
        
        // Set attributes
        Object.entries(attributes).forEach(([key, value]) => {
            if (key === 'className') {
                element.className = value;
            } else if (key === 'dataset') {
                Object.entries(value).forEach(([dataKey, dataValue]) => {
                    element.dataset[dataKey] = dataValue;
                });
            } else {
                element.setAttribute(key, value);
            }
        });
        
        // Add content
        if (content) {
            if (Array.isArray(content)) {
                content.forEach(item => {
                    if (item instanceof Node) {
                        element.appendChild(item);
                    } else {
                        element.appendChild(document.createTextNode(item));
                    }
                });
            } else if (content instanceof Node) {
                element.appendChild(content);
            } else {
                element.textContent = content;
            }
        }
        
        return element;
    };
    
    // Return public methods
    return {
        sanitizeHTML,
        preventDefaults,
        getCurrentFormattedDate,
        generateExportFilename,
        logger,
        validateNumberInput,
        safeJsonParse,
        createElement
    };
})();

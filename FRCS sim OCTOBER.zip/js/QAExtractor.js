/**
 * Q&A Extractor - Extracts existing questions and answers from documents
 * Handles various question formats commonly found in medical documents
 */

class QAExtractor {
    constructor() {
        this.patterns = {
            // Multiple choice questions with options A, B, C, D
            mcq: {
                question: /^(?:\d+\.?\s*|Q\d*\.?\s*)?(.+?)(?=\s*[A-Z]\.)/gm,
                options: /^([A-Z])\.\s*(.+)$/gm,
                answer: /(?:Answer|Ans|Correct|Solution):\s*([A-Z])/gi
            },
            
            // Numbered questions (1., 2., etc.)
            numbered: {
                question: /^(\d+\.?\s*)((?:(?!\d+\.).)+?)(?=(?:\d+\.|Answer|Ans|A:|Q\d+|$))/gms,
                answer: /(?:Answer|Ans|Solution):\s*(.+?)(?=(?:\d+\.|Q\d+|$))/gis
            },
            
            // Q: / A: format
            qanda: {
                question: /^Q(?:\d+)?:\s*(.+?)(?=\s*A:|$)/gims,
                answer: /^A(?:\d+)?:\s*(.+?)(?=\s*Q:|$)/gims
            },
            
            // Bold questions (often marked with **text** or <b>text</b>)
            bold: {
                question: /(?:\*\*|<b>|<strong>)(.+?)(?:\*\*|<\/b>|<\/strong>).*?(?=\*\*|<b>|<strong>|$)/gis,
                answer: /(?:Answer|Ans|Solution):\s*(.+?)(?=(?:\*\*|<b>|<strong>)|$)/gis
            },
            
            // Clinical case format
            clinical: {
                question: /(?:Case|Scenario|Patient)\s*\d*:\s*(.+?)(?=(?:Question|What|Which|How|Answer)|$)/gis,
                answer: /(?:Answer|Diagnosis|Management|Treatment):\s*(.+?)(?=(?:Case|Question)|$)/gis
            }
        };
        
        this.settings = {
            minQuestionLength: 10,
            maxQuestionLength: 1000,
            minAnswerLength: 3,
            maxAnswerLength: 2000,
            extractMCQ: true,
            extractNumbered: true,
            extractQandA: true,
            extractBold: true,
            extractClinical: true,
            // New smarter/looser extraction controls
            aggressiveMode: true,
            allowShortQuestions: true,
            pairAnswersByProximity: true
        };
    }

    /**
     * Update extraction settings
     */
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
    }

    /**
     * Main extraction function
     */
    extractQuestionsAndAnswers(text, options = {}) {
        log('Starting Q&A extraction from document...', 'info');
        
        // Update settings if provided
        if (options) {
            this.updateSettings(options);
        }

        let extractedQA = [];
        
        // Clean and normalize text
        const cleanText = this.cleanText(text);
        log(`Cleaned text length: ${cleanText.length} characters`, 'info');

        try {
            // Extract using different patterns based on settings
            if (this.settings.extractMCQ) {
                const mcqQuestions = this.extractMCQQuestions(cleanText);
                extractedQA = extractedQA.concat(mcqQuestions);
                log(`Extracted ${mcqQuestions.length} MCQ questions`, 'info');
            }

            if (this.settings.extractNumbered) {
                const numberedQuestions = this.extractNumberedQuestions(cleanText);
                extractedQA = extractedQA.concat(numberedQuestions);
                log(`Extracted ${numberedQuestions.length} numbered questions`, 'info');
            }

            if (this.settings.extractQandA) {
                const qandaQuestions = this.extractQandAQuestions(cleanText);
                extractedQA = extractedQA.concat(qandaQuestions);
                log(`Extracted ${qandaQuestions.length} Q&A format questions`, 'info');
            }

            if (this.settings.extractBold) {
                const boldQuestions = this.extractBoldQuestions(cleanText);
                extractedQA = extractedQA.concat(boldQuestions);
                log(`Extracted ${boldQuestions.length} bold questions`, 'info');
            }

            if (this.settings.extractClinical) {
                const clinicalQuestions = this.extractClinicalQuestions(cleanText);
                extractedQA = extractedQA.concat(clinicalQuestions);
                log(`Extracted ${clinicalQuestions.length} clinical case questions`, 'info');
            }

            // Aggressive fallback: broaden detection and pair by proximity
            if (this.settings.aggressiveMode || extractedQA.length === 0) {
                const aggressive = this.aggressiveFallbackExtraction(cleanText);
                log(`Aggressive fallback extracted ${aggressive.length} items`, 'info');
                extractedQA = this.mergeAndDedupe(extractedQA, aggressive);

                // If enhanced extractor is available, merge its results with lower threshold
                if (typeof window !== 'undefined' && window.enhancedQAExtractor &&
                    typeof window.enhancedQAExtractor.extractFromText === 'function') {
                    try {
                        const enhancedResult = window.enhancedQAExtractor.extractFromText(cleanText, { confidenceThreshold: 0.3 });
                        if (enhancedResult && enhancedResult.then) {
                            // Handle promise
                            // Note: synchronous wrapper; we can't await here, so skip in strict environments
                        } else if (enhancedResult && enhancedResult.questions) {
                            extractedQA = this.mergeAndDedupe(extractedQA, enhancedResult.questions.map(q => ({
                                question: q.question,
                                answer: q.answer || '',
                                type: q.type || 'short-answer',
                                options: q.options || [],
                                source: 'enhanced',
                                confidence: Math.max(0.5, q.confidence || 0.5)
                            })));
                        }
                    } catch (e) {
                        // Non-fatal
                        log('Enhanced extractor merge skipped: ' + (e && e.message ? e.message : 'unknown error'), 'warning');
                    }
                }
            }

        } catch (error) {
            log(`Error during extraction: ${error.message}`, 'error');
        }

        // Remove duplicates and clean up results
        extractedQA = this.removeDuplicates(extractedQA);
        extractedQA = this.validateQuestions(extractedQA);

        log(`Total extracted Q&A pairs: ${extractedQA.length}`, 'success');
        return extractedQA;
    }

    /**
     * Clean and normalize text for processing
     */
    cleanText(text) {
        return text
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .replace(/\t+/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim();
    }

    /**
     * Extract multiple choice questions
     */
    extractMCQQuestions(text) {
        const questions = [];
        const lines = text.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            
            // Look for question pattern
            if (this.isQuestionLine(line)) {
                const questionObj = {
                    question: this.cleanQuestionText(line),
                    options: [],
                    answer: '',
                    type: 'multiple-choice',
                    source: 'extracted',
                    confidence: 0.7
                };

                // Look for options in following lines
                let j = i + 1;
                while (j < lines.length && lines[j].trim()) {
                    const optionLine = lines[j].trim();
                    
                    // Check if it's an option (A., B., C., D., etc.)
                    const optionMatch = optionLine.match(/^([A-Ea-e])([\)\.:])?\s+(.+)$/);
                    if (optionMatch) {
                        const label = optionMatch[1].toUpperCase();
                        const textPart = optionMatch[3] ? optionMatch[3] : (optionMatch[2] || '').trim();
                        questionObj.options.push({
                            label: label,
                            text: (textPart || '').trim()
                        });
                        j++;
                    } else if (this.isAnswerLine(optionLine)) {
                        // Found answer line
                        const answerMatch = optionLine.match(/(?:Answer|Ans|Correct(?:\s+answer)?):?\s*([A-E])/i);
                        if (answerMatch) {
                            questionObj.answer = answerMatch[1].toUpperCase();
                            questionObj.confidence = 0.9;
                        }
                        break;
                    } else {
                        break;
                    }
                }

                // Only include if we found options
                if (questionObj.options.length >= 2 && 
                    (this.settings.allowShortQuestions || questionObj.question.length >= this.settings.minQuestionLength)) {
                    // If no explicit answer line, try to infer marked correct option
                    if (!questionObj.answer) {
                        const marked = questionObj.options.find(opt => /\b(correct|true)\b|\*|✔|✓/i.test(opt.text));
                        if (marked) {
                            questionObj.answer = questionObj.options.findIndex(opt => opt === marked) !== -1 ? marked.label : '';
                            if (questionObj.answer) questionObj.confidence = Math.max(questionObj.confidence, 0.8);
                        }
                    }
                    questions.push(questionObj);
                }
            }
        }

        return questions;
    }

    /**
     * Extract numbered questions
     */
    extractNumberedQuestions(text) {
        const questions = [];
        const matches = Array.from(text.matchAll(this.patterns.numbered.question));
        
        for (let idx = 0; idx < matches.length; idx++) {
            const match = matches[idx];
            const questionText = match[2].trim();
            const thisEnd = match.index + match[0].length;
            const nextStart = idx + 1 < matches.length ? matches[idx + 1].index : text.length;
            const scope = text.slice(thisEnd, nextStart);
            
            if (this.settings.allowShortQuestions || questionText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: questionText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.6
                };

                // Look for corresponding answer inside the scope between this and next question
                const answerMatch = scope.match(/(?:^|\n)\s*(?:Answer|Ans|Solution|Explanation)[:\.]?\s*(.+?)(?=\n\s*\d+\.|\n\s*Q\d+|$)/is);
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.8;
                } else if (this.settings.pairAnswersByProximity) {
                    // Fallback: take the next non-empty line/paragraph as tentative answer
                    const tentative = scope.split('\n').map(s => s.trim()).filter(Boolean)[0] || '';
                    if (tentative && tentative.length >= this.settings.minAnswerLength && !/^\d+\.|^Q\d+/i.test(tentative)) {
                        questionObj.answer = tentative;
                        questionObj.confidence = Math.max(questionObj.confidence, 0.65);
                    }
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract Q&A format questions
     */
    extractQandAQuestions(text) {
        const questions = [];
        const qMatches = Array.from(text.matchAll(this.patterns.qanda.question));
        const aMatches = Array.from(text.matchAll(this.patterns.qanda.answer));

        for (let i = 0; i < qMatches.length; i++) {
            const q = qMatches[i];
            const qText = q[1].trim();
            const qEnd = q.index + q[0].length;
            const nextQStart = i + 1 < qMatches.length ? qMatches[i + 1].index : text.length;

            if (this.settings.allowShortQuestions || qText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: qText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.8
                };

                // Find nearest answer that falls between this question end and next question start
                const candidate = aMatches.find(a => a.index >= qEnd && a.index < nextQStart);
                if (candidate) {
                    questionObj.answer = (candidate[1] || '').trim();
                    questionObj.confidence = 0.9;
                } else if (this.settings.pairAnswersByProximity) {
                    const scope = text.slice(qEnd, nextQStart);
                    const tentative = scope.split('\n').map(s => s.trim()).filter(Boolean)[0] || '';
                    if (tentative && tentative.length >= this.settings.minAnswerLength && !/^Q\s*\d*[:\.]?/i.test(tentative)) {
                        questionObj.answer = tentative;
                        questionObj.confidence = Math.max(questionObj.confidence, 0.7);
                    }
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract bold/emphasized questions
     */
    extractBoldQuestions(text) {
        const questions = [];
        const matches = text.matchAll(this.patterns.bold.question);
        
        for (const match of matches) {
            const questionText = match[1].trim();
            
            if (questionText.length >= this.settings.minQuestionLength && 
                this.looksLikeQuestion(questionText)) {
                
                const questionObj = {
                    question: questionText,
                    answer: '',
                    type: 'short-answer',
                    source: 'extracted',
                    confidence: 0.5
                };

                // Look for nearby answer
                const context = text.substring(match.index, match.index + 500);
                const answerMatch = context.match(this.patterns.bold.answer);
                
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.7;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Extract clinical case questions
     */
    extractClinicalQuestions(text) {
        const questions = [];
        const matches = text.matchAll(this.patterns.clinical.question);
        
        for (const match of matches) {
            const caseText = match[1].trim();
            
            if (caseText.length >= this.settings.minQuestionLength) {
                const questionObj = {
                    question: `Clinical Case: ${caseText}`,
                    answer: '',
                    type: 'clinical-case',
                    source: 'extracted',
                    confidence: 0.7
                };

                // Look for corresponding answer/diagnosis
                const context = text.substring(match.index, match.index + 1000);
                const answerMatch = context.match(this.patterns.clinical.answer);
                
                if (answerMatch) {
                    questionObj.answer = answerMatch[1].trim();
                    questionObj.confidence = 0.8;
                }

                questions.push(questionObj);
            }
        }

        return questions;
    }

    /**
     * Check if a line looks like a question
     */
    isQuestionLine(line) {
        // Check for question indicators (more permissive)
        const questionIndicators = [
            /^\d+\.?\s*.+[\?:]/,  // Numbered question ending with ? or :
            /^Q\d*\.?\s*.+/,       // Q1., Q., etc.
            /^(What|Which|How|When|Where|Why|Who|Can|Could|Should|Does|Do|Did|Is|Are)\b/i,
            /^(Case|Scenario|Patient)\b/i,
            /True\s+or\s+False|T\/F/i
        ];

        if (questionIndicators.some(pattern => pattern.test(line))) {
            const minLen = Math.min(this.settings.minQuestionLength, 10);
            return line.length >= (this.settings.allowShortQuestions ? 8 : minLen);
        }
        
        // Also accept lines with a question mark even if short
        if (line.includes('?')) {
            return line.trim().length >= 8;
        }
        
        return false;
    }

    /**
     * Check if a line looks like an answer
     */
    isAnswerLine(line) {
        return /^(?:Answer|Ans|Solution|Explanation|Rationale|Diagnosis|Management|Treatment|Correct(?:\s+answer)?):\s*/i.test(line);
    }

    /**
     * Check if text looks like a question
     */
    looksLikeQuestion(text) {
        const questionWords = ['what', 'which', 'how', 'when', 'where', 'why', 'can', 'should', 'does', 'is', 'are'];
        const hasQuestionWord = questionWords.some(word => 
            text.toLowerCase().includes(word)
        );
        
        return hasQuestionWord || text.includes('?') || 
               /^(?:Define|Explain|Describe|List|Name|Identify)/i.test(text);
    }

    /**
     * Clean question text
     */
    cleanQuestionText(text) {
        return text
            .replace(/^\d+\.?\s*/, '')  // Remove question numbers
            .replace(/^Q\d*\.?\s*/i, '') // Remove Q1., Q., etc.
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Remove duplicate questions
     */
    removeDuplicates(questions) {
        const seen = new Set();
        return questions.filter(q => {
            const key = q.question.toLowerCase().trim();
            if (seen.has(key)) {
                return false;
            }
            seen.add(key);
            return true;
        });
    }

    /**
     * Validate and filter questions
     */
    validateQuestions(questions) {
        return questions.filter(q => {
            const qText = (q.question || '').trim();
            const aText = (q.answer || '').trim();

            // Check question length (more permissive)
            if (!this.settings.allowShortQuestions) {
                if (qText.length < this.settings.minQuestionLength || qText.length > this.settings.maxQuestionLength) {
                    return false;
                }
            } else {
                if (qText.length < 8 || qText.length > this.settings.maxQuestionLength) {
                    return false;
                }
            }

            // Check answer length if present
            if (aText && (aText.length < this.settings.minAnswerLength || aText.length > this.settings.maxAnswerLength)) {
                // Don't filter out, just log
                log(`Answer length warning for question: ${qText.substring(0, 50)}...`, 'warning');
            }

            // Basic quality checks
            if (qText.split(' ').length < 2) {
                return false; // Too short
            }

            // Remove questions that are likely headers or non-questions
            if (/^(?:Chapter|Section|Part|Page|\d+\.?\s*$)/i.test(qText)) {
                return false;
            }

            return true;
        });
    }

    // Merge helper that prefers items with answers and higher confidence
    mergeAndDedupe(existing, incoming) {
        const byKey = new Map();
        const consider = [...existing, ...incoming];
        consider.forEach(item => {
            const key = (item.question || '').toLowerCase().replace(/\s+/g, ' ').trim();
            if (!key) return;
            const prev = byKey.get(key);
            if (!prev) {
                byKey.set(key, item);
            } else {
                const prevHasAns = !!(prev.answer && prev.answer.trim());
                const curHasAns = !!(item.answer && item.answer.trim());
                if (curHasAns && !prevHasAns) {
                    byKey.set(key, item);
                } else if ((curHasAns === prevHasAns) && ((item.confidence || 0) > (prev.confidence || 0))) {
                    byKey.set(key, item);
                }
            }
        });
        return Array.from(byKey.values());
    }

    // Aggressive fallback extractor: looser heuristics and proximity-based A pairing
    aggressiveFallbackExtraction(text) {
        const results = [];
        const lines = text.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            const raw = lines[i];
            const line = raw.trim();
            if (!line) continue;

            if (this.isQuestionLine(line) || /\?$/.test(line) || /:\s*$/.test(line)) {
                let questionText = this.cleanQuestionText(line);
                if (!/[?]$/.test(questionText) && /\?$/.test(line)) {
                    questionText = questionText + '';
                }

                const qa = {
                    question: questionText,
                    answer: '',
                    options: [],
                    type: 'short-answer',
                    source: 'aggressive',
                    confidence: 0.5
                };

                // Look ahead for options and answers within a small window
                let j = i + 1;
                while (j < lines.length) {
                    const look = lines[j].trim();
                    if (!look) { j++; continue; }
                    if (this.isQuestionLine(look)) break;

                    // Options
                    const opt = look.match(/^([A-Ea-e])([\)\.:])?\s+(.+)$/);
                    if (opt) {
                        qa.options.push({ label: opt[1].toUpperCase(), text: (opt[3] || '').trim() });
                        j++; continue;
                    }

                    // Answer start
                    if (this.isAnswerLine(look)) {
                        qa.answer = look.replace(/^(?:Answer|Ans|Solution|Explanation|Rationale|Diagnosis|Management|Treatment|Correct(?:\s+answer)?):\s*/i, '').trim();
                        qa.confidence = Math.max(qa.confidence, 0.7);
                        j++; break;
                    }

                    // Tentative answer: the next non-empty line that is not a new question
                    if (!qa.answer && this.settings.pairAnswersByProximity && look.length >= this.settings.minAnswerLength) {
                        qa.answer = look;
                        qa.confidence = Math.max(qa.confidence, 0.6);
                        j++; break;
                    }

                    j++;
                }

                if (qa.options.length >= 2) {
                    qa.type = 'multiple-choice';
                    // Attempt to infer marked correct option
                    if (!qa.answer) {
                        const marked = qa.options.find(opt => /\b(correct|true)\b|\*|✔|✓/i.test(opt.text));
                        if (marked) {
                            qa.answer = marked.label;
                            qa.confidence = Math.max(qa.confidence, 0.75);
                        }
                    }
                }

                if (this.settings.allowShortQuestions || qa.question.length >= this.settings.minQuestionLength) {
                    results.push(qa);
                }
            }
        }

        return results;
    }

    /**
     * Format extracted Q&A for display
     */
    formatForDisplay(extractedQA) {
        return extractedQA.map((qa, index) => ({
            id: `extracted_${index + 1}`,
            question: qa.question,
            answer: qa.answer || 'No answer found in document',
            type: qa.type,
            options: qa.options || [],
            source: 'extracted',
            confidence: qa.confidence,
            metadata: {
                extractionMethod: qa.type,
                originalIndex: index
            }
        }));
    }

    /**
     * Get extraction statistics
     */
    getExtractionStats(extractedQA) {
        const stats = {
            total: extractedQA.length,
            withAnswers: extractedQA.filter(qa => qa.answer && qa.answer.trim()).length,
            types: {},
            averageConfidence: 0
        };

        extractedQA.forEach(qa => {
            stats.types[qa.type] = (stats.types[qa.type] || 0) + 1;
            stats.averageConfidence += qa.confidence || 0;
        });

        if (extractedQA.length > 0) {
            stats.averageConfidence /= extractedQA.length;
        }

        return stats;
    }
}

// Make available globally
window.QAExtractor = QAExtractor; 
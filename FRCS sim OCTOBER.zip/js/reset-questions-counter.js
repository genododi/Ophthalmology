document.addEventListener('DOMContentLoaded', () => {
    // Reset the question counter to zero (requirement #3)
    const questionCountElement = document.getElementById('question-count');
    if (questionCountElement) {
        // Reset the counter to zero
        questionCountElement.textContent = '0';
        
        // Save to localStorage
        localStorage.setItem('question_count', '0');
        
        console.log('Questions counter has been reset to zero');
    } else {
        console.warn('Question counter element not found');
    }
    
    // Make the usage counter visible
    const usageCounter = document.querySelector('.usage-counter');
    if (usageCounter) {
        usageCounter.classList.remove('hidden');
    }
    
    // Initialize question history tracking for duplicate detection
    if (!window.questionHistory) {
        window.questionHistory = [];
        
        // Load any existing history from localStorage
        try {
            const savedHistory = localStorage.getItem('question_history');
            if (savedHistory) {
                window.questionHistory = JSON.parse(savedHistory);
                console.log(`Loaded ${window.questionHistory.length} questions from history for duplicate detection`);
            }
        } catch (error) {
            console.error('Error loading question history:', error);
            // Reset history if there was an error
            window.questionHistory = [];
        }
    }
    
    // Function to check for duplicate questions
    window.checkForDuplicateQuestion = (questionText) => {
        // Skip if no text or history not initialized
        if (!questionText || !window.questionHistory) return false;
        
        // Normalize question text for comparison
        const normalizedText = questionText
            .toLowerCase()
            .replace(/\s+/g, ' ')
            .trim();
        
        // Check if this normalized question exists in our history
        return window.questionHistory.some(q => {
            const normalizedHistory = q
                .toLowerCase()
                .replace(/\s+/g, ' ')
                .trim();
            return normalizedHistory === normalizedText;
        });
    };
    
    // Function to add a question to history
    window.addQuestionToHistory = (questionText) => {
        if (!questionText || !window.questionHistory) return;
        
        // Add to history
        window.questionHistory.push(questionText);
        
        // Save to localStorage (limit to last 200 questions to prevent storage issues)
        if (window.questionHistory.length > 200) {
            window.questionHistory = window.questionHistory.slice(-200);
        }
        
        try {
            localStorage.setItem('question_history', JSON.stringify(window.questionHistory));
        } catch (error) {
            console.error('Error saving question history:', error);
        }
    };
    
    console.log('Question history tracking initialized for duplicate detection');
});

(function(){
  const STORAGE_KEY = 'referenceSourcesEnabled_v1';

  function readToggleFromStorage(){
    try { const v = localStorage.getItem(STORAGE_KEY); return v === null ? true : v === '1'; } catch(_) { return true; }
  }
  function writeToggleToStorage(enabled){
    try { localStorage.setItem(STORAGE_KEY, enabled ? '1' : '0'); } catch(_) {}
  }

  function createFileUrl(absolutePath){
    try {
      if (!absolutePath) return null;
      if (/^file:\/\//i.test(absolutePath)) return encodeURI(absolutePath);
      // Ensure three slashes after scheme
      const normalized = absolutePath.startsWith('/') ? absolutePath : '/' + absolutePath;
      return encodeURI('file://' + normalized).replace('file:///', 'file:///');
    } catch(_) { return null; }
  }

  // Known references (names and accessible URLs where possible)
  const defaultSources = [
    {
      id: 'oxford',
      name: 'Oxford (Local copy)',
      // This file is expected alongside the HTML in the same directory
      url: 'oxford.pdf'
    },
    {
      id: 'wills-eye-manual-8e',
      name: 'The Wills Eye Manual (8th Ed.)',
      url: createFileUrl('/Users/mahmoudsami/Downloads/The Wills Eye Manual 8th Ed.pdf')
    },
    {
      id: 'wong-ophthal-exam-review-3e',
      name: 'The Ophthalmology Examinations Review (Tien Yin Wong, 3rd Ed.)',
      url: createFileUrl('/Users/mahmoudsami/Downloads/The Ophthalmology Examinations Review Tien Yin WONG 3rd Ed.pdf')
    },
    {
      id: 'waleed-badr-maoe',
      name: 'INT & Emergency Medicine (Waleed Badr, MAOE)',
      url: createFileUrl('/Users/mahmoudsami/Downloads/INT & Emergency Medicine - Waleed Badr MAOE.pdf')
    }
  ];

  function getSources(){
    return defaultSources.map(s => ({ id: s.id, name: s.name, url: s.url }));
  }

  function getSourcesForPrompt(){
    const srcs = getSources();
    if (!Array.isArray(srcs) || srcs.length === 0) return '';
    const lines = srcs.map(s => {
      const label = s.name || s.id;
      const link = s.url ? ` <${s.url}>` : '';
      return `- ${label}${link}`;
    });
    return ['Reference sources:', ...lines].join('\n');
  }

  function dispatchChange(){
    try {
      const event = new CustomEvent('reference-sources-changed', {
        detail: { enabled: api.isEnabled(), sources: api.getSources() }
      });
      window.dispatchEvent(event);
    } catch(_) {}
  }

  function ensureToggleUI(){
    try {
      if (document.getElementById('reference-sources-toggle')) return;

      const container = document.createElement('div');
      container.id = 'reference-sources-toggle';
      container.className = 'max-w-4xl mx-auto my-4 p-4 bg-white rounded-lg shadow card';

      const enabled = api.isEnabled();

      container.innerHTML = [
        '<div class="flex items-start justify-between">',
        '  <div class="flex items-start gap-3">',
        '    <input id="use-reference-sources" type="checkbox" class="mt-1 h-4 w-4 text-blue-600 border-gray-300 rounded" ' + (enabled ? 'checked' : '') + ' />',
        '    <div>',
        '      <label for="use-reference-sources" class="text-sm font-medium text-gray-800">Use reference sources (Oxford, Wills, Wong, Waleed Badr)</label>',
        '      <p class="text-xs text-gray-500 mt-1">When enabled, question generation can cite these references.</p>',
        '    </div>',
        '  </div>',
        '  <details class="text-sm text-gray-600">',
        '    <summary class="cursor-pointer select-none">View sources</summary>',
        '    <ul class="list-disc list-inside mt-2">',
        defaultSources.map(s => {
          const safeName = (s.name || s.id);
          if (s.url) return `<li><a href="${s.url}" target="_blank" class="text-blue-600 hover:underline">${safeName}</a></li>`;
          return `<li>${safeName}</li>`;
        }).join(''),
        '    </ul>',
        '  </details>',
        '</div>'
      ].join('');

      // Insert after <header> if present, else before Anki section, else at top of body
      const headerEl = document.querySelector('header');
      const ankiSection = document.getElementById('anki-section');
      if (headerEl && headerEl.parentNode) {
        headerEl.parentNode.insertBefore(container, headerEl.nextSibling);
      } else if (ankiSection && ankiSection.parentNode) {
        ankiSection.parentNode.insertBefore(container, ankiSection);
      } else {
        document.body.insertBefore(container, document.body.firstChild);
      }

      const checkbox = container.querySelector('#use-reference-sources');
      if (checkbox) {
        checkbox.addEventListener('change', function(){
          api.enable(this.checked);
        });
      }
    } catch(_) {}
  }

  const api = {
    enable: function(enabled){
      const value = !!enabled;
      writeToggleToStorage(value);
      dispatchChange();
    },
    isEnabled: function(){ return readToggleFromStorage(); },
    getSources: getSources,
    getSourcesForPrompt: getSourcesForPrompt
  };

  window.referenceSourceManager = api;

  function onReady(fn){
    if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(fn, 0);
    else document.addEventListener('DOMContentLoaded', fn);
  }

  onReady(function(){
    ensureToggleUI();
    dispatchChange();
  });
})();



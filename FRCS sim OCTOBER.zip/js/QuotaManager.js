/**
 * QuotaManager - Manages API call quotas for different services
 * Tracks, limits, and resets API usage based on user status
 */
class QuotaManager {
    constructor() {
        this.quotaConfig = CONFIG.API_QUOTA;
        this.quotas = {};
        
        // Alternative API keys for bypassing quota limits
        this.alternativeApiKeys = {
            GEMINI: (Array.isArray(CONFIG?.API_KEYS?.GEMINI_FAILOVER) && CONFIG.API_KEYS.GEMINI_FAILOVER[0]) || null
        };
        this.usingAlternativeKey = {
            GEMINI: false
        };
        
        // UI elements
        this.openaiQuotaBar = null;
        this.geminiQuotaBar = null;
        this.claudeQuotaBar = null;
        this.cursorAiQuotaBar = null;
        this.openaiQuotaCount = null;
        this.geminiQuotaCount = null;
        this.claudeQuotaCount = null;
        this.cursorAiQuotaCount = null;
        
        // Flag to track if user is creator/admin
        this.isCreator = false;
        
        // Initialize quotas from localStorage
        this.initializeQuotas();
        
        // Initialize UI elements after DOM is fully loaded
        document.addEventListener('DOMContentLoaded', () => this.initializeUI());
        
        // Listen for login events to reset quotas
        document.addEventListener('ophthalmoqa:loginChanged', (e) => this.handleLoginChange(e.detail));
        
        // Maximum content size for API calls to prevent quota issues with large files
        this.maxContentSize = 50000; // Characters
    }
    
    /**
     * Initialize quota tracking from localStorage
     */
    initializeQuotas() {
        // Initialize quota for each API
        for (const [apiName, config] of Object.entries(this.quotaConfig)) {
            const storedQuota = localStorage.getItem(config.QUOTA_STORAGE_KEY);
            
            if (storedQuota !== null) {
                this.quotas[apiName] = parseInt(storedQuota, 10);
            } else {
                // Set default quota if not found
                this.quotas[apiName] = config.DEFAULT_QUOTA;
                localStorage.setItem(config.QUOTA_STORAGE_KEY, String(config.DEFAULT_QUOTA));
            }
        }
        
        // Check if user is creator
        this.checkCreatorStatus();
    }
    
    /**
     * Check if the current user is the creator/admin
     */
    checkCreatorStatus() {
        // First check if authManager is available
        if (window.authManager && window.authManager.currentUser) {
            this.isCreator = window.authManager.currentUser.isCreator === true;
        } else {
            // If not yet available, check again when DOM is loaded
            document.addEventListener('DOMContentLoaded', () => {
                if (window.authManager && window.authManager.currentUser) {
                    this.isCreator = window.authManager.currentUser.isCreator === true;
                }
            });
        }
    }
    
    /**
     * Initialize UI elements for quota display
     */
    initializeUI() {
        // Get quota display elements
        this.openaiQuotaBar = document.getElementById('openai-quota-bar');
        this.geminiQuotaBar = document.getElementById('gemini-quota-bar');
        this.claudeQuotaBar = document.getElementById('claude-quota-bar');
        this.cursorAiQuotaBar = document.getElementById('cursor-ai-quota-bar');
        this.openaiQuotaCount = document.getElementById('openai-quota-count');
        this.geminiQuotaCount = document.getElementById('gemini-quota-count');
        this.claudeQuotaCount = document.getElementById('claude-quota-count');
        this.cursorAiQuotaCount = document.getElementById('cursor-ai-quota-count');
        
        // Update UI with current quota values
        this.updateQuotaUI();
    }
    
    /**
     * Update UI elements to reflect current quota status
     */
    updateQuotaUI() {
        if (!this.openaiQuotaBar || !this.geminiQuotaBar || 
            !this.openaiQuotaCount || !this.geminiQuotaCount) {
            return;
        }
        
        // If user is creator, show unlimited quota
        if (this.isCreator) {
            this.updateCreatorQuotaUI();
            return;
        }
        
        // Update OpenAI quota display
        const openaiQuota = this.quotas['OPENAI'] || 0;
        const openaiMaxQuota = this.getMaxQuota('OPENAI');
        const openaiPercentage = Math.min(100, Math.max(0, (openaiQuota / openaiMaxQuota) * 100));
        
        this.openaiQuotaBar.style.width = `${openaiPercentage}%`;
        this.openaiQuotaCount.textContent = `${openaiQuota}/${openaiMaxQuota}`;
        
        // Update color based on remaining quota
        if (openaiPercentage <= 20) {
            this.openaiQuotaBar.classList.remove('bg-green-500', 'bg-yellow-500');
            this.openaiQuotaBar.classList.add('bg-red-500');
        } else if (openaiPercentage <= 50) {
            this.openaiQuotaBar.classList.remove('bg-green-500', 'bg-red-500');
            this.openaiQuotaBar.classList.add('bg-yellow-500');
        } else {
            this.openaiQuotaBar.classList.remove('bg-yellow-500', 'bg-red-500');
            this.openaiQuotaBar.classList.add('bg-green-500');
        }
        
        // Update Gemini quota display
        const geminiQuota = this.quotas['GEMINI'] || 0;
        const geminiMaxQuota = this.getMaxQuota('GEMINI');
        const geminiPercentage = Math.min(100, Math.max(0, (geminiQuota / geminiMaxQuota) * 100));
        
        this.geminiQuotaBar.style.width = `${geminiPercentage}%`;
        this.geminiQuotaCount.textContent = `${geminiQuota}/${geminiMaxQuota}`;
        
        // Update color based on remaining quota
        if (geminiPercentage <= 20) {
            this.geminiQuotaBar.classList.remove('bg-green-500', 'bg-yellow-500');
            this.geminiQuotaBar.classList.add('bg-red-500');
        } else if (geminiPercentage <= 50) {
            this.geminiQuotaBar.classList.remove('bg-green-500', 'bg-red-500');
            this.geminiQuotaBar.classList.add('bg-yellow-500');
        } else {
            this.geminiQuotaBar.classList.remove('bg-yellow-500', 'bg-red-500');
            this.geminiQuotaBar.classList.add('bg-green-500');
        }
        
        // Update Claude quota display if UI elements exist
        if (this.claudeQuotaBar && this.claudeQuotaCount) {
            const claudeQuota = this.quotas['CLAUDE'] || 0;
            const claudeMaxQuota = this.getMaxQuota('CLAUDE');
            const claudePercentage = Math.min(100, Math.max(0, (claudeQuota / claudeMaxQuota) * 100));
            
            this.claudeQuotaBar.style.width = `${claudePercentage}%`;
            this.claudeQuotaCount.textContent = `${claudeQuota}/${claudeMaxQuota}`;
            
            // Update color based on remaining quota
            if (claudePercentage <= 20) {
                this.claudeQuotaBar.classList.remove('bg-green-500', 'bg-yellow-500');
                this.claudeQuotaBar.classList.add('bg-red-500');
            } else if (claudePercentage <= 50) {
                this.claudeQuotaBar.classList.remove('bg-green-500', 'bg-red-500');
                this.claudeQuotaBar.classList.add('bg-yellow-500');
            } else {
                this.claudeQuotaBar.classList.remove('bg-yellow-500', 'bg-red-500');
                this.claudeQuotaBar.classList.add('bg-green-500');
            }
        }
        
        // Update Cursor AI quota display if UI elements exist
        if (this.cursorAiQuotaBar && this.cursorAiQuotaCount) {
            const cursorQuota = this.quotas['CURSOR_AI'] || 0;
            const cursorMaxQuota = this.getMaxQuota('CURSOR_AI');
            const cursorPercentage = Math.min(100, Math.max(0, (cursorQuota / cursorMaxQuota) * 100));
            
            this.cursorAiQuotaBar.style.width = `${cursorPercentage}%`;
            this.cursorAiQuotaCount.textContent = `${cursorQuota}/${cursorMaxQuota}`;
            
            // Update color based on remaining quota
            if (cursorPercentage <= 20) {
                this.cursorAiQuotaBar.classList.remove('bg-green-500', 'bg-yellow-500');
                this.cursorAiQuotaBar.classList.add('bg-red-500');
            } else if (cursorPercentage <= 50) {
                this.cursorAiQuotaBar.classList.remove('bg-green-500', 'bg-red-500');
                this.cursorAiQuotaBar.classList.add('bg-yellow-500');
            } else {
                this.cursorAiQuotaBar.classList.remove('bg-yellow-500', 'bg-red-500');
                this.cursorAiQuotaBar.classList.add('bg-green-500');
            }
        }
        
        // Update BioGPT quota display if applicable
        if (this.quotas['BIOGPT'] !== undefined) {
            // Even if no UI elements, keep the quota tracking up to date
            // This ensures accurate quota checks even if not displayed in UI
            console.log(`BioGPT quota: ${this.quotas['BIOGPT']}/${this.getMaxQuota('BIOGPT')}`);
        }
        
        // Update BioMistral quota display if applicable
        if (this.quotas['BIOMISTRAL'] !== undefined) {
            // Even if no UI elements, keep the quota tracking up to date
            console.log(`BioMistral quota: ${this.quotas['BIOMISTRAL']}/${this.getMaxQuota('BIOMISTRAL')}`);
        }
    }
    
    /**
     * Special UI update for creator/admin showing unlimited quota
     */
    updateCreatorQuotaUI() {
        if (this.openaiQuotaBar && this.openaiQuotaCount) {
            this.openaiQuotaBar.style.width = "100%";
            this.openaiQuotaBar.classList.remove('bg-red-500', 'bg-yellow-500');
            this.openaiQuotaBar.classList.add('bg-green-500');
            this.openaiQuotaCount.textContent = "∞/∞";
        }
        
        if (this.geminiQuotaBar && this.geminiQuotaCount) {
            this.geminiQuotaBar.style.width = "100%";
            this.geminiQuotaBar.classList.remove('bg-red-500', 'bg-yellow-500');
            this.geminiQuotaBar.classList.add('bg-green-500');
            this.geminiQuotaCount.textContent = "∞/∞";
        }
        
        if (this.claudeQuotaBar && this.claudeQuotaCount) {
            this.claudeQuotaBar.style.width = "100%";
            this.claudeQuotaBar.classList.remove('bg-red-500', 'bg-yellow-500');
            this.claudeQuotaBar.classList.add('bg-green-500');
            this.claudeQuotaCount.textContent = "∞/∞";
        }
        
        if (this.cursorAiQuotaBar && this.cursorAiQuotaCount) {
            this.cursorAiQuotaBar.style.width = "100%";
            this.cursorAiQuotaBar.classList.remove('bg-red-500', 'bg-yellow-500');
            this.cursorAiQuotaBar.classList.add('bg-green-500'); 
            this.cursorAiQuotaCount.textContent = "∞/∞";
        }
    }
    
    /**
     * Get the maximum quota for a specific API based on premium status
     */
    getMaxQuota(apiName) {
        if (!this.quotaConfig[apiName]) {
            return 0;
        }
        
        const isPremium = window.authManager?.currentUser?.premium || false;
        return isPremium ? this.quotaConfig[apiName].PREMIUM_QUOTA : this.quotaConfig[apiName].DEFAULT_QUOTA;
    }
    
    /**
     * Handle login status changes
     */
    handleLoginChange(detail) {
        if (detail.isLoggedIn && detail.user) {
            // Update creator status
            this.isCreator = detail.user.isCreator === true;
            
            // Reset quotas on login if configured to do so
            this.resetQuotasOnLogin(detail.user.premium);
        }
    }
    
    /**
     * Reset quotas when a user logs in
     * @param {boolean} isPremium - Whether the user has premium status
     */
    resetQuotasOnLogin(isPremium) {
        for (const [apiName, config] of Object.entries(this.quotaConfig)) {
            if (config.QUOTA_RESET_ON_LOGIN) {
                const quota = isPremium ? config.PREMIUM_QUOTA : config.DEFAULT_QUOTA;
                this.quotas[apiName] = quota;
                localStorage.setItem(config.QUOTA_STORAGE_KEY, String(quota));
            }
        }
        
        console.log(`Quotas reset on login. Premium status: ${isPremium}`);
    }
    
    /**
     * Check if user has remaining quota for a specific API
     * @param {string} apiName - The API name to check (e.g., 'OPENAI', 'GEMINI')
     * @returns {boolean} - Whether user has remaining quota
     */
    hasQuotaRemaining(apiName) {
        // Creator/admin always has quota remaining
        if (this.isCreator) {
            return true;
        }
        
        if (!this.quotaConfig[apiName]) {
            console.error(`Unknown API: ${apiName}`);
            return false;
        }
        
        // For Gemini, we can use the alternative key if needed
        if (apiName === 'GEMINI' && this.alternativeApiKeys.GEMINI && this.getQuotaRemaining(apiName) <= 0) {
            this.usingAlternativeKey.GEMINI = true;
            console.log('Using alternative Gemini API key to bypass quota limitation');
            return true;
        }
        
        return this.getQuotaRemaining(apiName) > 0;
    }
    
    /**
     * Get remaining quota for a specific API
     * @param {string} apiName - The API name to check
     * @returns {number} - Remaining quota
     */
    getQuotaRemaining(apiName) {
        // Creator/admin has infinite quota
        if (this.isCreator) {
            return Number.MAX_SAFE_INTEGER;
        }
        
        if (!this.quotaConfig[apiName]) {
            console.error(`Unknown API: ${apiName}`);
            return 0;
        }
        
        return this.quotas[apiName] || 0;
    }
    
    /**
     * Get the current API key to use for a specific service
     * @param {string} apiName - The API name (e.g., 'OPENAI', 'GEMINI')
     * @returns {string|null} - The API key to use, or null if not available
     */
    getApiKey(apiName) {
        if (apiName === 'GEMINI' && this.usingAlternativeKey.GEMINI) {
            return this.alternativeApiKeys.GEMINI;
        }
        
        // Return the default API key (implementation would depend on how keys are normally stored)
        // This would need to be implemented based on how your application normally retrieves API keys
        return CONFIG?.API_KEYS?.[apiName] || null;
    }
    
    /**
     * Reset the API key usage back to default
     * @param {string} apiName - The API name to reset
     */
    resetToDefaultApiKey(apiName) {
        if (apiName === 'GEMINI') {
            this.usingAlternativeKey.GEMINI = false;
            console.log('Reset to using default Gemini API key');
        }
    }
    
    /**
     * Consume one quota unit for the specified API
     * @param {string} apiName - The API to consume a quota from
     * @returns {boolean} - Whether the operation was successful
     */
    consumeQuota(apiName) {
        // Creator/admin doesn't consume quota
        if (this.isCreator) {
            return true;
        }
        
        if (!this.quotaConfig[apiName]) {
            console.error(`Unknown API: ${apiName}`);
            return false;
        }
        
        // If using alternative key for Gemini, don't consume quota
        if (apiName === 'GEMINI' && this.usingAlternativeKey.GEMINI) {
            return true;
        }
        
        if (this.quotas[apiName] <= 0) {
            // For Gemini, try to use the alternative key
            if (apiName === 'GEMINI' && this.alternativeApiKeys.GEMINI) {
                this.usingAlternativeKey.GEMINI = true;
                console.log('Switched to alternative Gemini API key due to quota exhaustion');
                return true;
            }
            return false;
        }
        
        // Decrement quota
        this.quotas[apiName]--;
        
        // Store updated quota
        localStorage.setItem(this.quotaConfig[apiName].QUOTA_STORAGE_KEY, String(this.quotas[apiName]));
        
        return true;
    }
    
    /**
     * Add additional quota for a specific API
     * @param {string} apiName - The API to add quota to
     * @param {number} amount - Amount of quota to add
     */
    addQuota(apiName, amount) {
        // Creator/admin has infinite quota, no need to add
        if (this.isCreator) {
            return;
        }
        
        if (!this.quotaConfig[apiName]) {
            console.error(`Unknown API: ${apiName}`);
            return;
        }
        
        // Add quota
        this.quotas[apiName] = (this.quotas[apiName] || 0) + amount;
        
        // Store updated quota
        localStorage.setItem(this.quotaConfig[apiName].QUOTA_STORAGE_KEY, String(this.quotas[apiName]));
    }
    
    /**
     * Get quota message for display
     * @param {string} apiName - The API to get message for
     * @returns {string} - Message about quota status
     */
    getQuotaMessage(apiName) {
        // Creator/admin has unlimited quota
        if (this.isCreator) {
            return "You have unlimited API access as the creator.";
        }
        
        if (!this.quotaConfig[apiName]) {
            return 'Unknown API service';
        }
        
        const remaining = this.getQuotaRemaining(apiName);
        
        if (remaining <= 0) {
            return `Please upgrade to premium for more requests or try again after logging in.`;
        } else if (remaining <= 3) {
            return `You have only ${remaining} ${apiName} API requests remaining. Consider upgrading to premium for more.`;
        }
        
        return `${remaining} ${apiName} API requests remaining`;
    }
    
    /**
     * Handle API error and check if it's a quota exceeded error
     * @param {Object} error - Error object from API call
     * @param {string} apiName - API name that caused the error
     * @returns {boolean} - Whether it was a quota error
     */
    handleApiError(error, apiName) {
        // Creator/admin should never get quota errors
        if (this.isCreator) {
            return false;
        }
        
        // Check for OpenAI specific quota errors
        if (apiName === 'OPENAI' && error.response) {
            if (error.response.status === 429) {
                // Rate limit or quota exceeded
                this.quotas[apiName] = 0;
                localStorage.setItem(this.quotaConfig[apiName].QUOTA_STORAGE_KEY, '0');
                return true;
            }
        }
        
        // Generic handling for other APIs
        if (error.message && error.message.includes('quota') || 
            (error.response && error.response.status === 429)) {
            // Mark quota as exhausted
            this.quotas[apiName] = 0;
            localStorage.setItem(this.quotaConfig[apiName].QUOTA_STORAGE_KEY, '0');
            return true;
        }
        
        return false;
    }
    
    /**
     * Safely truncate content for API calls to avoid quota issues with large files
     * @param {string} content - The content to truncate
     * @returns {string} - Truncated content 
     */
    safelyTruncateContent(content) {
        if (!content || content.length <= this.maxContentSize) {
            return content;
        }
        
        console.log(`Content size (${content.length} chars) exceeds safe limit (${this.maxContentSize} chars). Truncating.`);
        
        // Take the first part and the last part with proper context
        const firstChunk = content.substring(0, this.maxContentSize / 2);
        const lastChunk = content.substring(content.length - (this.maxContentSize / 2));
        
        return `${firstChunk}\n\n[...Content truncated for API safety...]\n\n${lastChunk}`;
    }
} 
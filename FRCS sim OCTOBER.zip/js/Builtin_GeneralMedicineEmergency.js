// Built-in FRCS-style General Medicine & Emergency (Ophthalmology) question set
// Exposes window.BUILTIN_SETS['general-medicine-emergency'] with a standard schema
(function(){
  try {
    if (!window.BUILTIN_SETS) window.BUILTIN_SETS = {};
    const subspecialtyKey = 'general-medicine-emergency';
    const title = 'General Medicine & Emergency (Ophthalmology) - FRCS Oral Style';
    /**
     * Minimal seed set; the app can generate more from AI if desired.
     * Keep schema aligned with QuestionGenerator.loadQuestionSet expectations.
     */
    const questions = [
      {
        id: 'gme-acs-1',
        type: 'clinical-case',
        question: 'Chest pain in the clinic: 58-year-old with retrosternal pain radiating to left arm, diaphoresis. Outline immediate assessment and initial management steps (FRCS oral).',
        options: null,
        pairs: null,
        answer: 'Immediate ABC; attach monitors; 12-lead ECG within 10 minutes; IV access ×2; bloods including serial high-sensitivity troponin; oxygen only if SpO2 < 90%; give aspirin 300 mg chewed, consider P2Y12 based on pathway; sublingual GTN if hypertensive and no contraindications; analgesia (morphine judiciously); risk stratify (GRACE); early cardiology input; transfer for primary PCI if STEMI or NSTEMI with very high risk.',
        explanation: 'Key pitfalls: do not routinely give oxygen if normoxic; consider contraindications to antiplatelets/anticoagulation; early reperfusion for STEMI; bleeding risk assessment; document times and symptom onset.'
      },
      {
        id: 'gme-anaphylaxis-1',
        type: 'short-answer',
        question: 'Anaphylaxis after IV antibiotic in clinic. State first-line drug, dose, route, and site in adults.',
        options: null,
        pairs: null,
        answer: 'Adrenaline (epinephrine) 1:1000, 0.5 mL (0.5 mg) intramuscularly into the anterolateral thigh; repeat every 5 minutes if needed while assessing airway, breathing, circulation.',
        explanation: 'Place patient supine with legs elevated unless respiratory distress (then sitting). Give high-flow oxygen, IV fluids, consider adjuncts (chlorphenamine, hydrocortisone) after adrenaline. Observe for biphasic reaction and provide auto-injector education.'
      },
      {
        id: 'gme-dka-1',
        type: 'management',
        question: 'How would you manage diabetic ketoacidosis (DKA) in an adult?',
        options: null,
        pairs: null,
        answer: '**History:** Onset, insulin omission, infection symptoms, medications.\n\n**Examination:** Dehydration, Kussmaul breathing, GCS, vitals, infection focus.\n\n**Investigations:** Bedside glucose, venous/arterial blood gas, serum ketones, U&E, FBC, cultures, CXR if indicated.\n\n**Treatment:** Fluid resuscitation (0.9% saline per protocol), fixed-rate IV insulin (e.g., 0.1 units/kg/h), potassium replacement as per K+ and urine output, treat precipitant (e.g., antibiotics), avoid rapid sodium/osmolality shifts. Add dextrose when glucose < ~14 mmol/L while continuing insulin until ketone clearance.\n\n**Follow-up:** Transition to subcutaneous insulin when ketones cleared and patient eating; diabetes education and sick-day rules.',
        explanation: 'Focus on ketone clearance and safe potassium replacement. Monitor osmolality, avoid cerebral edema risk, and reassess frequently.'
      },
      {
        id: 'gme-pe-1',
        type: 'short-answer',
        question: 'Suspected pulmonary embolism (hemodynamically stable). Outline initial diagnostic approach.',
        options: null,
        pairs: null,
        answer: 'Assess pretest probability (e.g., Wells). If low/intermediate: D-dimer first; if positive, CTPA. If high probability, go straight to CTPA. Consider V/Q if contrast contraindicated or pregnancy. Start anticoagulation if high suspicion and imaging delayed, barring contraindications.',
        explanation: 'Use pregnancy-adapted pathways; in massive/high-risk PE with shock, consider thrombolysis after excluding contraindications.'
      },
      {
        id: 'gme-sepsis-1',
        type: 'clinical-case',
        question: 'A febrile postoperative patient is hypotensive and tachycardic. Describe your sepsis bundle within the first hour.',
        options: null,
        pairs: null,
        answer: 'Sepsis recognition; obtain lactate and cultures before antibiotics; give broad-spectrum IV antibiotics early; fluid resuscitation (e.g., 30 mL/kg crystalloid) targeting MAP ≥ 65 mmHg; source control planning; monitor urine output and perfusion; escalate for vasopressors if refractory.',
        explanation: 'Early effective antibiotics reduce mortality. Reassess lactate and perfusion; individualize fluids in heart failure/renal disease.'
      }
    ];

    window.BUILTIN_SETS[subspecialtyKey] = {
      id: subspecialtyKey,
      title: title,
      subspecialty: subspecialtyKey,
      questions: questions
    };
  } catch (e) {
    console.error('Failed to initialize built-in General Medicine & Emergency set:', e);
  }
})();



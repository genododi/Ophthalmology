class OphthalmoImageGenerator {
    constructor() {
        this.ui = null;
        this.questionGenerator = null;
        this.imageCache = new Map(); // Cache generated images by keyword
        this.currentPreviewImage = null;
        this.lastIdentifiedKeyword = null; // Track the last identified keyword for better display
        
        // No online DB: images must come from local Kanski APKG once loaded
        this.ophthalmicImagesDB = { default: null };

        // CORS proxy endpoints for fetching HTML from third-party ophthalmology sites
        // These proxies add permissive CORS headers so we can read response bodies in the browser
        this.corsProxies = [
            { type: 'raw_param', prefix: 'https://api.allorigins.win/raw?url=' },
            { type: 'json_param', prefix: 'https://api.allorigins.win/get?url=' },
            { type: 'direct_append', prefix: 'https://thingproxy.freeboard.io/fetch/' },
            { type: 'param', prefix: 'https://www.corsproxy.io/?' },
            { type: 'param_key', prefix: 'https://api.codetabs.com/v1/proxy/?quest=' }
        ];
    }

    initialize(ui, questionGenerator) {
        this.ui = ui;
        this.questionGenerator = questionGenerator;
        this.initializeModal();
    }

    initializeModal() {
        // Create image preview modal
        if (!document.getElementById('ophthalmic-image-modal')) {
            const modal = document.createElement('div');
            modal.id = 'ophthalmic-image-modal';
            modal.className = 'fixed inset-0 z-50 flex items-center justify-center hidden';
            modal.innerHTML = `
                <div class="fixed inset-0 bg-black bg-opacity-50" id="ophthalmic-modal-backdrop"></div>
                <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full z-10 p-6 relative max-h-[90vh] overflow-y-auto">
                    <button id="close-ophthalmic-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                    <h3 class="text-xl font-semibold mb-4 text-primary" id="ophthalmic-image-title">Ophthalmic Image</h3>
                    <div class="flex flex-col md:flex-row gap-6">
                        <div class="flex-1 text-center flex flex-col items-center">
                            <img id="ophthalmic-image-preview" src="" alt="Ophthalmic Image" class="max-w-full max-h-[60vh] object-contain border border-gray-200 rounded-lg shadow-md">
                            <p id="ophthalmic-image-caption" class="mt-3 text-sm text-gray-600 italic"></p>
                        </div>
                        <div class="flex-1">
                            <div class="mb-4">
                                <h4 class="font-medium text-gray-800 mb-2">Clinical Information</h4>
                                <div id="ophthalmic-image-info" class="bg-gray-50 p-4 rounded-md text-sm"></div>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-800 mb-2">Related Conditions</h4>
                                <div id="ophthalmic-image-related" class="flex flex-wrap gap-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // Add event listeners
            document.getElementById('close-ophthalmic-modal').addEventListener('click', () => {
                this.hideImageModal();
            });

            document.getElementById('ophthalmic-modal-backdrop').addEventListener('click', () => {
                this.hideImageModal();
            });
        }
    }

    /**
     * Generate or retrieve an ophthalmic image based on question content
     * @param {string} questionText - The text of the question
     * @param {string} questionId - The ID of the question
     * @returns {Promise<object>} - Object containing URL of the image and identified keyword
     */
    async generateImage(questionText, questionId) {
        try {
            const keywords = this.extractKeywords(questionText);
            const identifiedKeyword = this.lastIdentifiedKeyword || null;
            if (keywords.length === 0) {
                return { url: this.ophthalmicImagesDB.default, keyword: null };
            }
            const primaryKeyword = keywords[0].toLowerCase();
            const subspecialty = this.questionGenerator && this.questionGenerator.lastSettings ? this.questionGenerator.lastSettings.subspecialty : null;
            const subspecialtyText = this.questionGenerator && this.questionGenerator.lastSettings ? this.questionGenerator.lastSettings.subspecialtyText : null;

            // If no APKG images are loaded at all, prefer external ophthalmology sources
            if (!this.hasKanskiImages()) {
                const external = await this.fetchFromOphthalmologySources(questionText, primaryKeyword, subspecialtyText || subspecialty);
                if (external && external.url) {
                    this.imageCache.set(primaryKeyword, external.url);
                    return { url: external.url, keyword: identifiedKeyword || external.keyword || primaryKeyword };
                }
                const wiki = await this.fetchOnlineImage(questionText, primaryKeyword);
                if (wiki && wiki.url) {
                    this.imageCache.set(primaryKeyword, wiki.url);
                    return { url: wiki.url, keyword: identifiedKeyword || wiki.keyword || primaryKeyword };
                }
                return { url: '', keyword: identifiedKeyword || primaryKeyword };
            }

            // Strict local selection from Kanski images, subspecialty-aware
            const strictPick = await this.strictSelectFromKanski(questionText, subspecialty);
            if (strictPick && strictPick.url) {
                return { url: strictPick.url, keyword: identifiedKeyword || primaryKeyword };
            }
            // APKG filename/metadata matching with subspecialty bias
            const apkgImage = await this.findImageFromApkg(keywords, questionText, subspecialty);
            if (apkgImage) {
                return { url: apkgImage.url, keyword: identifiedKeyword || apkgImage.keyword || primaryKeyword };
            }
            // Cache fallback
            if (this.imageCache.has(primaryKeyword)) {
                return { url: this.imageCache.get(primaryKeyword), keyword: identifiedKeyword || primaryKeyword };
            }
            // Preferred ophthalmology sources
            const external = await this.fetchFromOphthalmologySources(questionText, primaryKeyword, subspecialtyText || subspecialty);
            if (external && external.url) {
                this.imageCache.set(primaryKeyword, external.url);
                return { url: external.url, keyword: identifiedKeyword || external.keyword || primaryKeyword };
            }
            // Wikipedia as generic fallback
            const online = await this.fetchOnlineImage(questionText, primaryKeyword);
            if (online && online.url) {
                this.imageCache.set(primaryKeyword, online.url);
                return { url: online.url, keyword: identifiedKeyword || online.keyword || primaryKeyword };
            }
            return { url: '', keyword: identifiedKeyword || primaryKeyword };
        } catch (error) {
            console.error('Error generating ophthalmic image:', error);
            return { url: '', keyword: null };
        }
    }

    // Ophthalmology-specific reranking to prefer modality-consistent images
    rerankDomainHeuristics(candidates, questionText) {
        try {
            const lowerQ = String(questionText || '').toLowerCase();
            const wantFundus = /(fundus|retina|macula|drusen|amd|cnv|optic disc|cup|nerve fiber|rnfl|vessel|fovea|choroid)/.test(lowerQ);
            const wantSlitLamp = /(cornea|keratitis|ulcer|conjunctiva|pterygium|keratoconus|iris|anterior chamber|arcus|epithelial|stromal|endothelium)/.test(lowerQ);
            const wantOCT = /(oct|optical coherence|macular thickness|b-scan|hyperreflective|hyporeflective|segmentation|retinal layers)/.test(lowerQ);
            const wantVisualField = /(humphrey|visual field|perimetry|md|psd|vf)/.test(lowerQ);
            const wantExternal = /(eyelid|ptosis|chalazion|orbit|dermoid|oculoplastic|lid)/.test(lowerQ);

            // Heuristic: prefer filenames containing modality hints
            const scoreModality = (key) => {
                const k = String(key).toLowerCase();
                let s = 0;
                if (wantFundus) s += /(fundus|retina|disc|macula|fovea|drusen|hemorrhage|vessel)/.test(k) ? 1 : 0;
                if (wantSlitLamp) s += /(slit|lamp|cornea|kerato|stain|fluorescein|conj|iris|anterior)/.test(k) ? 1 : 0;
                if (wantOCT) s += /(oct|bscan|b-scan|cube|thickness|scan)/.test(k) ? 1 : 0;
                if (wantVisualField) s += /(vf|hvf|humphrey|24-2|30-2|10-2|pattern|deviation|md|psd)/.test(k) ? 1 : 0;
                if (wantExternal) s += /(external|photo|face|lid|orbit|dermoid|ptosis|eyelid|oculo)/.test(k) ? 1 : 0;
                return s;
            };

            const images = window.kanskiImages;
            for (const [key] of candidates) {
                const url = images instanceof Map ? images.get(key) : images[key];
                if (!url) continue;
                const mscore = scoreModality(key);
                if (mscore > 0) return { key, url };
            }
            // Fallback to first candidate
            const [first] = candidates;
            if (first) {
                const images2 = window.kanskiImages;
                const url = images2 instanceof Map ? images2.get(first[0]) : images2[first[0]];
                if (url) return { key: first[0], url };
            }
            return null;
        } catch (_) {
            return null;
        }
    }

    // Strict APKG selection with modality and lexical thresholds
    async strictSelectFromKanski(questionText, subspecialty = null) {
        try {
            const images = window.kanskiImages;
            if (!images || !window.imageMatcher) return null;
            const ok = await window.imageMatcher.initialize();
            if (!ok) return null;
            if (!window.imageMatcher._indexedOnce) {
                window.imageMatcher.ensureBackgroundIndex(images);
            }
            const candidates = await window.imageMatcher.rankCandidates(questionText, 40);
            if (!candidates || candidates.length === 0) return null;
            const subKeywords = (this.questionGenerator && this.questionGenerator.fileHandler && this.questionGenerator.fileHandler.subspecialtyKeywords && subspecialty) ?
                (this.questionGenerator.fileHandler.subspecialtyKeywords[subspecialty] || []) : [];
            for (const [key, baseScore] of candidates) {
                const lex = window.imageMatcher.computeLexicalScore(questionText, key);
                const boost = window.imageMatcher.modalityBoost(questionText, key);
                let subBoost = 0;
                if (Array.isArray(subKeywords) && subKeywords.length) {
                    try {
                        const toks = window.imageMatcher.imageTokens.get(key) || window.imageMatcher.buildTokensForKey(key);
                        let hits = 0;
                        for (const sk of subKeywords) { if (toks.has(String(sk).toLowerCase())) hits++; }
                        if (hits > 0) subBoost = Math.min(0.25, 0.08 + 0.04 * hits);
                    } catch (_) {}
                }
                const combined = (lex || 0) + (boost || 0) + subBoost;
                if ((combined >= 0.42 && (lex >= 0.28 || boost >= 0.15 || subBoost >= 0.12)) || (lex >= 0.35)) {
                    const url = images instanceof Map ? images.get(key) : images[key];
                    if (url) {
                        window.imageMatcher.markUsed(key);
                        return { url, key, score: combined + (baseScore || 0) * 0.1 };
                    }
                }
            }
            return null;
        } catch (_) { return null; }
    }

    // Online fallback using Wikipedia PageImages API
    async fetchOnlineImage(questionText, fallbackKeyword) {
        try {
            const terms = this.extractKeywords(questionText);
            const q = encodeURIComponent((terms[0] || fallbackKeyword || 'ophthalmology'));
            const url = `https://en.wikipedia.org/w/api.php?origin=*&action=query&format=json&generator=search&gsrsearch=${q}&gsrlimit=1&prop=pageimages|pageterms&piprop=original&pithumbsize=800`;
            const res = await fetch(url, { method: 'GET' });
            if (!res.ok) return null;
            const data = await res.json();
            if (!data || !data.query || !data.query.pages) return null;
            const pages = Object.values(data.query.pages);
            if (!pages.length) return null;
            const page = pages[0];
            const img = (page.original && page.original.source) || (page.thumbnail && page.thumbnail.source);
            if (!img) return null;
            return { url: img, keyword: page.title };
        } catch (e) {
            console.warn('Online image fallback failed:', e && e.message ? e.message : e);
            return null;
        }
    }

    // Preferred external ophthalmology sources: EyeRounds, Atlas of Ophthalmology, RedAtlas
    async fetchFromOphthalmologySources(questionText, fallbackKeyword, subspecialtyLabel) {
        try { if (window && window.disableExternalOphthalmologySources) return null; } catch (_) {}
        const query = encodeURIComponent((fallbackKeyword || '').trim() || (this.extractKeywords(questionText)[0] || 'ophthalmology'));
        const decorated = subspecialtyLabel ? `${query}%20${encodeURIComponent(subspecialtyLabel)}` : query;
        const tryFetch = async (buildUrl, pick) => {
            try {
                const u = buildUrl(decorated);
                // Attempt via CORS-friendly proxies to avoid browser CORS blocks
                const html = await this.fetchTextWithCORS(u);
                if (!html) return null;
                const m = pick(html);
                if (m && m.startsWith('http')) return { url: m, keyword: decodeURIComponent(query) };
                return null;
            } catch (_) { return null; }
        };
        // EyeRounds search page
        const eyeRounds = await tryFetch(
            (q) => `https://eyerounds.org/search.asp?search=${q}`,
            (html) => {
                const m = html.match(/<img[^>]+src=["']([^"']+\.(?:jpg|jpeg|png|webp|gif))["']/i);
                if (m && m[1]) {
                    const src = m[1].startsWith('http') ? m[1] : `https://eyerounds.org/${m[1].replace(/^\/?/, '')}`;
                    return src;
                }
                return null;
            }
        );
        if (eyeRounds) return eyeRounds;
        // Atlas of Ophthalmology
        const atlas = await tryFetch(
            (q) => `https://atlasophthalmology.net/search?search=${q}`,
            (html) => {
                const m = html.match(/<img[^>]+src=["']([^"']+\.(?:jpg|jpeg|png|webp|gif))["'][^>]*class=["'][^"']*img/i);
                if (m && m[1]) return m[1].startsWith('http') ? m[1] : `https://atlasophthalmology.net/${m[1].replace(/^\/?/, '')}`;
                return null;
            }
        );
        if (atlas) return atlas;
        // RedAtlas
        const redAtlas = await tryFetch(
            (q) => `http://redatlas.org/?s=${q}`,
            (html) => {
                const m = html.match(/<img[^>]+src=["']([^"']+\.(?:jpg|jpeg|png|webp|gif))["']/i);
                if (m && m[1]) return m[1];
                return null;
            }
        );
        if (redAtlas) return redAtlas;
        return null;
    }

    /**
     * Fetch text content from a URL using CORS-friendly proxies when needed
     * Returns null if all attempts fail
     */
    async fetchTextWithCORS(originalUrl) {
        // Try direct fetch first if running from a proper http(s) origin
        try {
            if (location.protocol === 'http:' || location.protocol === 'https:') {
                const direct = await this._fetchWithTimeout(originalUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 7000);
                if (direct && direct.ok) {
                    const txt = await direct.text();
                    if (txt && txt.length) return txt;
                }
            }
        } catch (_) {}

        // Try via proxy list
        for (const proxy of this.corsProxies) {
            try {
                let proxiedUrl;
                if (proxy.type === 'raw_param') {
                    proxiedUrl = proxy.prefix + encodeURIComponent(originalUrl);
                    const r = await this._fetchWithTimeout(proxiedUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 8000);
                    if (!r || !r.ok) continue;
                    const text = await r.text();
                    if (text && text.length) return text;
                    continue;
                }
                if (proxy.type === 'json_param') {
                    proxiedUrl = proxy.prefix + encodeURIComponent(originalUrl);
                    const r = await this._fetchWithTimeout(proxiedUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 8000);
                    if (!r || !r.ok) continue;
                    const data = await r.json().catch(() => null);
                    const text = data && (data.contents || data.contents === '' ? data.contents : data.contentsRaw || null);
                    if (typeof text === 'string' && text.length) return text;
                    continue;
                }
                if (proxy.type === 'param') {
                    proxiedUrl = proxy.prefix + encodeURIComponent(originalUrl);
                    const r = await this._fetchWithTimeout(proxiedUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 8000);
                    if (!r || !r.ok) continue;
                    const text = await r.text();
                    if (text && text.length) return text;
                    continue;
                }
                if (proxy.type === 'param_key') {
                    proxiedUrl = proxy.prefix + encodeURIComponent(originalUrl);
                    const r = await this._fetchWithTimeout(proxiedUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 8000);
                    if (!r || !r.ok) continue;
                    const text = await r.text();
                    if (text && text.length) return text;
                    continue;
                }
                if (proxy.type === 'direct_append') {
                    proxiedUrl = proxy.prefix + originalUrl;
                    const r = await this._fetchWithTimeout(proxiedUrl, { method: 'GET', mode: 'cors', credentials: 'omit' }, 8000);
                    if (!r || !r.ok) continue;
                    const text = await r.text();
                    if (text && text.length) return text;
                    continue;
                }
            } catch (_) { /* continue to next proxy */ }
        }
        return null;
    }

    // Fetch with timeout helper using AbortController
    async _fetchWithTimeout(url, options, timeoutMs) {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), timeoutMs || 8000);
        try {
            const response = await fetch(url, { ...options, signal: controller.signal });
            return response;
        } catch (_) {
            return null;
        } finally {
            clearTimeout(id);
        }
    }

    hasKanskiImages() {
        try {
            const images = window.kanskiImages;
            if (!images) return false;
            if (images instanceof Map) return images.size > 0;
            return Object.keys(images).length > 0;
        } catch (_) { return false; }
    }

    /**
     * Find an image from loaded Kanski APKG assets using keywords
     */
    async findImageFromApkg(keywords, questionText = '', subspecialty = null) {
        try {
            const cards = window.kanskiCards;
            const images = window.kanskiImages;
            if (!cards || !images) return null;
            const iterateCards = cards instanceof Map ? cards.values() : Object.values(cards);
            const lowerKeywords = keywords.map(k => k.toLowerCase());
            const subKeywords = (this.questionGenerator && this.questionGenerator.fileHandler && this.questionGenerator.fileHandler.subspecialtyKeywords && subspecialty) ?
                (this.questionGenerator.fileHandler.subspecialtyKeywords[subspecialty] || []) : [];
            let best = { score: -1, url: null, keyword: null };
            for (const card of iterateCards) {
                const parts = [];
                if (card.primary) parts.push(String(card.primary));
                if (Array.isArray(card.fields)) parts.push(String(card.fields.join(' ')));
                if (card.tags) parts.push(String(card.tags));
                const haystack = parts.join(' ').toLowerCase();
                let kwHits = 0;
                for (const kw of lowerKeywords) { if (haystack.includes(kw)) kwHits++; }
                if (kwHits === 0) continue;
                let subHits = 0;
                if (Array.isArray(subKeywords) && subKeywords.length) {
                    for (const sk of subKeywords) { if (haystack.includes(String(sk).toLowerCase())) subHits++; }
                }
                const qTokens = String(questionText || '').toLowerCase().split(/[^a-z0-9]+/g).filter(Boolean);
                const hTokens = haystack.split(/[^a-z0-9]+/g).filter(Boolean);
                const setH = new Set(hTokens);
                let overlap = 0;
                for (const t of qTokens) { if (setH.has(t)) overlap++; }
                const jacc = overlap > 0 ? overlap / (qTokens.length + setH.size - overlap) : 0;
                const score = kwHits * 2 + jacc + (subHits > 0 ? Math.min(0.8, 0.2 + 0.05 * subHits) : 0);
                const names = [];
                if (Array.isArray(card.images) && card.images.length) names.push(...card.images);
                if (card.media) names.push(card.media);
                if (card.image) names.push(card.image);
                if (card.mediaFile) names.push(card.mediaFile);
                let url = null;
                for (const n of names) {
                    if (!n) continue;
                    const u = images instanceof Map ? images.get(n) : images[n];
                    if (u) { url = u; break; }
                }
                if (url && score > best.score) {
                    best = { score, url, keyword: (Array.isArray(card.tags) ? card.tags[0] : null) };
                }
            }
            if (!best.url && images) {
                const keys = images instanceof Map ? Array.from(images.keys()) : Object.keys(images);
                // Simple lexical scoring against question text
                const scored = keys.map(name => {
                    const lower = String(name || '').toLowerCase();
                    const kwScore = keywords.reduce((s, kw) => s + (lower.includes(kw.toLowerCase()) ? 1 : 0), 0);
                    const nameTokens = lower.split(/[^a-z0-9]+/g).filter(Boolean);
                    const qTokens = String(questionText || '').toLowerCase().split(/[^a-z0-9]+/g).filter(Boolean);
                    let overlap = 0;
                    const set = new Set(nameTokens);
                    for (const t of qTokens) { if (set.has(t)) overlap++; }
                    const score = kwScore * 2 + overlap; // weight keywords higher
                    return [name, score];
                });
                scored.sort((a,b) => b[1] - a[1]);
                for (const [name] of scored.slice(0, 10)) {
                    const data = images instanceof Map ? images.get(name) : images[name];
                    if (data) return { url: data, keyword: name };
                }
            }
            return best.url ? { url: best.url, keyword: best.keyword } : null;
        } catch (e) {
            console.error('Error while searching APKG images:', e);
            return null;
        }
    }

    /**
     * Extract relevant ophthalmic keywords from text
     * @param {string} text - The text to extract keywords from
     * @returns {Array<string>} - Array of keywords
     */
    extractKeywords(text) {
        if (!text) return [];
        
        // Define common ophthalmic conditions to look for
        const commonConditions = Object.keys(this.ophthalmicImagesDB);
        
        // Extract condition mentions
        const keywords = [];
        const lowerText = text.toLowerCase();
        this.lastIdentifiedKeyword = null; // Reset last identified keyword
        
        // Look for multi-word conditions first (like "dermoid cyst")
        const multiWordConditions = commonConditions.filter(cond => cond.includes(' ') && cond !== 'default');
        for (const condition of multiWordConditions) {
            if (lowerText.includes(condition)) {
                keywords.push(condition);
                this.lastIdentifiedKeyword = condition; // Track the keyword we found
            }
        }
        
        // If no multi-word conditions found, check for single-word conditions
        if (keywords.length === 0) {
            const singleWordConditions = commonConditions.filter(cond => !cond.includes(' ') && cond !== 'default');
            for (const condition of singleWordConditions) {
                // Use word boundary regex to match whole words only
                const regex = new RegExp('\\b' + condition + '\\b', 'i');
                if (regex.test(lowerText)) {
                    keywords.push(condition);
                    this.lastIdentifiedKeyword = condition; // Track the keyword we found
                }
            }
        }
        
        // If still no specific conditions found, look for medical phrases
        if (keywords.length === 0) {
            // Define regex patterns for common ophthalmology phrases
            const patterns = [
                // Match phrases like "X syndrome", "X disease", etc.
                /\b(\w+)\s+(syndrome|disease|disorder|dystrophy|degeneration)\b/i,
                // Match surgical procedures
                /\b(surgery|surgical|procedure|operation|management|repair|removal)\s+of\s+(\w+)\b/i,
                // Match clinical presentations
                /\b(patient|case|presentation)\s+with\s+(\w+)\b/i
            ];
            
            for (const pattern of patterns) {
                const match = lowerText.match(pattern);
                if (match) {
                    // Extract the relevant part of the match
                    let extractedTerm = match[0];
                    // Check if this extracted term is related to any condition in our database
                    for (const condition of commonConditions) {
                        if (extractedTerm.includes(condition) || condition.includes(extractedTerm)) {
                            keywords.push(condition);
                            this.lastIdentifiedKeyword = condition;
                            break;
                        }
                    }
                    // If we found a term, stop looking
                    if (keywords.length > 0) break;
                }
            }
        }
        
        // If no specific conditions found, extract general eye anatomy terms
        if (keywords.length === 0) {
            const eyeTerms = [
                "cornea", "retina", "lens", "macula", "optic nerve", 
                "iris", "pupil", "sclera", "conjunctiva", "choroid",
                "vitreous", "anterior chamber", "posterior chamber", "eyelid",
                "orbit", "lacrimal", "canaliculi", "tear duct", "extraocular muscle"
            ];
            
            for (const term of eyeTerms) {
                if (lowerText.includes(term)) {
                    keywords.push(term);
                    this.lastIdentifiedKeyword = term;
                    break; // Just take the first match for simplicity
                }
            }
        }
        
        console.log("Extracted keywords:", keywords, "Last identified keyword:", this.lastIdentifiedKeyword);
        return keywords;
    }

    /**
     * Show the image preview modal
     * @param {string} imageUrl - URL of the image to preview
     * @param {string} questionText - The text of the question
     * @param {string} identifiedKeyword - The specific keyword identified in the question
     */
    showImagePreview(imageUrl, questionText, identifiedKeyword = null) {
        this.currentPreviewImage = imageUrl;
        
        let modal = document.getElementById('ophthalmic-image-modal');
        let imagePreview = document.getElementById('ophthalmic-image-preview');
        let imageTitle = document.getElementById('ophthalmic-image-title');
        let imageCaption = document.getElementById('ophthalmic-image-caption');
        let imageInfo = document.getElementById('ophthalmic-image-info');
        let imageRelated = document.getElementById('ophthalmic-image-related');
        
        if (!modal || !imagePreview) {
            console.warn('Image preview modal elements not found, initializing modal...');
            this.initializeModal(); // Try to create the modal if it doesn't exist
            
            // Get references again after initialization
            modal = document.getElementById('ophthalmic-image-modal');
            imagePreview = document.getElementById('ophthalmic-image-preview');
            imageTitle = document.getElementById('ophthalmic-image-title');
            imageCaption = document.getElementById('ophthalmic-image-caption');
            imageInfo = document.getElementById('ophthalmic-image-info');
            imageRelated = document.getElementById('ophthalmic-image-related');
            
            if (!modal || !imagePreview) {
                console.error('Failed to initialize image preview modal');
                return;
            }
        }
        
        // Use provided identified keyword if available, otherwise extract from question
        let displayKeyword;
        if (identifiedKeyword) {
            // Format the identified keyword with proper capitalization
            displayKeyword = identifiedKeyword.split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
        } else {
            // Extract keywords for image caption as fallback
            const keywords = this.extractKeywords(questionText);
            displayKeyword = keywords.length > 0 ? 
                keywords[0].charAt(0).toUpperCase() + keywords[0].slice(1) : 
                'Ophthalmology';
        }
        
        // Set the image and details
        imagePreview.src = imageUrl;
        imagePreview.alt = `Clinical image of ${displayKeyword}`;
        imageTitle.textContent = `${displayKeyword} Image`;
        imageCaption.textContent = `Clinical image illustrating ${displayKeyword.toLowerCase()}`;
        
        // Enhance image experience with zoom capability
        imagePreview.onclick = function() {
            // Toggle a zoomed class
            this.classList.toggle('zoomed');
            if (this.classList.contains('zoomed')) {
                this.style.maxHeight = '80vh';
                this.style.cursor = 'zoom-out';
            } else {
                this.style.maxHeight = '60vh';
                this.style.cursor = 'zoom-in';
            }
        };
        
        // Generate clinical information
        let clinicalInfo = this.generateClinicalInfo(displayKeyword, questionText);
        imageInfo.innerHTML = clinicalInfo;
        
        // Add related conditions
        imageRelated.innerHTML = '';
        const relatedConditions = this.getRelatedConditions(displayKeyword.toLowerCase());
        
        // Make related conditions clickable to show those images
        relatedConditions.forEach(condition => {
            const chip = document.createElement('span');
            chip.className = 'bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full mr-1 mb-1 inline-block cursor-pointer hover:bg-blue-200 transition-colors';
            chip.textContent = condition;
            
            // Make related condition clickable to show that condition's image
            chip.addEventListener('click', async () => {
                try {
                    const relatedImageInfo = await this.generateImage(condition);
                    if (relatedImageInfo && relatedImageInfo.url) {
                        // Update the current image with the related condition image
                        imagePreview.src = relatedImageInfo.url;
                        imageTitle.textContent = `${condition} Image`;
                        imageCaption.textContent = `Clinical image illustrating ${condition.toLowerCase()}`;
                        
                        // Update clinical info for the new condition
                        imageInfo.innerHTML = this.generateClinicalInfo(condition, condition);
                    }
                } catch (error) {
                    console.error('Error loading related condition image:', error);
                }
            });
            
            imageRelated.appendChild(chip);
        });
        
        // Add source citation
        const sourceElement = document.createElement('div');
        sourceElement.className = 'text-xs text-gray-500 mt-4';
        sourceElement.innerHTML = `Source: EyeWiki by American Academy of Ophthalmology`;
        imageInfo.appendChild(sourceElement);
        
        // Add magnification controls
        const magnificationControls = document.createElement('div');
        magnificationControls.className = 'flex items-center justify-center mt-2 space-x-2';
        magnificationControls.innerHTML = `
            <button id="zoom-out-btn" class="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors">
                <i class="fas fa-search-minus text-gray-600"></i>
            </button>
            <span class="text-sm text-gray-600">Zoom</span>
            <button id="zoom-in-btn" class="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors">
                <i class="fas fa-search-plus text-gray-600"></i>
            </button>
        `;
        
        // Add the controls to the modal
        const controlsContainer = document.querySelector('#ophthalmic-image-modal .flex-1');
        if (controlsContainer) {
            // Check if controls already exist
            const existingControls = controlsContainer.querySelector('.flex.items-center.justify-center');
            if (existingControls) {
                existingControls.remove();
            }
            controlsContainer.appendChild(magnificationControls);
            
            // Add event listeners for zoom controls
            document.getElementById('zoom-in-btn').addEventListener('click', () => {
                const currentScale = imagePreview.style.transform ? 
                    parseFloat(imagePreview.style.transform.replace('scale(', '').replace(')', '')) : 1;
                const newScale = Math.min(currentScale + 0.1, 2);
                imagePreview.style.transform = `scale(${newScale})`;
            });
            
            document.getElementById('zoom-out-btn').addEventListener('click', () => {
                const currentScale = imagePreview.style.transform ? 
                    parseFloat(imagePreview.style.transform.replace('scale(', '').replace(')', '')) : 1;
                const newScale = Math.max(currentScale - 0.1, 0.5);
                imagePreview.style.transform = `scale(${newScale})`;
            });
        }
        
        // Show the modal
        modal.classList.remove('hidden');
    }

    /**
     * Hide the image preview modal
     */
    hideImageModal() {
        const modal = document.getElementById('ophthalmic-image-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    /**
     * Get related conditions for a given condition
     * @param {string} condition - The primary condition
     * @returns {Array<string>} - Array of related conditions
     */
    getRelatedConditions(condition) {
        const lowerCondition = condition.toLowerCase();
        
        // Map of related conditions
        const relatedConditionsMap = {
            'retina': ['Diabetic Retinopathy', 'Retinal Detachment', 'Macular Degeneration'],
            'diabetic retinopathy': ['Macular Edema', 'Vitreous Hemorrhage', 'Neovascular Glaucoma'],
            'macular degeneration': ['Geographic Atrophy', 'Choroidal Neovascularization', 'Drusen'],
            'glaucoma': ['Primary Open Angle Glaucoma', 'Angle Closure Glaucoma', 'Normal Tension Glaucoma'],
            'cataract': ['Nuclear Sclerosis', 'Posterior Subcapsular Cataract', 'Cortical Cataract'],
            'cornea': ['Keratitis', 'Keratoconus', 'Corneal Ulcer', 'Fuchs Dystrophy'],
            'uveitis': ['Anterior Uveitis', 'Posterior Uveitis', 'Panuveitis'],
            'optic nerve': ['Optic Neuritis', 'Papilledema', 'Ischemic Optic Neuropathy'],
            
            // Oculoplastics conditions
            'dermoid': ['Dermoid Cyst', 'Choristoma', 'Orbital Tumor', 'Epibulbar Dermoid'],
            'dermoid cyst': ['Epibulbar Dermoid', 'Orbital Tumor', 'Encephalocele', 'Lid Swelling'],
            'orbital dermoid': ['Orbital Tumor', 'Orbital Cyst', 'Mucocele', 'Cavernous Hemangioma'],
            'eyelid': ['Ptosis', 'Ectropion', 'Entropion', 'Chalazion', 'Blepharitis'],
            'ptosis': ['Levator Dehiscence', 'Myasthenia Gravis', 'Horner\'s Syndrome', 'Congenital Ptosis'],
            'chalazion': ['Meibomian Gland Dysfunction', 'Hordeolum', 'Sebaceous Cell Carcinoma'],
            'lacrimal gland': ['Dacryoadenitis', 'Lacrimal Gland Tumor', 'Sjogren\'s Syndrome'],
            'thyroid eye disease': ['Proptosis', 'Extraocular Muscle Restriction', 'Lid Retraction', 'Optic Neuropathy'],
            
            // Surgical procedures
            'trabeculectomy': ['Glaucoma Surgery', 'Filtration Surgery', 'Bleb Management', 'Antifibrotics'],
            'phacoemulsification': ['Cataract Surgery', 'IOL Implantation', 'Posterior Capsule Rupture', 'Zonular Dialysis'],
            'vitrectomy': ['Retinal Detachment', 'Macular Hole', 'Epiretinal Membrane', 'Vitreous Hemorrhage'],
            'scleral buckling': ['Retinal Detachment', 'Retinal Break', 'Cryotherapy', 'Laser Retinopexy'],
            'penetrating keratoplasty': ['Corneal Transplant', 'DSAEK', 'DMEK', 'Corneal Opacity'],
            
            // Additional categories
            'surgical management': ['Surgical Excision', 'Orbitotomy', 'Lid Reconstruction', 'Enucleation'],
            
            'default': ['Refractive Error', 'Dry Eye', 'Conjunctivitis', 'Presbyopia']
        };
        
        // First check for exact matches
        if (relatedConditionsMap[lowerCondition]) {
            return relatedConditionsMap[lowerCondition];
        }
        
        // Then check for partial matches
        for (const key in relatedConditionsMap) {
            if (lowerCondition.includes(key) || key.includes(lowerCondition)) {
                return relatedConditionsMap[key];
            }
        }
        
        // Check for surgical context
        if (lowerCondition.includes('surgical') || 
            lowerCondition.includes('surgery') || 
            lowerCondition.includes('management') ||
            lowerCondition.includes('procedure') ||
            lowerCondition.includes('operation')) {
            
            return relatedConditionsMap['surgical management'];
        }
        
        return relatedConditionsMap.default;
    }

    /**
     * Generate detailed clinical information for a condition
     */
    generateClinicalInfo(condition, context) {
        const lowerCondition = condition.toLowerCase();
        
        // Clinical information database
        const clinicalInfoMap = {
            'diabetic retinopathy': `
                <p class="mb-2"><strong>Diabetic Retinopathy (DR)</strong> is a microvascular complication of diabetes mellitus that affects the retina.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Microaneurysms - earliest clinically detectable lesions appearing as small red dots</li>
                    <li>Intraretinal hemorrhages - dot and blot hemorrhages in the deeper retinal layers</li>
                    <li>Hard exudates - yellowish deposits of lipid and protein with sharp margins</li>
                    <li>Cotton wool spots - fluffy white lesions representing nerve fiber layer infarcts</li>
                    ${lowerCondition.includes('proliferative') ? 
                      '<li>Neovascularization - abnormal new vessels at the disc (NVD) or elsewhere (NVE)</li>' : ''}
                </ul>
                <p>Classification: ${lowerCondition.includes('proliferative') ? 
                  'Proliferative Diabetic Retinopathy (PDR)' : 'Non-Proliferative Diabetic Retinopathy (NPDR)'}</p>
            `,
            'retinal detachment': `
                <p class="mb-2"><strong>Retinal Detachment</strong> refers to the separation of the neurosensory retina from the underlying retinal pigment epithelium (RPE).</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Elevation of the retina with a convex appearance</li>
                    <li>Loss of the normal red reflex in the detached area, appearing gray or opaque</li>
                    <li>Undulating movement of the detached retina with eye movement</li>
                    <li>Possible retinal tears or holes (predisposing factors)</li>
                    <li>Pigmented demarcation lines may be present in chronic cases</li>
                </ul>
                <p>Classification: Rhegmatogenous (tear-related), Tractional, or Exudative</p>
            `,
            'macular degeneration': `
                <p class="mb-2"><strong>Age-Related Macular Degeneration (AMD)</strong> is a degenerative disorder affecting the macula, the central portion of the retina.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Drusen - yellowish deposits beneath the retina</li>
                    <li>Pigmentary changes in the macula</li>
                    ${lowerCondition.includes('wet') || lowerCondition.includes('neovascular') ? 
                      '<li>Choroidal neovascularization (CNV) - abnormal blood vessels</li>' +
                      '<li>Subretinal fluid and/or hemorrhage</li>' +
                      '<li>Possible fibrovascular scarring in advanced cases</li>' : 
                      '<li>Geographic atrophy - well-demarcated areas of RPE loss</li>'}
                </ul>
                <p>Classification: ${lowerCondition.includes('wet') || lowerCondition.includes('neovascular') ? 
                  'Wet (Neovascular) AMD' : 'Dry (Non-neovascular) AMD'}</p>
            `,
            'glaucoma': `
                <p class="mb-2"><strong>Glaucoma</strong> is a progressive optic neuropathy characterized by specific structural changes to the optic nerve head.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Increased cup-to-disc ratio (CDR)</li>
                    <li>Thinning of the neuroretinal rim</li>
                    <li>Vertical elongation of the optic cup</li>
                    <li>ISNT rule violation (Inferior ≥ Superior > Nasal > Temporal rim thickness)</li>
                    <li>Potential disc hemorrhages at the rim</li>
                    <li>Retinal nerve fiber layer (RNFL) defects may be visible</li>
                </ul>
                <p>Classification: Primary Open Angle, Primary Angle Closure, Normal Tension, or Secondary Glaucoma</p>
            `,
            'keratoconus': `
                <p class="mb-2"><strong>Keratoconus</strong> is a non-inflammatory, progressive corneal ectasia characterized by thinning and steepening of the cornea.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Conical protrusion of the cornea</li>
                    <li>Corneal thinning, typically inferior/inferotemporal</li>
                    <li>Fleischer ring - iron deposition at the base of the cone</li>
                    <li>Vogt's striae - fine vertical lines in the posterior stroma</li>
                    <li>Possible scarring in advanced cases</li>
                </ul>
                <p>Classification: Mild, Moderate, or Severe based on corneal steepening and thickness</p>
            `,
            'dermoid cyst': `
                <p class="mb-2"><strong>Dermoid Cyst</strong> is a benign congenital choristoma typically located at the superotemporal orbital rim or limbus.</p>
                <p class="mb-2">Key clinical features visible in this image include:</p>
                <ul class="list-disc ml-5 mb-2">
                    <li>Well-circumscribed, smooth, round lesion</li>
                    <li>Yellowish-white or flesh-colored appearance</li>
                    <li>May contain dermal appendages (hair follicles, sebaceous glands)</li>
                    <li>Non-tender, fixed to underlying periosteum</li>
                    <li>May cause mechanical ptosis if large enough</li>
                </ul>
                <p>Classification: Orbital (deep) or Epibulbar (superficial, at limbus)</p>
            `
        };
        
        // Default clinical information if not found in the database
        const defaultInfo = `
            <p class="mb-2">This image shows a typical presentation of ${condition}.</p>
            <p class="mb-2">The key ophthalmological features visible include:</p>
            <ul class="list-disc ml-5 mb-2">
                <li>Characteristic anatomical appearance</li>
                <li>Typical tissue changes associated with this condition</li>
                <li>Relevant structural alterations visible on clinical examination</li>
            </ul>
            <p class="mt-2 text-sm italic">Question context: <span class="font-normal">${this.highlightKeywords(context, condition)}</span></p>
        `;
        
        // Check for exact matches
        for (const key in clinicalInfoMap) {
            if (lowerCondition.includes(key) || key.includes(lowerCondition)) {
                return clinicalInfoMap[key];
            }
        }
        
        return defaultInfo;
    }
    
    /**
     * Highlight keywords in text
     */
    highlightKeywords(text, keyword) {
        if (!keyword || !text) return text;
        
        const keywordPattern = new RegExp(`(${keyword})`, 'gi');
        return text.replace(keywordPattern, '<mark class="bg-yellow-200 px-0.5 rounded">$1</mark>');
    }
}

// Initialize and export
window.ophthalmoImageGenerator = new OphthalmoImageGenerator(); 
/**
 * UserApiInjector.js
 * Allows users to inject their own Gemini API key for use with OphthalmoQA
 * This way users can use their personal quota instead of the app's shared quota
 */
class UserApiInjector {
    constructor() {
        this.modalElement = null;
        this.userApiKey = null;
        this.isApiKeyActive = false;
        this.testResult = null;
        this.questionGenerator = null;
        this.authManager = null;
        
        // Get stored API key if available
        this.loadStoredApiKey();
        
        // Create UI elements
        this.createModal();
    }
    
    /**
     * Load stored API key from localStorage
     */
    loadStoredApiKey() {
        try {
            const storedApiData = localStorage.getItem('ophthalmoqa_user_api_key');
            if (storedApiData) {
                const apiData = JSON.parse(storedApiData);
                this.userApiKey = apiData.key;
                this.isApiKeyActive = apiData.active || false;
                
                // Update QuestionGenerator if available
                this.injectApiKeyToGenerator();
                
                console.log('User API key loaded from storage');
            }
        } catch (error) {
            console.error('Error loading API key from storage:', error);
        }
    }
    
    /**
     * Create the API key modal
     */
    createModal() {
        // Create modal element
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-gray-800 bg-opacity-80 flex items-center justify-center z-50 hidden';
        modal.id = 'api-key-modal';
        
        // Modal HTML content
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-xl relative max-h-[90vh] overflow-y-auto">
                <button id="close-api-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
                <h2 class="text-2xl font-semibold text-primary mb-4 flex items-center">
                    <i class="fas fa-key mr-2"></i> Your Gemini API Key
                </h2>
                
                <div class="bg-blue-50 p-4 rounded-md border-l-4 border-blue-500 text-sm text-gray-700 mb-4">
                    <p class="mb-2">Use your personal Gemini API key to:</p>
                    <ul class="list-disc pl-5 space-y-1">
                        <li>Utilize your own quota instead of the shared app quota</li>
                        <li>Ensure smooth operation even during peak usage periods</li>
                        <li>Maintain privacy by using your own API credentials</li>
                    </ul>
                    <p class="mt-2">Get a Gemini API key from <a href="https://makersuite.google.com/app/apikey" target="_blank" class="text-blue-600 hover:underline">Google AI Studio</a></p>
                </div>
                
                <div class="mb-5">
                    <label for="gemini-api-key" class="block text-gray-700 font-medium mb-2">Your Gemini API Key</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-key text-gray-400"></i>
                        </div>
                        <input type="password" id="gemini-api-key" 
                            class="w-full pl-10 p-3 border border-gray-300 rounded-md bg-gray-50 focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent transition"
                            placeholder="Enter your Gemini API key here">
                        <button type="button" id="toggle-api-key-visibility" class="absolute inset-y-0 right-12 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" id="paste-api-key" class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-primary">
                            <i class="fas fa-paste"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mb-5">
                    <label class="flex items-start">
                        <input type="checkbox" id="activate-api-key" class="h-4 w-4 mt-1 text-primary focus:ring-secondary border-gray-300 rounded">
                        <span class="ml-2 block text-sm text-gray-700">
                            Activate this API key for all future questions
                        </span>
                    </label>
                </div>
                
                <div id="api-key-test-result" class="mb-4 p-3 rounded-md text-sm hidden"></div>
                
                <div class="flex flex-col sm:flex-row gap-3">
                    <button type="button" id="save-api-key" class="flex-1 bg-primary hover:bg-accent text-white font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                        <i class="fas fa-save mr-2"></i> Save API Key
                    </button>
                    <button type="button" id="test-api-key" class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-6 rounded-md shadow-sm transition flex items-center justify-center">
                        <i class="fas fa-vial mr-2"></i> Test API Key
                    </button>
                </div>
                
                <div class="mt-4 pt-4 border-t border-gray-200 text-xs text-gray-500">
                    <p class="flex items-center mb-1"><i class="fas fa-shield-alt mr-2"></i> Your API key is stored locally on your device and never sent to our servers.</p>
                    <p>Tip: Gmail accounts get free Gemini API usage with generous quotas.</p>
                </div>
            </div>
        `;
        
        // Add modal to document
        document.body.appendChild(modal);
        this.modalElement = modal;
        
        // Initialize event listeners
        this.initializeEventListeners();
    }
    
    /**
     * Initialize event listeners for the modal
     */
    initializeEventListeners() {
        if (!this.modalElement) return;
        
        // Close modal
        const closeBtn = document.getElementById('close-api-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.hideModal());
        }
        
        // Toggle API key visibility
        const toggleVisibilityBtn = document.getElementById('toggle-api-key-visibility');
        if (toggleVisibilityBtn) {
            toggleVisibilityBtn.addEventListener('click', () => {
                const apiKeyInput = document.getElementById('gemini-api-key');
                const icon = toggleVisibilityBtn.querySelector('i');
                
                if (apiKeyInput.type === 'password') {
                    apiKeyInput.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    apiKeyInput.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        }
        
        // Paste API key
        const pasteBtn = document.getElementById('paste-api-key');
        if (pasteBtn) {
            pasteBtn.addEventListener('click', async () => {
                try {
                    const text = await navigator.clipboard.readText();
                    const apiKeyInput = document.getElementById('gemini-api-key');
                    apiKeyInput.value = text.trim();
                } catch (err) {
                    console.error('Failed to paste API key:', err);
                    // Show a message to the user about clipboard permissions
                    this.showApiTestResult('Unable to paste from clipboard. Please paste manually.', 'error');
                }
            });
        }
        
        // Test API key
        const testBtn = document.getElementById('test-api-key');
        if (testBtn) {
            testBtn.addEventListener('click', () => this.testApiKey());
        }
        
        // Save API key
        const saveBtn = document.getElementById('save-api-key');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveApiKey());
        }
        
        // Pre-fill and check the activate checkbox if we have an active key
        const activateCheckbox = document.getElementById('activate-api-key');
        if (activateCheckbox && this.isApiKeyActive) {
            activateCheckbox.checked = true;
        }
        
        // Pre-fill the API key input if we have a stored key
        const apiKeyInput = document.getElementById('gemini-api-key');
        if (apiKeyInput && this.userApiKey) {
            apiKeyInput.value = this.userApiKey;
        }
    }
    
    /**
     * Initialize the UI and connect event listeners
     */
    initializeUI() {
        // Connect the API key management link that already exists in the HTML
        const apiKeyLink = document.getElementById('api-key-management');
        if (apiKeyLink) {
            apiKeyLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.showModal();
            });
            console.log('API key management link connected');
        } else {
            console.warn('API key management link not found in the DOM');
        }
    }
    
    /**
     * Set the QuestionGenerator reference
     * @param {QuestionGenerator} generator - The QuestionGenerator instance
     */
    setQuestionGenerator(generator) {
        this.questionGenerator = generator;
        // Try to inject API key in case we already have one
        this.injectApiKeyToGenerator();
    }
    
    /**
     * Set the AuthManager reference
     * @param {AuthManager} authManager - The AuthManager instance
     */
    setAuthManager(authManager) {
        this.authManager = authManager;
    }
    
    /**
     * Load saved API key and activate if needed
     */
    loadSavedApiKey() {
        this.loadStoredApiKey();
        if (this.userApiKey && this.isApiKeyActive) {
            this.injectApiKeyToGenerator();
            this.addApiKeyIndicator();
        }
    }
    
    /**
     * Show the API key modal
     */
    showModal() {
        if (!this.modalElement) return;
        this.modalElement.classList.remove('hidden');
        
        // Add event listener to close modal when clicking outside
        const handleOutsideClick = (e) => {
            if (e.target === this.modalElement) {
                this.hideModal();
                document.removeEventListener('click', handleOutsideClick);
            }
        };
        
        // Add outside click handler after a short delay to prevent immediate closure
        setTimeout(() => {
            document.addEventListener('click', handleOutsideClick);
        }, 100);
    }
    
    /**
     * Hide the API key modal
     */
    hideModal() {
        if (!this.modalElement) return;
        this.modalElement.classList.add('hidden');
    }
    
    /**
     * Test the API key by making a simple Gemini API call
     */
    async testApiKey() {
        const apiKeyInput = document.getElementById('gemini-api-key');
        const testBtn = document.getElementById('test-api-key');
        
        if (!apiKeyInput || !testBtn) return;
        
        const apiKey = apiKeyInput.value.trim();
        if (!apiKey) {
            this.showApiTestResult('Please enter an API key to test.', 'error');
            return;
        }
        
        // Disable button and show loading
        testBtn.disabled = true;
        const originalBtnText = testBtn.innerHTML;
        testBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Testing...';
        
        try {
            // Test the API key with a simple request
            const result = await this.makeTestApiCall(apiKey);
            
            if (result.success) {
                this.showApiTestResult('API key is valid and working correctly!', 'success');
                this.testResult = true;
            } else {
                this.showApiTestResult(`API key test failed: ${result.error}`, 'error');
                this.testResult = false;
            }
        } catch (error) {
            console.error('API key test error:', error);
            this.showApiTestResult(`API test error: ${error.message}`, 'error');
            this.testResult = false;
        } finally {
            // Restore button state
            testBtn.disabled = false;
            testBtn.innerHTML = originalBtnText;
        }
    }
    
    /**
     * Make a test call to the Gemini API
     * @param {string} apiKey - The API key to test
     * @returns {Object} Result object with success flag and error if applicable
     */
    async makeTestApiCall(apiKey) {
        try {
            const geminiApiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";
            
            const requestBody = {
                contents: [{ parts: [{ text: "Hello, please respond with the word 'success' to confirm Gemini API connection." }] }],
                generationConfig: {
                    temperature: 0
                }
            };
            
            const response = await fetch(`${geminiApiUrl}?key=${apiKey}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });
            
            if (!response.ok) {
                const errorData = await response.json();
                return {
                    success: false,
                    error: errorData.error?.message || `Error: ${response.status} ${response.statusText}`
                };
            }
            
            const data = await response.json();
            return { success: true, data };
            
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Unknown error testing API key'
            };
        }
    }
    
    /**
     * Show API test result in the modal
     * @param {string} message - The message to display
     * @param {string} type - The message type (success, error, info)
     */
    showApiTestResult(message, type = 'info') {
        const resultElement = document.getElementById('api-key-test-result');
        if (!resultElement) return;
        
        resultElement.classList.remove('hidden', 'bg-green-100', 'text-green-700', 'bg-red-100', 'text-red-700', 'bg-blue-100', 'text-blue-700');
        
        if (type === 'success') {
            resultElement.classList.add('bg-green-100', 'text-green-700');
        } else if (type === 'error') {
            resultElement.classList.add('bg-red-100', 'text-red-700');
        } else {
            resultElement.classList.add('bg-blue-100', 'text-blue-700');
        }
        
        resultElement.innerHTML = message;
        resultElement.classList.remove('hidden');
    }
    
    /**
     * Save the API key
     */
    async saveApiKey() {
        const apiKeyInput = document.getElementById('gemini-api-key');
        const activateCheckbox = document.getElementById('activate-api-key');
        const saveBtn = document.getElementById('save-api-key');
        
        if (!apiKeyInput || !activateCheckbox || !saveBtn) return;
        
        const apiKey = apiKeyInput.value.trim();
        if (!apiKey) {
            this.showApiTestResult('Please enter an API key to save.', 'error');
            return;
        }
        
        // Disable button and show loading
        saveBtn.disabled = true;
        const originalBtnText = saveBtn.innerHTML;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Saving...';
        
        try {
            // If we haven't tested the key yet, test it now
            if (this.testResult === null) {
                const testResult = await this.makeTestApiCall(apiKey);
                if (!testResult.success) {
                    this.showApiTestResult(`API key appears invalid: ${testResult.error}. Save anyway?`, 'error');
                    // Continue anyway - user might want to save a key that's temporarily failing
                }
            }
            
            // Save the API key
            this.userApiKey = apiKey;
            this.isApiKeyActive = activateCheckbox.checked;
            
            // Store in localStorage
            localStorage.setItem('ophthalmoqa_user_api_key', JSON.stringify({
                key: apiKey,
                active: this.isApiKeyActive,
                timestamp: new Date().toISOString()
            }));
            
            // Inject API key to QuestionGenerator if active
            if (this.isApiKeyActive) {
                this.injectApiKeyToGenerator();
            }
            
            this.showApiTestResult('API key saved successfully!', 'success');
            
            // Close modal after a short delay
            setTimeout(() => {
                this.hideModal();
            }, 1500);
            
        } catch (error) {
            console.error('Error saving API key:', error);
            this.showApiTestResult(`Error saving API key: ${error.message}`, 'error');
        } finally {
            // Restore button state
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalBtnText;
        }
    }
    
    /**
     * Inject the user's API key into the QuestionGenerator
     */
    injectApiKeyToGenerator() {
        if (!this.userApiKey || !this.isApiKeyActive) return;
        
        // Get the QuestionGenerator instance from window or global scope
        if (window.questionGenerator) {
            // Update the Gemini API key
            window.questionGenerator.geminiApiKey = this.userApiKey;
            console.log('User API key injected into QuestionGenerator');
            
            // Add indicator to the UI
            this.addApiKeyIndicator();
        } else {
            console.warn('QuestionGenerator not found, cannot inject API key');
            
            // Try again later when the question generator might be initialized
            setTimeout(() => {
                this.injectApiKeyToGenerator();
            }, 1000);
        }
    }
    
    /**
     * Add an indicator to the UI when a user API key is active
     */
    addApiKeyIndicator() {
        // Check if indicator already exists
        if (document.getElementById('user-api-indicator')) return;
        
        // Look for places where we can add the indicator
        const accountStatus = document.getElementById('account-status');
        if (accountStatus) {
            const indicator = document.createElement('span');
            indicator.id = 'user-api-indicator';
            indicator.className = 'text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full ml-2';
            indicator.innerHTML = '<i class="fas fa-key mr-1"></i> Using Your API';
            
            accountStatus.appendChild(indicator);
        }
    }
}

// Initialize the API injector
document.addEventListener('DOMContentLoaded', () => {
    window.userApiInjector = new UserApiInjector();
});

/**
 * Advanced File Processor for Multi-Format Document Handling
 * Supports PDF, DOCX, TXT, RTF, MD, HTML and other formats
 */

class AdvancedFileProcessor {
    constructor() {
        this.supportedTypes = {
            'application/pdf': 'pdf',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
            'application/msword': 'doc',
            'text/plain': 'txt',
            'text/rtf': 'rtf',
            'application/rtf': 'rtf',
            'text/markdown': 'md',
            'text/html': 'html'
        };
        
        this.processors = {
            pdf: this.processPDF.bind(this),
            docx: this.processDOCX.bind(this),
            doc: this.processDOC.bind(this),
            txt: this.processTXT.bind(this),
            rtf: this.processRTF.bind(this),
            md: this.processMarkdown.bind(this),
            html: this.processHTML.bind(this)
        };
        
        this.extractionStats = {
            fileType: '',
            originalSize: 0,
            processedSize: 0,
            processingTime: 0,
            errors: [],
            warnings: []
        };
    }

    async processFile(file) {
        console.log(`🔍 Processing file: ${file.name} (${file.type})`);
        const startTime = Date.now();
        
        this.extractionStats = {
            fileType: this.getFileType(file),
            originalSize: file.size,
            processedSize: 0,
            processingTime: 0,
            errors: [],
            warnings: []
        };

        try {
            const fileType = this.getFileType(file);
            const processor = this.processors[fileType];
            
            if (!processor) {
                throw new Error(`Unsupported file type: ${file.type}`);
            }

            const content = await processor(file);
            const processedContent = await this.postProcessContent(content, fileType);
            
            this.extractionStats.processedSize = processedContent.length;
            this.extractionStats.processingTime = Date.now() - startTime;
            
            console.log(`✅ File processed successfully in ${this.extractionStats.processingTime}ms`);
            
            return {
                content: processedContent,
                metadata: {
                    fileName: file.name,
                    fileType: fileType,
                    fileSize: file.size,
                    stats: this.extractionStats
                }
            };
            
        } catch (error) {
            this.extractionStats.errors.push(error.message);
            this.extractionStats.processingTime = Date.now() - startTime;
            
            console.error(`❌ Error processing file: ${error.message}`);
            throw error;
        }
    }

    getFileType(file) {
        // Check MIME type first
        if (this.supportedTypes[file.type]) {
            return this.supportedTypes[file.type];
        }
        
        // Fallback to file extension
        const extension = file.name.split('.').pop().toLowerCase();
        const extensionMap = {
            'pdf': 'pdf',
            'docx': 'docx',
            'doc': 'doc',
            'txt': 'txt',
            'text': 'txt',
            'rtf': 'rtf',
            'md': 'md',
            'markdown': 'md',
            'html': 'html',
            'htm': 'html'
        };
        
        return extensionMap[extension] || 'txt';
    }

    async processPDF(file) {
        console.log('📄 Processing PDF file...');
        
        if (typeof pdfjsLib === 'undefined') {
            throw new Error('PDF.js library not loaded');
        }

        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            
            let fullText = '';
            const totalPages = pdf.numPages;
            
            for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
                try {
                    const page = await pdf.getPage(pageNum);
                    const textContent = await page.getTextContent();
                    
                    let pageText = '';
                    textContent.items.forEach(item => {
                        if (item.str) {
                            pageText += item.str + ' ';
                        }
                    });
                    
                    fullText += `\n--- Page ${pageNum} ---\n${pageText}\n`;
                    
                } catch (pageError) {
                    this.extractionStats.warnings.push(`Error reading page ${pageNum}: ${pageError.message}`);
                    console.warn(`Warning: Could not read page ${pageNum}`);
                }
            }
            
            return fullText;
            
        } catch (error) {
            throw new Error(`PDF processing error: ${error.message}`);
        }
    }

    async processDOCX(file) {
        console.log('📝 Processing DOCX file...');
        
        try {
            const text = await this.readAsText(file);
            
            if (text.includes('<?xml')) {
                const textMatches = text.match(/<w:t[^>]*>([^<]*)<\/w:t>/g);
                if (textMatches) {
                    return textMatches
                        .map(match => match.replace(/<[^>]*>/g, ''))
                        .join(' ')
                        .replace(/\s+/g, ' ')
                        .trim();
                }
            }
            
            return this.cleanRawText(text);
            
        } catch (error) {
            throw new Error(`DOCX processing error: ${error.message}`);
        }
    }

    async processDOC(file) {
        console.log('📄 Processing DOC file...');
        
        try {
            const text = await this.readAsText(file);
            return this.cleanRawText(text);
            
        } catch (error) {
            throw new Error(`DOC processing error: ${error.message}`);
        }
    }

    async processTXT(file) {
        console.log('📄 Processing TXT file...');
        
        try {
            const text = await this.readAsText(file);
            return text;
            
        } catch (error) {
            throw new Error(`TXT processing error: ${error.message}`);
        }
    }

    async processRTF(file) {
        console.log('📄 Processing RTF file...');
        
        try {
            const text = await this.readAsText(file);
            
            let cleanText = text
                .replace(/\\[a-z]+\d*/g, ' ')
                .replace(/[{}]/g, ' ')
                .replace(/\\\\/g, '\\')
                .replace(/\\'/g, "'")
                .replace(/\s+/g, ' ')
                .trim();
            
            return cleanText;
            
        } catch (error) {
            throw new Error(`RTF processing error: ${error.message}`);
        }
    }

    async processMarkdown(file) {
        console.log('📄 Processing Markdown file...');
        
        try {
            const text = await this.readAsText(file);
            
            let cleanText = text
                .replace(/^#{1,6}\s+/gm, '')
                .replace(/\*\*(.*?)\*\*/g, '$1')
                .replace(/\*(.*?)\*/g, '$1')
                .replace(/`(.*?)`/g, '$1')
                .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
                .replace(/^\s*[-*+]\s+/gm, '')
                .replace(/^\s*\d+\.\s+/gm, '')
                .trim();
            
            return cleanText;
            
        } catch (error) {
            throw new Error(`Markdown processing error: ${error.message}`);
        }
    }

    async processHTML(file) {
        console.log('🌐 Processing HTML file...');
        
        try {
            const text = await this.readAsText(file);
            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = text;
            
            const scripts = tempDiv.querySelectorAll('script, style');
            scripts.forEach(script => script.remove());
            
            const cleanText = tempDiv.textContent || tempDiv.innerText || '';
            
            return cleanText.replace(/\s+/g, ' ').trim();
            
        } catch (error) {
            throw new Error(`HTML processing error: ${error.message}`);
        }
    }

    async readAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = (e) => reject(new Error('Failed to read file'));
            reader.readAsText(file, 'utf-8');
        });
    }

    cleanRawText(text) {
        return text
            .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, '')
            .replace(/[^\x20-\x7E\u00A0-\uFFFF]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    async postProcessContent(content, fileType) {
        console.log('🔧 Post-processing content...');
        
        let processedContent = content;
        
        processedContent = processedContent
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .replace(/[ \t]+/g, ' ');
        
        processedContent = this.fixCommonIssues(processedContent);
        processedContent = this.enhanceStructure(processedContent);
        
        return processedContent;
    }

    fixCommonIssues(text) {
        const corrections = {
            'I0L': 'IOL',
            'I0P': 'IOP',
            '0CT': 'OCT',
            'rnm': 'mm',
            'rnl': 'ml',
            'rng': 'mg'
        };
        
        let fixedText = text;
        if (corrections && typeof corrections === 'object') {
            Object.entries(corrections).forEach(([wrong, correct]) => {
                fixedText = fixedText.replace(new RegExp(wrong, 'g'), correct);
            });
        }
        
        return fixedText;
    }

    enhanceStructure(text) {
        let enhanced = text;
        
        enhanced = enhanced.replace(/(\d+\.)\s*([A-Z])/g, '$1 $2');
        enhanced = enhanced.replace(/(Question\s*\d*:?)\s*/gi, '\n$1 ');
        enhanced = enhanced.replace(/(Answer:?)\s*/gi, '\nAnswer: ');
        enhanced = enhanced.replace(/([A-E][\):\.])\s*([A-Z])/g, '$1 $2');
        
        return enhanced;
    }

    getProcessingStats() {
        return this.extractionStats;
    }

    async analyzeContent(content) {
        const analysis = {
            hasQuestions: false,
            hasAnswers: false,
            hasMultipleChoice: false,
            questionCount: 0,
            answerCount: 0,
            confidence: 0,
            contentType: 'unknown'
        };

        const questionPatterns = [
            /\bquestion\s*\d*[:\.]?\s/gi,
            /^\d+\.?\s*(?:what|which|where|when|why|how|who|is|are|can|could|will|would|should|does|do|did)\b/gmi,
            /[?]/g
        ];

        const answerPatterns = [
            /\banswer[:\.]?\s/gi,
            /^[A-E][\):\.]?\s/gm,
            /\b(?:true|false)\b/gi
        ];

        questionPatterns.forEach(pattern => {
            const matches = content.match(pattern);
            if (matches) {
                analysis.questionCount += matches.length;
                analysis.hasQuestions = true;
            }
        });

        answerPatterns.forEach(pattern => {
            const matches = content.match(pattern);
            if (matches) {
                analysis.answerCount += matches.length;
                analysis.hasAnswers = true;
            }
        });

        const mcqPattern = /^[A-E][\):\.]?\s.+$/gm;
        const mcqMatches = content.match(mcqPattern);
        if (mcqMatches && mcqMatches.length >= 3) {
            analysis.hasMultipleChoice = true;
        }

        let confidenceScore = 0;
        if (analysis.hasQuestions) confidenceScore += 0.4;
        if (analysis.hasAnswers) confidenceScore += 0.3;
        if (analysis.hasMultipleChoice) confidenceScore += 0.2;
        if (analysis.questionCount > 0) confidenceScore += Math.min(analysis.questionCount * 0.1, 0.1);

        analysis.confidence = Math.min(confidenceScore, 1.0);

        if (analysis.hasMultipleChoice && analysis.hasQuestions) {
            analysis.contentType = 'multiple_choice_quiz';
        } else if (analysis.hasQuestions && analysis.hasAnswers) {
            analysis.contentType = 'question_answer_set';
        } else if (analysis.hasQuestions) {
            analysis.contentType = 'questions_only';
        } else {
            analysis.contentType = 'general_text';
        }

        return analysis;
    }
}

// Initialize the advanced file processor
window.advancedFileProcessor = new AdvancedFileProcessor();

// Export for global access
window.processFileAdvanced = async (file) => {
    return await window.advancedFileProcessor.processFile(file);
};

window.analyzeFileContent = async (content) => {
    return await window.advancedFileProcessor.analyzeContent(content);
};

console.log('🔧 Advanced File Processor loaded and ready!'); 
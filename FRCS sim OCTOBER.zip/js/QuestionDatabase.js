/**
 * QuestionDatabase.js
 * Manages the storage and retrieval of generated questions
 */
class QuestionDatabase {
    constructor() {
        this.storedQuestions = [];
        this.dbName = 'ophthalmoqa_questions';
        this.loadFromLocalStorage();
    }

    /**
     * Load questions from localStorage
     */
    loadFromLocalStorage() {
        try {
            const storedData = localStorage.getItem(this.dbName);
            if (storedData) {
                this.storedQuestions = JSON.parse(storedData);
                console.log(`Loaded ${this.storedQuestions.length} questions from local storage`);
            }
        } catch (error) {
            console.error('Error loading questions from localStorage:', error);
            this.storedQuestions = [];
        }
    }

    /**
     * Save questions to localStorage
     */
    saveToLocalStorage() {
        try {
            // Use safe storage if available, fallback to localStorage
            if (window.safeSetItem) {
                const success = window.safeSetItem(this.dbName, this.storedQuestions);
                if (!success) {
                    console.warn('⚠️ Failed to save questions - storage may be full');
                }
            } else {
                localStorage.setItem(this.dbName, JSON.stringify(this.storedQuestions));
            }
        } catch (error) {
            console.error('Error saving questions to localStorage:', error);
            
            // Try emergency cleanup if quota exceeded
            if (error.name === 'QuotaExceededError' && window.storageManager) {
                console.log('🚨 Attempting emergency cleanup...');
                window.storageManager.emergencyCleanup();
                
                // Retry once
                try {
                    localStorage.setItem(this.dbName, JSON.stringify(this.storedQuestions));
                    console.log('✅ Successfully saved after cleanup');
                } catch (retryError) {
                    console.error('❌ Still failed to save after cleanup:', retryError);
                }
            }
        }
    }

    /**
     * Add a single question to the database
     * @param {Object} question - Question object to add
     * @returns {boolean} - Whether the question was added (not a duplicate)
     */
    addQuestion(question) {
        if (!question) return false;
        
        // Add metadata if not present
        if (!question.metadata) {
            question.metadata = {
                dateAdded: new Date().toISOString(),
                id: this.generateQuestionId(question)
            };
        }
        
        // Check for duplicates
        if (this.isDuplicate(question)) {
            return false;
        }
        
        // Add the question
        this.storedQuestions.push(question);
        this.saveToLocalStorage();
        
        return true;
    }

    /**
     * Add new questions to the database
     * @param {Array} questions - Array of question objects to add
     * @param {Object} metadata - Metadata about the questions (source, subspecialty, etc.)
     * @returns {number} - Number of questions added (excluding duplicates)
     */
    addQuestions(questions, metadata = {}) {
        if (!questions || !Array.isArray(questions) || questions.length === 0) {
            return 0;
        }

        // Add timestamp and metadata to questions
        const timestamp = new Date().toISOString();
        const enhancedQuestions = questions.map(q => ({
            ...q,
            metadata: {
                ...metadata,
                dateAdded: timestamp,
                id: this.generateQuestionId(q)
            }
        }));

        // Filter out duplicates
        const initialCount = this.storedQuestions.length;
        const newQuestions = enhancedQuestions.filter(newQ => {
            return !this.isDuplicate(newQ);
        });

        // Add new questions
        this.storedQuestions = [...this.storedQuestions, ...newQuestions];
        this.saveToLocalStorage();
        
        return newQuestions.length;
    }

    /**
     * Generate a unique ID for a question based on its content
     * @param {Object} question - The question object
     * @returns {string} - A hash ID
     */
    generateQuestionId(question) {
        // Create a simple hash from the question text and type
        const str = `${question.type}:${question.question}`;
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32bit integer
        }
        return `q_${Math.abs(hash).toString(16)}`;
    }

    /**
     * Check if a question is a duplicate
     * @param {Object} newQuestion - Question to check
     * @returns {boolean} - True if duplicate found
     */
    isDuplicate(newQuestion) {
        // First check if the ID already exists
        const idMatch = this.storedQuestions.some(q => {
            return q.metadata && q.metadata.id === newQuestion.metadata.id;
        });
        
        if (idMatch) return true;
        
        // Secondary check using similarity
        return this.storedQuestions.some(existingQ => {
            return this.calculateSimilarity(existingQ.question, newQuestion.question) > 0.8;
        });
    }

    /**
     * Calculate similarity between two strings (simple implementation)
     * @param {string} str1 - First string
     * @param {string} str2 - Second string
     * @returns {number} - Similarity score (0-1)
     */
    calculateSimilarity(str1, str2) {
        // Convert to lowercase for better comparison
        const s1 = String(str1).toLowerCase();
        const s2 = String(str2).toLowerCase();
        
        // If strings are identical
        if (s1 === s2) return 1.0;
        
        // Simple Jaccard similarity using word sets
        const words1 = new Set(s1.split(/\s+/).filter(w => w.length > 3));
        const words2 = new Set(s2.split(/\s+/).filter(w => w.length > 3));
        
        if (words1.size === 0 || words2.size === 0) return 0;
        
        // Count intersections
        let intersection = 0;
        for (const word of words1) {
            if (words2.has(word)) intersection++;
        }
        
        // Calculate Jaccard similarity
        const union = words1.size + words2.size - intersection;
        return intersection / union;
    }

    /**
     * Get questions filtered by criteria
     * @param {Object} filters - Filter criteria
     * @returns {Array} - Filtered questions
     */
    getQuestions(filters = {}) {
        let filteredQuestions = [...this.storedQuestions];
        
        // Apply filters
        if (filters.subspecialty) {
            filteredQuestions = filteredQuestions.filter(q => {
                return q.metadata && q.metadata.subspecialty === filters.subspecialty;
            });
        }
        
        if (filters.type) {
            filteredQuestions = filteredQuestions.filter(q => q.type === filters.type);
        }
        
        if (filters.difficulty) {
            filteredQuestions = filteredQuestions.filter(q => {
                return q.metadata && q.metadata.difficulty === filters.difficulty;
            });
        }
        
        if (filters.limit && filteredQuestions.length > filters.limit) {
            filteredQuestions = filteredQuestions.slice(0, filters.limit);
        }
        
        return filteredQuestions;
    }

    /**
     * Get total count of stored questions
     * @returns {number} - Count of questions
     */
    getQuestionCount() {
        return this.storedQuestions.length;
    }

    /**
     * Clear all stored questions
     */
    clearAllQuestions() {
        this.storedQuestions = [];
        this.saveToLocalStorage();
    }
}

// Export as global
window.questionDatabase = new QuestionDatabase();

/**
 * OphthalmoQA UI Manager
 * Handles UI interactions, state management, and display functionality
 */
const UIManager = (() => {
    // UI Element references
    let elements = {};
    
    // Status message timeout ID for cleanup
    let statusMessageTimeout = null;
    
    /**
     * Initialize UI elements and store references
     */
    const initialize = () => {
        // Store references to all UI elements
        elements = {
            // Input elements
            inputTypeSelect: document.getElementById('input-type'),
            uploadContainer: document.getElementById('upload-container'),
            textContainer: document.getElementById('text-container'),
            knowledgeBaseContainer: document.getElementById('knowledge-base-container'),
            fileDropArea: document.getElementById('file-drop-area'),
            fileInput: document.getElementById('pdf-upload'),
            fileInfo: document.getElementById('file-info'),
            fileNameElement: document.getElementById('file-name'),
            fileProcessingStatus: document.getElementById('file-processing-status'),
            progressBarContainer: document.getElementById('progress-bar-container'),
            progressBar: document.getElementById('progress-bar'),
            inputTextElement: document.getElementById('input-text'),
            knowledgeAreaSelect: document.getElementById('knowledge-area'),
            
            // Question types checkboxes
            questionTypeCheckboxes: {
                mcq: document.getElementById('type-mcq'),
                tf: document.getElementById('type-tf'),
                matching: document.getElementById('type-matching'),
                shortAnswer: document.getElementById('type-short-answer'),
                clinicalCase: document.getElementById('type-clinical-case'),
                differential: document.getElementById('type-differential'),
            },
            
            // Settings elements
            difficultySelect: document.getElementById('difficulty'),
            numQuestionsInput: document.getElementById('num-questions'),
            focusAreaInput: document.getElementById('focus-area'),
            showAnswersDefaultCheckbox: document.getElementById('show-answers-default'),
            
            // Buttons
            generateBtn: document.getElementById('generate-btn'),
            clearBtn: document.getElementById('clear-btn'),
            exportBtn: document.getElementById('export-btn'),
            regenerateBtn: document.getElementById('regenerate-btn'),
            
            // Output elements
            qaContainer: document.getElementById('qa-container'),
            loadingIndicator: document.getElementById('loading-indicator'),
            statusMessage: document.getElementById('status-message'),
            exportFormatSelect: document.getElementById('export-format'),
            
            // Other elements
            currentYearElement: document.getElementById('current-year')
        };
        
        // Set current year in footer
        elements.currentYearElement.textContent = new Date().getFullYear();
    };
    
    /**
     * Show status message with specified type
     * @param {string} message Message to display
     * @param {string} type Message type ('success', 'error', 'info')
     * @param {number} duration Duration in ms to show message (default: 5000)
     */
    const showStatusMessage = (message, type = 'info', duration = 5000) => {
        // Clear any existing timeout
        if (statusMessageTimeout) {
            clearTimeout(statusMessageTimeout);
        }
        
        const statusEl = elements.statusMessage;
        statusEl.textContent = message;
        statusEl.className = `status-message ${type}`;
        statusEl.style.display = 'block';
        
        // Hide after duration
        statusMessageTimeout = setTimeout(() => {
            statusEl.style.display = 'none';
        }, duration);
    };
    
    /**
     * Update UI based on selected input type
     */
    const handleInputTypeChange = () => {
        const selectedType = elements.inputTypeSelect.value;
        
        // Hide all containers first
        elements.uploadContainer.style.display = 'none';
        elements.textContainer.style.display = 'none';
        elements.knowledgeBaseContainer.style.display = 'none';
        
        // Show selected container
        switch (selectedType) {
            case 'pdf':
                elements.uploadContainer.style.display = 'block';
                break;
            case 'text':
                elements.textContainer.style.display = 'block';
                break;
            case 'knowledge-base':
                elements.knowledgeBaseContainer.style.display = 'block';
                break;
        }
    };
    
    /**
     * Set up file drop area functionality
     */
    const initializeFileDropArea = () => {
        const dropArea = elements.fileDropArea;
        const fileInput = elements.fileInput;
        
        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        // Highlight drop area when dragging over it
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => {
                dropArea.classList.add('highlight');
            }, false);
        });
        
        // Remove highlight when drag leaves
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => {
                dropArea.classList.remove('highlight');
            }, false);
        });
        
        // Handle dropped files
        dropArea.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length > 0) {
                handleFileSelection(files[0]);
            }
        }, false);
        
        // Handle click to upload
        dropArea.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Handle file input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelection(e.target.files[0]);
            }
        });
    };
    
    /**
     * Handle file selection from drop or input
     * @param {File} file The selected file
     */
    const handleFileSelection = (file) => {
        // Only accept PDFs
        if (file.type !== 'application/pdf') {
            showStatusMessage('Please select a PDF file.', 'error');
            return;
        }
        
        // Display file info
        elements.fileInfo.style.display = 'block';
        elements.fileNameElement.textContent = file.name;
        elements.fileProcessingStatus.textContent = 'Ready to process';
        
        // Store file reference for processing
        elements.fileInput.file = file;
        
        // Reset progress bar
        elements.progressBar.style.width = '0%';
        elements.progressBarContainer.style.display = 'none';
    };
    
    /**
     * Show loading state during generation
     * @param {boolean} isLoading Whether the app is in loading state
     */
    const setLoadingState = (isLoading) => {
        if (isLoading) {
            elements.loadingIndicator.style.display = 'flex';
            elements.generateBtn.disabled = true;
        } else {
            elements.loadingIndicator.style.display = 'none';
            elements.generateBtn.disabled = false;
        }
    };
    
    /**
     * Update progress bar
     * @param {number} percent Progress percentage (0-100)
     * @param {string} statusText Optional status text to display
     */
    const updateProgress = (percent, statusText = null) => {
        elements.progressBarContainer.style.display = 'block';
        elements.progressBar.style.width = `${percent}%`;
        
        if (statusText) {
            elements.fileProcessingStatus.textContent = statusText;
        }
    };
    
    /**
     * Get selected question types
     * @returns {Array} Array of selected question types
     */
    const getSelectedQuestionTypes = () => {
        const selectedTypes = [];
        
        for (const [type, checkbox] of Object.entries(elements.questionTypeCheckboxes)) {
            if (checkbox.checked) {
                selectedTypes.push(type);
            }
        }
        
        return selectedTypes;
    };
    
    /**
     * Get current form data
     * @returns {Object} Object containing all form inputs
     */
    const getFormData = () => {
        return {
            inputType: elements.inputTypeSelect.value,
            file: elements.fileInput.file || null,
            text: elements.inputTextElement.value,
            knowledgeArea: elements.knowledgeAreaSelect.value,
            questionTypes: getSelectedQuestionTypes(),
            difficulty: elements.difficultySelect.value,
            numQuestions: parseInt(elements.numQuestionsInput.value, 10),
            focusArea: elements.focusAreaInput.value,
            showAnswersDefault: elements.showAnswersDefaultCheckbox.checked
        };
    };
    
    /**
     * Validate form inputs before generation
     * @returns {boolean} Whether the form is valid
     */
    const validateForm = () => {
        const formData = getFormData();
        
        // Check if question types are selected
        if (formData.questionTypes.length === 0) {
            showStatusMessage('Please select at least one question type.', 'error');
            return false;
        }
        
        // Check input type specific validations
        switch (formData.inputType) {
            case 'pdf':
                if (!formData.file) {
                    showStatusMessage('Please select a PDF file.', 'error');
                    return false;
                }
                break;
            case 'text':
                if (!formData.text.trim()) {
                    showStatusMessage('Please enter some text content.', 'error');
                    return false;
                }
                break;
            case 'knowledge-base':
                if (formData.knowledgeArea === 'none') {
                    showStatusMessage('Please select a knowledge area.', 'error');
                    return false;
                }
                break;
        }
        
        // Check number of questions
        if (isNaN(formData.numQuestions) || formData.numQuestions < 1 || formData.numQuestions > 50) {
            showStatusMessage('Number of questions must be between 1 and 50.', 'error');
            return false;
        }
        
        return true;
    };
    
    /**
     * Clear all form inputs and reset to default state
     */
    const clearForm = () => {
        // Reset input type and show appropriate container
        elements.inputTypeSelect.value = 'pdf';
        handleInputTypeChange();
        
        // Reset file input
        elements.fileInput.value = '';
        elements.fileInput.file = null;
        elements.fileInfo.style.display = 'none';
        elements.progressBarContainer.style.display = 'none';
        
        // Reset text input
        elements.inputTextElement.value = '';
        
        // Reset knowledge base selection
        elements.knowledgeAreaSelect.value = 'none';
        
        // Check MCQ by default, uncheck others
        for (const [type, checkbox] of Object.entries(elements.questionTypeCheckboxes)) {
            checkbox.checked = type === 'mcq';
        }
        
        // Reset other inputs
        elements.difficultySelect.value = 'medium';
        elements.numQuestionsInput.value = '10';
        elements.focusAreaInput.value = '';
        elements.showAnswersDefaultCheckbox.checked = true;
        
        // Clear output
        elements.qaContainer.innerHTML = '';
        
        // Hide elements
        elements.exportBtn.style.display = 'none';
        elements.regenerateBtn.style.display = 'none';
    };
    
    /**
     * Display generated questions and answers
     * @param {Array} questions Array of question objects
     */
    const displayQuestions = (questions) => {
        const container = elements.qaContainer;
        const showAnswers = elements.showAnswersDefaultCheckbox.checked;
        
        // Clear previous content
        container.innerHTML = '';
        
        // Display questions
        questions.forEach((question, index) => {
            const questionElement = document.createElement('div');
            questionElement.className = 'question-item';
            questionElement.dataset.index = index;
            
            // Create header with question number
            const header = document.createElement('div');
            header.className = 'question-header';
            header.innerHTML = `
                <span class="question-number">Question ${index + 1}</span>
                <span class="question-type">${formatQuestionType(question.type)}</span>
                <span class="difficulty-badge ${question.difficulty.toLowerCase()}">${question.difficulty}</span>
            `;
            
            // Create question content
            const content = document.createElement('div');
            content.className = 'question-content';
            content.innerHTML = `<p>${question.text}</p>`;
            
            // Add options based on question type
            const optionsContainer = document.createElement('div');
            optionsContainer.className = 'question-options';
            
            switch (question.type) {
                case 'mcq':
                    question.options.forEach((option, optIndex) => {
                        const optionEl = document.createElement('div');
                        optionEl.className = 'option';
                        optionEl.innerHTML = `
                            <input type="radio" id="q${index}-opt${optIndex}" name="q${index}" disabled>
                            <label for="q${index}-opt${optIndex}">${option}</label>
                        `;
                        optionsContainer.appendChild(optionEl);
                    });
                    break;
                    
                case 'tf':
                    ['True', 'False'].forEach((option, optIndex) => {
                        const optionEl = document.createElement('div');
                        optionEl.className = 'option';
                        optionEl.innerHTML = `
                            <input type="radio" id="q${index}-opt${optIndex}" name="q${index}" disabled>
                            <label for="q${index}-opt${optIndex}">${option}</label>
                        `;
                        optionsContainer.appendChild(optionEl);
                    });
                    break;
                    
                case 'matching':
                    const matchingTable = document.createElement('table');
                    matchingTable.className = 'matching-table';
                    
                    question.items.forEach((item, itemIndex) => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td class="matching-item">${item.term}</td>
                            <td class="matching-connector">→</td>
                            <td class="matching-answer">${showAnswers ? item.match : '?'}</td>
                        `;
                        matchingTable.appendChild(row);
                    });
                    
                    optionsContainer.appendChild(matchingTable);
                    break;
                    
                case 'shortAnswer':
                    const answerArea = document.createElement('div');
                    answerArea.className = 'short-answer-area';
                    answerArea.innerHTML = `
                        <textarea disabled placeholder="Type your answer here"></textarea>
                    `;
                    optionsContainer.appendChild(answerArea);
                    break;
                    
                case 'clinicalCase':
                case 'differential':
                    // These types might have additional sections or structure
                    if (question.additionalInfo) {
                        const additionalInfo = document.createElement('div');
                        additionalInfo.className = 'additional-info';
                        additionalInfo.innerHTML = question.additionalInfo;
                        content.appendChild(additionalInfo);
                    }
                    
                    if (question.options) {
                        question.options.forEach((option, optIndex) => {
                            const optionEl = document.createElement('div');
                            optionEl.className = 'option';
                            optionEl.innerHTML = `
                                <input type="${question.multiSelect ? 'checkbox' : 'radio'}" id="q${index}-opt${optIndex}" name="q${index}" disabled>
                                <label for="q${index}-opt${optIndex}">${option}</label>
                            `;
                            optionsContainer.appendChild(optionEl);
                        });
                    }
                    break;
            }
            
            // Create answer section
            const answerSection = document.createElement('div');
            answerSection.className = `answer-section ${showAnswers ? 'visible' : ''}`;
            
            // Format answer based on question type
            let answerContent = '';
            
            switch (question.type) {
                case 'mcq':
                    answerContent = `<strong>Correct Answer:</strong> ${question.correctAnswer}`;
                    break;
                    
                case 'tf':
                    answerContent = `<strong>Correct Answer:</strong> ${question.correctAnswer}`;
                    break;
                    
                case 'matching':
                    // Answer is already shown in the table if enabled
                    answerContent = '<strong>Correct Matches:</strong> Shown in table above';
                    break;
                    
                case 'shortAnswer':
                case 'clinicalCase':
                case 'differential':
                    answerContent = `<strong>Model Answer:</strong> ${question.modelAnswer}`;
                    break;
            }
            
            // Add explanation if available
            if (question.explanation) {
                answerContent += `<p><strong>Explanation:</strong> ${question.explanation}</p>`;
            }
            
            answerSection.innerHTML = answerContent;
            
            // Create toggle button
            const toggleButton = document.createElement('button');
            toggleButton.className = 'answer-toggle';
            toggleButton.textContent = showAnswers ? 'Hide Answer' : 'Show Answer';
            toggleButton.addEventListener('click', () => {
                answerSection.classList.toggle('visible');
                toggleButton.textContent = answerSection.classList.contains('visible') ? 'Hide Answer' : 'Show Answer';
            });
            
            // Assemble question item
            questionElement.appendChild(header);
            questionElement.appendChild(content);
            questionElement.appendChild(optionsContainer);
            questionElement.appendChild(toggleButton);
            questionElement.appendChild(answerSection);
            
            // Add to container
            container.appendChild(questionElement);
        });
        
        // Show export and regenerate buttons
        elements.exportBtn.style.display = 'inline-block';
        elements.regenerateBtn.style.display = 'inline-block';
    };
    
    /**
     * Format question type for display
     * @param {string} type Question type code
     * @returns {string} Formatted question type
     */
    const formatQuestionType = (type) => {
        const typeMap = {
            'mcq': 'Multiple Choice',
            'tf': 'True/False',
            'matching': 'Matching',
            'shortAnswer': 'Short Answer',
            'clinicalCase': 'Clinical Case',
            'differential': 'Differential Diagnosis'
        };
        
        return typeMap[type] || type;
    };
    
    /**
     * Export questions in selected format
     */
    const exportQuestions = () => {
        const format = elements.exportFormatSelect.value;
        let content = '';
        let filename = `ophthalmology-questions-${new Date().toISOString().slice(0, 10)}`;
        let mimeType = '';
        
        // Extract questions from display
        const questionElements = elements.qaContainer.querySelectorAll('.question-item');
        const questions = Array.from(questionElements).map(el => {
            const index = parseInt(el.dataset.index, 10);
            const questionNumber = index + 1;
            const questionType = el.querySelector('.question-type').textContent;
            const difficulty = el.querySelector('.difficulty-badge').textContent;
            const questionText = el.querySelector('.question-content p').textContent;
            
            // Get options if present
            const options = Array.from(el.querySelectorAll('.option label')).map(label => label.textContent);
            
            // Get answer
            const answerSection = el.querySelector('.answer-section').innerHTML;
            
            return {
                number: questionNumber,
                type: questionType,
                difficulty,
                text: questionText,
                options,
                answerSection
            };
        });
        
        // Generate content based on format
        switch (format) {
            case 'pdf':
                exportAsPDF(questions);
                return;
                
            case 'word':
                // Generate docx format (simplified approach)
                showStatusMessage('Word export feature is coming soon!', 'info');
                return;
                
            case 'text':
                content = questions.map(q => {
                    let questionText = `Question ${q.number} (${q.type} - ${q.difficulty}):\n${q.text}\n\n`;
                    
                    if (q.options && q.options.length > 0) {
                        questionText += q.options.map((opt, i) => `${String.fromCharCode(65 + i)}) ${opt}`).join('\n');
                        questionText += '\n\n';
                    }
                    
                    // Extract answer text
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = q.answerSection;
                    const answerText = tempDiv.textContent;
                    
                    questionText += `${answerText}\n\n`;
                    questionText += '----------------------------------------\n\n';
                    
                    return questionText;
                }).join('');
                
                filename += '.txt';
                mimeType = 'text/plain';
                break;
                
            case 'html':
                // Create an HTML document with styling
                content = `
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Ophthalmology Questions</title>
                    <style>
                        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
                        .question { margin-bottom: 30px; border-bottom: 1px solid #ddd; padding-bottom: 20px; }
                        .question-header { font-weight: bold; margin-bottom: 10px; }
                        .easy { color: green; }
                        .medium { color: orange; }
                        .hard { color: red; }
                        .option { margin-left: 20px; margin-bottom: 5px; }
                        .answer-section { background-color: #f5f5f5; padding: 10px; margin-top: 10px; }
                    </style>
                </head>
                <body>
                    <h1>Ophthalmology Questions</h1>
                    <p>Generated on ${new Date().toLocaleDateString()}</p>
                    
                    ${questions.map(q => `
                        <div class="question">
                            <div class="question-header">
                                Question ${q.number} (${q.type} - <span class="${q.difficulty.toLowerCase()}">${q.difficulty}</span>)
                            </div>
                            <p>${q.text}</p>
                            
                            ${q.options && q.options.length > 0 ? `
                                <div class="options">
                                    ${q.options.map((opt, i) => `
                                        <div class="option">${String.fromCharCode(65 + i)}) ${opt}</div>
                                    `).join('')}
                                </div>
                            ` : ''}
                            
                            <div class="answer-section">
                                ${q.answerSection}
                            </div>
                        </div>
                    `).join('')}
                </body>
                </html>
                `;
                
                filename += '.html';
                mimeType = 'text/html';
                break;
        }
        
        // Trigger download
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showStatusMessage(`Questions exported as ${format.toUpperCase()} successfully!`, 'success');
    };
    
    /**
     * Export questions as PDF (requires external library)
     * @param {Array} questions Array of question objects
     */
    const exportAsPDF = (questions) => {
        // This would typically use a library like pdfmake or jsPDF
        // For simplicity, show a message
        showStatusMessage('PDF export feature is coming soon!', 'info');
    };
    
    /**
     * Prevent default browser actions
     * @param {Event} e Event object
     */
    const preventDefaults = (e) => {
        e.preventDefault();
        e.stopPropagation();
    };
    
    /**
     * Set up event listeners
     */
    const setupEventListeners = () => {
        // Input type change
        elements.inputTypeSelect.addEventListener('change', handleInputTypeChange);
        
        // Generate button
        elements.generateBtn.addEventListener('click', () => {
            if (validateForm()) {
                const formData = getFormData();
                
                // Trigger generation - in a real app, this would call an API
                // For demonstration, we'll simulate the process
                setLoadingState(true);
                simulateGeneration(formData);
            }
        });
        
        // Clear button
        elements.clearBtn.addEventListener('click', clearForm);
        
        // Export button
        elements.exportBtn.addEventListener('click', exportQuestions);
        
        // Regenerate button
        elements.regenerateBtn.addEventListener('click', () => {
            if (validateForm()) {
                const formData = getFormData();
                setLoadingState(true);
                simulateGeneration(formData);
            }
        });
    };
    
    /**
     * Simulate question generation process
     * @param {Object} formData Form data for generation
     */
    const simulateGeneration = (formData) => {
        // Show progress for PDF processing if needed
        if (formData.inputType === 'pdf') {
            // Simulate PDF processing steps
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += 10;
                updateProgress(progress, `Processing PDF (${progress}%)...`);
                
                if (progress >= 100) {
                    clearInterval(progressInterval);
                    updateProgress(100, 'PDF processed successfully');
                    
                    // Now simulate question generation
                    setTimeout(() => {
                        generateQuestions(formData);
                    }, 500);
                }
            }, 300);
        } else {
            // Directly simulate question generation for other types
            setTimeout(() => {
                generateQuestions(formData);
            }, 1500);
        }
    };
    
    /**
     * Generate sample questions based on form data
     * @param {Object} formData Form data for generation
     */
    const generateQuestions = (formData) => {
        // In a real app, this would call an API or ML model
        // For demonstration, we'll generate sample questions
        
        const questions = [];
        const numQuestions = formData.numQuestions;
        const selectedTypes = formData.questionTypes;
        const difficulty = formData.difficulty;
        const focusArea = formData.focusArea || 'general ophthalmology';
        
        // Generate sample questions
        for (let i = 0; i < numQuestions; i++) {
            // Select a question type from the selected types
            const questionType = selectedTypes[i % selectedTypes.length];
            
            // Create question based on type
            let question = {
                type: questionType,
                difficulty: difficulty,
                text: `Sample ${questionType} question about ${focusArea}. This is question ${i + 1} of ${numQuestions}.`
            };
            
            switch (questionType) {
                case 'mcq':
                    question.options = [
                        'Sample option A',
                        'Sample option B',
                        'Sample option C',
                        'Sample option D'
                    ];
                    question.correctAnswer = 'Sample option B';
                    question.explanation = 'This is a sample explanation for this multiple choice question.';
                    break;
                    
                case 'tf':
                    question.correctAnswer = 'True';
                    question.explanation = 'This is a sample explanation for this true/false question.';
                    break;
                    
                case 'matching':
                    question.items = [
                        { term: 'Term A', match: 'Definition 1' },
                        { term: 'Term B', match: 'Definition 2' },
                        { term: 'Term C', match: 'Definition 3' },
                        { term: 'Term D', match: 'Definition 4' }
                    ];
                    question.explanation = 'This is a sample explanation for this matching question.';
                    break;
                    
                case 'shortAnswer':
                    question.modelAnswer = 'This is a sample model answer for this short answer question.';
                    question.explanation = 'Additional notes on the answer.';
                    break;
                    
                case 'clinicalCase':
                    question.text = `Clinical Case: A 65-year-old patient presents with ${focusArea} symptoms including...`;
                    question.additionalInfo = 'Patient history: Hypertension, Type 2 Diabetes for 10 years.';
                    question.options = [
                        'Diagnosis A',
                        'Diagnosis B',
                        'Diagnosis C',
                        'Diagnosis D'
                    ];
                    question.correctAnswer = 'Diagnosis B';
                    question.explanation = 'This is the clinical reasoning behind the diagnosis.';
                    break;
                    
                case 'differential':
                    question.text = `Create a differential diagnosis for a patient with the following ${focusArea} findings...`;
                    question.options = [
                        'Condition A',
                        'Condition B',
                        'Condition C',
                        'Condition D'
                    ];
                    question.multiSelect = true;
                    question.correctAnswer = 'Conditions A, C, and D';
                    question.modelAnswer = 'The differential diagnosis should include...';
                    question.explanation = 'This is the reasoning for the differential diagnosis.';
                    break;
            }
            
            questions.push(question);
        }
        
        // Display generated questions
        setTimeout(() => {
            setLoadingState(false);
            displayQuestions(questions);
            showStatusMessage('Questions generated successfully!', 'success');
        }, 500);
    };
    
    /**
     * Public methods
     */
    return {
        init: () => {
            initialize();
            initializeFileDropArea();
            setupEventListeners();
            handleInputTypeChange(); // Set initial view
            showStatusMessage('Welcome to OphthalmoQA! Ready to generate ophthalmology questions.', 'info');
        }
    };
})();

// Initialize UI Manager when DOM is ready
document.addEventListener('DOMContentLoaded', UIManager.init);
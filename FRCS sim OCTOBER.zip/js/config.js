// Configuration for OphthalmoQA
window.CONFIG = {
    // Default AI model for the application
    DEFAULT_MODEL: 'gemini',
    
    // API Keys
    API_KEYS: {
        GEMINI: "AIzaSyB12UIbBNqdSEvXgy03bzNQ2yr5OvUTeRs",
        GEMINI_FAILOVER: [
            "AIzaSyB12UIbBNqdSEvXgy03bzNQ2yr5OvUTeRs",
            "AIzaSyDdryTJj5WDEY05hYa9scHkE4zG59zlxXM",
            "AIzaSyAfComr98Dt9Ms2UhkGL1wXUMYkfcbxBWw",
            "AIzaSyAq7e5_hqgt6NwoTrZd1yQuJQ74WVeUwMc",
            "AIzaSyBcF7MTCw08shbQGgA5IA2phT0ZSOyvBLE"
        ],
        NCBI: "9bf2be2683f9a133cad29bc4891684364e08",
        OPENAI: "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",
        CLAUDE: "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",
        // Cursor AI uses user credentials
    },
    
    // API Endpoints
    API_ENDPOINTS: {
        GEMINI: "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent",
        NCBI_ESEARCH: "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        NCBI_EFETCH: "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi",
        NCBI_ESUMMARY: "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
        OPENAI: "https://api.openai.com/v1/chat/completions",
        CLAUDE: "https://api.anthropic.com/v1/messages",
        CURSOR_AI: "https://cursor.sh/api/chat", // Using Cursor AI API endpoint
        BIOMISTRAL: "http://localhost:8000/completion", // BioMistral local API endpoint
        BIOGPT: "http://localhost:8001/completion", // BioGPT local API endpoint
    },
    
    // API Quota settings
    API_QUOTA: {
        // Default quota limits
        OPENAI: {
            DEFAULT_QUOTA: 10,      // Free users get 10 API calls
            PREMIUM_QUOTA: 50,     // Premium users get 50 API calls
            QUOTA_RESET_ON_LOGIN: true,  // Reset quota on each login
            QUOTA_STORAGE_KEY: 'ophthalmoqa_openai_quota'
        },
        GEMINI: {
            DEFAULT_QUOTA: 20,      // Free users get 20 API calls
            PREMIUM_QUOTA: 100,     // Premium users get 100 API calls
            QUOTA_RESET_ON_LOGIN: true,
            QUOTA_STORAGE_KEY: 'ophthalmoqa_gemini_quota'
        },
        CLAUDE: {
            DEFAULT_QUOTA: 15,      // Free users get 15 API calls
            PREMIUM_QUOTA: 75,     // Premium users get 75 API calls
            QUOTA_RESET_ON_LOGIN: true,
            QUOTA_STORAGE_KEY: 'ophthalmoqa_claude_quota'
        },
        CURSOR_AI: {
            DEFAULT_QUOTA: 10,      // Free users get 10 API calls
            PREMIUM_QUOTA: 60,     // Premium users get 60 API calls
            QUOTA_RESET_ON_LOGIN: true,
            QUOTA_STORAGE_KEY: 'ophthalmoqa_cursor_quota'
        },
        BIOMISTRAL: {
            DEFAULT_QUOTA: 25,      // Free users get 25 API calls (local model)
            PREMIUM_QUOTA: 100,     // Premium users get 100 API calls
            QUOTA_RESET_ON_LOGIN: true,
            QUOTA_STORAGE_KEY: 'ophthalmoqa_biomistral_quota'
        },
        BIOGPT: {
            DEFAULT_QUOTA: 25,      // Free users get 25 API calls (local model)
            PREMIUM_QUOTA: 100,     // Premium users get 100 API calls
            QUOTA_RESET_ON_LOGIN: true,
            QUOTA_STORAGE_KEY: 'ophthalmoqa_biogpt_quota'
        }
    },
    
    // Model configurations
    MODELS: {
        // Default model settings for different question types
        DEFAULT: {
            temperature: 0.7,
            maxOutputTokens: 2048,
            topK: 40,
            topP: 0.95
        },
        MEDICAL_QA: {
            temperature: 0.4, // Lower temperature for more deterministic medical content
            maxOutputTokens: 4096,
            topK: 40,
            topP: 0.85
        },
        OPENAI: {
            model: "gpt-4o",
            temperature: 0.3,
            max_tokens: 3000,
            top_p: 0.9
        },
        CLAUDE: {
            model: "claude-3-sonnet-20240229",
            temperature: 0.2,
            max_tokens: 4000,
            top_p: 0.95
        },
        CURSOR_AI: {
            model: "claude-3-opus-20240229", // Uses Cursor AI premium models
            temperature: 0.2,
            max_tokens: 4000
        },
        BIOMISTRAL: {
            model: "mistral-7b-medical",
            temperature: 0.3,
            max_tokens: 3000,
            top_p: 0.9
        },
        BIOGPT: {
            model: "biogpt-large",
            temperature: 0.3,
            max_tokens: 3000,
            top_p: 0.9
        }
    },
    
    // PDF Parsing Settings
    PDF_PARSER: {
        CHUNK_SIZE: 5000, // Character count per chunk
        MAX_PAGES: 2000,  // Maximum pages to process - increased from 50 to 2000 to accommodate large PDFs
        OVERLAP: 500,   // Character overlap between chunks
    },
    
    // Subspecialty-specific knowledge enhancement
    MEDICAL_SUBSPECIALTIES: {
        "retinal-disorders": [
            "retinal detachment", "macular degeneration", "diabetic retinopathy",
            "retinal vein occlusion", "retinitis pigmentosa", "vitreous hemorrhage"
        ],
        "corneal-diseases": [
            "keratoconus", "corneal ulcer", "fuchs dystrophy", "keratitis",
            "corneal abrasion", "corneal transplant"
        ],
        "glaucoma": [
            "open-angle glaucoma", "angle-closure glaucoma", "normal-tension glaucoma",
            "ocular hypertension", "congenital glaucoma", "glaucoma surgery"
        ],
        "cataract": [
            "phacoemulsification", "intraocular lens", "posterior capsule opacification",
            "congenital cataract", "cataract surgery complications", "lens dislocation"
        ],
        "refractive-errors": [
            "myopia", "hyperopia", "astigmatism", "presbyopia",
            "refractive surgery", "LASIK", "PRK", "wavefront"
        ],
        "neuro-ophthalmology": [
            "optic neuritis", "papilledema", "nystagmus", "diplopia",
            "visual field defects", "cranial nerve palsies", "optic neuropathy"
        ],
        "ocular-inflammation": [
            "uveitis", "scleritis", "episcleritis", "iritis",
            "choroiditis", "pars planitis", "immunosuppressive therapy"
        ],
        "pediatric": [
            "strabismus", "amblyopia", "retinopathy of prematurity",
            "pediatric cataract", "congenital glaucoma", "nasolacrimal duct obstruction"
        ],
        "oculoplastics-oncology": [
            "ptosis", "blepharoplasty", "ectropion", "entropion",
            "orbital tumors", "ocular melanoma", "eyelid reconstruction"
        ],
        // Added for FRCS Ophthalmology Part 3 focus
        "general-medicine-emergency": [
            // Emergency ophthalmology scenarios
            "acute angle-closure glaucoma", "chemical eye injury", "ocular trauma",
            "open globe injury", "corneal foreign body", "endophthalmitis",
            "central retinal artery occlusion", "retinal artery occlusion",
            "central retinal vein occlusion", "orbital cellulitis", "preseptal cellulitis",
            "herpes zoster ophthalmicus", "sudden vision loss", "amaurosis fugax",
            "temporal arteritis", "giant cell arteritis",
            // General medicine interfaces with ophthalmology
            "thyroid eye disease", "diabetic retinopathy screening",
            "hypertensive retinopathy", "sarcoidosis uveitis", "tb uveitis",
            "syphilitic uveitis", "hiv retinopathy", "cmv retinitis",
            // ER triage and red flags
            "painful red eye", "photophobia", "flashes and floaters",
            "headache with visual symptoms", "pupil abnormalities",
            // Imaging and initial management
            "lateral canthotomy", "intravitreal antibiotics", "IV acetazolamide",
            "IV methylprednisolone", "temporal artery biopsy",
            // Medications and systemic considerations
            "anticoagulation and eye surgery", "steroids and IOP",
            "beta-blocker eye drops systemic effects"
        ]
    },
    
    // Premium features configuration - available after donation
    PREMIUM_FEATURES: {
        // Enhanced question banks for each subspecialty
        QUESTION_BANKS: {
            "retinal-disorders": {
                name: "Advanced Retinal Disorders Question Bank",
                questionCount: 200,
                categories: ["Medical Retina", "Surgical Retina", "Vitreous"]
            },
            "glaucoma": {
                name: "Comprehensive Glaucoma Question Bank",
                questionCount: 150,
                categories: ["Open-Angle", "Angle-Closure", "Secondary Glaucomas"]
            },
            "cataract": {
                name: "Cataract Surgery Excellence Question Bank",
                questionCount: 180,
                categories: ["Preoperative", "Intraoperative", "Postoperative"]
            },
            "board-review": {
                name: "Ophthalmology Board Review Question Bank",
                questionCount: 500,
                categories: ["Written Exam", "Clinical Skills", "Oral Examination"]
            }
        },
        
        // Enhanced explanation detail level
        EXPLANATION_DETAIL: {
            standard: "Basic pathophysiology and standard management",
            enhanced: "Detailed pathophysiology, evidence-based management, and recent research findings"
        }
    },
    
    // Donation configuration
    DONATION: {
        AMOUNT: "$20",
        PAYPAL_ACCOUNT: "docms90",
        PAYPAL_LINK: "https://www.paypal.com/paypalme/docms90/20"
    },
    
    // Use 'debug: true' only during development
    DEBUG: false
};
// Also expose as a global identifier for existing code paths
// Using var to create a global binding accessible across scripts
// eslint-disable-next-line no-var
var CONFIG = window.CONFIG;
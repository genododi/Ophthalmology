const fs = require('fs');
const path = require('path');

// Path to the file
const filePath = path.join(__dirname, 'js', 'QuestionGenerator.js');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Find the first instance of the focus keywords section (which is the wrong implementation)
const startPattern = `            // For uploaded documents, strictly focus on the provided additional focus keywords if available
            if (this.lastSettings.inputType === 'upload' && this.lastSettings.focusArea && this.lastSettings.focusArea.trim()) {
                const focusKeywords = this.lastSettings.focusArea.trim().toLowerCase().split(/[ ,;]+/);`;

const endPattern = `                console.log(\`Warning: No questions found containing the focus keywords. Using all questions.\`);
                }
            }`;

// Get the full pattern to replace
const fullPattern = content.substring(
    content.indexOf(startPattern),
    content.indexOf(endPattern) + endPattern.length
);

// Remove the wrong implementation
if (content.includes(fullPattern)) {
    content = content.replace(fullPattern, '');
    
    // Write the updated file
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('Successfully removed the duplicate code section.');
} else {
    console.log('Could not find the duplicate code section to remove.');
}

// Also fix the indentation of the correct implementation
const correctStartPattern = `                        // For uploaded documents, strictly focus on the provided additional focus keywords if available`;
const correctEndPattern = `                console.log(\`Added strict focus on keywords: "\${focusKeywords}" for uploaded document\`);
            }`;

if (content.includes(correctStartPattern)) {
    // Fix indentation of the correct implementation
    const correctFullPattern = content.substring(
        content.indexOf(correctStartPattern),
        content.indexOf(correctEndPattern) + correctEndPattern.length
    );
    
    // Create a properly indented version
    const fixedPattern = correctFullPattern.replace(/^ {24}/gm, '            ');
    
    // Replace with the fixed version
    content = content.replace(correctFullPattern, fixedPattern);
    
    // Write the updated file
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('Successfully fixed indentation of the correct implementation.');
} else {
    console.log('Could not find the correct implementation to fix indentation.');
}

// Also fix the indentation of the Call Gemini API line
const apiCallPattern = `// Call the Gemini API with enhanced prompt`;
if (content.includes(apiCallPattern)) {
    content = content.replace(apiCallPattern, `            // Call the Gemini API with enhanced prompt`);
    
    // Write the updated file
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('Successfully fixed indentation of the API call line.');
} else {
    console.log('Could not find the API call line to fix indentation.');
}

console.log('All fixes completed!'); 
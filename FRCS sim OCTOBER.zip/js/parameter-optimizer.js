/**
 * Parameter Optimizer for OphthalmoQA
 * 
 * This module provides an intelligent parameter optimization system that:
 * 1. Learns from feedback on generated questions
 * 2. Analyzes repetition patterns to improve diversity
 * 3. Suggests optimal parameters based on historical performance
 * 4. Automatically adjusts generation parameters to maximize quality
 */

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    initParameterOptimizer();
});

// Global state for parameter optimization
const parameterState = {
    optimizedParameters: null,  // Current optimized parameters
    parameterHistory: [],       // History of used parameter sets
    performanceMetrics: {},     // Performance metrics for different parameter combinations
    activeLearning: false,      // Whether active learning mode is enabled
    autoOptimize: false,        // Whether to auto-apply optimizations
    repetitionAvoidance: {      // Settings for avoiding repetition
        activeTopics: [],           // Topics to avoid due to repetition
        activeQuestionTypes: [],    // Question types to avoid due to repetition
        diversityScore: 0           // Current diversity score (0-1)
    }
};

/**
 * Initialize the parameter optimizer
 */
function initParameterOptimizer() {
    // Load state from localStorage
    loadOptimizerState();
    
    // Setup event listeners
    setupOptimizerEventListeners();
    
    // Initialize integration with feedback system
    initFeedbackLoopIntegration();
    
    // Initialize repetition detection integration
    initRepetitionDetectionIntegration();
    
    console.log('Parameter Optimizer initialized');
}

/**
 * Setup event listeners for parameter optimization
 */
function setupOptimizerEventListeners() {
    // Listen for optimization button click
    document.getElementById('optimize-parameters-btn')?.addEventListener('click', optimizeParameters);
    
    // Listen for generation events
    document.getElementById('generate-btn')?.addEventListener('click', captureGenerationEvent);
    document.getElementById('regenerate-btn')?.addEventListener('click', captureGenerationEvent);
    
    // Listen for manual parameter changes (debounced)
    setupParameterChangeListeners();
    
    // Add recommended parameters button to analytics modal
    addRecommendedParametersButton();
    
    // Setup auto-optimization toggle if available
    document.getElementById('auto-optimize-toggle')?.addEventListener('change', function() {
        parameterState.autoOptimize = this.checked;
        saveOptimizerState();
        
        // Show confirmation
        if (this.checked) {
            showStatusMessage('Auto-optimization enabled. Parameters will be automatically adjusted based on feedback.', 'success');
        }
    });
}

/**
 * Setup listeners for parameter changes
 */
function setupParameterChangeListeners() {
    // Get all parameter input elements
    const parameterInputs = [
        document.getElementById('difficulty'),
        document.getElementById('num-questions'),
        document.getElementById('ai-model'),
        document.getElementById('knowledge-area'),
        document.getElementById('focus-area')
    ];
    
    // Listen for changes to question type checkboxes
    const questionTypeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ].map(id => document.getElementById(id));
    
    // Debounce function to avoid excessive processing
    let debounceTimer;
    const debouncedUpdate = () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            analyzeCurrentParameters();
        }, 500);
    };
    
    // Add listeners to all inputs
    parameterInputs.forEach(input => {
        if (input) {
            input.addEventListener('change', debouncedUpdate);
        }
    });
    
    // Add listeners to question type checkboxes
    questionTypeCheckboxes.forEach(checkbox => {
        if (checkbox) {
            checkbox.addEventListener('change', debouncedUpdate);
        }
    });
}

/**
 * Add recommended parameters button to analytics modal
 */
function addRecommendedParametersButton() {
    // Check if button already exists
    if (document.getElementById('apply-recommendations-btn')) {
        // Add click handler to existing button
        document.getElementById('apply-recommendations-btn').addEventListener('click', () => {
            applyRecommendedParameters();
            
            // Close the analytics modal
            document.getElementById('close-feedback-analytics-modal')?.click();
        });
    }
}

/**
 * Initialize integration with the feedback loop system
 */
function initFeedbackLoopIntegration() {
    // Listen for feedback submission events
    document.addEventListener('feedback:submitted', (event) => {
        // Process the feedback to update parameter performance
        processFeedbackForOptimization(event.detail);
    });
}

/**
 * Initialize integration with repetition detection
 */
function initRepetitionDetectionIntegration() {
    // Listen for repeated question events
    document.addEventListener('question:repeated', (event) => {
        // Process repetition data to improve diversity
        processRepetitionData(event.detail);
    });
}

/**
 * Handle generation event
 */
function captureGenerationEvent() {
    // Get current parameters
    const currentParams = getCurrentParameters();
    
    // Store in history
    parameterState.parameterHistory.push({
        ...currentParams,
        timestamp: Date.now()
    });
    
    // Limit history size
    if (parameterState.parameterHistory.length > 50) {
        parameterState.parameterHistory = parameterState.parameterHistory.slice(-50);
    }
    
    // Save state
    saveOptimizerState();
    
    // If auto-optimize is enabled, apply optimizations
    if (parameterState.autoOptimize && parameterState.optimizedParameters) {
        // But only if we're not already using optimized parameters
        if (!isUsingOptimizedParameters()) {
            console.log('Auto-applying optimized parameters');
            applyOptimizedParameters();
        }
    }
}

/**
 * Process feedback for parameter optimization
 */
function processFeedbackForOptimization(feedback) {
    // Get the parameters used to generate the question
    const params = feedback.generationParameters;
    if (!params) return;
    
    // Create parameter key for storing metrics
    const paramKey = createParameterKey(params);
    
    // Initialize performance metrics for this parameter set if needed
    if (!parameterState.performanceMetrics[paramKey]) {
        parameterState.performanceMetrics[paramKey] = {
            parameters: params,
            usageCount: 0,
            feedbackCount: 0,
            positiveCount: 0,
            negativeCount: 0,
            metrics: {
                relevance: 0,
                accuracy: 0,
                clarity: 0,
                difficulty: 0
            },
            repetitionRate: 0,
            lastUsed: Date.now()
        };
    }
    
    // Update metrics
    const metrics = parameterState.performanceMetrics[paramKey];
    metrics.feedbackCount++;
    metrics.lastUsed = Date.now();
    
    // Update positive/negative counts
    if (feedback.rating === 'positive') {
        metrics.positiveCount++;
    } else if (feedback.rating === 'negative') {
        metrics.negativeCount++;
    }
    
    // Update specific metrics if available
    if (feedback.metrics) {
        for (const [key, value] of Object.entries(feedback.metrics)) {
            if (metrics.metrics[key] !== undefined) {
                // Weighted moving average
                metrics.metrics[key] = 
                    (metrics.metrics[key] * (metrics.feedbackCount - 1) + value) / 
                    metrics.feedbackCount;
            }
        }
    }
    
    // Save updated state
    saveOptimizerState();
    
    // Run optimization if we have enough data
    if (parameterState.autoOptimize && Object.keys(parameterState.performanceMetrics).length >= 2) {
        optimizeParameters();
    }
}

/**
 * Process repetition data to improve diversity
 */
function processRepetitionData(repetitionData) {
    const { question, similarityScore } = repetitionData;
    
    // Extract topic and question type
    const topic = question.topic || 'unknown';
    const questionType = question.type || 'unknown';
    
    // Add to active topics to avoid if not already there
    if (!parameterState.repetitionAvoidance.activeTopics.includes(topic) && 
        similarityScore > 0.85) { // Only add if very similar
        parameterState.repetitionAvoidance.activeTopics.push(topic);
        
        // Limit list size
        if (parameterState.repetitionAvoidance.activeTopics.length > 3) {
            parameterState.repetitionAvoidance.activeTopics.shift();
        }
    }
    
    // Add to active question types to avoid if not already there
    if (!parameterState.repetitionAvoidance.activeQuestionTypes.includes(questionType) &&
        similarityScore > 0.85) {
        parameterState.repetitionAvoidance.activeQuestionTypes.push(questionType);
        
        // Limit list size
        if (parameterState.repetitionAvoidance.activeQuestionTypes.length > 2) {
            parameterState.repetitionAvoidance.activeQuestionTypes.shift();
        }
    }
    
    // Update diversity score
    updateDiversityScore();
    
    // Save state
    saveOptimizerState();
    
    // If auto-optimize enabled and diversity score is low, optimize
    if (parameterState.autoOptimize && parameterState.repetitionAvoidance.diversityScore < 0.4) {
        optimizeParameters();
    }
}

/**
 * Update diversity score based on repetition avoidance data
 */
function updateDiversityScore() {
    // Calculate score based on:
    // 1. Number of active topics to avoid
    // 2. Number of active question types to avoid
    // 3. Parameter variation in recent history
    
    // Start with a base score
    let score = 1.0;
    
    // Reduce score for each active topic to avoid
    score -= parameterState.repetitionAvoidance.activeTopics.length * 0.15;
    
    // Reduce score for each active question type to avoid
    score -= parameterState.repetitionAvoidance.activeQuestionTypes.length * 0.15;
    
    // Analyze parameter variation in recent history (last 5 generations)
    const recentHistory = parameterState.parameterHistory.slice(-5);
    if (recentHistory.length >= 3) {
        // Check how many different question types were used
        const uniqueQuestionTypes = new Set();
        recentHistory.forEach(params => {
            params.questionTypes?.forEach(type => uniqueQuestionTypes.add(type));
        });
        
        // Check how many different difficulty levels were used
        const uniqueDifficulties = new Set(recentHistory.map(p => p.difficulty));
        
        // Check how many different knowledge areas were used
        const uniqueKnowledgeAreas = new Set(recentHistory.map(p => p.knowledgeArea));
        
        // Calculate parameter variation score
        const variationScore = 
            (uniqueQuestionTypes.size / 5) * 0.5 + // Max 5 different types
            (uniqueDifficulties.size / 2) * 0.25 + // Max 2 different difficulties
            (uniqueKnowledgeAreas.size / 2) * 0.25; // Max 2 different areas
        
        // Adjust score based on variation (more variation = higher diversity)
        score += variationScore * 0.3; // Boost score by up to 0.3
    }
    
    // Clamp between 0 and 1
    score = Math.max(0, Math.min(1, score));
    
    // Update state
    parameterState.repetitionAvoidance.diversityScore = score;
    
    return score;
}

/**
 * Create a unique key for parameter combinations
 */
function createParameterKey(params) {
    // Create a consistent key from the main parameters
    return `${params.difficulty}_${params.knowledgeArea}_${params.aiModel}_${params.questionTypes?.sort().join('_')}`;
}

/**
 * Get current parameters from the UI
 */
function getCurrentParameters() {
    // Get values from form elements
    const difficulty = document.getElementById('difficulty')?.value;
    const numQuestions = parseInt(document.getElementById('num-questions')?.value || '10');
    const aiModel = document.getElementById('ai-model')?.value;
    const knowledgeArea = document.getElementById('knowledge-area')?.value;
    const focusKeywords = document.getElementById('focus-area')?.value;
    const showAnswers = document.getElementById('show-answers-default')?.checked;
    
    // Get selected question types
    const questionTypes = [];
    [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ].forEach(id => {
        const checkbox = document.getElementById(id);
        if (checkbox?.checked) {
            questionTypes.push(id.replace('type-', ''));
        }
    });
    
    return {
        difficulty,
        numQuestions,
        aiModel,
        knowledgeArea,
        focusKeywords,
        showAnswers,
        questionTypes,
        timestamp: Date.now()
    };
}

/**
 * Optimize parameters based on:
 * 1. Feedback history
 * 2. Repetition detection
 * 3. Current parameter performance
 */
function optimizeParameters() {
    console.log('Optimizing parameters...');
    
    // Start with the best parameter set from feedback data
    let optimizedParams = findBestPerformingParameters();
    
    // If no best parameters found, use current parameters
    if (!optimizedParams) {
        optimizedParams = getCurrentParameters();
    }
    
    // Apply repetition avoidance adjustments
    optimizedParams = applyRepetitionAvoidanceAdjustments(optimizedParams);
    
    // Apply diversity adjustments if diversity score is low
    if (parameterState.repetitionAvoidance.diversityScore < 0.5) {
        optimizedParams = applyDiversityAdjustments(optimizedParams);
    }
    
    // Store the optimized parameters
    parameterState.optimizedParameters = optimizedParams;
    
    // Save state
    saveOptimizerState();
    
    // Log the optimized parameters
    console.log('Optimized parameters:', optimizedParams);
    
    // Auto-apply if enabled
    if (parameterState.autoOptimize) {
        applyOptimizedParameters();
    }
    
    // Return the optimized parameters
    return optimizedParams;
}

/**
 * Find the best performing parameter set based on feedback
 */
function findBestPerformingParameters() {
    // Skip if we don't have enough data
    if (Object.keys(parameterState.performanceMetrics).length < 2) {
        return null;
    }
    
    // Calculate overall scores for each parameter set
    const scoredParams = Object.values(parameterState.performanceMetrics)
        .filter(metrics => metrics.feedbackCount >= 2) // Need enough feedback
        .map(metrics => ({
            parameters: metrics.parameters,
            score: calculateOverallScore(metrics),
            metrics: metrics,
            lastUsed: metrics.lastUsed
        }))
        .sort((a, b) => b.score - a.score); // Sort by score descending
    
    // Return the best parameter set if available
    return scoredParams.length > 0 ? scoredParams[0].parameters : null;
}

/**
 * Calculate an overall score for a parameter set
 */
function calculateOverallScore(metrics) {
    // Base score from positive feedback percentage
    const positiveFeedbackRate = metrics.feedbackCount > 0 ? 
        metrics.positiveCount / metrics.feedbackCount : 0;
    
    // Individual metric scores (normalize to 0-1)
    const relevanceScore = metrics.metrics.relevance || 0;
    const accuracyScore = metrics.metrics.accuracy || 0;
    const clarityScore = metrics.metrics.clarity || 0;
    const difficultyScore = metrics.metrics.difficulty || 0;
    
    // Calculate weighted score
    const weightedScore = 
        (positiveFeedbackRate * 0.4) + 
        (relevanceScore * 0.2) + 
        (accuracyScore * 0.2) + 
        (clarityScore * 0.1) + 
        (difficultyScore * 0.1);
    
    // Penalty for high repetition rate
    const repetitionPenalty = metrics.repetitionRate * 0.3;
    
    // Final score (0-10 scale)
    return (weightedScore * 10) - repetitionPenalty;
}

/**
 * Apply repetition avoidance adjustments to parameters
 */
function applyRepetitionAvoidanceAdjustments(params) {
    // Create a copy of the parameters
    const adjustedParams = { ...params };
    
    // Avoid topics with high repetition
    if (parameterState.repetitionAvoidance.activeTopics.length > 0) {
        const topicToAvoid = parameterState.repetitionAvoidance.activeTopics[0];
        
        // Suggest a different knowledge area if the current one is causing repetition
        if (topicToAvoid === adjustedParams.knowledgeArea) {
            // Find a different knowledge area that doesn't match any active topic
            const knowledgeSelect = document.getElementById('knowledge-area');
            if (knowledgeSelect) {
                const options = Array.from(knowledgeSelect.options)
                    .map(option => option.value)
                    .filter(value => !parameterState.repetitionAvoidance.activeTopics.includes(value));
                
                if (options.length > 0) {
                    // Choose a random alternative
                    adjustedParams.knowledgeArea = options[Math.floor(Math.random() * options.length)];
                }
            }
        }
    }
    
    // Avoid question types with high repetition
    if (parameterState.repetitionAvoidance.activeQuestionTypes.length > 0) {
        // Filter out question types to avoid
        adjustedParams.questionTypes = (adjustedParams.questionTypes || [])
            .filter(type => !parameterState.repetitionAvoidance.activeQuestionTypes.includes(type));
        
        // Ensure we have at least some question types enabled
        if (adjustedParams.questionTypes.length < 2) {
            // Add some default types
            const defaultTypes = ['mcq', 'short-answer', 'clinical-case'];
            defaultTypes.forEach(type => {
                if (!adjustedParams.questionTypes.includes(type) && 
                    !parameterState.repetitionAvoidance.activeQuestionTypes.includes(type)) {
                    adjustedParams.questionTypes.push(type);
                }
            });
        }
    }
    
    return adjustedParams;
}

/**
 * Apply diversity adjustments to parameters
 */
function applyDiversityAdjustments(params) {
    // Create a copy of the parameters
    const adjustedParams = { ...params };
    
    // Analyze recent parameter history to increase diversity
    const recentHistory = parameterState.parameterHistory.slice(-3);
    
    if (recentHistory.length > 0) {
        // Check if difficulty has been the same in recent generations
        const recentDifficulties = new Set(recentHistory.map(p => p.difficulty));
        if (recentDifficulties.size === 1 && recentHistory[0].difficulty === adjustedParams.difficulty) {
            // Change difficulty - get available options
            const difficultySelect = document.getElementById('difficulty');
            if (difficultySelect) {
                const options = Array.from(difficultySelect.options)
                    .map(option => option.value)
                    .filter(value => value !== adjustedParams.difficulty);
                
                if (options.length > 0) {
                    // Choose a random alternative
                    adjustedParams.difficulty = options[Math.floor(Math.random() * options.length)];
                }
            }
        }
        
        // Check for question type diversity
        const recentTypeUsage = {};
        recentHistory.forEach(params => {
            params.questionTypes?.forEach(type => {
                recentTypeUsage[type] = (recentTypeUsage[type] || 0) + 1;
            });
        });
        
        // Find overused types (used in all recent generations)
        const overusedTypes = Object.entries(recentTypeUsage)
            .filter(([type, count]) => count === recentHistory.length)
            .map(([type]) => type);
        
        if (overusedTypes.length > 0) {
            // Remove one overused type and add a different type
            const typeToReplace = overusedTypes[Math.floor(Math.random() * overusedTypes.length)];
            const indexToRemove = adjustedParams.questionTypes.indexOf(typeToReplace);
            
            if (indexToRemove !== -1) {
                // Remove the overused type
                adjustedParams.questionTypes.splice(indexToRemove, 1);
                
                // Find alternative types not recently used
                const allTypes = ['mcq', 'tf', 'matching', 'short-answer', 'clinical-case', 
                                 'differential', 'management', 'viva', 'osce'];
                const unusedTypes = allTypes.filter(type => !recentTypeUsage[type]);
                
                if (unusedTypes.length > 0) {
                    // Add a type that hasn't been used recently
                    adjustedParams.questionTypes.push(unusedTypes[Math.floor(Math.random() * unusedTypes.length)]);
                }
            }
        }
    }
    
    return adjustedParams;
}

/**
 * Apply the optimized parameters to the UI
 */
function applyOptimizedParameters() {
    const params = parameterState.optimizedParameters;
    if (!params) {
        console.log('No optimized parameters available');
        return;
    }
    
    console.log('Applying optimized parameters:', params);
    
    // Apply difficulty
    const difficultySelect = document.getElementById('difficulty');
    if (difficultySelect && params.difficulty) {
        difficultySelect.value = params.difficulty;
    }
    
    // Apply knowledge area
    const knowledgeSelect = document.getElementById('knowledge-area');
    if (knowledgeSelect && params.knowledgeArea) {
        knowledgeSelect.value = params.knowledgeArea;
    }
    
    // Apply AI model
    const modelSelect = document.getElementById('ai-model');
    if (modelSelect && params.aiModel) {
        modelSelect.value = params.aiModel;
    }
    
    // Apply question types
    if (params.questionTypes && params.questionTypes.length) {
        // First uncheck all
        const typeCheckboxes = [
            'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
            'type-clinical-case', 'type-differential', 'type-management',
            'type-viva', 'type-osce'
        ];
        
        typeCheckboxes.forEach(id => {
            const checkbox = document.getElementById(id);
            if (checkbox) {
                checkbox.checked = false;
            }
        });
        
        // Then check recommended types
        params.questionTypes.forEach(type => {
            const checkbox = document.getElementById(`type-${type}`);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
        
        // Update "Select All" checkbox state if needed
        updateSelectAllCheckboxState();
    }
    
    // Show success message
    showStatusMessage('Parameters optimized based on feedback and repetition analysis', 'success');
}

/**
 * Update "Select All" checkbox state based on individual checkboxes
 */
function updateSelectAllCheckboxState() {
    const typeAllCheckbox = document.getElementById('type-all');
    if (!typeAllCheckbox) return;
    
    const questionTypeCheckboxes = [
        'type-mcq', 'type-tf', 'type-matching', 'type-short-answer',
        'type-clinical-case', 'type-differential', 'type-management',
        'type-viva', 'type-osce'
    ].map(id => document.getElementById(id));
    
    const allChecked = questionTypeCheckboxes.every(cb => cb && cb.checked);
    const someChecked = questionTypeCheckboxes.some(cb => cb && cb.checked);
    
    typeAllCheckbox.checked = allChecked;
    typeAllCheckbox.indeterminate = someChecked && !allChecked;
}

/**
 * Apply recommended parameters from feedback system
 */
function applyRecommendedParameters() {
    // Check if we have a FeedbackLoop system with recommendations
    if (window.FeedbackLoop && window.FeedbackLoop.getRecommendedParameters) {
        const recommendations = window.FeedbackLoop.getRecommendedParameters();
        if (recommendations) {
            console.log('Applying recommended parameters from feedback system:', recommendations);
            
            // Create parameters object
            const params = {
                difficulty: recommendations.difficulty,
                questionTypes: recommendations.questionTypes,
                aiModel: recommendations.model
            };
            
            // Store as optimized parameters
            parameterState.optimizedParameters = {
                ...getCurrentParameters(),
                ...params
            };
            
            // Apply the parameters
            applyOptimizedParameters();
            
            // Return true to indicate success
            return true;
        }
    }
    
    // No recommendations available
    return false;
}

/**
 * Check if currently using the optimized parameters
 */
function isUsingOptimizedParameters() {
    const optimized = parameterState.optimizedParameters;
    if (!optimized) return false;
    
    // Get current parameters
    const current = getCurrentParameters();
    
    // Compare key parameters
    const isSameDifficulty = optimized.difficulty === current.difficulty;
    const isSameKnowledgeArea = optimized.knowledgeArea === current.knowledgeArea;
    
    // Compare question types (order doesn't matter)
    const optimizedTypes = new Set(optimized.questionTypes || []);
    const currentTypes = new Set(current.questionTypes || []);
    const isSameTypes = 
        optimizedTypes.size === currentTypes.size && 
        [...optimizedTypes].every(type => currentTypes.has(type));
    
    // Consider it the same if difficulty and question types match
    return isSameDifficulty && isSameTypes;
}

/**
 * Analyze the current parameter settings
 */
function analyzeCurrentParameters() {
    // Get current parameters
    const currentParams = getCurrentParameters();
    
    // Look up performance metrics for these parameters
    const paramKey = createParameterKey(currentParams);
    const metrics = parameterState.performanceMetrics[paramKey];
    
    console.log('Analyzing current parameters', currentParams);
    
    if (metrics) {
        console.log('Performance metrics found:', metrics);
        
        // Calculate overall score
        const score = calculateOverallScore(metrics);
        
        // Check if optimized parameters would be better
        if (parameterState.optimizedParameters) {
            const optimizedKey = createParameterKey(parameterState.optimizedParameters);
            const optimizedMetrics = parameterState.performanceMetrics[optimizedKey];
            
            if (optimizedMetrics) {
                const optimizedScore = calculateOverallScore(optimizedMetrics);
                
                // If optimized score is significantly better, suggest switching
                if (optimizedScore > score + 1.5) {
                    console.log('Optimized parameters would perform better');
                    
                    // If auto-optimize is enabled, switch automatically
                    if (parameterState.autoOptimize) {
                        applyOptimizedParameters();
                    }
                    // Otherwise, show suggestion
                    else {
                        suggestParameterOptimization(score, optimizedScore);
                    }
                }
            }
        }
        
        // Update usage count
        metrics.usageCount++;
        saveOptimizerState();
    }
}

/**
 * Suggest parameter optimization to the user
 */
function suggestParameterOptimization(currentScore, optimizedScore) {
    // Only show suggestion if we have a significant improvement
    const improvement = Math.round((optimizedScore - currentScore) * 10) / 10;
    
    if (improvement >= 1.5) {
        // Create optimization suggestion element
        const existingMsg = document.querySelector('.optimization-suggestion');
        if (existingMsg) existingMsg.remove();
        
        const suggestionEl = document.createElement('div');
        suggestionEl.className = 'optimization-suggestion fixed top-4 right-4 bg-blue-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-md transition-all duration-300 transform translate-x-0';
        suggestionEl.innerHTML = `
            <div class="flex justify-between items-center mb-2">
                <h4 class="font-semibold">Parameter Optimization Available</h4>
                <button class="text-white hover:text-blue-200 dismiss-btn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <p class="mb-2">Optimized parameters available that could improve question quality by ${improvement.toFixed(1)} points.</p>
            <div class="flex space-x-3 mt-3">
                <button class="apply-btn flex-1 bg-white text-blue-600 hover:bg-blue-100 font-medium py-1.5 px-3 rounded transition">
                    Apply Now
                </button>
                <button class="dismiss-btn flex-1 bg-blue-500 hover:bg-blue-700 text-white font-medium py-1.5 px-3 rounded transition">
                    Dismiss
                </button>
            </div>
        `;
        
        // Add to body
        document.body.appendChild(suggestionEl);
        
        // Add event listeners
        suggestionEl.querySelector('.apply-btn').addEventListener('click', () => {
            applyOptimizedParameters();
            suggestionEl.remove();
        });
        
        suggestionEl.querySelectorAll('.dismiss-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                suggestionEl.remove();
            });
        });
        
        // Automatically remove after 10 seconds
        setTimeout(() => {
            if (document.body.contains(suggestionEl)) {
                suggestionEl.classList.add('opacity-0', 'translate-x-full');
                setTimeout(() => suggestionEl.remove(), 300);
            }
        }, 10000);
    }
}

/**
 * Show status message to user
 */
function showStatusMessage(message, type = 'info') {
    const statusMessage = document.getElementById('status-message');
    if (!statusMessage) return;
    
    // Set message and styling
    statusMessage.textContent = message;
    
    // Set appropriate styling based on message type
    switch (type) {
        case 'success':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-green-100 text-green-800';
            break;
        case 'error':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-red-100 text-red-800';
            break;
        case 'warning':
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-yellow-100 text-yellow-800';
            break;
        default:
            statusMessage.className = 'text-center my-4 p-3 rounded-md font-medium bg-blue-100 text-blue-800';
    }
    
    // Display the message
    statusMessage.style.display = 'block';
    
    // Hide after a few seconds
    setTimeout(() => {
        statusMessage.style.display = 'none';
    }, 4000);
}

/**
 * Load optimizer state from localStorage
 */
function loadOptimizerState() {
    try {
        // Load optimized parameters
        const optimizedParams = localStorage.getItem('optimizedParameters');
        if (optimizedParams) {
            parameterState.optimizedParameters = JSON.parse(optimizedParams);
        }
        
        // Load parameter history
        const paramHistory = localStorage.getItem('parameterHistory');
        if (paramHistory) {
            parameterState.parameterHistory = JSON.parse(paramHistory);
        }
        
        // Load performance metrics
        const perfMetrics = localStorage.getItem('performanceMetrics');
        if (perfMetrics) {
            parameterState.performanceMetrics = JSON.parse(perfMetrics);
        }
        
        // Load repetition avoidance
        const repetitionAvoidance = localStorage.getItem('repetitionAvoidance');
        if (repetitionAvoidance) {
            parameterState.repetitionAvoidance = JSON.parse(repetitionAvoidance);
        }
        
        // Load auto-optimize setting
        const autoOptimize = localStorage.getItem('autoOptimize');
        if (autoOptimize !== null) {
            parameterState.autoOptimize = autoOptimize === 'true';
            
            // Update UI toggle if available
            const autoOptimizeToggle = document.getElementById('auto-optimize-toggle');
            if (autoOptimizeToggle) {
                autoOptimizeToggle.checked = parameterState.autoOptimize;
            }
        }
        
        console.log('Parameter optimizer state loaded');
    } catch (error) {
        console.error('Error loading optimizer state:', error);
    }
}

/**
 * Save optimizer state to localStorage
 */
function saveOptimizerState() {
    try {
        // Save optimized parameters
        if (parameterState.optimizedParameters) {
            localStorage.setItem('optimizedParameters', JSON.stringify(parameterState.optimizedParameters));
        }
        
        // Save parameter history
        localStorage.setItem('parameterHistory', JSON.stringify(parameterState.parameterHistory));
        
        // Save performance metrics
        localStorage.setItem('performanceMetrics', JSON.stringify(parameterState.performanceMetrics));
        
        // Save repetition avoidance
        localStorage.setItem('repetitionAvoidance', JSON.stringify(parameterState.repetitionAvoidance));
        
        // Save auto-optimize setting
        localStorage.setItem('autoOptimize', parameterState.autoOptimize.toString());
    } catch (error) {
        console.error('Error saving optimizer state:', error);
    }
}

// Export public API
window.ParameterOptimizer = {
    optimize: optimizeParameters,
    applyOptimizedParameters,
    getOptimizedParameters: () => parameterState.optimizedParameters,
    getDiversityScore: () => parameterState.repetitionAvoidance.diversityScore,
    enableAutoOptimize: () => {
        parameterState.autoOptimize = true;
        saveOptimizerState();
        return true;
    },
    disableAutoOptimize: () => {
        parameterState.autoOptimize = false;
        saveOptimizerState();
        return true;
    },
    getRepetitionAvoidance: () => ({ ...parameterState.repetitionAvoidance }),
    resetState: () => {
        parameterState.optimizedParameters = null;
        parameterState.parameterHistory = [];
        parameterState.performanceMetrics = {};
        parameterState.repetitionAvoidance = {
            activeTopics: [],
            activeQuestionTypes: [],
            diversityScore: 0
        };
        saveOptimizerState();
        return true;
    }
}; 